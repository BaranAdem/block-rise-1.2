"""
Block Rise ses paketi v2 — "Sinestezi" (Tetris Effect'ten ilham)

Ortak dil
  • Tonalite: D majör pentatonik (D E F# A B). Her ses bu dizide; üst üste binen sesler asla çatışmaz.
    Oyun pop/zincir/övgü seslerini bu dizide basamak basamak tizleştirir, bu yüzden kök hep D'dir.
  • Paleti: FM kalimba ve cam çanları, sıcak supersaw pad'ler, formant "koro", sub-bas darbeleri,
    hava/nefes gürültüsü, oktav-üstü "shimmer" yankı ve stereo ping-pong delay.
  • Sık çalan sesler (sürükleme, yerleştirme) kısa, yumuşak ve küçük odada; nadir ödüller (zincir,
    bomba, kazanma) büyük salonda, uzun ışıltılı kuyruklarla.
"""
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

SR = 44100
rng = np.random.default_rng(2027)
PENTA = ['D', 'E', 'F#', 'A', 'B']


# ================================================================ temel araçlar
def N(note):                                   # 'D5' → Hz
    names = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5, 'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}
    n, o = note[:-1], int(note[-1])
    return 440 * 2 ** ((12 * (o + 1) + names[n] - 69) / 12)


def T(d): return np.arange(int(SR * d)) / SR
def lp(x, f, o=2): return sosfilt(butter(o, min(f, SR * .45), 'low', fs=SR, output='sos'), x, axis=0)
def hp(x, f, o=2): return sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x, axis=0)
def bp(x, a, b, o=2): return sosfilt(butter(o, [a, min(b, SR * .45)], 'band', fs=SR, output='sos'), x, axis=0)


def stereo(x):
    return x if x.ndim == 2 else np.stack([x, x], 1)


def pan(x, p=0.0):                             # -1 sol … +1 sağ, sabit güç
    a = (p + 1) * np.pi / 4
    return np.stack([x * np.cos(a), x * np.sin(a)], 1) * np.sqrt(2)


def buf(d): return np.zeros((int(SR * d), 2))


def at(b, x, t0, g=1.0):
    """Katmanı karışıma ekler. Her katmana 1.5 ms giriş ve sonda yumuşak çıkış uygulanır:
    sönmeden kesilen ya da rastgele fazla başlayan bir katman tık (klik) üretmesin."""
    x = stereo(x).copy(); i = int(SR * t0); n = min(len(x), len(b) - i)
    if n <= 0: return
    x = x[:n]; k = min(int(SR * .0015), n // 4)
    if k > 1: x[:k] *= np.linspace(0, 1, k)[:, None]
    f = max(16, min(int(n * .25), int(SR * .08)))
    if f < n: x[-f:] *= (np.cos(np.linspace(0, np.pi / 2, f)) ** 2)[:, None]
    b[i:i + n] += g * x


def env(tt, a, d):                             # yumuşak atak + üstel sönüm
    e = np.exp(-tt / d); k = int(SR * a)
    if k > 0: e[:k] *= np.sin(np.linspace(0, np.pi / 2, k)) ** 2
    return e


def swell(tt, a, r, dur):                      # yavaş açılıp kapanan zarf (pad)
    return np.minimum(1, tt / max(a, 1e-4)) ** 2 * np.clip((dur - tt) / max(r, 1e-4), 0, 1) ** 1.5


def fadeout(x, frac=.2):
    x = x.copy(); n = max(16, int(len(x) * frac))
    x[-n:] *= (np.cos(np.linspace(0, np.pi / 2, n)) ** 2)[:, None] if x.ndim == 2 else np.cos(np.linspace(0, np.pi / 2, n)) ** 2
    return x


# ---------------- zamanla değişen rezonanslı filtre (RBJ biquad, blok blok)
def _biquad(kind, f, q):
    w = 2 * np.pi * np.clip(f, 20, SR * .45) / SR; al = np.sin(w) / (2 * q); c = np.cos(w)
    if kind == 'lp': b = [(1 - c) / 2, 1 - c, (1 - c) / 2]
    else:            b = [al, 0, -al]                    # bp (sabit tepe kazancı)
    a = [1 + al, -2 * c, 1 - al]
    return np.array([[b[0] / a[0], b[1] / a[0], b[2] / a[0], 1, a[1] / a[0], a[2] / a[0]]])


def sweep(x, fc, q=.9, kind='lp', block=128):
    """fc: Hz dizisi (örnek başına) ya da sabit. Filtre durumu bloklar arasında korunur."""
    fc = np.broadcast_to(np.asarray(fc, float), (len(x),))
    out = np.empty_like(x); zi = np.zeros((1, 2) + x.shape[1:])
    for s in range(0, len(x), block):
        sos = _biquad(kind, fc[min(s + block // 2, len(x) - 1)], q)
        out[s:s + block], zi = sosfilt(sos, x[s:s + block], axis=0, zi=zi)
    return out


# ================================================================ kaynaklar
def saw(f, n):
    """Bant sınırlı testere (polyBLEP). f: Hz ya da örnek başına Hz dizisi."""
    dt = np.broadcast_to(np.asarray(f, float), (n,)) / SR
    ph = (np.cumsum(dt) + rng.random()) % 1.0
    y = 2 * ph - 1
    m = ph < dt; x = ph[m] / dt[m]; y[m] -= x + x - x * x - 1
    m = ph > 1 - dt; x = (ph[m] - 1) / dt[m]; y[m] -= x * x + x + x + 1
    return y


def supersaw(f, dur, voices=7, detune=.14, width=.9):
    """JP-8000 tarzı kalın, parlak pad kaynağı (stereo). Sesler sola/sağa yayılır."""
    n = int(SR * dur); out = np.zeros((n, 2))
    spread = np.linspace(-1, 1, voices)
    for k, s in enumerate(spread):
        g = 1.0 if abs(s) < 1e-6 else .62
        y = saw(f * (1 + s * detune * .011), n) * g
        out += pan(y, s * width)
    return out / voices


def fm(f, dur, ratio=1.0, index=1.5, idecay=.2, decay=.5, attack=.002, ph=None):
    tt = T(dur); I = index * np.exp(-tt / idecay)
    p0 = rng.uniform(0, 6.28) if ph is None else ph
    y = np.sin(2 * np.pi * f * tt + p0 + I * np.sin(2 * np.pi * f * ratio * tt))
    return y * env(tt, attack, decay)


def kalimba(f, dur=.5, decay=.22, bright=1.0):
    """Yumuşak FM tını: sürükleme / yerleştirme notaları. Çatlamayan, sıcak bir 'tık-ding'."""
    tt = T(dur)
    y = fm(f, dur, 1.0, 1.4 * bright, .025, decay, .0012)
    y += .22 * bright * fm(f * 5.43, dur, 1.0, .3, .01, decay * .12, .0005)   # metal dil (tine)
    y += .35 * np.sin(2 * np.pi * f * .5 * tt) * env(tt, .002, decay * .6)      # gövde
    y += .18 * bp(rng.standard_normal(len(tt)) * np.exp(-tt / .0025), f * .9, min(f * 6, 12000), 2)
    return y


def glass(f, dur=1.2, decay=.6, bright=.6, attack=.0015):
    """Cam / kristal çan: ışıltılı, uzun, hafif dalgalanan. Arpejler ve ödüller için."""
    tt = T(dur)
    y = fm(f, dur, 3.5, 1.2 * bright, .12, decay, attack)
    y += .6 * fm(f * 1.0015, dur, 1.0, .5 * bright, .3, decay * 1.2, attack)   # ikiz ton → yavaş dalgalanma
    y += .25 * bright * fm(f * 2, dur, 3.5, .8, .05, decay * .35, attack)
    return y * .55


def sub(f0, f1, dur, glide=.08, decay=.25, attack=.002, drive=1.0):
    """Sub-bas darbesi: yüksekten köke hızlı süzülen sinüs (Tetris Effect'in derin 'thoom'u)."""
    tt = T(dur); f = f1 + (f0 - f1) * np.exp(-tt / glide)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(tt, attack, decay)
    return np.tanh(y * drive) / np.tanh(drive)


def choir(notes, dur, a=.35, r=.8, vowel='a'):
    """Formant süzgeçli testere 'koro' pad'i (stereo)."""
    F = {'a': [(730, 1), (1090, .5), (2440, .22)], 'o': [(570, 1), (840, .45), (2410, .15)]}[vowel]
    tt = T(dur); out = np.zeros((len(tt), 2))
    for i, nt in enumerate(notes):
        vib = 1 + .004 * np.sin(2 * np.pi * (4.6 + .3 * i) * tt + rng.uniform(0, 6))
        for side in (-.7, .7):
            s = saw(N(nt) * vib * (1 + side * .003), len(tt))
            v = sum(g * bp(s, fq * .85, fq * 1.15, 2) for fq, g in F)
            out += pan(v, side)
    return out * swell(tt, a, r, dur)[:, None] / len(notes)


def noise(dur): return rng.standard_normal(int(SR * dur))


def riser(dur, f0=400, f1=9000, q=1.2, shape=2.0):
    """Yükselen hava süpürmesi (stereo)."""
    tt = T(dur); k = (tt / dur) ** shape
    fc = f0 * (f1 / f0) ** k
    out = np.stack([sweep(noise(dur), fc, q, 'bp'), sweep(noise(dur), fc * 1.07, q, 'bp')], 1)
    return out * (np.sin(np.pi / 2 * np.minimum(1, tt / dur)) ** 2)[:, None]


def burst(dur, f0=8000, f1=600, decay=.15, q=.7):
    """Patlama nefesi: parlak başlayıp kararan gürültü (stereo)."""
    tt = T(dur); fc = f1 + (f0 - f1) * np.exp(-tt / (decay * .8))
    out = np.stack([sweep(noise(dur), fc, q), sweep(noise(dur), fc, q)], 1)
    return out * env(tt, .001, decay)[:, None]


def pad(notes, dur, a=.2, r=.8, cut0=400, cut1=3500, cut_t=.25, q=1.2, detune=.14):
    """Filtresi açılıp kapanan supersaw akor pad'i (stereo)."""
    tt = T(dur); out = np.zeros((len(tt), 2))
    for nt in notes: out += supersaw(N(nt), dur, detune=detune)
    fc = cut0 + (cut1 - cut0) * np.minimum(1, tt / max(cut_t, 1e-3)) ** .7 * np.exp(-np.maximum(0, tt - cut_t) / max(dur * .5, .05))
    out = sweep(out, fc, q)
    return out * swell(tt, a, r, dur)[:, None] / np.sqrt(len(notes))


def stab(notes, dur, decay=.35, cut0=6000, cut1=500, q=1.6):
    """Kısa 'pluck' akor: filtresi hızla kapanan supersaw (Tetris Effect satır silme vuruşu)."""
    tt = T(dur); out = np.zeros((len(tt), 2))
    for nt in notes: out += supersaw(N(nt), dur, detune=.18)
    fc = cut1 + (cut0 - cut1) * np.exp(-tt / (decay * .45))
    return sweep(out, fc, q) * env(tt, .003, decay)[:, None] / np.sqrt(len(notes))


def arp(b, notes, t0, step, maker, g0=.5, gstep=0., pans=None):
    for k, nt in enumerate(notes):
        p = pans[k % len(pans)] if pans else (-.6 if k % 2 else .6)
        at(b, pan(maker(N(nt)), p), t0 + k * step, g0 + gstep * k)


def sparkles(b, n, t0, spread, lo=6, hi=7, amp=.08, decay=.25):
    for _ in range(n):
        f = N(rng.choice(PENTA) + str(rng.integers(lo, hi + 1)))
        at(b, pan(glass(f, .6, decay * rng.uniform(.6, 1.3), .3), rng.uniform(-.9, .9)),
           t0 + rng.uniform(0, spread), amp * rng.uniform(.4, 1))


# ================================================================ uzay: yankı, shimmer, delay
def make_ir(length, taus, pre=.018, seed=1):
    r_ = np.random.default_rng(seed); tt = T(length); ir = np.zeros((len(tt), 2))
    for ch in range(2):
        n = r_.standard_normal(len(tt))
        x = lp(n, 600) * np.exp(-tt / taus[0]) + .8 * bp(n, 600, 4000) * np.exp(-tt / taus[1]) \
            + .4 * hp(n, 4000) * np.exp(-tt / taus[2])
        x *= np.minimum(1, tt / .03) ** 1.5                     # yumuşak, yoğun başlangıç
        x[:int(SR * pre)] = 0
        ir[:, ch] = x / np.sqrt((x ** 2).sum())
    return ir


HALL = make_ir(3.4, (.62, .52, .26), .022, 11)                   # geniş, ışıltılı salon
ROOM = make_ir(.9, (.16, .13, .07), .008, 12)                    # sık çalan sesler için küçük oda


def octave_up(x):                                               # basit oktav üstü (shimmer için)
    m = x.mean(1) if x.ndim == 2 else x
    i = np.arange(0, len(m) - 1, 2.0)
    return np.interp(i, np.arange(len(m)), m)


def verb(x, ir, wet):
    x = stereo(x); m = x.mean(1)
    w = np.stack([fftconvolve(m, ir[:, 0]), fftconvolve(m, ir[:, 1])], 1)
    out = np.zeros((len(w), 2)); out[:len(x)] = x
    return out + wet * w


def shimmer(x, amount):
    """Oktav üstü kopyayı salona göndererek kuyruğa 'kristal' bir parıltı ekler."""
    up = hp(octave_up(x), 900)
    w = np.stack([fftconvolve(up, HALL[:, 0]), fftconvolve(up, HALL[:, 1])], 1)
    x = stereo(x); out = np.zeros((max(len(x), len(w)), 2)); out[:len(x)] = x
    out[:len(w)] += amount * w
    return out


def pingpong(x, t=.19, fb=.42, n=6, lpf=4200, wet=.3):
    x = stereo(x); m = x.mean(1); L = len(m) + int(SR * t * (n + 1))
    out = np.zeros((L, 2)); out[:len(x)] = x; sig = m
    for k in range(1, n + 1):
        sig = lp(sig, lpf) * fb
        i = int(SR * t * k); out[i:i + len(sig), k % 2] += wet * sig
    return out


def space(x, hall=0., room=0., shim=0., delay=None):
    y = stereo(x)
    if delay: y = pingpong(y, *delay)
    if shim: y = shimmer(y, shim)
    if room: y = verb(y, ROOM, room)
    if hall: y = verb(y, HALL, hall)
    return y


# ================================================================ bitiş: yükseklik, sınırlayıcı, kırpma
def kweight(x):
    y = hp(x, 100); return y + .58 * hp(y, 1500)


def loudness(st):                                # en yüksek 50 ms penceresinin RMS'i (dB)
    m = kweight(st.mean(1)); w = int(SR * .05)
    if len(m) < w: m = np.pad(m, (0, w - len(m)))
    p = np.convolve(m ** 2, np.ones(w) / w, 'valid')
    return 10 * np.log10(p.max() + 1e-12)


def master(st, target_db, maxlen, lpf=15000, tail_db=-58):
    st = hp(stereo(st), 32, 2); st = lp(st, lpf, 2)
    st *= 10 ** ((target_db - loudness(st)) / 20)
    ceil = 10 ** (-1 / 20); k = ceil * .75
    over = np.abs(st) > k                         # yumuşak sınırlayıcı
    st[over] = np.sign(st[over]) * (k + (ceil - k) * np.tanh((np.abs(st[over]) - k) / (ceil - k)))
    e = np.abs(st).max(1); thr = e.max() * 10 ** (tail_db / 20)
    end = len(e) - np.argmax(e[::-1] > thr)
    end = min(len(st), end + int(SR * .02), int(SR * maxlen))
    st = st[:end].copy()
    f = min(int(SR * .4), max(int(SR * .02), len(st) // 5))
    st[-f:] *= (np.cos(np.linspace(0, np.pi / 2, f)) ** 2)[:, None]
    st[:24] *= np.linspace(0, 1, 24)[:, None]
    return st


def save(name, st, folder='.'):
    wavfile.write(f'{folder}/{name}.wav', SR, np.clip(np.round(st * 32767), -32768, 32767).astype(np.int16))
    return name, len(st) / SR, loudness(st), 20 * np.log10(np.abs(st).max())
