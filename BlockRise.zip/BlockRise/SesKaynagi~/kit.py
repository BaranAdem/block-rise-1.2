"""
Block Rise ses paketi — "Yıldız Tozu & ASMR"
Ortak dil: D majör pentatonik (D E F# A B), cam/kristal çan tonları, keçe+tahta dokunuşlar,
ortak sentetik 'gece gökyüzü' yankısı, ortak sınırlayıcı ve ses yüksekliği hedefleri.
"""
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile
SR = 44100
rng = np.random.default_rng(2026)

def N(note):                      # 'D5' → Hz
    names = {'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}
    n, o = note[:-1], int(note[-1]); midi = 12*(o+1) + names[n]
    return 440*2**((midi-69)/12)

def T(d): return np.arange(int(SR*d))/SR
def lp(x,f,o=2): return sosfilt(butter(o,f,'low',fs=SR,output='sos'),x,axis=0)
def hp(x,f,o=2): return sosfilt(butter(o,f,'high',fs=SR,output='sos'),x,axis=0)
def bp(x,a,b,o=2): return sosfilt(butter(o,[a,b],'band',fs=SR,output='sos'),x,axis=0)
def pad(x,n): return np.pad(x,(0,max(0,n-len(x))))[:n]
def at(buf, x, t0, g=1.0):
    i = int(SR*t0); n = min(len(x), len(buf)-i)
    if n > 0: buf[i:i+n] += g*x[:n]

def tailfade(y, frac=.25):
    n = max(16, int(len(y)*frac)); y = y.copy(); y[-n:] *= np.cos(np.linspace(0, np.pi/2, n))**2
    return y

def env(tt, a, d):                # yumuşak atak + üstel sönüm
    e = np.exp(-tt/d); k = int(SR*a)
    if k > 0: e[:k] *= np.sin(np.linspace(0, np.pi/2, k))**2
    return e

# ---------------- kaynaklar
def bell(f, dur=1.2, decay=0.45, bright=0.5, attack=0.002, shimmer=0.0015):
    """Kristal/yıldız çanı: harmonik ağırlıklı, üst kısmiler hızlı söner, ikiz ton hafif dalgalanır."""
    tt = T(dur); y = np.zeros_like(tt)
    parts = [(1,1,1),(2.0,.38*bright,.55),(3.0,.14*bright,.33),(4.17,.07*bright,.2),(5.43,.03*bright,.12)]
    for r,a,dk in parts:
        fr = f*r
        if fr > 15000: continue
        y += a*np.sin(2*np.pi*fr*tt + rng.uniform(0,6.28))*env(tt, attack, decay*dk)
    y += .35*np.sin(2*np.pi*f*(1+shimmer)*tt)*env(tt, attack*2, decay*.9)   # yavaş dalgalanma (canlılık)
    y += .25*bp(rng.standard_normal(len(tt))*np.exp(-tt/.003), f*.8, min(f*3,9000), 3)  # tokmak teması
    return tailfade(y)

def wood(f, dur=.2, decay=.04, ratios=(1,2.31,3.87), amps=(1,.35,.12), body=None, tap=.5, tapband=(500,3000)):
    tt = T(dur); y = np.zeros_like(tt)
    for i,(r,a) in enumerate(zip(ratios,amps)):
        y += a*np.sin(2*np.pi*f*r*(1+rng.uniform(-.003,.003))*tt+rng.uniform(0,.3))*env(tt,.0008,decay/(1+i*.9))
    if body: y += .6*np.sin(2*np.pi*body*tt)*env(tt,.0015,decay*1.3)
    y += tap*bp(rng.standard_normal(len(tt))*np.exp(-tt/.0025), *tapband, 3)
    return tailfade(y)

def droplet(f0, f1, dur=.12, decay=.03):
    """Su damlası / baloncuk 'plip' — yukarı süzülen perde."""
    tt = T(dur); f = f0*(f1/f0)**np.minimum(1, tt/.03)
    ph = 2*np.pi*np.cumsum(f)/SR
    return tailfade(np.sin(ph)*env(tt, .001, decay))

def dust(dur, n, notes, oct_lo=6, oct_hi=7, start=0.0, spread=None, amp=.12, decay=.09):
    """Yıldız tozu: pentatonik notalarda küçük parıltılar."""
    buf = np.zeros(int(SR*dur)); spread = spread or dur*.7
    for _ in range(n):
        f = N(rng.choice(notes)+str(rng.integers(oct_lo, oct_hi+1)))
        g = bell(f, .35, decay*rng.uniform(.6,1.3), bright=.25, attack=.0015)
        at(buf, g, start + rng.uniform(0, spread), amp*rng.uniform(.4,1))
    return buf

def air(dur, lo, hi, a, d):
    tt = T(dur); return tailfade(bp(rng.standard_normal(len(tt)), lo, hi, 3)*env(tt, a, d))

def pad_chord(notes, dur, attack=.25, release=.6, det=.003):
    tt = T(dur); y = np.zeros_like(tt)
    e = np.minimum(1, tt/attack)**2 * np.minimum(1, np.maximum(0, (dur-tt)/release))
    for n in notes:
        f = N(n)
        for d in (-det, det):
            y += np.sin(2*np.pi*f*(1+d)*tt + rng.uniform(0,6.28)) + .18*np.sin(2*np.pi*2*f*(1+d)*tt)
    return lp(y*e, 2500)

# ---------------- ortak uzay: gece gökyüzü yankısı (stereo)
def make_ir(length=2.4):
    tt = T(length); ir = np.zeros((len(tt),2))
    for ch in range(2):
        n = rng.standard_normal(len(tt))
        lo = lp(n,500)*np.exp(-tt/.62); mid = bp(n,500,3500)*np.exp(-tt/.48); hi = hp(n,3500)*np.exp(-tt/.22)
        r = lo + .8*mid + .45*hi
        r[:int(SR*.014)] = 0                                        # ön gecikme
        for tap in (.019,.027,.041,.053):                           # erken yansımalar
            r[int(SR*(tap+ch*.003))] += .5*rng.uniform(.5,1)
        ir[:,ch] = r/np.sqrt((r**2).sum())
    return ir
IR = make_ir()

def space(x, wet, width=1.0):
    dry = np.stack([x,x],1)
    if wet <= 0: return dry
    w = np.stack([fftconvolve(x, IR[:,0]), fftconvolve(x, IR[:,1])],1)[:len(x)+int(SR*1.6)]
    mid = (w[:,0]+w[:,1])/2; side = (w[:,0]-w[:,1])/2*width
    w = np.stack([mid+side, mid-side],1)
    out = np.zeros((len(w),2)); out[:len(x)] = dry
    return out + wet*w

# ---------------- ortak bitiş: ses yüksekliği + sınırlayıcı
def kweight(x):
    y = hp(x,100); return y + .58*hp(y,1500)

def loudness(st):                                # en yüksek 50 ms penceresinin RMS'i (dBFS)
    m = kweight(st.mean(1)); w = int(SR*.05)
    if len(m) < w: m = pad(m, w)
    p = np.convolve(m**2, np.ones(w)/w, 'valid')
    return 10*np.log10(p.max()+1e-12)

def master(st, target_db, lpf=11000, tail_db=-50, maxlen=None):
    st = hp(st, 38, 2); st = lp(st, lpf, 4)
    st *= 10**((target_db - loudness(st))/20)
    pk = np.abs(st).max(); ceil = 10**(-1/20)
    if pk > ceil * .8:                            # yumuşak sınırlayıcı (tanh dizi)
        k = ceil*.8; over = np.abs(st) > k
        st[over] = np.sign(st[over])*(k + (ceil-k)*np.tanh((np.abs(st[over])-k)/(ceil-k)))
    st[:16] *= np.linspace(0,1,16)[:,None]
    return st

LENS = {'asmr_tick':(.12,-42),'asmr_pick':(.2,-42),'asmr_place':(.5,-46),'asmr_land':(.36,-44),'UI3':(.32,-44),
        'pop':(.75,-48),'chain':(1.4,-50),'UI2':(1.3,-50),'bomb':(1.9,-52),'bolt':(1.6,-50),'rise':(.7,-46),
        'win':(3.2,-54),'perfect':(2.8,-54),'medal':(1.8,-52),'lose':(2.8,-54)}
def trim(name, st):
    key = max((k for k in LENS if name.startswith(k)), key=len)
    maxlen, tail_db = LENS[key]
    e = np.abs(st).max(1); thr = e.max()*10**(tail_db/20)
    end = len(e) - np.argmax(e[::-1] > thr)
    end = min(len(st), end + int(SR*.02), int(SR*maxlen))
    st = st[:end].copy()
    f = min(int(SR*.35), max(int(SR*.015), len(st)//5)); st[-f:] *= np.linspace(1,0,f)[:,None]**2
    return st

def save(name, st):
    st = trim(name, st)
    wavfile.write(name+'.wav', SR, np.clip(st*32767, -32768, 32767).astype(np.int16))
    return name, len(st)/SR, loudness(st), 20*np.log10(np.abs(st).max())
