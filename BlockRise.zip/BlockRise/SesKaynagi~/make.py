from kit import *
PENTA = ['D','E','F#','A','B']
out = []

# ======================= DOKUNSAL (ASMR) =======================
# Sürükleme tıkı — keçe üstünde tahta boncuk, ana titreşim pentatonik notada
for i, n in enumerate(['D6','E6','F#6','A5'], 1):
    y = wood(N(n), .09, .016, body=N(n)*.25, tap=.45, tapband=(900,3200))
    out.append(save(f'asmr_tick{i}', master(space(y,.04), -19, lpf=5000)))

# Tutma — boğuk kavrama + kumaş
y = wood(N('A4'), .16, .024, ratios=(1,2.4), amps=(1,.25), body=N('D3'), tap=.3, tapband=(400,2200))
y += pad(.12*air(.08, 700, 2600, .006, .025), len(y))
out.append(save('asmr_pick', master(space(y,.05), -19, lpf=4200)))

# Yerleştirme — yastıklı masaya tahta blok + mini sekme + uzakta minik yıldız parıltısı
for i, (b, m) in enumerate([('D3','D5'),('E3','A4'),('A2','F#4')], 1):
    def hit(g):
        y = wood(N(m)*.92, .3, .032, ratios=(1,2.05,3.6), amps=(.45,.16,.05), body=N(b), tap=.5, tapband=(250,2400))
        tt = T(.3); y += np.sin(2*np.pi*N(b)*1.52*tt)*env(tt,.002,.03)*.25
        return y*g
    y = hit(1.0); d = rng.uniform(.026,.034); at(y, hit(.17), d)
    tw = np.zeros(int(SR*.6)); at(tw, y, 0)
    at(tw, bell(N(rng.choice(['D','A','F#'])+'7'), .4, .08, bright=.1), .045, .02)
    out.append(save(f'asmr_place{i}', master(space(tw,.08), -18, lpf=6000)))

# Düşüp oturma — kuma yerleşen çakıl
for i, b in enumerate(['A2','B2','D3'], 1):
    tt = T(.26); y = np.zeros_like(tt)
    y += wood(N(b)*2.9, .26, .02, ratios=(1,2.2), amps=(.3,.08), body=N(b), tap=.4, tapband=(200,1800))
    g = np.zeros_like(tt)
    for _ in range(9):
        p = int(SR*rng.uniform(.004,.07)); L = int(SR*.006)
        g[p:p+L] += rng.standard_normal(L)*np.hanning(L)*rng.uniform(.3,1)
    y += .2*bp(g, 700, 2500, 4)
    out.append(save(f'asmr_land{i}', master(space(y,.06), -19, lpf=4000)))

# ======================= ARAYÜZ =======================
# Düğme — cam + tahta, kuru ve temiz
y = pad(wood(N('A5'), .12, .018, body=N('D4'), tap=.25, tapband=(1200,4000)), int(SR*.3))
y += pad(.35*bell(N('A6'), .3, .08, bright=.2), len(y))
out.append(save('UI3', master(space(y,.07), -22, lpf=8000)))

# ======================= PATLAMA (zincir perdesiyle D pentatonikte yükselir) =======================
def star_pop(root, drop0, drop1, bright, wet):
    buf = np.zeros(int(SR*.6))
    at(buf, droplet(drop0, drop1, .12, .028), 0, .9)                 # organik 'plip'
    at(buf, bell(N(root), .55, .22, bright=bright), .006, .55)       # yıldız çanı
    at(buf, bell(N(root)*2, .3, .07, bright=.2), .008, .12)
    at(buf, .08*air(.06, 2000, 7000, .001, .012), 0)                 # kabarcık patlama nefesi
    return master(space(buf, wet, .8), -17, lpf=10000)
out.append(save('pop',  star_pop('D5', 380, 950, .55, .12)))
out.append(save('pop2', star_pop('A4', 320, 820, .45, .14)))

# Zincir — hızlı yükselen kristal arpej + toz
buf = np.zeros(int(SR*1.0))
for k, n in enumerate(['D5','F#5','A5','D6']):
    at(buf, bell(N(n), .7, .3, bright=.45), k*.038, .55 + .1*k)
buf += dust(1.0, 7, PENTA, 6, 7, start=.08, spread=.3, amp=.1)
out.append(save('chain', master(space(buf, .28, 1.0), -18)))

# Övgü — iki notalı göz kırpan yıldız
buf = np.zeros(int(SR*1.0))
at(buf, bell(N('A5'), .7, .3, bright=.4), 0, .7)
at(buf, bell(N('D6'), .8, .36, bright=.4), .07, .8)
buf += dust(1.0, 5, PENTA, 7, 7, start=.1, spread=.25, amp=.07)
out.append(save('UI2', master(space(buf, .32, 1.0), -19)))

# ======================= ÖZEL BLOKLAR =======================
# Bomba (renk novası) — yumuşak derin nabız, açılan nefes, parlayan akor
buf = np.zeros(int(SR*1.4)); tt = T(.5)
f = 95*(48/95)**np.minimum(1, tt/.12)
at(buf, np.sin(2*np.pi*np.cumsum(f)/SR)*env(tt,.003,.16), 0, 1.0)          # derin nabız
at(buf, wood(N('D3')*2.1, .3, .05, ratios=(1,1.5), amps=(1,.4), body=N('D3'), tap=.6, tapband=(150,1500)), 0, .7)
w = rng.standard_normal(int(SR*.7)); tt = T(.7)
cut = 600 + 3800*np.exp(-((tt-.06)/.12)**2)                                  # açılıp kapanan filtre (segmentli)
sw = np.zeros_like(w)
for s in range(0, len(w), 512):
    sw[s:s+512] = bp(w[max(0,s-2048):s+512], 150, min(cut[s], 9000))[-len(w[s:s+512]):]
at(buf, sw*env(tt,.01,.16), 0, .35)
for k, n in enumerate(['D4','A4','D5','F#5','A5']):
    at(buf, bell(N(n), 1.0, .5, bright=.35, attack=.006), .03 + k*.012, .3)
buf += dust(1.4, 10, PENTA, 6, 7, start=.08, spread=.5, amp=.08)
out.append(save('bomb', master(space(buf, .38, 1.0), -16, lpf=9000)))

# Şimşek (kayan yıldız) — yükselen parıltı glisandosu + süzülen nefes
buf = np.zeros(int(SR*1.2))
seq = [n+str(o) for o in (5,6,7) for n in PENTA][:13]
for k, n in enumerate(seq):
    at(buf, bell(N(n), .45, .14, bright=.3, attack=.001), k*.022, .32 + .02*k)
tt = T(.5); w = rng.standard_normal(len(tt)); sw = np.zeros_like(w)
for s in range(0, len(w), 512):
    c = 1000 + 3800*min(1, s/len(w)*1.6)
    sw[s:s+512] = bp(w[max(0,s-2048):s+512], c*.6, min(c*1.4, 12000))[-len(w[s:s+512]):]
at(buf, lp(sw,7000,4)*np.sin(np.pi*np.minimum(1,tt/.5))**2, 0, .09)
at(buf, wood(N('D4'), .2, .03, body=N('D3'), tap=.4), 0, .5)                    # başlangıç dokunuşu
buf += dust(1.2, 8, PENTA, 7, 7, start=.28, spread=.35, amp=.07)
out.append(save('bolt', master(space(buf, .34, 1.0), -18, lpf=8500)))

# ======================= DUVAR YÜKSELİŞİ =======================
# Sık çalar: sakin — keçe kayması nefesi + alçak ton + yumuşak oturma
buf = np.zeros(int(SR*.6)); tt = T(.26)
at(buf, bp(rng.standard_normal(len(tt)), 220, 1400)*np.sin(np.pi*tt/.26)**2, 0, .22)
at(buf, (np.sin(2*np.pi*N('D3')*tt)+.4*np.sin(2*np.pi*N('A3')*tt))*np.sin(np.pi*tt/.26)**2*.5, 0, .5)
at(buf, wood(N('A3')*2.4, .25, .035, ratios=(1,2.2), amps=(.5,.12), body=N('D3'), tap=.35, tapband=(200,1600)), .17, .9)
out.append(save('rise', master(space(buf, .1), -21, lpf=6000)))

# ======================= KAZANMA / KAYBETME =======================
# Kazanma — sıcak pad üstünde iki oktav yükselen takımyıldız arpeji
L = 2.6; buf = np.zeros(int(SR*L))
buf += pad(pad_chord(['D3','A3','D4','F#4'], 2.2, .35, 1.0)*.07, len(buf))
for k, n in enumerate(['D5','F#5','A5','D6','F#6','A6','D7']):
    at(buf, bell(N(n), 1.6, .6, bright=.45), .02 + k*.085, .45 + .04*k)
at(buf, bell(N('A5'), 1.8, .8, bright=.4), .7, .35)
at(buf, bell(N('D6'), 1.8, .8, bright=.4), .7, .35)
buf += dust(L, 18, PENTA, 6, 7, start=.25, spread=1.3, amp=.08)
out.append(save('win', master(space(buf, .4, 1.0), -17)))

# Kusursuz temizlik — tüm pentatoniği tarayan parıltı + açık akor
L = 2.2; buf = np.zeros(int(SR*L))
seq = [n+str(o) for o in (5,6) for n in PENTA] + ['D7']
for k, n in enumerate(seq):
    at(buf, bell(N(n), 1.2, .45, bright=.4), k*.045, .35 + .03*k)
for n in ['D5','A5','F#6']: at(buf, bell(N(n), 1.7, .75, bright=.35), .52, .3)
buf += pad(pad_chord(['D4','A4','E5'], 1.6, .2, .9)*.05, len(buf))
buf += dust(L, 16, PENTA, 7, 7, start=.4, spread=1.0, amp=.07)
out.append(save('perfect', master(space(buf, .42, 1.0), -17)))

# Madalya — kısa, zarif üç nota
buf = np.zeros(int(SR*1.4))
for k, n in enumerate(['A5','D6','F#6']): at(buf, bell(N(n), 1.1, .45, bright=.4), k*.07, .6)
buf += dust(1.4, 6, PENTA, 7, 7, start=.2, spread=.4, amp=.06)
out.append(save('medal', master(space(buf, .35, 1.0), -20)))

# Kaybetme — sönen yıldız: yavaş inen çanlar, kapanan filtre, cezalandırmayan
L = 2.2; buf = np.zeros(int(SR*L))
for k, n in enumerate(['A5','F#5','D5','A4']):
    at(buf, bell(N(n), 1.3, .55 - .05*k, bright=.3 - .05*k, attack=.004), k*.16, .5 - .06*k)
buf += pad(pad_chord(['D3','A3','B3'], 1.9, .3, 1.1)*.06, len(buf))
tt = T(L); buf = buf*(.55 + .45*np.exp(-tt/.7))
st = space(buf, .38, .9); n = len(st)
fade = 9000*np.exp(-np.arange(n)/SR/.5) + 900
out_ = np.zeros_like(st)
for s in range(0, n, 1024):
    seg = st[max(0,s-4096):s+1024]
    out_[s:s+1024] = lp(seg, fade[s], 2)[-len(st[s:s+1024]):]
out.append(save('lose', master(out_, -20)))

for name, d, l, p in out: print(f'{name:12s} {d:5.2f}s  loud {l:6.1f} dB  peak {p:5.1f} dB')
