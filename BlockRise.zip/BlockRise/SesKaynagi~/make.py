"""
Block Rise ses paketi v2 — "Sinestezi" (Tetris Effect'ten ilham). Çalıştır:
    python make.py [çıktı_klasörü]      (varsayılan: ../Resources/BlockRiseSounds)
Dosya adları oyunun beklediği adlarla aynıdır; çıktıyı doğrudan Resources'a yazar.

Tasarım ilkeleri
  • Her hareket bir nota: sürükleme tıkları köke (D5) akortludur; oyun her hücre kaydırmasında
    pentatonik dizide bir basamak yukarı/aşağı çalar → blok kaydırmak küçük bir melodi çizer.
  • Yerleştirme = derin 'thoom' (sub-bas süzülmesi) + yumuşak FM akoru. Ekranda ağırlık hissi.
  • Patlama = filtresi kapanan supersaw vuruşu + cam çanı + hava nefesi + shimmer salon. Zincirde
    oyun bunu dizide tizleştirir, yükselen arpej katmanı eklenir.
  • Ödüller (bomba, şimşek, kusursuz, kazanma) büyük salonda, koro ve ışıltı kuyruklarıyla.
  • Ses yükseklikleri v1 ile aynı hedeflerde → oyundaki ses dengesi (GameSettings) bozulmaz.
"""
import os, sys
from kit import *

OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'Resources', 'BlockRiseSounds')
out = []
def put(name, st): out.append(save(name, st, OUT))
DLY = (.1875, .4, 5, 3800, .22)          # ortak ping-pong (120 BPM noktalı on altılık)

# ======================= DOKUNSAL =======================
# Sürükleme tıkı — hepsi D5'e akortlu (oyun dizide kaydırır). 4 hafif tını varyasyonu: aynı ses makine gibi tekrarlamasın.
for i, (br, dk) in enumerate([(1.0, .16), (.85, .18), (1.15, .14), (.95, .2)], 1):
    b = buf(.5)
    at(b, pan(kalimba(N('D5'), .4, dk, br), (-.25, .2, -.1, .3)[i - 1]), 0)
    at(b, pan(glass(N('D6'), .3, .06, .2), .0), .002, .12)                    # üstte minik cam ışıltısı
    put(f'asmr_tick{i}', master(space(b, room=.35, delay=(.1875, .25, 2, 3000, .18)), -20, .45))

# Tutma — blok kalkar: yukarı süzülen yumuşak ton + nefes
b = buf(.6); tt = T(.25)
f = N('A4') + (N('D5') - N('A4')) * (1 - np.exp(-tt / .03))
at(b, np.sin(2 * np.pi * np.cumsum(f) / SR) * env(tt, .004, .07), 0, .8)
at(b, pan(kalimba(N('D6'), .3, .08, .6), .2), .012, .35)
at(b, riser(.14, 900, 5000, 1.0, 1.5) * np.linspace(1, 0, int(SR * .14))[:, None] ** 2, 0, .12)
put('asmr_pick', master(space(b, room=.4, hall=.06), -20, .5))

# Yerleştirme — derin thoom + FM akor (3 voicing, hepsi D üzerinde)
for i, voicing in enumerate([('D4', 'A4', 'F#5'), ('D4', 'A4', 'E5'), ('D4', 'B4', 'F#5')], 1):
    b = buf(1.2)
    at(b, sub(N('A2'), N('D2'), .5, .035, .16, drive=1.6), 0, .9)
    for k, nt in enumerate(voicing):
        at(b, pan(kalimba(N(nt), .9, .32 - .05 * k, .8), (-.35, .35, 0)[k]), .004 + .006 * k, .42)
    at(b, burst(.12, 3500, 300, .025), 0, .25)                               # keçe teması
    at(b, pan(glass(N(voicing[-1]) * 2, .8, .25, .3), .4), .03, .08)
    put(f'asmr_place{i}', master(space(b, room=.3, hall=.1, delay=(.1875, .3, 2, 2500, .14)), -18, .9))

# Oturma — patlamadan sonra düşen bloklar yerine oturur: yumuşak, alçak, kısa
for i, root in enumerate(['D3', 'A2', 'F#3'], 1):
    b = buf(.8)
    at(b, sub(N(root) * 1.5, N(root), .35, .025, .1, drive=1.3), 0, .7)
    at(b, kalimba(N(root) * 2, .5, .14, .6), .003, .45)
    at(b, burst(.08, 2500, 250, .018), 0, .2)
    put(f'asmr_land{i}', master(space(b, room=.3, hall=.05), -20, .6))

# ======================= ARAYÜZ =======================
# Düğme — temiz cam 'tink'
b = buf(.7)
at(b, pan(glass(N('A5'), .6, .14, .5), -.15), 0, .8)
at(b, pan(kalimba(N('D6'), .4, .06, .7), .15), .018, .35)
put('UI3', master(space(b, room=.3, hall=.08), -22, .55))

# Övgü (Nice!/Great!…; oyun dizide tizleştirir) — iki notalı ışıltı + kısa koro nefesi
b = buf(2.0)
at(b, pan(glass(N('A5'), 1.4, .45, .6), -.4), 0, .7)
at(b, pan(glass(N('D6'), 1.5, .55, .6), .4), .075, .8)
at(b, choir(['D5', 'A5'], 1.0, .06, .7), 0, .35)
sparkles(b, 6, .12, .35, 6, 7, .06)
put('UI2', master(space(b, hall=.32, shim=.12, delay=DLY), -19, 1.9))

# ======================= PATLAMA =======================
def pop_sound(voicing, bell_notes, seed_pan):
    b = buf(2.0)
    at(b, stab(voicing, 1.2, .3, 7000, 450, 1.8), 0, .9)                      # supersaw vuruşu
    at(b, sub(N('D3'), N('D2'), .5, .03, .2, drive=1.4), 0, .55)              # alt gövde
    for k, nt in enumerate(bell_notes):
        at(b, pan(glass(N(nt), 1.4, .5, .55), seed_pan * (1 if k % 2 else -1)), .004 + k * .022, .5 - .1 * k)
    at(b, burst(.4, 11000, 1200, .09, .6), 0, .28)                           # hava patlaması
    return master(space(b, hall=.3, shim=.18, delay=DLY), -17, 1.5)

put('pop',  pop_sound(['D4', 'A4', 'D5', 'F#5'], ['D6', 'A6'], .5))
put('pop2', pop_sound(['D4', 'A4', 'E5', 'F#5'], ['A5', 'D6', 'F#6'], .4))

# Zincir — pop'un üstüne binen, yükselen kristal arpej + süpürme (oyun dizide tizleştirir)
b = buf(2.2)
arp(b, ['D5', 'F#5', 'A5', 'D6', 'E6', 'A6'], 0, .042, lambda f: glass(f, 1.1, .4, .6), .42, .03)
at(b, riser(.3, 600, 10000, 1.3, 1.4), 0, .1)
at(b, pad(['D5', 'A5', 'E6'], 1.0, .03, .7, 800, 6000, .08), 0, .25)
sparkles(b, 8, .2, .5, 6, 7, .06)
put('chain', master(space(b, hall=.36, shim=.25, delay=DLY), -18, 1.8))

# ======================= ÖZEL BLOKLAR =======================
# Bomba — "Zone" anı: derin sub düşüşü, kararan gürültü patlaması, açılan dev akor, ışıltı yağmuru
b = buf(3.0)
at(b, sub(N('D3'), N('D1') * 1.0, 1.2, .18, .45, drive=2.2), 0, 1.0)
at(b, burst(1.1, 14000, 180, .35, .8), 0, .55)
at(b, stab(['D3', 'A3', 'D4', 'F#4', 'A4', 'E5'], 1.6, .55, 8000, 300, 1.4), 0, .7)
at(b, pad(['D4', 'A4', 'E5', 'F#5'], 2.2, .25, 1.4, 500, 4500, .5), .05, .35)
at(b, choir(['D4', 'A4', 'F#5'], 2.0, .3, 1.2, 'o'), .1, .28)
arp(b, ['A6', 'F#6', 'D6', 'B5', 'A5', 'F#5'], .08, .05, lambda f: glass(f, 1.0, .35, .5), .3, -.02)
sparkles(b, 14, .15, .9, 6, 7, .07)
put('bomb', master(space(b, hall=.42, shim=.2, delay=DLY), -16, 2.6, lpf=13000))

# Şimşek — elektrik 'zap' + üç oktav yukarı koşan pentatonik glissando + yükselen süpürme
b = buf(2.6); tt = T(.12)
f = 300 + 4200 * np.exp(-tt / .018)
zap = np.sin(2 * np.pi * np.cumsum(f) / SR + 2.5 * np.sin(2 * np.pi * np.cumsum(f * 2.01) / SR)) * env(tt, .001, .04)
at(b, zap, 0, .5)
at(b, burst(.15, 12000, 3000, .03, 1.2), 0, .35)
seq = [n + str(o) for o in (5, 6, 7) for n in PENTA][:14]
arp(b, seq, .02, .028, lambda f: glass(f, .7, .2, .55), .28, .012, [-.8, -.4, 0, .4, .8, .4, 0, -.4])
at(b, riser(.45, 500, 12000, 1.6, 1.2), 0, .14)
at(b, pad(['D5', 'A5', 'E6'], 1.4, .25, .9, 1500, 7000, .35), .3, .22)
sparkles(b, 8, .4, .5, 7, 7, .06)
put('bolt', master(space(b, hall=.36, shim=.22, delay=DLY), -18, 2.2))

# ======================= DUVAR YÜKSELİŞİ =======================
# Sık çalar: sakin — alçak beşli pad nefesi, açılan filtre, sonda yumuşak oturma
b = buf(1.3)
at(b, pad(['D2', 'A2', 'D3'], .55, .16, .35, 150, 900, .3, .8, .1), 0, .9)
at(b, sub(N('D2') * 1.02, N('D2'), .5, .1, .2), .02, .35)
at(b, riser(.3, 200, 1400, .8, 1.0) * np.sin(np.pi * np.linspace(0, 1, int(SR * .3)))[:, None] ** 2, 0, .12)
at(b, kalimba(N('A3'), .5, .12, .5), .26, .4)
put('rise', master(space(b, room=.25, hall=.1), -21, 1.0, lpf=7000))

# ======================= KAZANMA / KAYBETME =======================
# Kazanma — açılan Dadd9 pad + koro, iki oktav yükselen cam arpej, finalde parlayan akor
b = buf(4.4)
at(b, pad(['D3', 'A3', 'E4', 'F#4', 'A4'], 3.6, .4, 1.6, 300, 4200, 1.2), 0, .55)
at(b, choir(['D4', 'A4', 'F#5'], 3.4, .6, 1.5), .1, .3)
at(b, sub(N('D2') * 1.5, N('D2'), 2.0, .2, .9, .05), 0, .4)
arp(b, ['D5', 'E5', 'F#5', 'A5', 'B5', 'D6', 'E6', 'F#6', 'A6'], .05, .075, lambda f: glass(f, 1.6, .55, .55), .38, .02)
for k, nt in enumerate(['D6', 'F#6', 'A6', 'E7']):
    at(b, pan(glass(N(nt), 2.4, 1.0, .5), (-.5, .5, 0, .2)[k]), .78 + k * .012, .3)
sparkles(b, 20, .5, 2.2, 6, 7, .07)
put('win', master(space(b, hall=.42, shim=.25, delay=DLY), -17, 4.0))

# Kusursuz temizlik — dev açılış: sub + akor patlaması, üç oktav ışıltı taraması, koro ve finalde kristal akor
b = buf(4.0)
at(b, sub(N('D3'), N('D1') * 2, 1.5, .1, .5, drive=1.8), 0, .7)
at(b, burst(.8, 14000, 400, .25, .7), 0, .4)
at(b, stab(['D3', 'A3', 'D4', 'E4', 'F#4', 'A4', 'D5'], 1.8, .6, 9000, 400, 1.3), 0, .6)
at(b, pad(['D4', 'A4', 'E5', 'F#5', 'A5'], 3.0, .15, 1.5, 600, 6000, .6), 0, .45)
at(b, choir(['D4', 'A4', 'E5', 'F#5'], 2.8, .25, 1.4), .05, .35)
seq = [n + str(o) for o in (5, 6, 7) for n in PENTA][:13]
arp(b, seq, .03, .045, lambda f: glass(f, 1.2, .4, .55), .3, .015, [-.8, -.4, 0, .4, .8, .4, 0, -.4])
for k, nt in enumerate(['D6', 'A6', 'F#7']):
    at(b, pan(glass(N(nt), 2.2, .9, .45), (-.4, .4, 0)[k]), .65, .32)
sparkles(b, 18, .4, 1.8, 6, 7, .07)
put('perfect', master(space(b, hall=.42, shim=.28, delay=DLY), -16, 3.6))

# Madalya — kısa, zarif üç notalı cam fanfar + altta yumuşak pad
b = buf(2.6)
arp(b, ['A5', 'D6', 'F#6'], 0, .085, lambda f: glass(f, 1.6, .6, .6), .55, .03, [-.4, .4, 0])
at(b, pad(['D4', 'A4', 'F#5'], 1.6, .08, 1.0, 700, 3500, .3), 0, .3)
at(b, kalimba(N('D5'), .6, .2, .7), 0, .3)
sparkles(b, 8, .25, .7, 7, 7, .05)
put('medal', master(space(b, hall=.36, shim=.2, delay=DLY), -20, 2.3))

# Kaybetme — sönen ışık: yavaşça inen çanlar, Bm7 pad'i, kapanan filtre ve hafif aşağı kayan perde
b = buf(3.8)
for k, nt in enumerate(['A5', 'F#5', 'D5', 'B4']):
    at(b, pan(glass(N(nt), 1.8, .7 - .08 * k, .4 - .06 * k), (.4, -.4, .2, -.2)[k]), k * .22, .5 - .06 * k)
tt = T(3.2); bend = 1 - .03 * np.clip((tt - 1.0) / 2.0, 0, 1)                # sonda ~yarım ton düşüş
pd_ = np.zeros((len(tt), 2))
for nt in ['B2', 'F#3', 'A3', 'D4']:
    for s in (-.6, .6): pd_ += pan(saw(N(nt) * bend * (1 + s * .002), len(tt)), s)
fc = 2200 * np.exp(-tt / 1.0) + 250
pd_ = sweep(pd_, fc, .9) * swell(tt, .3, 1.4, 3.2)[:, None] * .12
at(b, pd_, 0, 1.0)
at(b, sub(N('B1') * 1.01, N('B1'), 2.0, .3, .8, .1), 0, .25)
put('lose', master(space(b, hall=.38, shim=.08, delay=(.25, .35, 4, 2500, .18)), -20, 3.4))

for name, d, l, p in out: print(f'{name:12s} {d:5.2f}s  loud {l:6.1f} dB  peak {p:5.1f} dB')
