// Block Rise — iOS haptics köprüsü (Taptic Engine).
// Haptics.cs bu fonksiyonları [DllImport("__Internal")] ile çağırır. Unity bu dosyayı yalnızca iOS derlemesine katar.
#import <UIKit/UIKit.h>

static UIImpactFeedbackGenerator *gLight, *gMedium, *gHeavy;
static UISelectionFeedbackGenerator *gSelection;
static UINotificationFeedbackGenerator *gNotify;

static void BRHapticsInit()
{
    if (gLight != nil) return;
    gLight = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    gMedium = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    gHeavy = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleHeavy];
    gSelection = [[UISelectionFeedbackGenerator alloc] init];
    gNotify = [[UINotificationFeedbackGenerator alloc] init];
    // prepare: Taptic Engine'i ısıtır, ilk titreşim gecikmesiz olur
    [gLight prepare]; [gMedium prepare]; [gHeavy prepare]; [gSelection prepare]; [gNotify prepare];
}

extern "C"
{
    // style: 0 = hafif, 1 = orta, 2 = sert · intensity: 0..1 (iOS 13+)
    void BRHaptics_Impact(int style, float intensity)
    {
        BRHapticsInit();
        UIImpactFeedbackGenerator *g = style <= 0 ? gLight : (style == 1 ? gMedium : gHeavy);
        if (@available(iOS 13.0, *)) [g impactOccurredWithIntensity:MAX(0.0f, MIN(1.0f, intensity))];
        else [g impactOccurred];
        [g prepare];
    }

    void BRHaptics_Selection()
    {
        BRHapticsInit();
        [gSelection selectionChanged];
        [gSelection prepare];
    }

    // type: 0 = başarı, 1 = uyarı, 2 = hata
    void BRHaptics_Notify(int type)
    {
        BRHapticsInit();
        [gNotify notificationOccurred:(UINotificationFeedbackType)type];
        [gNotify prepare];
    }
}
