namespace BlockRise
{
    /// <summary>
    /// Gerilim yönetmeninin arka plan hesapları için hafif tahta kopyası.
    /// BoardModel ile aynı kurallar (öbekler, rijit yerçekimi, popSize patlama, bomba boyama/patlatma, şimşek),
    /// ama yalnızca düz diziler kullanır ve oluşturulduktan sonra bellek ayırmaz → telefonda her turda
    /// yüzlerce hamle denemesi takılma yapmadan biter. Oyun mantığı değil, yalnızca tahmin içindir.
    /// Hücre indeksi: y * W + x (y = 0 en alt).
    /// </summary>
    public sealed class BoardSim
    {
        public readonly int W, H, Pop, N;
        public BombMode BombMode = BombMode.Recolor;

        readonly int[] _col;    // -1 = boş
        readonly byte[] _sp;    // SpecialType

        // Öbek etiketleme (y dışta, x içte — BoardModel.GetAllClumps sırası)
        readonly int[] _lab, _cells, _clOff, _clN, _stack, _owner;
        int _ncl;

        // Patlama / yerçekimi geçici alanları
        readonly bool[] _remove, _processed, _recolored;
        readonly int[] _queue, _rcCell, _rcCol, _tmpCol;
        readonly byte[] _rcKind;   // boyama: bombanın türü (hangi eksen)
        readonly byte[] _tmpSp;

        public BoardSim(int w, int h, int pop)
        {
            W = w; H = h; Pop = pop; N = w * h;
            _col = new int[N]; _sp = new byte[N];
            _lab = new int[N]; _cells = new int[N]; _clOff = new int[N]; _clN = new int[N]; _stack = new int[N]; _owner = new int[N];
            _remove = new bool[N]; _processed = new bool[N]; _recolored = new bool[N];
            _queue = new int[N * 4]; _rcCell = new int[N]; _rcCol = new int[N]; _rcKind = new byte[N]; _tmpCol = new int[N]; _tmpSp = new byte[N];
            for (int i = 0; i < N; i++) _col[i] = -1;
        }


        public void CopyFrom(BoardSim o)
        {
            System.Array.Copy(o._col, _col, N);
            System.Array.Copy(o._sp, _sp, N);
            BombMode = o.BombMode;
        }

        public void CopyFrom(BoardModel m)
        {
            BombMode = m.BombMode;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    var b = m.Get(x, y);
                    int i = y * W + x;
                    _col[i] = b != null ? b.Color : -1;
                    _sp[i] = b != null ? (byte)b.Special : (byte)0;
                }
        }

        /// <summary>Her şeyi bir sıra yukarı iter, verilen sırayı en alta koyar.</summary>
        public void RiseWith(Block[] row)
        {
            for (int y = H - 1; y >= 1; y--)
                for (int x = 0; x < W; x++)
                {
                    _col[y * W + x] = _col[(y - 1) * W + x];
                    _sp[y * W + x] = _sp[(y - 1) * W + x];
                }
            for (int x = 0; x < W; x++)
            {
                var b = row != null && x < row.Length ? row[x] : null;
                _col[x] = b != null ? b.Color : -1;
                _sp[x] = b != null ? (byte)b.Special : (byte)0;
            }
        }

        public int Highest()
        {
            for (int y = H - 1; y >= 0; y--)
                for (int x = 0; x < W; x++)
                    if (_col[y * W + x] >= 0) return y;
            return -1;
        }

        public bool TopOccupied()
        {
            for (int x = 0; x < W; x++) if (_col[(H - 1) * W + x] >= 0) return true;
            return false;
        }

        // ------------------------------------------------------------------ Etiketleme

        void Label()
        {
            for (int i = 0; i < N; i++) _lab[i] = -1;
            _ncl = 0;
            int nc = 0;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    int s = y * W + x;
                    if (_lab[s] >= 0 || _col[s] < 0) continue;
                    int id = _ncl++;
                    _clN[id] = 0;
                    _clOff[id] = nc;
                    int c = _col[s];
                    int sp = 0;
                    _stack[sp++] = s;
                    _lab[s] = id;
                    while (sp > 0)
                    {
                        int p = _stack[--sp];
                        _cells[nc++] = p;
                        _clN[id]++;
                        int px = p % W, py = p / W;
                        if (px + 1 < W) Visit(p + 1, c, id, ref sp);
                        if (px > 0) Visit(p - 1, c, id, ref sp);
                        if (py + 1 < H) Visit(p + W, c, id, ref sp);
                        if (py > 0) Visit(p - W, c, id, ref sp);
                    }
                }
        }

        void Visit(int n, int c, int id, ref int sp)
        {
            if (_lab[n] >= 0 || _col[n] != c) return;
            _lab[n] = id;
            _stack[sp++] = n;
        }

        // ------------------------------------------------------------------ Yerçekimi

        bool Gravity()
        {
            bool any = false, moved;
            int safety = 0;
            do
            {
                moved = false;
                Label();
                System.Array.Copy(_lab, _owner, N);
                for (int i = 0; i < _ncl; i++)
                {
                    int off = _clOff[i], n = _clN[i];
                    bool can = true;
                    for (int k = 0; k < n; k++)
                    {
                        int p = _cells[off + k];
                        if (p < W) { can = false; break; }
                        int below = p - W;
                        if (_col[below] >= 0 && _owner[below] != i) { can = false; break; }
                    }
                    if (!can) continue;
                    for (int k = 0; k < n; k++)
                    {
                        int p = _cells[off + k];
                        _tmpCol[k] = _col[p]; _tmpSp[k] = _sp[p];
                        _col[p] = -1; _sp[p] = 0; _owner[p] = -1;
                    }
                    for (int k = 0; k < n; k++)
                    {
                        int p = _cells[off + k] - W;
                        _cells[off + k] = p;
                        _col[p] = _tmpCol[k]; _sp[p] = _tmpSp[k]; _owner[p] = i;
                    }
                    moved = true;
                    any = true;
                }
            } while (moved && ++safety < 200);
            return any;
        }

        // ------------------------------------------------------------------ Patlama

        /// <summary>Bir patlama turu. Patlayan blok sayısı (0 = patlama yok).</summary>
        int PopOnce()
        {
            Label();
            int groups = 0;
            for (int i = 0; i < N; i++) { _remove[i] = false; _processed[i] = false; _recolored[i] = false; }
            int qh = 0, qt = 0;
            for (int i = 0; i < _ncl; i++)
            {
                if (_clN[i] < Pop) continue;
                groups++;
                for (int k = 0; k < _clN[i]; k++) Mark(_cells[_clOff[i] + k], ref qt);
            }
            if (groups == 0) return 0;

            int nrc = 0;
            while (qh < qt)
            {
                int p = _queue[qh++];
                if (_processed[p]) continue;
                _processed[p] = true;
                if (_col[p] < 0) continue;
                var kind = (SpecialType)_sp[p];
                if (Specials.IsBomb(kind))
                {
                    if (BombMode == BombMode.Explode)
                    {
                        int px = p % W, py = p / W;
                        if (Specials.HitsRow(kind)) for (int x = 0; x < W; x++) Mark(py * W + x, ref qt);
                        if (Specials.HitsColumn(kind)) for (int y = 0; y < H; y++) Mark(y * W + px, ref qt);
                    }
                    else { _rcCell[nrc] = p; _rcCol[nrc] = _col[p]; _rcKind[nrc] = _sp[p]; nrc++; }
                }
                else if (_sp[p] == (byte)SpecialType.Lightning)
                {
                    int c = _col[p];
                    for (int i = 0; i < N; i++) if (_col[i] == c) Mark(i, ref qt);
                }
            }

            // Bomba boyaması: patlamayan bloklar bombanın rengini alır
            for (int r = 0; r < nrc; r++)
            {
                int cx = _rcCell[r] % W, cy = _rcCell[r] / W, c = _rcCol[r];
                var kind = (SpecialType)_rcKind[r];
                if (Specials.HitsRow(kind)) for (int x = 0; x < W; x++) Recolor(cy * W + x, c);
                if (Specials.HitsColumn(kind)) for (int y = 0; y < H; y++) Recolor(y * W + cx, c);
            }

            int count = 0;
            for (int i = 0; i < N; i++)
                if (_remove[i] && _col[i] >= 0) { _col[i] = -1; _sp[i] = 0; count++; }
            return count;
        }

        void Mark(int p, ref int qt)
        {
            if (_remove[p] || _col[p] < 0) return;
            _remove[p] = true;
            if (_sp[p] != 0 && qt < _queue.Length) _queue[qt++] = p;
        }

        void Recolor(int p, int c)
        {
            if (_col[p] < 0 || _remove[p] || _col[p] == c || _recolored[p]) return;
            _col[p] = c;
            _recolored[p] = true;
        }

        /// <summary>Yerçekimi + patlama zincirini çözer. Zincir sayısı.</summary>
        public int Settle(out int popped)
        {
            int chains = 0;
            popped = 0;
            for (int guard = 0; guard < 50; guard++)
            {
                Gravity();
                int n = PopOnce();
                if (n == 0) break;
                chains++;
                popped += n;
            }
            return chains;
        }

        public int Settle() => Settle(out _);

        // ------------------------------------------------------------------ Oyuncu hamleleri

        public struct MoveStats
        {
            public int moves, popMoves, chainMoves, maxChain;
        }

        /// <summary>
        /// Oyuncunun yapabileceği tüm kaydırmaları dener (scratch üzerinde) ve kaçının patlattığını,
        /// en uzun zinciri vb. döner. Bu tahtanın kendisi değişmez.
        /// </summary>
        public MoveStats AnalyzeMoves(BoardSim scratch)
        {
            var m = new MoveStats();
            Label();
            int ncl = _ncl;
            for (int i = 0; i < ncl; i++)
            {
                int off = _clOff[i], n = _clN[i];
                MoveRange(off, n, i, out int mn, out int mx);
                for (int s = mn; s <= mx; s++)
                {
                    if (s == 0) continue;
                    m.moves++;
                    scratch.CopyFrom(this);
                    scratch.Shift(_cells, off, n, s);
                    int ch = scratch.Settle();
                    if (ch >= 1) m.popMoves++;
                    if (ch >= 2) m.chainMoves++;
                    if (ch > m.maxChain) m.maxChain = ch;
                }
            }
            return m;
        }

        void MoveRange(int off, int n, int id, out int mn, out int mx)
        {
            mx = MaxShift(off, n, id, 1);
            mn = -MaxShift(off, n, id, -1);
        }

        int MaxShift(int off, int n, int id, int dir)
        {
            for (int k = 1; k <= W; k++)
                for (int j = 0; j < n; j++)
                {
                    int p = _cells[off + j];
                    int nx = p % W + dir * k, py = p / W;
                    if (nx < 0 || nx >= W) return k - 1;
                    int q = py * W + nx;
                    if (_col[q] >= 0 && _lab[q] != id) return k - 1;
                }
            return 0;
        }

        /// <summary>Verilen hücre listesini (başka bir kopyanın etiketlemesinden) yatayda kaydırır.</summary>
        void Shift(int[] cells, int off, int n, int s)
        {
            for (int k = 0; k < n; k++)
            {
                int p = cells[off + k];
                _tmpCol[k] = _col[p]; _tmpSp[k] = _sp[p];
                _col[p] = -1; _sp[p] = 0;
            }
            for (int k = 0; k < n; k++)
            {
                int p = cells[off + k] + s;
                _col[p] = _tmpCol[k]; _sp[p] = _tmpSp[k];
            }
        }
    }
}
