using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Özel bloklar. Bomba ailesi aynı BombMode'u izler (patlatma ya da boyama), yalnızca etki ekseni farklıdır:
    /// Bomb = satır + sütun (dört yönlü oklar), Row = yalnızca satır (sağ-sol oklar), Column = yalnızca sütun (yukarı-aşağı oklar).
    /// Lightning (eşittir işareti) tahtadaki kendi rengindeki tüm blokları temizler.
    /// </summary>
    public enum SpecialType { None = 0, Bomb = 1, Lightning = 2, Row = 3, Column = 4 }

    public static class Specials
    {
        /// <summary>Bomba ailesinden mi (bomba, satır, sütun). Hedeflerde ve puanlamada hepsi bomba sayılır.</summary>
        public static bool IsBomb(SpecialType s) => s == SpecialType.Bomb || s == SpecialType.Row || s == SpecialType.Column;
        public static bool HitsRow(SpecialType s) => s == SpecialType.Bomb || s == SpecialType.Row;
        public static bool HitsColumn(SpecialType s) => s == SpecialType.Bomb || s == SpecialType.Column;
    }

    public class Block
    {
        public readonly int Id;
        public int Color;
        public SpecialType Special;

        public Block(int id, int color, SpecialType special)
        {
            Id = id;
            Color = color;
            Special = special;
        }
    }

    /// <summary>Yeni sıra üretim kuralları.</summary>
    public struct RowRules
    {
        public int colorCount;
        public float bombChance;
        public float lightningChance;
        /// <summary>Yeni bloğun satır bombası olma ihtimali (bomba ihtimalinden bağımsız).</summary>
        public float rowBombChance;
        /// <summary>Yeni bloğun sütun bombası olma ihtimali (bomba ihtimalinden bağımsız).</summary>
        public float columnBombChance;
        public int minGaps;
        public int maxGaps;
        /// <summary>0 = saf rastgele. >0 ise yeni sıra, tamamlanmaya yakın gruplar oluşturacak renkleri tercih eder.</summary>
        public float assist;
        public float nearWeight;
        public float midWeight;
        public float autoPopWeight;
        /// <summary>Zincir kurulumu ağırlığı (bkz. GameSettings.chainWeight).</summary>
        public float chainWeight;
        /// <summary>Zincir kurulumu gücü 0..1 (0 = kapalı). assist'ten bağımsızdır.</summary>
        public float chainAssist;
        /// <summary>
        /// Baskı (0..1): yeni bloğun aynı renkli bir gruba eklenmesinin ağırlığı bu oranda düşer.
        /// Sıra "dağınık" gelir, patlatmak zorlaşır, tahta yükselir. Tahta alçakken gerilim için kullanılır.
        /// </summary>
        public float spoil;
    }

    public class PopResult
    {
        public readonly List<Block> Blocks = new List<Block>();
        public readonly List<Vector2Int> Positions = new List<Vector2Int>();
        public readonly List<int> GroupSizes = new List<int>();
        public readonly List<Vector2Int> BombCenters = new List<Vector2Int>();
        /// <summary>BombCenters ile aynı sırada: her bombanın türü (Bomb / Row / Column).</summary>
        public readonly List<SpecialType> BombKinds = new List<SpecialType>();
        public readonly List<Vector2Int> LightningCenters = new List<Vector2Int>();
        public readonly List<int> LightningColors = new List<int>();
        /// <summary>Bomba (Recolor modunda) tarafından boyanan bloklar ve konumları.</summary>
        public readonly List<Block> Recolored = new List<Block>();
        public readonly List<Vector2Int> RecoloredPositions = new List<Vector2Int>();
        public int Count => Blocks.Count;
    }

    /// <summary>
    /// Oyunun saf mantığı (Unity objesi yok). y=0 en alt sıradır.
    /// Aynı renkte birbirine değen bloklar bir "clump" (öbek) oluşturur ve birlikte hareket eder.
    /// Öbek sadece altındaki tüm hücreler boşsa düşer (rijit yerçekimi).
    /// </summary>
    public class BoardModel
    {
        public readonly int Width;
        public readonly int Height;
        public readonly int PopSize;
        public RowRules Rules;
        public BombMode BombMode = BombMode.Recolor;
        public Block[] NextRow { get; private set; }

        readonly Block[,] _grid;
        readonly System.Random _rng;
        int _nextId = 1;

        // Tekrar kullanılan tamponlar (performans): öbek arama, yerçekimi ve tahmin her hamlede yüzlerce kez çalışır.
        // Her çağrıda yeni dizi ayırmak düşük segment Android'de GC takılmasına yol açıyordu.
        // "Damga" yöntemi: dizi temizlenmez, her aramada sayaç artar; hücre ancak damgası bu aramanınkiyse ziyaret edilmiştir.
        readonly int[,] _visitStamp;
        int _visitId;
        readonly int[,] _seenStamp;
        int _seenId;
        readonly int[,] _owner;
        readonly Stack<Vector2Int> _stack = new Stack<Vector2Int>(64);
        readonly Block[,] _predictBackup;

        static readonly Vector2Int[] Dirs =
        {
            new Vector2Int(1, 0), new Vector2Int(-1, 0), new Vector2Int(0, 1), new Vector2Int(0, -1)
        };

        public BoardModel(int width, int height, int popSize, int seed)
        {
            Width = width;
            Height = height;
            PopSize = Mathf.Max(2, popSize);
            _grid = new Block[width, height];
            _visitStamp = new int[width, height];
            _seenStamp = new int[width, height];
            _owner = new int[width, height];
            _predictBackup = new Block[width, height];
            _rng = seed != 0 ? new System.Random(seed) : new System.Random();
            NextRow = new Block[width];
        }

        public bool InBounds(int x, int y) => x >= 0 && y >= 0 && x < Width && y < Height;
        public Block Get(int x, int y) => InBounds(x, y) ? _grid[x, y] : null;

        // ------------------------------------------------------------------ Setup

        public void Clear()
        {
            for (int x = 0; x < Width; x++)
                for (int y = 0; y < Height; y++)
                    _grid[x, y] = null;
        }

        /// <summary>Kaydetme: hücreler x + y * Width sırasıyla (renk -1 = boş) ve sıradaki sıra.</summary>
        public void Export(out int[] colors, out int[] specials, out int[] nextColors, out int[] nextSpecials)
        {
            colors = new int[Width * Height];
            specials = new int[Width * Height];
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    var b = _grid[x, y];
                    colors[x + y * Width] = b != null ? b.Color : -1;
                    specials[x + y * Width] = b != null ? (int)b.Special : 0;
                }
            nextColors = new int[Width];
            nextSpecials = new int[Width];
            for (int x = 0; x < Width; x++)
            {
                var b = NextRow != null && x < NextRow.Length ? NextRow[x] : null;
                nextColors[x] = b != null ? b.Color : -1;
                nextSpecials[x] = b != null ? (int)b.Special : 0;
            }
        }

        /// <summary>Kaydedilmiş tahtayı geri yükler (Export ile aynı biçim). Bloklar yeni kimlik alır.</summary>
        public void Restore(int[] colors, int[] specials, int[] nextColors, int[] nextSpecials)
        {
            Clear();
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    int i = x + y * Width;
                    if (colors[i] >= 0) _grid[x, y] = new Block(_nextId++, colors[i], (SpecialType)specials[i]);
                }
            NextRow = new Block[Width];
            for (int x = 0; x < Width; x++)
                NextRow[x] = nextColors[x] < 0 ? null : new Block(_nextId++, nextColors[x], (SpecialType)nextSpecials[x]);
        }

        /// <summary>Tahtayı alttan 'rows' sıra ile doldurur, patlayacak grup bırakmaz ve en az bir hamle olmasını garanti eder.</summary>
        public void Fill(int rows)
        {
            // Nadiren hiç kaydırılabilir öbek olmayan bir tahta çıkabiliyor (oyuncu ilk hamlede kilitlenir) → yeniden üret
            for (int attempt = 0; attempt < 20; attempt++)
            {
                FillOnce(rows);
                if (HasAnyMove()) return;
            }
        }

        void FillOnce(int rows)
        {
            Clear();
            rows = Mathf.Clamp(rows, 0, Height - 2);
            for (int y = 0; y < rows; y++)
            {
                var row = GenerateRow(y - 1);
                for (int x = 0; x < Width; x++) _grid[x, y] = row[x];
            }
            ApplyGravity();
            FixGroups();
            PrepareNextRow();
        }

        // ------------------------------------------------------------------ Tutorial / hazır dizilim

        /// <summary>Tek bir hücreye blok koyar (color &lt; 0 → boşaltır). Tutorial tahtaları için.</summary>
        public void Place(int x, int y, int color, SpecialType special = SpecialType.None)
        {
            if (!InBounds(x, y)) return;
            _grid[x, y] = color < 0 ? null : new Block(_nextId++, color, special);
        }

        /// <summary>Önizleme sırasını elle belirler (-1 = boş hücre).</summary>
        public void SetNextRow(int[] colors)
        {
            NextRow = new Block[Width];
            for (int x = 0; x < Width && colors != null && x < colors.Length; x++)
                NextRow[x] = colors[x] < 0 ? null : new Block(_nextId++, colors[x], SpecialType.None);
        }

        /// <summary>Id'si verilen bloğun konumunu bulur (yoksa -1,-1).</summary>
        public Vector2Int FindBlock(int id)
        {
            for (int x = 0; x < Width; x++)
                for (int y = 0; y < Height; y++)
                    if (_grid[x, y] != null && _grid[x, y].Id == id) return new Vector2Int(x, y);
            return new Vector2Int(-1, -1);
        }

        /// <summary>Önizleme sırası, tahtanın şu anki en alt sırasına göre (yükselince onun altına girecek) üretilir.</summary>
        public void PrepareNextRow() => NextRow = GenerateRow(0);

        public Block[] GenerateRow() => GenerateRow(-1);

        /// <param name="contextY">Yeni sıraya bitişik olacak mevcut sıra (-1 = yok). Yardım (assist) bunu kullanır.</param>
        public Block[] GenerateRow(int contextY)
        {
            if (Rules.assist > 0f || Rules.spoil > 0f || (Rules.chainAssist > 0f && Rules.chainWeight > 0f)) return GenerateAssistedRow(contextY);

            var row = new Block[Width];
            int colorCount = Mathf.Clamp(Rules.colorCount, 2, 5);
            int minG = Mathf.Clamp(Rules.minGaps, 1, Width - 1);
            int maxG = Mathf.Clamp(Rules.maxGaps, minG, Width - 1);
            int gaps = _rng.Next(minG, maxG + 1);

            var idx = new List<int>();
            for (int i = 0; i < Width; i++) idx.Add(i);
            Shuffle(idx);
            var gapSet = new HashSet<int>();
            for (int i = 0; i < gaps; i++) gapSet.Add(idx[i]);

            for (int x = 0; x < Width; x++)
            {
                if (gapSet.Contains(x)) continue;
                int c = _rng.Next(colorCount);
                // Aynı sırada popSize kadar yan yana aynı renk olmasın
                int tries = 0;
                while (tries++ < 10 && RunLengthLeft(row, x, c) >= PopSize - 1)
                    c = _rng.Next(colorCount);

                SpecialType sp = RollSpecial();

                row[x] = new Block(_nextId++, c, sp);
            }
            return row;
        }

        static int RunLengthLeft(Block[] row, int x, int c)
        {
            int n = 0;
            for (int i = x - 1; i >= 0; i--)
            {
                if (row[i] != null && row[i].Color == c) n++;
                else break;
            }
            return n;
        }

        /// <summary>
        /// Ödüllendirici üretim: her hücre için olası renklerin, oluşturacağı grup büyüklüğüne göre ağırlığı hesaplanır.
        /// popSize-1 büyüklüğünde grup (tek hamlede patlatılabilir) en çok tercih edilir.
        /// </summary>
        Block[] GenerateAssistedRow(int contextY)
        {
            var row = new Block[Width];
            int colorCount = Mathf.Clamp(Rules.colorCount, 2, 5);
            int minG = Mathf.Clamp(Rules.minGaps, 1, Width - 1);
            int maxG = Mathf.Clamp(Rules.maxGaps, minG, Width - 1);
            int gaps = _rng.Next(minG, maxG + 1);

            var idx = new List<int>();
            for (int i = 0; i < Width; i++) idx.Add(i);
            Shuffle(idx);
            var gapSet = new HashSet<int>();
            for (int i = 0; i < gaps; i++) gapSet.Add(idx[i]);

            // Bağlam: bitişik sıradaki blokların öbekleri (union-find düğümleri)
            var ctxColor = new int[Width];
            var ctxNode = new int[Width];
            var parent = new List<int>();
            var size = new List<int>();
            for (int x = 0; x < Width; x++) { ctxColor[x] = -1; ctxNode[x] = -1; }
            if (contextY >= 0 && contextY < Height)
            {
                var seen = new Dictionary<int, int>(); // blok id -> düğüm
                for (int x = 0; x < Width; x++)
                {
                    var b = _grid[x, contextY];
                    if (b == null) continue;
                    ctxColor[x] = b.Color;
                    if (seen.TryGetValue(b.Id, out int node)) { ctxNode[x] = node; continue; }
                    var clump = GetClump(x, contextY);
                    int nid = parent.Count;
                    parent.Add(nid);
                    size.Add(clump.Count);
                    foreach (var p in clump)
                    {
                        var cb = _grid[p.x, p.y];
                        if (cb != null) seen[cb.Id] = nid;
                    }
                    ctxNode[x] = nid;
                }
            }

            int Find(int a) { while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a]; } return a; }

            // ZİNCİR KURULUMU (sandviç): yeni blok (alt) – bağlam bloğu (orta) – bir üstteki blok (üst).
            // Orta blok farklı renkteyse ve patlarsa, üst blok aşağı düşüp yeni bloğa değer. Yeni blok üstle aynı
            // renkteyse ve düşen grup + yeni grup popSize'a ulaşırsa ikinci patlama (zincir) olur.
            //   midNear: orta grup patlamaya bir blok uzakta (oyuncu tek hamleyle zinciri başlatabilir)
            //   topSize: üst bloğun öbek büyüklüğü (düşünce yeni grupla birleşecek kısım)
            // Yerçekimi rijit olduğu için düşme garanti değil: bu bir ağırlık, kesin hesap değil.
            bool chainOn = Rules.chainAssist > 0f && Rules.chainWeight > 0f && contextY >= 0 && contextY + 1 < Height;
            var topColor = new int[Width];
            var topSize = new int[Width];
            var midNear = new bool[Width];
            for (int x = 0; x < Width; x++) { topColor[x] = -1; topSize[x] = 0; }
            if (chainOn)
            {
                for (int x = 0; x < Width; x++)
                {
                    var mid = _grid[x, contextY];
                    var top = _grid[x, contextY + 1];
                    if (mid == null || top == null || mid.Color == top.Color) continue;
                    topColor[x] = top.Color;
                    topSize[x] = GetClump(x, contextY + 1).Count;
                    midNear[x] = ctxNode[x] >= 0 && size[Find(ctxNode[x])] >= PopSize - 1;
                }
            }

            var rowNode = new int[Width];
            for (int x = 0; x < Width; x++) rowNode[x] = -1;
            var weights = new float[colorCount];
            var roots = new List<int>(2);

            for (int x = 0; x < Width; x++)
            {
                if (gapSet.Contains(x)) continue;

                float total = 0f;
                for (int c = 0; c < colorCount; c++)
                {
                    roots.Clear();
                    if (x > 0 && row[x - 1] != null && row[x - 1].Color == c) roots.Add(Find(rowNode[x - 1]));
                    if (ctxColor[x] == c)
                    {
                        int ctxRoot = Find(ctxNode[x]);
                        if (!roots.Contains(ctxRoot)) roots.Add(ctxRoot);
                    }
                    int groupSize = 1;
                    foreach (var root in roots) groupSize += size[root];

                    float w = 1f;
                    if (groupSize >= PopSize) w = Rules.autoPopWeight;
                    else if (groupSize == PopSize - 1) w = 1f + Rules.nearWeight * Rules.assist;
                    else if (groupSize == PopSize - 2 && groupSize >= 2) w = 1f + Rules.midWeight * Rules.assist;

                    // Zincir kurulumu: bu renk, üstten düşecek grupla birleşip ikinci patlamayı hazırlıyor mu
                    if (chainOn && groupSize < PopSize && topColor[x] == c)
                    {
                        float q = midNear[x] ? 1f : 0.4f;                      // zincir tek hamle uzakta mı
                        q *= topSize[x] + groupSize >= PopSize ? 1f : 0.5f;    // düşünce kesin patlar mı
                        w += Rules.chainWeight * Rules.chainAssist * q;
                    }
                    // Baskı: mevcut bir gruba eklenen renkler daha az seçilir (sıra dağınık gelir)
                    if (Rules.spoil > 0f && groupSize >= 2) w *= 1f - Mathf.Clamp01(Rules.spoil);
                    weights[c] = Mathf.Max(0.0001f, w);
                    total += weights[c];
                }

                double pick = _rng.NextDouble() * total;
                int chosen = colorCount - 1;
                for (int c = 0; c < colorCount; c++)
                {
                    pick -= weights[c];
                    if (pick <= 0) { chosen = c; break; }
                }

                // Düğümü oluştur ve aynı renkli komşularla birleştir
                int me = parent.Count;
                parent.Add(me);
                size.Add(1);
                rowNode[x] = me;
                if (x > 0 && row[x - 1] != null && row[x - 1].Color == chosen) Union(parent, size, me, rowNode[x - 1]);
                if (ctxColor[x] == chosen) Union(parent, size, me, ctxNode[x]);

                SpecialType sp = RollSpecial();

                row[x] = new Block(_nextId++, chosen, sp);
            }
            return row;
        }

        static void Union(List<int> parent, List<int> size, int a, int b)
        {
            while (parent[a] != a) a = parent[a];
            while (parent[b] != b) b = parent[b];
            if (a == b) return;
            parent[b] = a;
            size[a] += size[b];
        }

        void Shuffle<T>(IList<T> list)
        {
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = _rng.Next(i + 1);
                T t = list[i]; list[i] = list[j]; list[j] = t;
            }
        }

        // ------------------------------------------------------------------ Clumps

        public List<Vector2Int> GetClump(int sx, int sy)
        {
            var result = new List<Vector2Int>();
            var start = Get(sx, sy);
            if (start == null) return result;

            int id = NextStamp(ref _visitId, _visitStamp);
            var stack = _stack;
            stack.Clear();
            stack.Push(new Vector2Int(sx, sy));
            _visitStamp[sx, sy] = id;
            while (stack.Count > 0)
            {
                var p = stack.Pop();
                result.Add(p);
                for (int i = 0; i < Dirs.Length; i++)
                {
                    int nx = p.x + Dirs[i].x, ny = p.y + Dirs[i].y;
                    if (!InBounds(nx, ny) || _visitStamp[nx, ny] == id) continue;
                    var b = _grid[nx, ny];
                    if (b != null && b.Color == start.Color)
                    {
                        _visitStamp[nx, ny] = id;
                        stack.Push(new Vector2Int(nx, ny));
                    }
                }
            }
            return result;
        }

        public List<List<Vector2Int>> GetAllClumps()
        {
            var all = new List<List<Vector2Int>>();
            int id = NextStamp(ref _seenId, _seenStamp);
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    if (_seenStamp[x, y] == id || _grid[x, y] == null) continue;
                    var c = GetClump(x, y);
                    for (int i = 0; i < c.Count; i++) _seenStamp[c[i].x, c[i].y] = id;
                    all.Add(c);
                }
            return all;
        }

        /// <summary>Damga sayacını ilerletir; taşma olursa (pratikte asla) diziyi sıfırlar.</summary>
        static int NextStamp(ref int counter, int[,] stamps)
        {
            if (counter == int.MaxValue)
            {
                System.Array.Clear(stamps, 0, stamps.Length);
                counter = 0;
            }
            return ++counter;
        }

        /// <summary>Öbeğin sola (min, negatif) ve sağa (max) en fazla kaç hücre kayabileceği.</summary>
        public void GetMoveRange(List<Vector2Int> clump, out int minShift, out int maxShift)
        {
            var mine = new HashSet<Vector2Int>(clump);
            maxShift = MaxShift(clump, mine, 1);
            minShift = -MaxShift(clump, mine, -1);
        }

        int MaxShift(List<Vector2Int> clump, HashSet<Vector2Int> mine, int dir)
        {
            for (int k = 1; k <= Width; k++)
            {
                foreach (var p in clump)
                {
                    int nx = p.x + dir * k;
                    if (nx < 0 || nx >= Width) return k - 1;
                    if (_grid[nx, p.y] != null && !mine.Contains(new Vector2Int(nx, p.y))) return k - 1;
                }
            }
            return 0;
        }

        public bool ApplyMove(List<Vector2Int> clump, int shift)
        {
            if (shift == 0 || clump == null || clump.Count == 0) return false;
            GetMoveRange(clump, out int min, out int max);
            shift = Mathf.Clamp(shift, min, max);
            if (shift == 0) return false;
            ShiftCells(clump, shift, 0);
            return true;
        }

        void ShiftCells(List<Vector2Int> cells, int dx, int dy)
        {
            var blocks = new Block[cells.Count];
            for (int i = 0; i < cells.Count; i++)
            {
                blocks[i] = _grid[cells[i].x, cells[i].y];
                _grid[cells[i].x, cells[i].y] = null;
            }
            for (int i = 0; i < cells.Count; i++)
                _grid[cells[i].x + dx, cells[i].y + dy] = blocks[i];
        }

        /// <summary>
        /// Kümeyi 'shift' kadar kaydırıp yerçekimini uygularsak bloklarının nereye düşeceğini tahmin eder.
        /// Tahtayı DEĞİŞTİRMEZ (denemeyi yapar, sonra geri alır). willPop: indiği yerde patlayacak mı.
        /// </summary>
        public List<Vector2Int> PredictLanding(List<Vector2Int> clump, int shift, out bool willPop)
        {
            willPop = false;
            var result = new List<Vector2Int>();
            if (clump == null || clump.Count == 0) return result;
            GetMoveRange(clump, out int min, out int max);
            shift = Mathf.Clamp(shift, min, max);

            var ids = new HashSet<int>();
            foreach (var p in clump) if (_grid[p.x, p.y] != null) ids.Add(_grid[p.x, p.y].Id);

            var saved = _predictBackup; // tekrar kullanılan yedek (PredictLanding iç içe çağrılmaz)
            System.Array.Copy(_grid, saved, _grid.Length);
            if (shift != 0) ShiftCells(clump, shift, 0);
            ApplyGravity();
            for (int x = 0; x < Width; x++)
                for (int y = 0; y < Height; y++)
                    if (_grid[x, y] != null && ids.Contains(_grid[x, y].Id)) result.Add(new Vector2Int(x, y));
            if (result.Count > 0) willPop = GetClump(result[0].x, result[0].y).Count >= PopSize;
            System.Array.Copy(saved, _grid, saved.Length); // tahtayı eski hâline döndür
            return result;
        }

        public bool HasAnyMove()
        {
            foreach (var c in GetAllClumps())
            {
                GetMoveRange(c, out int min, out int max);
                if (min < 0 || max > 0) return true;
            }
            return false;
        }

        // ------------------------------------------------------------------ Gravity

        /// <summary>Rijit yerçekimi. Bir şey düştüyse true döner.</summary>
        public bool ApplyGravity()
        {
            bool any = false;
            bool moved;
            int safety = 0;
            do
            {
                moved = false;
                var clumps = GetAllClumps(); // alttan yukarı sıralı (y döngüsü dıştaydı)
                var owner = _owner;
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        owner[x, y] = -1;
                for (int i = 0; i < clumps.Count; i++)
                    foreach (var p in clumps[i]) owner[p.x, p.y] = i;

                for (int i = 0; i < clumps.Count; i++)
                {
                    var c = clumps[i];
                    bool canFall = true;
                    foreach (var p in c)
                    {
                        if (p.y == 0) { canFall = false; break; }
                        if (_grid[p.x, p.y - 1] != null && owner[p.x, p.y - 1] != i) { canFall = false; break; }
                    }
                    if (!canFall) continue;

                    ShiftCells(c, 0, -1);
                    foreach (var p in c) owner[p.x, p.y] = -1;
                    for (int k = 0; k < c.Count; k++)
                    {
                        c[k] = new Vector2Int(c[k].x, c[k].y - 1);
                        owner[c[k].x, c[k].y] = i;
                    }
                    moved = true;
                    any = true;
                }
            } while (moved && ++safety < 200);
            return any;
        }

        // ------------------------------------------------------------------ Pops

        public List<List<Vector2Int>> FindGroups()
        {
            var groups = new List<List<Vector2Int>>();
            foreach (var c in GetAllClumps())
                if (c.Count >= PopSize) groups.Add(c);
            return groups;
        }

        /// <summary>Yeni blok özel mi: her türün kendi ihtimali var (tek zarla, toplamları üst üste eklenir).</summary>
        SpecialType RollSpecial()
        {
            double r = _rng.NextDouble();
            double edge = Rules.bombChance;
            if (r < edge) return SpecialType.Bomb;
            edge += Rules.rowBombChance;
            if (r < edge) return SpecialType.Row;
            edge += Rules.columnBombChance;
            if (r < edge) return SpecialType.Column;
            edge += Rules.lightningChance;
            if (r < edge) return SpecialType.Lightning;
            return SpecialType.None;
        }

        /// <summary>popSize+ grupları ve tetiklenen özel blokları kaldırır. Hiçbir şey yoksa null.</summary>
        public PopResult FindAndRemovePops()
        {
            var groups = FindGroups();
            if (groups.Count == 0) return null;

            var result = new PopResult();
            var remove = new bool[Width, Height];
            var queue = new Queue<Vector2Int>();
            var processed = new bool[Width, Height];

            foreach (var g in groups)
            {
                result.GroupSizes.Add(g.Count);
                foreach (var p in g) Mark(p.x, p.y, remove, queue);
            }

            var recolorCenters = new List<Vector2Int>();
            var recolorColors = new List<int>();
            var recolorKinds = new List<SpecialType>();

            while (queue.Count > 0)
            {
                var p = queue.Dequeue();
                if (processed[p.x, p.y]) continue;
                processed[p.x, p.y] = true;
                var b = _grid[p.x, p.y];
                if (b == null) continue;

                if (Specials.IsBomb(b.Special))
                {
                    result.BombCenters.Add(p);
                    result.BombKinds.Add(b.Special);
                    if (BombMode == BombMode.Explode)
                    {
                        // Patlatma: bombanın eksen(ler)indeki blokları patlat
                        if (Specials.HitsRow(b.Special)) for (int x = 0; x < Width; x++) Mark(x, p.y, remove, queue);
                        if (Specials.HitsColumn(b.Special)) for (int y = 0; y < Height; y++) Mark(p.x, y, remove, queue);
                    }
                    else
                    {
                        // Boyama: eksen(ler)i bombanın rengine boya (patlamadan sonra uygulanır)
                        recolorCenters.Add(p);
                        recolorColors.Add(b.Color);
                        recolorKinds.Add(b.Special);
                    }
                }
                else if (b.Special == SpecialType.Lightning)
                {
                    result.LightningCenters.Add(p);
                    result.LightningColors.Add(b.Color);
                    for (int x = 0; x < Width; x++)
                        for (int y = 0; y < Height; y++)
                            if (_grid[x, y] != null && _grid[x, y].Color == b.Color)
                                Mark(x, y, remove, queue);
                }
            }

            // Bomba boyaması: patlamayan bloklar bombanın rengini alır
            var recolored = new HashSet<int>();
            for (int i = 0; i < recolorCenters.Count; i++)
            {
                var c = recolorCenters[i];
                int col = recolorColors[i];
                var kind = recolorKinds[i];
                if (Specials.HitsRow(kind)) for (int x = 0; x < Width; x++) Recolor(x, c.y, col, remove, recolored, result);
                if (Specials.HitsColumn(kind)) for (int y = 0; y < Height; y++) Recolor(c.x, y, col, remove, recolored, result);
            }

            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    if (!remove[x, y] || _grid[x, y] == null) continue;
                    result.Blocks.Add(_grid[x, y]);
                    result.Positions.Add(new Vector2Int(x, y));
                    _grid[x, y] = null;
                }
            return result;
        }

        void Recolor(int x, int y, int color, bool[,] remove, HashSet<int> done, PopResult result)
        {
            var b = _grid[x, y];
            if (b == null || remove[x, y] || b.Color == color || done.Contains(b.Id)) return;
            b.Color = color;
            done.Add(b.Id);
            result.Recolored.Add(b);
            result.RecoloredPositions.Add(new Vector2Int(x, y));
        }

        public bool IsEmpty() => HighestFilledRow() < 0;

        void Mark(int x, int y, bool[,] remove, Queue<Vector2Int> queue)
        {
            if (remove[x, y] || _grid[x, y] == null) return;
            remove[x, y] = true;
            if (_grid[x, y].Special != SpecialType.None) queue.Enqueue(new Vector2Int(x, y));
        }

        /// <summary>Başlangıçta / karıştırmada popSize+ grup kalmaması için renk değiştirir.</summary>
        public void FixGroups()
        {
            int colorCount = Mathf.Clamp(Rules.colorCount, 2, 5);
            for (int iter = 0; iter < 300; iter++)
            {
                var groups = FindGroups();
                if (groups.Count == 0) return;
                foreach (var g in groups)
                {
                    var p = g[_rng.Next(g.Count)];
                    var b = _grid[p.x, p.y];
                    int nc = _rng.Next(colorCount - 1);
                    if (nc >= b.Color) nc++;
                    b.Color = Mathf.Min(nc, colorCount - 1);
                }
            }
        }

        // ------------------------------------------------------------------ Rise

        public bool TopRowOccupied()
        {
            for (int x = 0; x < Width; x++)
                if (_grid[x, Height - 1] != null) return true;
            return false;
        }

        public int HighestFilledRow()
        {
            for (int y = Height - 1; y >= 0; y--)
                for (int x = 0; x < Width; x++)
                    if (_grid[x, y] != null) return y;
            return -1;
        }

        /// <summary>Her şeyi bir sıra yukarı iter, önizleme sırasını en alta koyar.</summary>
        public void Rise()
        {
            for (int y = Height - 1; y >= 1; y--)
                for (int x = 0; x < Width; x++)
                    _grid[x, y] = _grid[x, y - 1];
            for (int x = 0; x < Width; x++)
                _grid[x, 0] = NextRow[x];
            PrepareNextRow();
        }

        /// <summary>Üstteki n sırayı temizler (revive için). Kaldırılan blokları döner.</summary>
        public List<Block> ClearTopRows(int n)
        {
            var removed = new List<Block>();
            for (int y = Mathf.Max(0, Height - n); y < Height; y++)
                for (int x = 0; x < Width; x++)
                    if (_grid[x, y] != null)
                    {
                        removed.Add(_grid[x, y]);
                        _grid[x, y] = null;
                    }
            return removed;
        }

        public void ReshuffleColors()
        {
            var blocks = new List<Block>();
            var colors = new List<int>();
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                    if (_grid[x, y] != null)
                    {
                        blocks.Add(_grid[x, y]);
                        colors.Add(_grid[x, y].Color);
                    }
            Shuffle(colors);
            for (int i = 0; i < blocks.Count; i++) blocks[i].Color = colors[i];
            FixGroups();
        }
    }
}