using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Tek bir bloğun görseli. Hiyerarşi:
    ///  Block (root, pozisyon/scale animasyonu)
    ///   ├ Body       (Unified: komşulara göre şekillenen karo | Classic: renkli blok PNG'si)
    ///   ├ Shine      (Unified: üst parlama)
    ///   ├ Icon       (bomba / şimşek)
    ///   ├ LinkRight  (Classic: sağdaki aynı renk komşuya köprü)
    ///   └ LinkUp     (Classic: üstteki aynı renk komşuya köprü)
    /// Stil GameSettings.blockStyle ile seçilir.
    /// </summary>
    public class BlockView : MonoBehaviour
    {
        public const int BaseOrder = 10;
        const float BodySize = 1f;

        public Block Block { get; private set; }
        public bool IsPreview { get; private set; }
        public int LinkRightId { get; private set; } = -1;
        public int LinkUpId { get; private set; } = -1;
        public bool LinkLeft { get; private set; }
        public bool LinkDown { get; private set; }
        /// <summary>Çapraz bağlantılar (SpriteLibrary.MaskUpRight vb.). İç köşe kavisleri için. BoardView ayarlar.</summary>
        public int DiagonalMask { get; private set; }

        SpriteRenderer _body, _shine, _icon, _glow, _linkRight, _linkUp;
        float _iconPhase;
        bool _unified;
        int _mask = -1;
        float _alpha = 1f;
        float _visualScale = 1f;
        float _gray;
        float _flash;
        bool _classicGraySprite;
        bool _built, _special;

        /// <summary>Bu görsel şu anki blok stiliyle mi kuruldu (havuzdan yeniden kullanılabilir mi).</summary>
        public bool MatchesStyle => _unified == (GameSettings.Instance.blockStyle == BlockStyle.Unified);

        public static BlockView Create(Transform parent, Block block)
        {
            var go = new GameObject("Block");
            go.transform.SetParent(parent, false);
            var v = go.AddComponent<BlockView>();
            v.Bind(block);
            return v;
        }

        /// <summary>
        /// Görseli bir bloğa bağlar. PERFORMANS: BoardView patlayan blokların görsellerini yok etmez, havuzda tutar ve
        /// yeni gelen bloklar için Bind ile yeniden kullanır (her turda ~40 GameObject oluşturup silmek yerine).
        /// Tüm durum burada sıfırlanır: önceki bloktan hiçbir şey taşınmaz.
        /// </summary>
        public void Bind(Block block)
        {
            BuildRenderers();
            Block = block;
#if UNITY_EDITOR
            gameObject.name = "Block_" + block.Id; // sadece editörde (isim string'i GC üretir)
#endif
            IsPreview = false;
            LinkRightId = -1;
            LinkUpId = -1;
            LinkLeft = false;
            LinkDown = false;
            DiagonalMask = 0;
            _alpha = 1f;
            _visualScale = 1f;
            _gray = 0f;
            _flash = 0f;
            transform.localScale = Vector3.one;
            transform.localRotation = Quaternion.identity;

            if (_unified) _mask = -1; // ilk RefreshShape doğru karoyu seçsin
            else
            {
                _classicGraySprite = false;
                _body.sprite = SpriteLibrary.Block(block.Color);
            }

            _special = block.Special != SpecialType.None;
            if (_special)
            {
                var iconName = block.Special == SpecialType.Bomb ? "icon_bomb"
                             : block.Special == SpecialType.Row ? "icon_row"
                             : block.Special == SpecialType.Column ? "icon_column"
                             : "icon_lightning";
                if (_icon == null)
                {
                    // İkonun arkasında yumuşak beyaz ışıma (beyaz ikonla uyumlu; hareket etmez, yalnızca parlaklığı dalgalanır)
                    _glow = MakeRenderer("IconGlow", SpriteLibrary.SoftGlow(), BaseOrder + 2);
                    _glow.transform.localPosition = Vector3.zero;
                    SetSpriteSize(_glow, new Vector2(0.95f, 0.95f));
                    _icon = MakeRenderer("Icon", SpriteLibrary.Get(iconName), BaseOrder + 3);
                    _icon.transform.localPosition = Vector3.zero;
                }
                _icon.sprite = SpriteLibrary.Get(iconName);
                SetSpriteSize(_icon, new Vector2(0.62f, 0.62f));
                _glow.color = new Color(1f, 1f, 1f, 0f);
                _icon.enabled = true;
                _glow.enabled = true;
                _iconPhase = (block.Id * 0.618f) % 1f * 6.283f; // ışımalar birbirinden bağımsız nefes alsın
            }
            else if (_icon != null)
            {
                _icon.enabled = false;
                _glow.enabled = false;
            }

            SetLifted(false);
            SetLinks(-1, -1);
            UpdateColors();
#if !UNITY_EDITOR
            // PERFORMANS: Update yalnızca özel blokların ışıması için gerekli. Sıradan bloklarda bileşen kapalı kalır,
            // Unity tahtadaki onlarca blok için her karede boş Update çağırmaz. (Editörde LateUpdate karo tazelemesi için açık.)
            enabled = _special;
#endif
        }

        /// <summary>Alt renderer'ları bir kez kurar (havuzdan dönen görselde tekrar kurulmaz).</summary>
        void BuildRenderers()
        {
            if (_built) return;
            _built = true;
            _unified = GameSettings.Instance.blockStyle == BlockStyle.Unified;

            _linkRight = MakeRenderer("LinkRight", SpriteLibrary.Get("square"), BaseOrder - 1);
            _linkRight.transform.localPosition = new Vector3(0.5f, -0.03f, 0);
            SetSpriteSize(_linkRight, new Vector2(0.3f, 0.62f));

            _linkUp = MakeRenderer("LinkUp", SpriteLibrary.Get("square"), BaseOrder - 1);
            _linkUp.transform.localPosition = new Vector3(0, 0.5f, 0);
            SetSpriteSize(_linkUp, new Vector2(0.62f, 0.3f));

            if (_unified)
            {
                _body = MakeRenderer("Body", SpriteLibrary.UnifiedTile(0, false), BaseOrder);
                _shine = MakeRenderer("Shine", SpriteLibrary.UnifiedTile(0, true), BaseOrder + 1);
                _mask = 0;
                SetSpriteSize(_body, Vector2.one * SpriteLibrary.TileBodyWorldSize);
                SetSpriteSize(_shine, Vector2.one * SpriteLibrary.TileShineWorldSize);
            }
            else
            {
                _body = MakeRenderer("Body", SpriteLibrary.Block(0), BaseOrder);
                SetSpriteSize(_body, new Vector2(BodySize, BodySize));
            }
        }

        SpriteRenderer MakeRenderer(string name, Sprite sprite, int order)
        {
            var go = new GameObject(name);
            go.transform.SetParent(transform, false);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.sortingOrder = order;
            return sr;
        }

        static void SetSpriteSize(SpriteRenderer sr, Vector2 size)
        {
            var b = sr.sprite != null ? sr.sprite.bounds.size : Vector3.one;
            sr.transform.localScale = new Vector3(size.x / Mathf.Max(0.0001f, b.x), size.y / Mathf.Max(0.0001f, b.y), 1f);
        }

        // ================================================================ Renk

        /// <summary>Renk değişirse (karıştırma / bomba boyaması) görseli yeniler.</summary>
        public void RefreshColor()
        {
            if (!_unified && !_classicGraySprite) _body.sprite = SpriteLibrary.Block(Block.Color);
            UpdateColors();
        }

        /// <summary>0 = normal renk, 1 = tamamen gri (game over).</summary>
        public void SetGray(float g)
        {
            _gray = Mathf.Clamp01(g);
            if (!_unified)
            {
                bool useGray = _gray >= 0.5f;
                if (useGray != _classicGraySprite)
                {
                    _classicGraySprite = useGray;
                    _body.sprite = useGray ? SpriteLibrary.GetGray("block_" + Block.Color) : SpriteLibrary.Block(Block.Color);
                }
            }
            UpdateColors();
        }


        /// <summary>Kısa beyaz parlama (0..1), renk değişiminde vurgu için.</summary>
        public void SetFlash(float f)
        {
            _flash = Mathf.Clamp01(f);
            UpdateColors();
        }

        void UpdateColors()
        {
            var s = GameSettings.Instance;
            Color baseCol = s.GetColor(Block.Color);
            Color gray = s.grayColor;
            Color tint = Color.Lerp(baseCol, gray, _gray);
            tint = Color.Lerp(tint, Color.white, _flash * 0.7f);

            if (_unified)
            {
                tint.a = _alpha;
                _body.color = tint;
            }
            else
            {
                // Classic: sprite zaten renkli; parlamada hafif kararıp açılır
                var bc = Color.Lerp(Color.white, new Color(1f, 1f, 0.85f), _flash);
                bc.a = _alpha;
                _body.color = bc;
            }

            if (_shine != null) _shine.color = new Color(1f, 1f, 1f, _alpha * (1f - _gray * 0.6f));

            var linkColor = Color.Lerp(Color.Lerp(baseCol, Color.black, 0.12f), gray * 0.85f, _gray);
            linkColor.a = _alpha;
            _linkRight.color = linkColor;
            _linkUp.color = linkColor;

            if (_special)
            {
                var ic = Color.Lerp(Color.white, new Color(0.75f, 0.75f, 0.75f), _gray);
                ic.a = _alpha;
                _icon.color = ic;
            }
        }

        // ================================================================ Bağlantılar

        public void SetLinks(int rightId, int upId)
        {
            LinkRightId = rightId;
            LinkUpId = upId;
            RefreshShape();
        }

        /// <summary>Sol ve alt bağlantılar (komşunun sağ/üst bağlantısından türetilir). BoardView ayarlar.</summary>
        public void SetSideLinks(bool left, bool down, int diagonalMask = 0)
        {
            if (left == LinkLeft && down == LinkDown && diagonalMask == DiagonalMask) return;
            LinkLeft = left;
            LinkDown = down;
            DiagonalMask = diagonalMask;
            RefreshShape();
        }

#if UNITY_EDITOR
        int _tileVersion;
        /// <summary>Editörde ayar değişince karoları anında tazeler (sadece editör).</summary>
        void LateUpdate()
        {
            if (!_built || !_unified || _tileVersion == SpriteLibrary.TileVersion) return;
            _tileVersion = SpriteLibrary.TileVersion;
            int m = _mask;
            _mask = -1;
            RefreshShape();
            if (_mask < 0) _mask = m;
            SetSpriteSize(_body, Vector2.one * SpriteLibrary.TileBodyWorldSize);
            SetSpriteSize(_shine, Vector2.one * SpriteLibrary.TileShineWorldSize);
        }
#endif

        void RefreshShape()
        {
            bool r = LinkRightId >= 0 && !IsPreview;
            bool u = LinkUpId >= 0 && !IsPreview;
            bool l = LinkLeft && !IsPreview;
            bool d = LinkDown && !IsPreview;

            if (_unified)
            {
                _linkRight.enabled = false;
                _linkUp.enabled = false;
                int mask = (r ? SpriteLibrary.MaskRight : 0) | (u ? SpriteLibrary.MaskUp : 0)
                         | (l ? SpriteLibrary.MaskLeft : 0) | (d ? SpriteLibrary.MaskDown : 0)
                         | (IsPreview ? 0 : DiagonalMask);
                mask = SpriteLibrary.CanonicalMask(mask);
                if (mask != _mask)
                {
                    _mask = mask;
                    _body.sprite = SpriteLibrary.UnifiedTile(mask, false);
                    _shine.sprite = SpriteLibrary.UnifiedTile(mask, true);
                }
            }
            else
            {
                _linkRight.enabled = r;
                _linkUp.enabled = u;
            }
        }

        public void SetPreview(bool preview)
        {
            IsPreview = preview;
            if (preview)
            {
                LinkRightId = -1;
                LinkUpId = -1;
                LinkLeft = false;
                LinkDown = false;
                DiagonalMask = 0;
            }
            RefreshShape();
        }

        // ================================================================ Dönüşüm

        public void SetAlpha(float a)
        {
            _alpha = a;
            UpdateColors();
        }

        public void SetScale(float s)
        {
            _visualScale = s;
            transform.localScale = new Vector3(s, s, 1);
        }

        // ================================================================ Özel ikon animasyonu

        /// <summary>
        /// Özel bloklar (bomba, satır, sütun, şimşek): ikon sabit durur — dönme, sallanma, büyüme yok.
        /// Arkasındaki yumuşak beyaz ışıma yalnızca parlaklığını yavaşça değiştirerek nefes alır (her blok kendi
        /// fazında). Ayar kapalıysa ışıma sabit kalır. Gri (oyun sonu) hâlde ışıma söner.
        /// </summary>
        void Update()
        {
            if (!_special) return;
            var s = GameSettings.Instance;
            float life = (1f - _gray) * _alpha;

            var ic = Color.Lerp(Color.white, new Color(0.72f, 0.72f, 0.72f), _gray);
            ic.a = _alpha;
            _icon.color = ic;

            float breathe = s.animateSpecialIcons
                ? 0.5f + 0.5f * Mathf.Sin(Time.time * 2.2f * Mathf.Max(0.05f, s.specialBlinkSpeed) + _iconPhase)
                : 0.5f;
            _glow.color = new Color(1f, 1f, 1f, (0.16f + 0.30f * breathe) * life);
        }

        public float VisualScale => _visualScale;
        public float Alpha => _alpha;

        public void SetLifted(bool lifted)
        {
            int add = lifted ? 20 : 0;
            _body.sortingOrder = BaseOrder + add;
            if (_shine != null) _shine.sortingOrder = BaseOrder + 1 + add;
            if (_glow != null) _glow.sortingOrder = BaseOrder + 2 + add;
            if (_icon != null) _icon.sortingOrder = BaseOrder + 3 + add;
            _linkRight.sortingOrder = BaseOrder - 1 + add;
            _linkUp.sortingOrder = BaseOrder - 1 + add;
        }
    }
}