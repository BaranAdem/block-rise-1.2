using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace BlockRise
{
    /// <summary>
    /// Tahtanın görsel tarafı: arka plan, blok görselleri, animasyonlar ve sürükleme girdisi.
    /// Mantık BoardModel'de; bu sınıf sadece modeli ekrana yansıtır.
    /// </summary>
    public class BoardView : MonoBehaviour
    {
        public enum Ease { OutQuad, InQuad, OutBack }

        struct Target
        {
            public Vector3 pos;
            public bool preview;
        }

        const float PreviewScale = 0.55f;
        const float PreviewAlpha = 0.5f;
        const float PreviewOffset = 0.62f;
        const float SidePad = 0.3f;
        const float CellBgSize = 0.92f;      // boş hücre karesinin boyu (hücre oranı)
        const float PreviewStripH = 0.8f;    // alttaki önizleme şeridinin yüksekliği

        /// <summary>Oyuncu bir öbeği kaydırdığında çağrılır (hücreler, kaydırma miktarı).</summary>
        public event Action<List<Vector2Int>, int> MoveRequested;
        public bool InputEnabled { get; set; }

        GameSettings _s;
        BoardModel _model;
        Camera _cam;
        FxManager _fx;

        readonly Dictionary<int, BlockView> _views = new Dictionary<int, BlockView>();
        Transform _blocksRoot, _bgRoot;
        SpriteRenderer _boardBg, _previewBg, _danger, _limitLine;

        // Tehlike göstergesi: tepeden sönümlenen yumuşak ışıma + kesikli sınır çizgisi
        static readonly Color LimitSafe = new Color(0.30f, 0.26f, 0.45f, 0.30f); // pastel zeminde okunur
        static readonly Color LimitDanger = new Color(1f, 0.45f, 0.40f, 0.90f);
        static readonly Color GlowColor = new Color(1f, 0.36f, 0.30f, 1f);
        const float GlowMaxAlpha = 0.75f;   // ışımanın en yoğun anı
        const float GlowRows = 2.6f;        // ışıma kaç satır aşağı iner
        float _dangerLevel, _dangerTarget;
        float _blinkPhase;                  // yanıp sönme fazı (hız değişince sıçrama olmasın diye birikimli)
        const float BlinkMinHz = 0.9f;      // tehlike yeni başladığında yanıp sönme hızı (saniyede)
        const float BlinkMaxHz = 1.4f;      // en üst satır doluyken yanıp sönme hızı
        const float BlinkFloor = 0.4f;     // sönük anındaki parlaklık (0 = tamamen kapanır)
        static Sprite _dashSprite, _glowSprite;
        readonly List<SpriteRenderer> _cellBgs = new List<SpriteRenderer>();
        Vector2 _origin;
        float _topReservePx, _bottomReservePx;
        int _lastScreenW, _lastScreenH;
        int _builtW, _builtH;
        int _animating;
        int _shapeVersion = -1;   // köşe ayarları değişince zemini yeniden giydirmek için

        // drag state
        bool _dragging;
        List<Vector2Int> _dragCells;
        readonly List<BlockView> _dragViews = new List<BlockView>();
        readonly List<Vector3> _dragBase = new List<Vector3>();
        int _dragMin, _dragMax;
        float _dragStartX, _dragOffset;

        // Sürükleme işaretleri: alındığı yer (iz) + bırakınca düşeceği yer (hayalet)
        readonly List<SpriteRenderer> _originMarks = new List<SpriteRenderer>();
        readonly List<SpriteRenderer> _landMarks = new List<SpriteRenderer>();
        Color _dragColor;
        int _predShift = int.MinValue;
        bool _landWillPop;
        static Sprite _markFillSprite, _markGhostSprite;
        const float OriginAlpha = 0.30f;   // alındığı yerin izi
        const float LandAlpha = 0.85f;     // düşeceği yerin çerçevesi

        public bool IsAnimating => _animating > 0;

        public void Init(Camera cam, FxManager fx)
        {
            _s = GameSettings.Instance;
            _cam = cam;
            _fx = fx;
            _bgRoot = new GameObject("BoardBackground").transform;
            _bgRoot.SetParent(transform, false);
            _blocksRoot = new GameObject("Blocks").transform;
            _blocksRoot.SetParent(transform, false);
        }

        public void SetVisible(bool visible)
        {
            _bgRoot.gameObject.SetActive(visible);
            _blocksRoot.gameObject.SetActive(visible);
        }

        // ================================================================ Setup / Layout

        public void SetModel(BoardModel model)
        {
            // Yarıda kesilen animasyonlardan kalan durumu sıfırla
            StopAllCoroutines();
            _animating = 0;
            CancelDrag();
            _model = model;
            if (_builtW != model.Width || _builtH != model.Height) BuildBackground();
            RebuildAll();
        }

        void BuildBackground()
        {
            foreach (Transform c in _bgRoot) Destroy(c.gameObject);
            _cellBgs.Clear();
            _originMarks.Clear(); // işaretler de _bgRoot altındaydı, yukarıda silindi
            _landMarks.Clear();
            _builtW = _model.Width;
            _builtH = _model.Height;

            _boardBg = MakeSR("Board", "panel", -20, _s.boardColor, _bgRoot);
            _boardBg.drawMode = SpriteDrawMode.Sliced;

            _previewBg = MakeSR("PreviewStrip", "panel", -20, new Color(_s.boardColor.r, _s.boardColor.g, _s.boardColor.b, _s.boardColor.a * 0.6f), _bgRoot);
            _previewBg.drawMode = SpriteDrawMode.Sliced;

            for (int y = 0; y < _builtH; y++)
                for (int x = 0; x < _builtW; x++)
                    _cellBgs.Add(MakeSR("Cell", "cell", -19, _s.cellColor, _bgRoot));

            _danger = MakeSR("Danger", "square", -18, GlowColor, _bgRoot);
            _danger.sprite = GlowSprite();
            _danger.enabled = false;

            _limitLine = MakeSR("Limit", "square", -17, LimitSafe, _bgRoot);
            _limitLine.sprite = DashSprite();
            _limitLine.drawMode = SpriteDrawMode.Tiled;
            _limitLine.tileMode = SpriteTileMode.Continuous;

            ApplyBoardShapes();
        }

        /// <summary>
        /// Tahta zemini, önizleme şeridi ve hücre karelerine köşe ayarına uygun sprite'ı verir.
        /// GameSettings > Board Look değişince (Play sırasında da) otomatik yeniden çağrılır.
        /// </summary>
        void ApplyBoardShapes()
        {
            _shapeVersion = SpriteLibrary.TileVersion;
            if (_boardBg == null) return;

            bool proc = _s.proceduralBoardShapes;
            float boardR = _s.boardCornerRadius;
            // Köşeler, parçanın yarısından büyük olamaz (aksi halde 9-dilim bozulur)
            float stripR = Mathf.Min(boardR, PreviewStripH * 0.5f * 0.95f);
            float cellR = Mathf.Min(_s.cellCornerRadius, CellBgSize * 0.5f * 0.95f);

            _boardBg.sprite = proc ? SpriteLibrary.RoundedRect(boardR) : SpriteLibrary.Get("panel");
            _boardBg.enabled = _s.showBoardPanel; // kapalıyken sadece ızgara + önizleme şeridi kalır
            _previewBg.sprite = proc ? SpriteLibrary.RoundedRect(stripR) : SpriteLibrary.Get("panel");
            var cellSprite = proc ? SpriteLibrary.RoundedRect(cellR) : SpriteLibrary.Get("cell");
            foreach (var sr in _cellBgs)
            {
                sr.sprite = cellSprite;
                sr.drawMode = SpriteDrawMode.Sliced; // köşe, hücre boyutundan bağımsız kalsın
            }

            // Sürükleme işaretleri de hücrelerle aynı köşeyi kullansın
            _markFillSprite = null;
            _markGhostSprite = null;
            foreach (var m in _originMarks) if (m != null) m.sprite = MarkFillSprite();
            foreach (var m in _landMarks) if (m != null) m.sprite = MarkGhostSprite();
        }

        SpriteRenderer MakeSR(string name, string sprite, int order, Color color, Transform parent)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = SpriteLibrary.Get(sprite);
            sr.sortingOrder = order;
            sr.color = color;
            return sr;
        }

        static void SizeSR(SpriteRenderer sr, float w, float h)
        {
            if (sr.drawMode == SpriteDrawMode.Sliced)
            {
                sr.transform.localScale = Vector3.one;
                sr.size = new Vector2(w, h);
            }
            else
            {
                var b = sr.sprite.bounds.size;
                sr.transform.localScale = new Vector3(w / b.x, h / b.y, 1);
            }
        }

        /// <summary>Kamerayı tahta ekrana sığacak şekilde ayarlar. Rezervler piksel cinsinden (üst HUD, alt boşluk).</summary>
        public void FitCamera(float topReservePx, float bottomReservePx)
        {
            _topReservePx = topReservePx;
            _bottomReservePx = bottomReservePx;
            Layout();
        }

        void Layout()
        {
            if (_model == null || _cam == null) return;
            _lastScreenW = Screen.width;
            _lastScreenH = Screen.height;

            int W = _model.Width, H = _model.Height;
            float aspect = (float)Screen.width / Mathf.Max(1, Screen.height);
            float topFrac = Mathf.Clamp01(_topReservePx / Mathf.Max(1, Screen.height));
            float botFrac = Mathf.Clamp01(_bottomReservePx / Mathf.Max(1, Screen.height));
            float availFrac = Mathf.Max(0.3f, 1f - topFrac - botFrac);

            float contentW = W + SidePad * 2f;
            float contentH = H + 1.3f + 0.4f; // tahta + önizleme şeridi + pay

            float sizeByW = contentW / aspect / 2f;
            float sizeByH = contentH / availFrac / 2f;
            float ortho = Mathf.Max(sizeByW, sizeByH);

            _cam.orthographic = true;
            _cam.orthographicSize = ortho;
            var camPos = new Vector3(0, 0, -10);
            _cam.transform.position = camPos;
            if (_fx != null) _fx.SetCameraBase(camPos);

            float availTop = ortho - topFrac * 2f * ortho;
            float availBot = -ortho + botFrac * 2f * ortho;
            float center = (availTop + availBot) * 0.5f;
            float boardTop = center + (H + 1.3f) * 0.5f;
            // Ekran uzunsa tahtayı HUD'a yakın tut (ortada boşluk kalmasın)
            boardTop = Mathf.Min(boardTop, availTop - 0.2f);
            _origin = new Vector2(-W * 0.5f, boardTop - H);

            // Arka plan
            _boardBg.transform.position = new Vector3(0, _origin.y + H * 0.5f, 0);
            SizeSR(_boardBg, W + 0.36f, H + 0.36f);
            _previewBg.transform.position = new Vector3(0, _origin.y - PreviewOffset, 0);
            SizeSR(_previewBg, W + 0.36f, PreviewStripH);
            int i = 0;
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                {
                    var sr = _cellBgs[i++];
                    sr.transform.position = CellCenter(x, y);
                    SizeSR(sr, CellBgSize, CellBgSize);
                }
            _limitLine.transform.position = new Vector3(0, _origin.y + H + 0.12f, 0);
            _limitLine.transform.localScale = Vector3.one;
            _limitLine.size = new Vector2(W - 0.1f, _limitLine.sprite.bounds.size.y);
            // Işımanın üst kenarı tahtanın tepesine hizalı
            _danger.transform.position = new Vector3(0, _origin.y + H - GlowRows * 0.5f, 0);
            SizeSR(_danger, W, GlowRows);

            if (_animating == 0 && !_dragging) SnapAll();
        }

        /// <summary>Oyuncu şu an bir kümeyi sürüklüyor mu (tutorial işareti için).</summary>
        public bool IsDragging => _dragging;

        readonly List<BlockView> _highlighted = new List<BlockView>();

        /// <summary>Verilen hücrelerdeki blokları beyaz parlamayla vurgular (0..1).</summary>
        public void HighlightCells(List<Vector2Int> cells, float amount)
        {
            ClearHighlight();
            if (_model == null || cells == null) return;
            foreach (var c in cells)
            {
                var b = _model.Get(c.x, c.y);
                if (b != null && _views.TryGetValue(b.Id, out var v) && v != null)
                {
                    v.SetFlash(amount);
                    _highlighted.Add(v);
                }
            }
        }

        public void ClearHighlight()
        {
            foreach (var v in _highlighted) if (v != null) v.SetFlash(0f);
            _highlighted.Clear();
        }

        public Vector3 CellCenter(int x, int y) => new Vector3(_origin.x + x + 0.5f, _origin.y + y + 0.5f, 0);
        public Vector3 PreviewCenter(int x) => new Vector3(_origin.x + x + 0.5f, _origin.y - PreviewOffset, 0);
        public Vector3 BoardCenter => new Vector3(0, _origin.y + (_model != null ? _model.Height : 10) * 0.5f, 0);
        public Vector3 BoardTopCenter => new Vector3(0, _origin.y + (_model != null ? _model.Height : 10) - 1f, 0);

        // ================================================================ Views

        public void RebuildAll()
        {
            foreach (var v in _views.Values) if (v != null) Recycle(v);
            _views.Clear();
            var targets = ComputeTargets();
            foreach (var kv in targets) GetOrCreate(kv.Key);
            SnapAll();
        }

        BlockView GetOrCreate(int id)
        {
            if (_views.TryGetValue(id, out var v) && v != null) return v;
            var block = FindBlock(id);
            if (block == null) return null;
            v = null;
            while (_pool.Count > 0 && v == null)
            {
                var p = _pool.Pop();
                if (p == null) continue;
                if (!p.MatchesStyle) { Destroy(p.gameObject); continue; } // stil değiştiyse (editör) eski görsel kullanılmaz
                v = p;
            }
            if (v != null)
            {
                v.gameObject.SetActive(true);
                v.Bind(block);
            }
            else v = BlockView.Create(_blocksRoot, block);
            _views[id] = v;
            return v;
        }

        Block FindBlock(int id)
        {
            for (int y = 0; y < _model.Height; y++)
                for (int x = 0; x < _model.Width; x++)
                {
                    var b = _model.Get(x, y);
                    if (b != null && b.Id == id) return b;
                }
            foreach (var b in _model.NextRow)
                if (b != null && b.Id == id) return b;
            return null;
        }

        Dictionary<int, Target> ComputeTargets()
        {
            var t = new Dictionary<int, Target>();
            if (_model == null) return t;
            for (int y = 0; y < _model.Height; y++)
                for (int x = 0; x < _model.Width; x++)
                {
                    var b = _model.Get(x, y);
                    if (b != null) t[b.Id] = new Target { pos = CellCenter(x, y), preview = false };
                }
            for (int x = 0; x < _model.Width; x++)
            {
                var b = _model.NextRow[x];
                if (b != null) t[b.Id] = new Target { pos = PreviewCenter(x), preview = true };
            }
            return t;
        }

        Dictionary<int, Vector2Int> ComputeLinks()
        {
            var links = new Dictionary<int, Vector2Int>();
            for (int y = 0; y < _model.Height; y++)
                for (int x = 0; x < _model.Width; x++)
                {
                    var b = _model.Get(x, y);
                    if (b == null) continue;
                    var r = _model.Get(x + 1, y);
                    var u = _model.Get(x, y + 1);
                    links[b.Id] = new Vector2Int(
                        r != null && r.Color == b.Color ? r.Id : -1,
                        u != null && u.Color == b.Color ? u.Id : -1);
                }
            return links;
        }

        void ApplyLinks(Dictionary<int, Vector2Int> links, bool onlyKeepExisting)
        {
            foreach (var kv in _views)
            {
                var v = kv.Value;
                if (v == null) continue;
                Vector2Int l;
                if (!links.TryGetValue(kv.Key, out l)) l = new Vector2Int(-1, -1);
                if (onlyKeepExisting)
                {
                    int r = v.LinkRightId == l.x ? l.x : -1;
                    int u = v.LinkUpId == l.y ? l.y : -1;
                    v.SetLinks(r, u);
                }
                else v.SetLinks(l.x, l.y);
            }
            RefreshSideLinks();
        }

        /// <summary>
        /// Sağ/üst bağlantılardan sol/alt ve çapraz bağlantıları türetir (yekpare şekil için 8 yön gerekir).
        /// Çapraz komşu, ancak bir kenar komşusu üzerinden bağlıysa sayılır (L şeklindeki iç köşeler için).
        /// </summary>
        void RefreshSideLinks()
        {
            var byId = new Dictionary<int, BlockView>();
            var leftOf = new Dictionary<int, int>();  // id → solundaki bağlı bloğun id'si
            var downOf = new Dictionary<int, int>();  // id → altındaki bağlı bloğun id'si
            foreach (var v in _views.Values)
            {
                if (v == null || v.IsPreview) continue;
                byId[v.Block.Id] = v;
            }
            foreach (var v in byId.Values)
            {
                if (v.LinkRightId >= 0) leftOf[v.LinkRightId] = v.Block.Id;
                if (v.LinkUpId >= 0) downOf[v.LinkUpId] = v.Block.Id;
            }

            foreach (var v in _views.Values)
            {
                if (v == null) continue;
                int id = v.Block.Id;
                if (v.IsPreview) { v.SetSideLinks(false, false, 0); continue; }

                int r = v.LinkRightId, u = v.LinkUpId;
                int l = leftOf.TryGetValue(id, out var li) ? li : -1;
                int d = downOf.TryGetValue(id, out var di) ? di : -1;

                bool ur = (r >= 0 && UpOf(byId, r) >= 0) || (u >= 0 && RightOf(byId, u) >= 0);
                bool ul = (l >= 0 && UpOf(byId, l) >= 0) || (u >= 0 && leftOf.ContainsKey(u));
                bool dl = (l >= 0 && downOf.ContainsKey(l)) || (d >= 0 && leftOf.ContainsKey(d));
                bool dr = (r >= 0 && downOf.ContainsKey(r)) || (d >= 0 && RightOf(byId, d) >= 0);

                int diag = (ur ? SpriteLibrary.MaskUpRight : 0) | (ul ? SpriteLibrary.MaskUpLeft : 0)
                         | (dl ? SpriteLibrary.MaskDownLeft : 0) | (dr ? SpriteLibrary.MaskDownRight : 0);
                v.SetSideLinks(l >= 0, d >= 0, diag);
            }
        }

        static int UpOf(Dictionary<int, BlockView> byId, int id) => byId.TryGetValue(id, out var v) ? v.LinkUpId : -1;
        static int RightOf(Dictionary<int, BlockView> byId, int id) => byId.TryGetValue(id, out var v) ? v.LinkRightId : -1;

        void SnapAll()
        {
            var targets = ComputeTargets();
            foreach (var kv in targets)
            {
                var v = GetOrCreate(kv.Key);
                if (v == null) continue;
                v.transform.position = kv.Value.pos;
                v.SetPreview(kv.Value.preview);
                v.SetScale(kv.Value.preview ? PreviewScale : 1f);
                v.SetAlpha(kv.Value.preview ? PreviewAlpha : 1f);
            }
            ApplyLinks(ComputeLinks(), false);
            UpdateDanger();
        }

        /// <summary>Tüm blok görsellerini modeldeki yerlerine animasyonla taşır.</summary>
        public IEnumerator AnimateToModel(float baseTime, float perCell, Ease ease)
        {
            _animating++;
            var targets = ComputeTargets();

            // modelde olmayan görselleri kaldır
            var stale = new List<int>();
            foreach (var kv in _views) if (!targets.ContainsKey(kv.Key)) stale.Add(kv.Key);
            foreach (var id in stale)
            {
                if (_views[id] != null) Recycle(_views[id]);
                _views.Remove(id);
            }

            var links = ComputeLinks();
            ApplyLinks(links, true); // kopacak bağlantıları hemen gizle

            var list = new List<BlockView>();
            var from = new List<Vector3>();
            var to = new List<Vector3>();
            var s0 = new List<float>();
            var s1 = new List<float>();
            var a0 = new List<float>();
            var a1 = new List<float>();
            float maxDist = 0;

            foreach (var kv in targets)
            {
                bool isNew = !_views.ContainsKey(kv.Key) || _views[kv.Key] == null;
                var v = GetOrCreate(kv.Key);
                if (v == null) continue;
                if (isNew)
                {
                    v.transform.position = kv.Value.pos;
                    v.SetScale(0f);
                    v.SetAlpha(0f);
                }
                v.SetPreview(kv.Value.preview);
                list.Add(v);
                from.Add(v.transform.position);
                to.Add(kv.Value.pos);
                s0.Add(v.VisualScale);
                s1.Add(kv.Value.preview ? PreviewScale : 1f);
                a0.Add(v.Alpha);
                a1.Add(kv.Value.preview ? PreviewAlpha : 1f);
                maxDist = Mathf.Max(maxDist, Vector3.Distance(v.transform.position, kv.Value.pos));
            }

            float duration = baseTime + perCell * maxDist;
            float t = 0;
            while (t < duration)
            {
                t += AnimDt;
                float k = Mathf.Clamp01(t / duration);
                float e = Apply(ease, k);
                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i] == null) continue;
                    list[i].transform.position = Vector3.LerpUnclamped(from[i], to[i], e);
                    list[i].SetScale(Mathf.Lerp(s0[i], s1[i], k));
                    list[i].SetAlpha(Mathf.Lerp(a0[i], a1[i], k));
                }
                yield return null;
            }
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i] == null) continue;
                list[i].transform.position = to[i];
                list[i].SetScale(s1[i]);
                list[i].SetAlpha(a1[i]);
            }
            ApplyLinks(ComputeLinks(), false);
            UpdateDanger();
            _animating--;
        }

        /// <summary>
        /// Animasyon adımı: tek bir yavaş kare (GC, sistem bildirimi) animasyonu ileri SIÇRATMASIN diye 1/30 sn ile sınırlı.
        /// Takılma olursa animasyon o an çok kısa süre yavaşlar ama atlamaz: göze çok daha akıcı gelir.
        /// </summary>
        static float AnimDt => Mathf.Min(Time.deltaTime, 1f / 30f);

        static float Apply(Ease e, float k)
        {
            switch (e)
            {
                case Ease.InQuad: return k * k;
                case Ease.OutBack:
                    const float c1 = 1.70158f, c3 = c1 + 1f;
                    return 1f + c3 * Mathf.Pow(k - 1f, 3) + c1 * Mathf.Pow(k - 1f, 2);
                default: return 1f - (1f - k) * (1f - k);
            }
        }

        /// <summary>Patlayan blokların animasyonu ve efektleri. chain büyüdükçe efektler güçlenir.</summary>
        public IEnumerator PlayPops(PopResult r, int chain = 1)
        {
            _animating++;
            var popped = new HashSet<int>();
            foreach (var b in r.Blocks) popped.Add(b.Id);
            foreach (var b in r.Recolored) popped.Add(b.Id); // boyananların eski bağlantıları da kopsun
            float power = 1f + Mathf.Min(chain - 1, 6) * 0.25f;

            // Kopan bağlantıları gizle
            foreach (var v in _views.Values)
            {
                if (v == null) continue;
                if (popped.Contains(v.Block.Id)) v.SetLinks(-1, -1);
                else v.SetLinks(popped.Contains(v.LinkRightId) ? -1 : v.LinkRightId,
                                popped.Contains(v.LinkUpId) ? -1 : v.LinkUpId);
            }
            RefreshSideLinks();

            bool recolorMode = r.Recolored.Count > 0 || _model.BombMode == BombMode.Recolor;
            for (int bi = 0; bi < r.BombCenters.Count; bi++)
            {
                var c = r.BombCenters[bi];
                var kind = bi < r.BombKinds.Count ? r.BombKinds[bi] : SpecialType.Bomb;
                var p = CellCenter(c.x, c.y);
                var bombCol = recolorMode ? Color.Lerp(BombColorAt(r, c), Color.white, 0.35f) : new Color(1f, 0.85f, 0.5f, 0.9f);
                _fx.Shockwave(p, new Color(bombCol.r, bombCol.g, bombCol.b, 0.9f), kind == SpecialType.Bomb ? 5f : 3.5f);
                _fx.Flash(p, new Color(1f, 1f, 1f, 0.8f), 1.5f);
                // Işın yalnızca bombanın etki ettiği eksen(ler)de
                if (Specials.HitsRow(kind)) _fx.Beam(CellCenter(0, c.y), CellCenter(_model.Width - 1, c.y), bombCol);
                if (Specials.HitsColumn(kind)) _fx.Beam(CellCenter(c.x, 0), CellCenter(c.x, _model.Height - 1), bombCol);
                _fx.Shake(0.18f, 0.3f);
                StardustField.Emit(p, bombCol, chain + 1, 12);
            }
            for (int i = 0; i < r.LightningCenters.Count; i++)
            {
                var c = r.LightningCenters[i];
                var p = CellCenter(c.x, c.y);
                var col = _s.GetColor(r.LightningColors[i]);
                _fx.Flash(p, new Color(1f, 1f, 0.7f, 0.9f), 2f);
                for (int k = 0; k < r.Blocks.Count; k++)
                    if (r.Blocks[k].Color == r.LightningColors[i])
                        _fx.Beam(p, CellCenter(r.Positions[k].x, r.Positions[k].y), Color.Lerp(col, Color.white, 0.5f));
                _fx.Shake(0.12f, 0.25f);
                StardustField.Emit(p, col, chain + 1, 10);
            }

            var views = new List<BlockView>();
            var positions = new List<Vector3>();
            foreach (var b in r.Blocks)
            {
                if (_views.TryGetValue(b.Id, out var v) && v != null)
                {
                    views.Add(v);
                    positions.Add(v.transform.position);
                    v.SetLifted(true);
                }
            }

            // Bomba boyaması: bombadan uzaklığa göre dalga halinde renk değişimi
            var recolorViews = new List<BlockView>();
            var recolorDelay = new List<float>();
            for (int i = 0; i < r.Recolored.Count; i++)
            {
                if (!_views.TryGetValue(r.Recolored[i].Id, out var v) || v == null) continue;
                float best = float.MaxValue;
                foreach (var c in r.BombCenters)
                    best = Mathf.Min(best, Mathf.Abs(c.x - r.RecoloredPositions[i].x) + Mathf.Abs(c.y - r.RecoloredPositions[i].y));
                recolorViews.Add(v);
                recolorDelay.Add(best == float.MaxValue ? 0f : best * 0.035f);
            }
            var recolorDone = new bool[recolorViews.Count];

            // Grup merkezlerinde halka
            if (positions.Count > 0)
            {
                Vector3 center = Vector3.zero;
                foreach (var p in positions) center += p;
                center /= positions.Count;
                var gc = _s.GetColor(views[0].Block.Color);
                _fx.Ring(center, new Color(gc.r, gc.g, gc.b, 0.8f), 2.5f + positions.Count * 0.15f * power, 0.4f);
                // Arka plandaki yıldız tozunda dalga
                StardustField.Emit(center, gc, chain, positions.Count);
                if (chain >= 2)
                {
                    _fx.Flash(center, new Color(1f, 1f, 1f, 0.5f), 2.2f * power);
                    if (_s.shakeOnChain) _fx.Shake(0.05f + 0.03f * Mathf.Min(chain, 6), 0.2f);
                }
                if (chain >= 3) _fx.Confetti(center, _s.blockColors, 10 + chain * 5, power);
            }

            float dur = Mathf.Max(_s.popTime, recolorDelay.Count > 0 ? MaxOf(recolorDelay) + 0.15f : 0f);
            float t = 0;
            bool burst = false;
            while (t < dur)
            {
                t += AnimDt;
                float k = Mathf.Clamp01(t / _s.popTime);
                float sc = k < 0.35f ? Mathf.Lerp(1f, 1.2f, k / 0.35f) : Mathf.Lerp(1.2f, 0f, (k - 0.35f) / 0.65f);
                foreach (var v in views) if (v != null) v.SetScale(sc);
                if (!burst && k >= 0.35f)
                {
                    burst = true;
                    for (int i = 0; i < views.Count; i++)
                    {
                        var col = _s.GetColor(views[i].Block.Color);
                        _fx.Burst(positions[i], col, Mathf.RoundToInt(5 * power));
                        _fx.Shards(positions[i], col, Mathf.RoundToInt(3 * power), power);
                        _fx.Sparkles(positions[i], col, chain >= 2 ? 2 : 1);
                    }
                }

                for (int i = 0; i < recolorViews.Count; i++)
                {
                    var v = recolorViews[i];
                    if (v == null) continue;
                    float lt = t - recolorDelay[i];
                    if (lt < 0) continue;
                    if (!recolorDone[i])
                    {
                        recolorDone[i] = true;
                        v.RefreshColor();
                        _fx.Sparkles(v.transform.position, _s.GetColor(v.Block.Color), 2, 0.3f);
                    }
                    float fk = Mathf.Clamp01(lt / 0.18f);
                    v.SetFlash(1f - fk);
                    v.SetScale(1f + Mathf.Sin(fk * Mathf.PI) * 0.18f);
                }
                yield return null;
            }

            for (int i = 0; i < recolorViews.Count; i++)
            {
                if (recolorViews[i] == null) continue;
                if (!recolorDone[i]) recolorViews[i].RefreshColor();
                recolorViews[i].SetFlash(0f);
                recolorViews[i].SetScale(1f);
            }

            foreach (var b in r.Blocks)
            {
                if (_views.TryGetValue(b.Id, out var v) && v != null) Recycle(v);
                _views.Remove(b.Id);
            }
            // Boyanan bloklar yeni komşularıyla birleşsin
            if (r.Recolored.Count > 0) ApplyLinks(ComputeLinks(), false);
            _animating--;
        }

        Color BombColorAt(PopResult r, Vector2Int cell)
        {
            for (int i = 0; i < r.Positions.Count; i++)
                if (r.Positions[i] == cell) return _s.GetColor(r.Blocks[i].Color);
            return Color.white;
        }

        static float MaxOf(List<float> list)
        {
            float m = 0f;
            foreach (var f in list) m = Mathf.Max(m, f);
            return m;
        }

        // ================================================================ Game over: griye dönüş

        /// <summary>Tüm bloklar yukarıdan aşağıya dalga halinde griye döner.</summary>
        public IEnumerator PlayGrayOut()
        {
            if (_model == null) yield break;
            _animating++;
            var rows = new List<List<BlockView>>();
            for (int y = _model.Height - 1; y >= 0; y--)
            {
                var list = new List<BlockView>();
                for (int x = 0; x < _model.Width; x++)
                {
                    var b = _model.Get(x, y);
                    if (b != null && _views.TryGetValue(b.Id, out var v) && v != null) list.Add(v);
                }
                if (list.Count > 0) rows.Add(list);
            }
            var preview = new List<BlockView>();
            foreach (var b in _model.NextRow)
                if (b != null && _views.TryGetValue(b.Id, out var v) && v != null) preview.Add(v);
            if (preview.Count > 0) rows.Add(preview);

            float total = Mathf.Max(0.05f, _s.grayOutTime);
            float step = rows.Count > 0 ? total * 0.6f / rows.Count : 0f;
            float each = total * 0.4f;
            float t = 0;
            while (t < total + 0.01f)
            {
                t += AnimDt;
                for (int i = 0; i < rows.Count; i++)
                {
                    float k = Mathf.Clamp01((t - i * step) / Mathf.Max(0.01f, each));
                    foreach (var v in rows[i]) if (v != null) v.SetGray(k);
                }
                yield return null;
            }
            foreach (var row in rows) foreach (var v in row) if (v != null) v.SetGray(1f);
            _animating--;
        }

        /// <summary>Gri durumu anında ayarlar (revive'da renkleri geri getirmek için false).</summary>
        public void SetGrayAll(bool gray)
        {
            foreach (var v in _views.Values) if (v != null) v.SetGray(gray ? 1f : 0f);
        }

        /// <summary>Revive vb. için blokları efektle kaldırır.</summary>
        public IEnumerator PlayRemove(List<Block> blocks)
        {
            var r = new PopResult();
            foreach (var b in blocks)
            {
                r.Blocks.Add(b);
                r.Positions.Add(Vector2Int.zero);
            }
            yield return PlayPops(r);
            yield return AnimateToModel(0.05f, 0f, Ease.OutQuad);
        }

        /// <summary>Renkleri karıştırılan blokları günceller.</summary>
        public IEnumerator PlayReshuffle()
        {
            _animating++;
            foreach (var v in _views.Values) if (v != null && !v.IsPreview) v.RefreshColor();
            ApplyLinks(ComputeLinks(), false);
            float t = 0, dur = 0.3f;
            while (t < dur)
            {
                t += AnimDt;
                float k = Mathf.Clamp01(t / dur);
                float sc = 1f + Mathf.Sin(k * Mathf.PI) * 0.15f;
                foreach (var v in _views.Values) if (v != null && !v.IsPreview) v.SetScale(sc);
                yield return null;
            }
            foreach (var v in _views.Values) if (v != null && !v.IsPreview) v.SetScale(1f);
            _animating--;
        }

        /// <summary>En yüksek bloğun tepeye uzaklığına göre tehlike seviyesini belirler (0 = güvenli, 1 = kritik).</summary>
        void UpdateDanger()
        {
            if (_model == null || _danger == null) return;
            int dist = (_model.Height - 1) - _model.HighestFilledRow(); // 0 = en üst satır dolu
            _dangerTarget = dist <= 0 ? 1f : dist == 1 ? 0.80f : dist == 2 ? 0.60f : dist == 3 ? 0.40f : 0f;        
        }

        // ================================================================ Input

        // PERFORMANS: blok görselleri yok edilmez, havuza döner; yeni gelen bloklar havuzdan alınır.
        // Her tur gelen 8 blok için ~40 GameObject oluşturup her patlamada silmek takılma ve GC yaratıyordu.
        // Havuz taşarsa fazlası karelere yayılarak silinir (büyük zincirde 100+ nesne aynı karede silinmesin).
        readonly Stack<BlockView> _pool = new Stack<BlockView>();
        const int PoolMax = 128;
        readonly Queue<GameObject> _retired = new Queue<GameObject>();
        const int DestroysPerFrame = 6;

        void Recycle(BlockView v)
        {
            v.gameObject.SetActive(false);
            if (_pool.Count < PoolMax && v.MatchesStyle) _pool.Push(v);
            else _retired.Enqueue(v.gameObject);
        }

        void Update()
        {
            for (int k = 0; k < DestroysPerFrame && _retired.Count > 0; k++)
            {
                var g = _retired.Dequeue();
                if (g != null) Destroy(g);
            }

            if (_model != null && (Screen.width != _lastScreenW || Screen.height != _lastScreenH)) Layout();

            // Inspector'da köşe ayarı değiştiyse zemini yeniden giydir
            if (_boardBg != null && _shapeVersion != SpriteLibrary.TileVersion)
            {
                ApplyBoardShapes();
                Layout();
            }

            if (_danger != null && _limitLine != null && _model != null)
            {
                // Seviye hedefe yumuşakça yaklaşır (ani parlama/sönme yok)
                _dangerLevel = Mathf.MoveTowards(_dangerLevel, _dangerTarget, Time.deltaTime * 2.5f);
                // Yanıp sönme: tehlike arttıkça hızlanır
                float hz = Mathf.Lerp(BlinkMinHz, BlinkMaxHz, Mathf.InverseLerp(0.4f, 1f, _dangerLevel));
                _blinkPhase = (_blinkPhase + Time.deltaTime * hz) % 1f;
                float wave = 0.5f + 0.5f * Mathf.Cos(_blinkPhase * Mathf.PI * 2f); // 1 → 0 → 1
                wave = wave * wave * (3f - 2f * wave);                               // tepede biraz bekle, net "yan-sön"
                float pulse = _dangerLevel > 0.005f ? Mathf.Lerp(BlinkFloor, 1f, wave) : 1f;
                float lvl = _dangerLevel * pulse;

                var g = GlowColor;
                g.a = GlowMaxAlpha * lvl;
                _danger.color = g;
                _danger.enabled = g.a > 0.005f;

                _limitLine.color = Color.Lerp(LimitSafe, LimitDanger, lvl);
            }

            if (_model == null) return;
            if (!InputEnabled || IsAnimating)
            {
                if (_dragging) CancelDrag();
                return;
            }

            // Mouse API dokunmatikte de çalışır (Input.simulateMouseWithTouches = true)
            if (Input.GetMouseButtonDown(0) && !PointerOverUI())
                BeginDrag(ScreenToWorld(Input.mousePosition));
            else if (_dragging && Input.GetMouseButton(0))
                UpdateDrag(ScreenToWorld(Input.mousePosition));
            else if (_dragging && !Input.GetMouseButton(0))
                EndDrag();
        }

        static bool PointerOverUI()
        {
            var es = EventSystem.current;
            if (es == null) return false;
            if (es.IsPointerOverGameObject()) return true;
            for (int i = 0; i < Input.touchCount; i++)
                if (es.IsPointerOverGameObject(Input.GetTouch(i).fingerId)) return true;
            return false;
        }

        Vector3 ScreenToWorld(Vector3 screen)
        {
            screen.z = -_cam.transform.position.z;
            return _cam.ScreenToWorldPoint(screen);
        }

        void BeginDrag(Vector3 world)
        {
            int x = Mathf.FloorToInt(world.x - _origin.x);
            int y = Mathf.FloorToInt(world.y - _origin.y);
            if (!_model.InBounds(x, y) || _model.Get(x, y) == null) return;

            var cells = _model.GetClump(x, y);
            _model.GetMoveRange(cells, out _dragMin, out _dragMax);

            _dragCells = cells;
            _dragViews.Clear();
            _dragBase.Clear();
            foreach (var c in cells)
            {
                var b = _model.Get(c.x, c.y);
                if (b != null && _views.TryGetValue(b.Id, out var v) && v != null)
                {
                    _dragViews.Add(v);
                    _dragBase.Add(CellCenter(c.x, c.y));
                    v.SetLifted(true);
                    v.SetScale(1.06f);
                }
            }
            _dragStartX = world.x;
            _dragOffset = 0;
            _dragging = true;

            var first = _model.Get(x, y);
            _dragColor = _s.GetColor(first.Color);
            ShowOriginMarks(cells);
            _predShift = int.MinValue;
            UpdateLandingMarks(0);
        }

        void UpdateDrag(Vector3 world)
        {
            float raw = world.x - _dragStartX;
            float off = raw;
            // sınırlarda hafif lastik efekti
            if (raw > _dragMax) off = _dragMax + Mathf.Min(0.2f, (raw - _dragMax) * 0.15f);
            else if (raw < _dragMin) off = _dragMin - Mathf.Min(0.2f, (_dragMin - raw) * 0.15f);
            _dragOffset = off;
            for (int i = 0; i < _dragViews.Count; i++)
                if (_dragViews[i] != null)
                    _dragViews[i].transform.position = _dragBase[i] + new Vector3(off, 0, 0);

            UpdateLandingMarks(Mathf.Clamp(Mathf.RoundToInt(off), _dragMin, _dragMax));
            StardustField.SetDrag(off); // arka plandaki zerreler parmağa hafifçe eşlik etsin
        }

        void EndDrag()
        {
            _dragging = false;
            HideDragMarks();
            int shift = Mathf.Clamp(Mathf.RoundToInt(_dragOffset), _dragMin, _dragMax);
            StardustField.ReleaseDrag(shift); // hamle yönünde itiş (shift 0 ise yerine döner)
            foreach (var v in _dragViews)
                if (v != null) { v.SetLifted(false); v.SetScale(1f); }

            var cells = _dragCells;
            _dragViews.Clear();
            _dragBase.Clear();
            _dragCells = null;

            if (shift != 0 && MoveRequested != null) MoveRequested(cells, shift);
            else
            {
                // Hamle yok: blok eski yerine sessizce geri konur
                if (SoundManager.Instance != null) SoundManager.Instance.PlayOrganic(_s.sfxPlace, _s.placeVolume * 0.35f, 1.1f);
                StartCoroutine(AnimateToModel(_s.slideSnapTime, 0.02f, Ease.OutQuad));
            }
        }

        void CancelDrag()
        {
            if (!_dragging) return;
            _dragging = false;
            HideDragMarks();
            StardustField.ReleaseDrag(0);
            foreach (var v in _dragViews)
                if (v != null) { v.SetLifted(false); v.SetScale(1f); }
            for (int i = 0; i < _dragViews.Count; i++)
                if (_dragViews[i] != null) _dragViews[i].transform.position = _dragBase[i];
            _dragViews.Clear();
            _dragBase.Clear();
            _dragCells = null;
        }

        // ================================================================ Sürükleme işaretleri

        void ShowOriginMarks(List<Vector2Int> cells)
        {
            for (int i = 0; i < cells.Count; i++)
            {
                var sr = Mark(_originMarks, i, MarkFillSprite(), -16);
                sr.transform.position = CellCenter(cells[i].x, cells[i].y);
                sr.color = new Color(_dragColor.r, _dragColor.g, _dragColor.b, OriginAlpha);
                sr.enabled = true;
            }
            for (int i = cells.Count; i < _originMarks.Count; i++) _originMarks[i].enabled = false;
        }

        /// <summary>Kaydırma miktarı değiştikçe düşeceği hücreleri yeniden hesaplar ve gösterir.</summary>
        void UpdateLandingMarks(int shift)
        {
            if (shift != _predShift)
            {
                bool firstMark = _predShift == int.MinValue;
                _predShift = shift;
                Haptics.Selection(); // tutunca ve her hücre geçişinde hafif tık
                var sm = SoundManager.Instance;
                if (sm != null)
                {
                    if (firstMark) sm.PlayOrganic(_s.sfxPick, _s.pickVolume);
                    else sm.PlayOrganic(_s.sfxDrag, _s.dragVolume);
                }
                List<Vector2Int> land = null;
                _landWillPop = false;
                if (shift != 0 && _dragCells != null) land = _model.PredictLanding(_dragCells, shift, out _landWillPop);

                int n = land != null ? land.Count : 0;
                for (int i = 0; i < n; i++)
                {
                    var sr = Mark(_landMarks, i, MarkGhostSprite(), -15);
                    sr.transform.position = CellCenter(land[i].x, land[i].y);
                    sr.enabled = true;
                }
                for (int i = n; i < _landMarks.Count; i++) _landMarks[i].enabled = false;
            }

            // Patlayacaksa hayalet nabız gibi parlar
            float a = LandAlpha;
            var c = _dragColor;
            if (_landWillPop)
            {
                float k = 0.5f + 0.5f * Mathf.Sin(Time.time * 10f);
                a = Mathf.Lerp(0.7f, 1f, k);
                c = Color.Lerp(_dragColor, Color.white, 0.35f * k);
            }
            foreach (var sr in _landMarks)
                if (sr.enabled) sr.color = new Color(c.r, c.g, c.b, a);
        }

        void HideDragMarks()
        {
            foreach (var sr in _originMarks) if (sr != null) sr.enabled = false;
            foreach (var sr in _landMarks) if (sr != null) sr.enabled = false;
            _predShift = int.MinValue;
            _landWillPop = false;
        }

        SpriteRenderer Mark(List<SpriteRenderer> pool, int i, Sprite sprite, int order)
        {
            while (pool.Count <= i)
            {
                var go = new GameObject("DragMark");
                go.transform.SetParent(_bgRoot, false);
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = sprite;
                sr.sortingOrder = order;
                sr.enabled = false;
                pool.Add(sr);
            }
            return pool[i];
        }

        static Sprite MarkFillSprite() => _markFillSprite != null ? _markFillSprite : (_markFillSprite = BuildMarkSprite(false));
        static Sprite MarkGhostSprite() => _markGhostSprite != null ? _markGhostSprite : (_markGhostSprite = BuildMarkSprite(true));

        /// <summary>Hücre boyunda yuvarlak kare. ghost = kalın çerçeve + hafif iç dolgu; değilse düz dolgu.</summary>
        static Sprite BuildMarkSprite(bool ghost)
        {
            const int n = 96;
            const float half = 0.5f - 0.07f, border = 0.045f;
            var gs = GameSettings.Instance;
            // Hücre kareleriyle aynı köşe (eski PNG görünümünde sabit 0.18)
            float radius = gs.proceduralBoardShapes ? Mathf.Clamp(gs.cellCornerRadius, 0f, half) : 0.18f;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float fx = (x + 0.5f) / n - 0.5f, fy = (y + 0.5f) / n - 0.5f;
                    float qx = Mathf.Abs(fx) - (half - radius), qy = Mathf.Abs(fy) - (half - radius);
                    float d = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude
                              + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
                    float inside = Mathf.Clamp01(0.5f - d * n);
                    float a;
                    if (ghost)
                    {
                        float edge = Mathf.Clamp01(0.5f - (Mathf.Abs(d + border * 0.5f) - border * 0.5f) * n);
                        a = Mathf.Max(edge, inside * 0.25f);
                    }
                    else a = inside;
                    px[y * n + x] = new Color(1f, 1f, 1f, a);
                }
            tex.SetPixels(px);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), n); // 1 birim = 1 hücre
        }

        // ================================================================ Tehlike göstergesi dokuları

        /// <summary>Yuvarlak uçlu tek bir çizgi parçası; Tiled modda yan yana dizilir.</summary>
        static Sprite DashSprite()
        {
            if (_dashSprite != null) return _dashSprite;
            const int w = 64, h = 16;
            const float r = 6.5f, x0 = 13f + r, x1 = 51f - r, cy = h * 0.5f;
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            var px = new Color[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    float fx = x + 0.5f, fy = y + 0.5f;
                    float qx = Mathf.Clamp(fx, x0, x1);
                    float d = Mathf.Sqrt((fx - qx) * (fx - qx) + (fy - cy) * (fy - cy)) - r;
                    px[y * w + x] = new Color(1f, 1f, 1f, Mathf.Clamp01(0.5f - d));
                }
            tex.SetPixels(px);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.Apply();
            // 128 px = 1 birim → her çizgi+boşluk 0.5 hücre
            _dashSprite = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 128f, 0, SpriteMeshType.FullRect);
            return _dashSprite;
        }

        /// <summary>Tepede opak, aşağı doğru yumuşakça sönen dikey ışıma.</summary>
        static Sprite GlowSprite()
        {
            if (_glowSprite != null) return _glowSprite;
            const int w = 4, h = 128;
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            var px = new Color[w * h];
            for (int y = 0; y < h; y++)
            {
                float k = y / (float)(h - 1);       // 0 = alt, 1 = üst
                k = k * k * (3f - 2f * k);
                k = Mathf.Pow(k, 1.6f);
                for (int x = 0; x < w; x++) px[y * w + x] = new Color(1f, 1f, 1f, k);
            }
            tex.SetPixels(px);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.Apply();
            _glowSprite = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect);
            return _glowSprite;
        }
    }
}