using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Asset gerektirmeyen basit efekt sistemi: parçacıklar, halkalar, yazı popup'ları, kamera sarsıntısı.
    /// </summary>
    public class FxManager : MonoBehaviour
    {
        // PERFORMANS: parçacıklar artık tek tek GameObject/SpriteRenderer değil. Her sprite türü (kare, daire, yıldız,
        // halka...) için TEK bir dinamik mesh var; tüm parçacıklar CPU'da güncellenip o mesh'e yazılır.
        // Önce: patlamada yüzlerce GameObject'in transform'u her karede güncelleniyordu (ve türler karışık sıralandığı
        // için batch kırılıyordu). Şimdi: tür başına 1 draw call, sıfır GameObject maliyeti, sıfır GC.
        struct Particle
        {
            public Vector3 pos, vel;
            public float rot, life, maxLife, startScale, endScale, gravity, spin;
            public Color color;
            public int layer;
        }

        /// <summary>Bir sprite türünün mesh katmanı.</summary>
        class Layer
        {
            public Sprite sprite;
            public Mesh mesh;
            public MeshRenderer mr;
            public Vector3[] verts;
            public Color32[] colors;
            public Vector2[] uvs;
            public int[] tris;
            public int used, lastUsed;     // bu karede / mesh'te şu an yüklü dörtgen sayısı
            public float halfW, halfH;     // 1 ölçekteki yarı boyut (dünya birimi)
        }

        class Popup
        {
            public TextMesh text, shadow, outline;
            public float life, maxLife, scale, rise, wobble;
            public bool big;
            public Vector3 start;
            public bool active;
        }

        /// <summary>Aynı anda en fazla bu kadar parçacık. Dolduğunda yeni parçacık atlanır.</summary>
        const int MaxParticles = 1200;
        readonly Particle[] _parts = new Particle[MaxParticles];
        int _count; // aktif parçacıklar dizinin başında, sıkışık tutulur (silmede sonuncuyla yer değiştirir)

        readonly List<Layer> _layers = new List<Layer>();
        readonly Dictionary<Sprite, int> _layerOf = new Dictionary<Sprite, int>();
        readonly Dictionary<string, Sprite> _spriteOf = new Dictionary<string, Sprite>();
        Material _baseMaterial;

        readonly List<Popup> _popups = new List<Popup>();
        Transform _root;
        Camera _cam;
        Vector3 _camBase;
        float _shakeTime, _shakeAmount;

        public void Init(Camera cam)
        {
            _cam = cam;
            _root = new GameObject("FX").transform;
            _root.SetParent(transform, false);
            _baseMaterial = new Material(Shader.Find("Sprites/Default"));
            // Sık kullanılan katmanları baştan kur: ilk patlamada mesh/materyal oluşturulmasın
            LayerFor("square"); LayerFor("circle"); LayerFor("star"); LayerFor("ring");
        }

        Sprite SpriteFor(string name)
        {
            if (_spriteOf.TryGetValue(name, out var sp) && sp != null) return sp;
            // "square" parçacıklar köşeleri yumuşatılmış kareyle çizilir
            sp = name == "square" ? SpriteLibrary.RoundedSquare() : SpriteLibrary.Get(name);
            _spriteOf[name] = sp;
            return sp;
        }

        int LayerFor(string name)
        {
            var sp = SpriteFor(name);
            if (sp == null) return -1;
            if (_layerOf.TryGetValue(sp, out int li)) return li;

            var go = new GameObject("FxLayer_" + name);
            go.transform.SetParent(_root, false);
            go.transform.position = Vector3.zero;   // köşeler dünya koordinatında yazılır
            go.transform.rotation = Quaternion.identity;
            var mesh = new Mesh { name = "FxMesh_" + name };
            mesh.MarkDynamic();
            var verts = new Vector3[MaxParticles * 4];
            var colors = new Color32[MaxParticles * 4];
            var uvs = new Vector2[MaxParticles * 4];
            var tris = new int[MaxParticles * 6];

            // Sprite'ın dokudaki dikdörtgeni (atlas olsa da doğru UV)
            var tex = sp.texture;
            var tr = sp.textureRect;
            float tw = tex != null ? tex.width : 1f, th = tex != null ? tex.height : 1f;
            var uv0 = new Vector2(tr.xMin / tw, tr.yMin / th);
            var uv1 = new Vector2(tr.xMax / tw, tr.yMax / th);
            for (int i = 0; i < MaxParticles; i++)
            {
                int v = i * 4, t = i * 6;
                uvs[v] = new Vector2(uv0.x, uv0.y);
                uvs[v + 1] = new Vector2(uv0.x, uv1.y);
                uvs[v + 2] = new Vector2(uv1.x, uv1.y);
                uvs[v + 3] = new Vector2(uv1.x, uv0.y);
                tris[t] = v; tris[t + 1] = v + 1; tris[t + 2] = v + 2;
                tris[t + 3] = v; tris[t + 4] = v + 2; tris[t + 5] = v + 3;
            }
            mesh.bounds = new Bounds(Vector3.zero, new Vector3(10000f, 10000f, 100f));

            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            var mr = go.AddComponent<MeshRenderer>();
            var mat = new Material(_baseMaterial) { mainTexture = tex };
            mr.sharedMaterial = mat;
            mr.sortingOrder = 60;
            mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            mr.receiveShadows = false;
            mr.enabled = false;

            // SpriteRenderer'daki görünür boyutun aynısı: piksel / ppu
            float ppu = Mathf.Max(0.0001f, sp.pixelsPerUnit);
            var layer = new Layer
            {
                sprite = sp, mesh = mesh, mr = mr, verts = verts, colors = colors, uvs = uvs, tris = tris,
                halfW = sp.rect.width / ppu * 0.5f, halfH = sp.rect.height / ppu * 0.5f
            };
            li = _layers.Count;
            _layers.Add(layer);
            _layerOf[sp] = li;
            return li;
        }

        public void SetCameraBase(Vector3 pos)
        {
            _camBase = pos;
            if (_shakeTime <= 0 && _cam != null) _cam.transform.position = pos;
        }

        static float Mult => GameSettings.Instance.particleMultiplier;

        static int Scaled(int count) => Mathf.Max(0, Mathf.RoundToInt(count * Mult));

        void Spawn(string sprite, Vector3 pos, Vector3 vel, Color c, float life, float s0, float s1, float gravity, float spin = 0f)
        {
            if (_count >= MaxParticles || life <= 0f) return;
            int layer = LayerFor(sprite);
            if (layer < 0) return;
            ref var p = ref _parts[_count++];
            p.pos = pos;
            p.vel = vel;
            p.rot = 0f;
            p.life = 0f;
            p.maxLife = life;
            p.startScale = s0;
            p.endScale = s1;
            p.gravity = gravity;
            p.spin = spin;
            p.color = c;
            p.layer = layer;
        }

        public void Burst(Vector3 pos, Color c, int count = 7)
        {
            count = Scaled(count);
            for (int i = 0; i < count; i++)
            {
                float a = Random.Range(0f, Mathf.PI * 2f);
                float sp = Random.Range(2.5f, 6f);
                var v = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0) * sp + Vector3.up * 2f;
                bool square = i % 3 == 0;
                float size = Random.Range(0.18f, 0.3f) * (square ? 1.3f : 1f); // kareler biraz daha büyük
                Spawn(square ? "square" : "circle", pos, v, c, Random.Range(0.35f, 0.6f), size, 0f, -14f, Random.Range(-400f, 400f));
            }
        }

        /// <summary>Blok parçaları: köşeleri yumuşak kare kırıntılar, yerçekimiyle düşer ve döner.</summary>
        public void Shards(Vector3 pos, Color c, int count = 4, float power = 1f)
        {
            count = Scaled(count);
            for (int i = 0; i < count; i++)
            {
                float a = Random.Range(0.2f, Mathf.PI - 0.2f);
                float sp = Random.Range(3f, 6.5f) * power;
                var v = new Vector3(Mathf.Cos(a) * 0.8f, Mathf.Sin(a), 0) * sp;
                var col = Color.Lerp(c, Color.white, Random.Range(0f, 0.25f));
                Spawn("square", pos + (Vector3)Random.insideUnitCircle * 0.25f, v, col,
                      Random.Range(0.5f, 0.8f), Random.Range(0.70f, 0.90f), 0.06f, -20f, Random.Range(-720f, 720f));
            }
        }

        /// <summary>Parıltılar: yıldız şekilli, yavaş yükselir.</summary>
        public void Sparkles(Vector3 pos, Color c, int count = 3, float radius = 0.4f)
        {
            count = Scaled(count);
            for (int i = 0; i < count; i++)
            {
                var off = (Vector3)Random.insideUnitCircle * radius;
                var v = new Vector3(Random.Range(-0.6f, 0.6f), Random.Range(0.8f, 2.2f), 0);
                var col = Color.Lerp(c, Color.white, 0.6f);
                Spawn("star", pos + off, v, col, Random.Range(0.45f, 0.75f), Random.Range(0.18f, 0.32f), 0f, 0f, Random.Range(-180f, 180f));
            }
        }

        /// <summary>Renkli konfeti patlaması (büyük zincirler için).</summary>
        public void Confetti(Vector3 pos, Color[] colors, int count = 20, float power = 1f)
        {
            count = Scaled(count);
            if (colors == null || colors.Length == 0) colors = new[] { Color.white };
            for (int i = 0; i < count; i++)
            {
                float a = Random.Range(0f, Mathf.PI * 2f);
                float sp = Random.Range(4f, 9f) * power;
                var v = new Vector3(Mathf.Cos(a), Mathf.Sin(a) * 0.8f + 0.6f, 0) * sp;
                var col = colors[Random.Range(0, colors.Length)];
                Spawn(i % 2 == 0 ? "square" : "circle", pos, v, col, Random.Range(0.7f, 1.2f),
                      Random.Range(0.12f, 0.22f), 0.08f, -12f, Random.Range(-900f, 900f));
            }
        }

        /// <summary>Genişleyen şok dalgası: iki halka üst üste.</summary>
        public void Shockwave(Vector3 pos, Color c, float maxScale = 4f)
        {
            Ring(pos, c, maxScale, 0.45f);
            var c2 = c; c2.a *= 0.5f;
            Ring(pos, c2, maxScale * 0.6f, 0.35f);
        }

        public void Ring(Vector3 pos, Color c, float maxScale = 3f, float life = 0.4f)
        {
            Spawn("ring", pos, Vector3.zero, c, life, 0.3f, maxScale, 0f);
        }

        public void Flash(Vector3 pos, Color c, float scale = 1.2f)
        {
            Spawn("circle", pos, Vector3.zero, c, 0.25f, scale, scale * 1.6f, 0f);
        }

        public void Beam(Vector3 from, Vector3 to, Color c)
        {
            int steps = Mathf.CeilToInt(Vector3.Distance(from, to) / 0.35f);
            for (int i = 0; i <= steps; i++)
            {
                var p = Vector3.Lerp(from, to, steps == 0 ? 0 : (float)i / steps);
                p += (Vector3)Random.insideUnitCircle * 0.08f;
                Spawn("circle", p, Vector3.zero, c, 0.3f, 0.22f, 0f, 0f);
            }
        }

        public void Text(Vector3 pos, string msg, Color c, float scale = 1f)
        {
            msg = Loc.T(msg);
            ShowPopup(pos, msg, c, scale, 0.9f, 1.2f, false);
        }

        /// <summary>
        /// Büyük övgü yazısı ("Amazing!" vb.): zıplayarak büyür, hafif sallanır, uzun kalır.
        /// </summary>
        public void Praise(Vector3 pos, string msg, Color c, float scale = 1.6f)
        {
            msg = Loc.T(msg); // övgü kelimeleri GameSettings'te İngilizce; çeviri tablosundan gelir
            // Aynı anda birden çok övgü üst üste binmesin: aktif olanları yukarı it
            foreach (var p in _popups)
                if (p.active && p.big) p.start += Vector3.up * 0.9f;
            ShowPopup(pos, msg, c, scale, 1.25f, 0.6f, true);
        }

        void ShowPopup(Vector3 pos, string msg, Color c, float scale, float life, float rise, bool big)
        {
            Popup pp = null;
            foreach (var p in _popups)
                if (!p.active) { pp = p; break; }
            if (pp == null)
            {
                pp = new Popup();
                pp.outline = MakeText("PopupOutline", 69);
                pp.shadow = MakeText("PopupShadow", 70);
                pp.text = MakeText("Popup", 71);
                _popups.Add(pp);
            }
            pp.active = true;
            pp.big = big;
            pp.life = 0;
            pp.maxLife = life;
            pp.rise = rise;
            pp.wobble = big ? Random.Range(-1f, 1f) : 0f;
            pp.start = pos;
            pp.scale = scale;
            pp.outline.text = msg;
            pp.outline.color = new Color(0.1f, 0.05f, 0.2f, 0.9f);
            pp.outline.gameObject.SetActive(big);
            pp.text.text = msg;
            pp.shadow.text = msg;
            pp.text.color = c;
            pp.shadow.color = new Color(0.1f, 0.05f, 0.2f, 0.85f);
            pp.text.gameObject.SetActive(true);
            pp.shadow.gameObject.SetActive(true);
            pp.text.transform.localScale = Vector3.one * scale;
            pp.shadow.transform.localScale = Vector3.one * scale;
        }

        TextMesh MakeText(string name, int order)
        {
            var go = new GameObject(name);
            go.transform.SetParent(_root, false);
            var tm = go.AddComponent<TextMesh>();
            tm.font = SpriteLibrary.Font;
            tm.fontSize = 64;
            tm.characterSize = 0.1f;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            var mr = go.GetComponent<MeshRenderer>();
            mr.sharedMaterial = tm.font.material;
            mr.sortingOrder = order;
            return tm;
        }

        public void Shake(float amount, float time)
        {
            _shakeAmount = Mathf.Max(_shakeAmount, amount);
            _shakeTime = Mathf.Max(_shakeTime, time);
        }

        static void UploadVerts(Layer L, int n)
        {
            L.mesh.SetVertices(L.verts, 0, n);
            L.mesh.SetColors(L.colors, 0, n);
            L.mesh.SetUVs(0, L.uvs, 0, n);
        }

        void UpdateParticles(float dt)
        {
            for (int l = 0; l < _layers.Count; l++) _layers[l].used = 0;

            int i = 0;
            while (i < _count)
            {
                ref var p = ref _parts[i];
                p.life += dt;
                float t = p.life / p.maxLife;
                if (t >= 1f)
                {
                    _parts[i] = _parts[--_count]; // sonuncuyu buraya taşı (sıra önemli değil)
                    continue;
                }
                p.vel.y += p.gravity * dt;
                p.pos += p.vel * dt;
                p.rot += p.spin * dt;

                var L = _layers[p.layer];
                float sc = Mathf.Lerp(p.startScale, p.endScale, t);
                float hw = L.halfW * sc, hh = L.halfH * sc;
                float rad = p.rot * Mathf.Deg2Rad;
                float cs = Mathf.Cos(rad), sn = Mathf.Sin(rad);
                // Döndürülmüş dörtgenin köşe vektörleri
                float ax = cs * hw, ay = sn * hw;    // yerel x ekseni * yarı genişlik
                float bx = -sn * hh, by = cs * hh;   // yerel y ekseni * yarı yükseklik
                var c = p.color;
                c.a = p.color.a * (1f - t * t);
                Color32 c32 = c;

                int v = L.used * 4;
                float z = p.pos.z;
                L.verts[v]     = new Vector3(p.pos.x - ax - bx, p.pos.y - ay - by, z);
                L.verts[v + 1] = new Vector3(p.pos.x - ax + bx, p.pos.y - ay + by, z);
                L.verts[v + 2] = new Vector3(p.pos.x + ax + bx, p.pos.y + ay + by, z);
                L.verts[v + 3] = new Vector3(p.pos.x + ax - bx, p.pos.y + ay - by, z);
                L.colors[v] = c32; L.colors[v + 1] = c32; L.colors[v + 2] = c32; L.colors[v + 3] = c32;
                L.used++;
                i++;
            }

            for (int l = 0; l < _layers.Count; l++)
            {
                var L = _layers[l];
                if (L.used == 0)
                {
                    L.mr.enabled = false; // boş katman çizilmez, mesh'e dokunulmaz
                    continue;
                }
                // Mesh yalnızca kullanılan dörtgen kadar yüklenir. Unity köşe sayısı ile üçgen indekslerini her çağrıda
                // doğrular: küçülürken önce üçgenler, büyürken önce köşeler ayarlanmalı.
                int nv = L.used * 4, ni = L.used * 6;
                if (L.used < L.lastUsed)
                {
                    L.mesh.SetTriangles(L.tris, 0, ni, 0, false);
                    UploadVerts(L, nv);
                }
                else if (L.used > L.lastUsed)
                {
                    UploadVerts(L, nv);
                    L.mesh.SetTriangles(L.tris, 0, ni, 0, false);
                }
                else UploadVerts(L, nv);
                L.mr.enabled = true;
                L.lastUsed = L.used;
            }
        }

        void Update()
        {
            float dt = Time.deltaTime;

            UpdateParticles(dt);

            foreach (var p in _popups)
            {
                if (!p.active) continue;
                p.life += dt;
                float t = p.life / p.maxLife;
                if (t >= 1f)
                {
                    p.active = false;
                    p.text.gameObject.SetActive(false);
                    p.shadow.gameObject.SetActive(false);
                    p.outline.gameObject.SetActive(false);
                    continue;
                }
                float rise = 1f - (1f - t) * (1f - t);
                var pos = p.start + Vector3.up * rise * p.rise;
                p.text.transform.position = pos;
                p.shadow.transform.position = pos + new Vector3(0.04f, -0.05f, 0) * (p.big ? 1.8f : 1f);
                p.outline.transform.position = pos + new Vector3(0, -0.02f, 0);
                float a = t < 0.7f ? 1f : 1f - (t - 0.7f) / 0.3f;
                var c = p.text.color; c.a = a; p.text.color = c;
                var sc = p.shadow.color; sc.a = a * 0.85f; p.shadow.color = sc;
                var oc = p.outline.color; oc.a = a * 0.9f; p.outline.color = oc;

                float pop;
                if (p.big)
                {
                    // Elastik zıplama: 0 → 1.35 → 0.92 → 1
                    if (t < 0.12f) pop = Mathf.Lerp(0.2f, 1.35f, t / 0.12f);
                    else if (t < 0.22f) pop = Mathf.Lerp(1.35f, 0.92f, (t - 0.12f) / 0.1f);
                    else pop = Mathf.Lerp(0.92f, 1f, Mathf.Min(1f, (t - 0.22f) / 0.12f));
                    if (t > 0.8f) pop *= 1f + (t - 0.8f) * 0.8f;
                    float rot = Mathf.Sin(t * 18f) * 6f * (1f - t) * p.wobble;
                    var q = Quaternion.Euler(0, 0, rot);
                    p.text.transform.rotation = q;
                    p.shadow.transform.rotation = q;
                    p.outline.transform.rotation = q;
                }
                else
                {
                    pop = t < 0.15f ? Mathf.Lerp(0.6f, 1.1f, t / 0.15f) : Mathf.Lerp(1.1f, 1f, Mathf.Min(1, (t - 0.15f) / 0.2f));
                    p.text.transform.rotation = Quaternion.identity;
                    p.shadow.transform.rotation = Quaternion.identity;
                }
                p.text.transform.localScale = Vector3.one * pop * p.scale;
                p.shadow.transform.localScale = p.text.transform.localScale;
                p.outline.transform.localScale = p.text.transform.localScale * 1.08f;
            }

            if (_cam != null)
            {
                if (_shakeTime > 0)
                {
                    _shakeTime -= dt;
                    var off = (Vector3)Random.insideUnitCircle * _shakeAmount;
                    _cam.transform.position = _camBase + off;
                    _shakeAmount = Mathf.Lerp(_shakeAmount, 0, dt * 6f);
                    if (_shakeTime <= 0) _cam.transform.position = _camBase;
                }
            }
        }
    }
}
