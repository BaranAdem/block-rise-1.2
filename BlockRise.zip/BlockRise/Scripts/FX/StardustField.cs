using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Katmanlı, paralakslı arka plan yıldız tozu.
    ///
    ///  • Dört tür zerre: uzak toz (çok küçük, silik, yavaş), yıldız (orta), parıltı (4 kollu ışık)
    ///    ve bokeh (yakında, büyük, çok saydam, odak dışı disk). Yakındakiler daha çok hareket eder → derinlik.
    ///  • Boştayken: alan çok yavaşça yukarı süzülür, her zerre kendi hızında parıldar. Ekran dışında sarmalanır.
    ///  • Blok sürüklenirken alan parmağa belirgin şekilde eşlik eder (derinliğe göre); hamle bırakılınca o yöne itilip yavaşça durur
    ///    (geri sıçramaz). Hızlı akışta zerreler hareket yönünde hafifçe uzar.
    ///  • Her patlamada: dışa yayılan dalga zerreleri iter, parlatır ve kısa süreliğine patlayan bloğun rengine
    ///    boyar (renk bir an tutulur, sonra yıldız eski rengine döner; zerre yayla yerine döner).
    ///  • Chain: dalga güçlenir, girdap gibi döner; alanın enerjisi bir süre yüksek kalır.
    ///
    /// Tek mesh, tek draw call. Kullanım:
    ///   StardustField.Emit(dünyaKonumu, renk, chain, blokSayısı);
    ///   StardustField.SetDrag(sürüklemeX);  StardustField.ReleaseDrag(kaydırma);
    /// Ayarlar: GameSettings > Stardust.
    /// </summary>
    [DisallowMultipleComponent]
    public class StardustField : MonoBehaviour
    {
        public static StardustField Instance { get; private set; }

        [Header("Alan")]
        [Tooltip("Zerre sayısı (GameSettings.particleMultiplier ile çarpılır)")]
        public int count = 500;
        [Tooltip("Zerrelerin kendi küçük yörüngelerinin genliği")]
        public float orbit = 0.06f;

        [Header("Patlama dalgası")]
        [Tooltip("Dalganın yayılma hızı (birim/sn)")]
        public float waveSpeed = 15f;
        [Tooltip("Dalga cephesinin kalınlığı")]
        public float waveWidth = 0.9f;
        [Tooltip("Dalganın ömrü (sn)")]
        public float waveLife = 1.7f;
        [Tooltip("Dalganın zerreleri itme gücü")]
        public float push = 40f;

        [Header("Yay (geri dönüş)")]
        [Tooltip("Zerrelerin yerine dönme sertliği")]
        public float stiffness = 6f;
        [Tooltip("Sönümleme (düşük = daha çok salınım)")]
        public float damping = 1f;

        const int MaxWaves = 12;
        const int SortingOrder = -100;
        const float FieldScale = 1.3f;      // alan ekrandan büyük → sarmalama ekran dışında olur, görünmez
        const float FlowDecay = 2.2f;       // hamle itişinin sönme hızı
        static readonly Vector2 DriftDir = new Vector2(0.18f, 1f); // boştaki süzülme yönü (hafif sağa, yukarı)

        enum Kind : byte { Dust, Star, Sparkle, Bokeh }

        struct Wave
        {
            public Vector2 Center;
            public Color Color;
            public float Start, Strength, Swirl;
        }

        Camera _cam;
        Mesh _mesh;
        Vector3[] _verts;
        Color32[] _colors;
        int _n;

        // Zerre durumu
        Vector2[] _home;      // alan içindeki konum (0..1)
        Vector2[] _off, _vel; // patlama dalgası yayı
        Vector4[] _phase;     // yörünge x/y, parıltı, yedek
        float[] _par;         // paralaks: 0.1 = uzak (az hareket) .. 0.95 = yakın (çok hareket)
        float[] _size, _alpha, _twF, _twA, _glow, _tintW, _tintHold;
        Color[] _base, _tint;
        Kind[] _kind;

        readonly List<Wave> _waves = new List<Wave>();
        float _energy;
        float _time;

        // Alanın toplu hareketi (paralaks = 1 için dünya birimi)
        Vector2 _scroll;      // birikmiş kayma
        Vector2 _flowVel;     // hamle itişi, zamanla söner
        float _dragTarget, _dragShift, _dragVel;

        // ================================================================ Dış API

        /// <summary>Patlama/chain dalgası başlatır. Alan yoksa sessizce hiçbir şey yapmaz.</summary>
        public static void Emit(Vector3 worldPos, Color color, int chain, int blockCount)
        {
            if (Instance != null) Instance.Pulse(worldPos, color, chain, blockCount);
        }

        /// <summary>Sürükleme sırasında her karede çağrılır (bloğun yatay kayması, hücre).</summary>
        public static void SetDrag(float offsetX)
        {
            if (Instance == null) return;
            Instance._dragTarget = offsetX * GameSettings.Instance.stardustDragAmount;
        }

        /// <summary>Sürükleme bitince çağrılır. shift != 0 ise alan o yöne itilir ve orada kalır.</summary>
        public static void ReleaseDrag(int shift)
        {
            var f = Instance;
            if (f == null) return;
            if (shift != 0)
            {
                // Sürüklemeyle oluşan kaymayı kalıcı hale getir → bırakınca geri sıçramaz
                f._scroll.x += f._dragShift;
                f._dragShift = 0f;
                // Uzun kaydırmalar orantısız savurmasın diye karekök
                f._flowVel.x += Mathf.Sign(shift) * Mathf.Sqrt(Mathf.Abs(shift)) * GameSettings.Instance.stardustReleasePush;
            }
            f._dragTarget = 0f; // iptal edilen sürüklemede alan yumuşakça yerine döner
        }

        void Awake()
        {
            Instance = this;
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        // ================================================================ Kurulum

        public void Init(Camera cam)
        {
            _cam = cam;
            if (_cam == null) return;

            float mult = Mathf.Clamp(GameSettings.Instance.particleMultiplier, 0.3f, 1.5f);
            _n = Mathf.Max(40, Mathf.RoundToInt(count * mult));

            // Kameranın çocuğu: arka planın (z=20) önünde, blokların arkasında
            var go = new GameObject("Stardust");
            go.transform.SetParent(_cam.transform, false);
            go.transform.localPosition = new Vector3(0f, 0f, 19f);

            _mesh = new Mesh { name = "StardustMesh" };
            _mesh.MarkDynamic();
            go.AddComponent<MeshFilter>().sharedMesh = _mesh;
            var mr = go.AddComponent<MeshRenderer>();
            var mat = new Material(Shader.Find("Sprites/Default")) { mainTexture = AtlasTexture() };
            mr.sharedMaterial = mat;
            mr.sortingOrder = SortingOrder;
            mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            mr.receiveShadows = false;

            Allocate();
        }

        void Allocate()
        {
            var rnd = new System.Random(1928);
            float R(float a, float b) => a + (float)rnd.NextDouble() * (b - a);

            _home = new Vector2[_n];
            _off = new Vector2[_n];
            _vel = new Vector2[_n];
            _phase = new Vector4[_n];
            _par = new float[_n];
            _size = new float[_n];
            _alpha = new float[_n];
            _twF = new float[_n];
            _twA = new float[_n];
            _glow = new float[_n];
            _tintW = new float[_n];
            _tintHold = new float[_n];
            _base = new Color[_n];
            _tint = new Color[_n];
            _kind = new Kind[_n];

            var uvs = new Vector2[_n * 4];
            var tris = new int[_n * 6];

            for (int i = 0; i < _n; i++)
            {
                _home[i] = new Vector2(R(0f, 1f), R(0f, 1f));
                _phase[i] = new Vector4(R(0f, 6.283f), R(0f, 6.283f), R(0f, 6.283f), R(0.6f, 1.4f));

                // Tür dağılımı: çoğu uzak toz, az sayıda parıltı ve bokeh
                float r = R(0f, 1f);
                Kind k;
                if (r < 0.62f)
                {
                    k = Kind.Dust;
                    _par[i] = R(0.08f, 0.25f);
                    _size[i] = R(0.032f, 0.052f);
                    _alpha[i] = R(0.30f, 0.60f);
                    _twA[i] = R(0.25f, 0.65f);
                    _twF[i] = R(0.8f, 2.6f);
                }
                else if (r < 0.92f)
                {
                    k = Kind.Star;
                    _par[i] = R(0.30f, 0.55f);
                    _size[i] = R(0.055f, 0.090f);
                    _alpha[i] = R(0.55f, 0.90f);
                    _twA[i] = R(0.10f, 0.40f);
                    _twF[i] = R(0.5f, 1.6f);
                }
                else if (r < 0.965f)
                {
                    k = Kind.Sparkle;
                    _par[i] = R(0.45f, 0.65f);
                    _size[i] = R(0.13f, 0.20f);
                    _alpha[i] = R(0.55f, 0.90f);
                    _twA[i] = R(0.35f, 0.75f);
                    _twF[i] = R(0.35f, 0.9f);
                }
                else
                {
                    k = Kind.Bokeh;
                    _par[i] = R(0.75f, 0.95f);
                    _size[i] = R(0.26f, 0.46f);
                    _alpha[i] = R(0.045f, 0.09f);
                    _twA[i] = R(0.05f, 0.15f);
                    _twF[i] = R(0.2f, 0.4f);
                }
                _kind[i] = k;

                // Hafif sıcak/soğuk ton farkı: tamamen beyaz yıldız alanı düz görünür
                float c = R(0f, 1f);
                _base[i] = c < 0.68f ? new Color(1f, 1f, 1f)
                         : c < 0.87f ? new Color(0.80f, 0.89f, 1f)    // soğuk mavi-beyaz
                                     : new Color(1f, 0.91f, 0.78f);  // sıcak
                _tint[i] = _base[i];

                // Atlas: [yuvarlak ışık | 4 kollu parıltı | bokeh diski]
                int cell = k == Kind.Sparkle ? 1 : k == Kind.Bokeh ? 2 : 0;
                const float pad = 0.5f / 64f;
                float u0 = cell / 3f + pad / 3f, u1 = (cell + 1) / 3f - pad / 3f;
                int v = i * 4, t = i * 6;
                uvs[v] = new Vector2(u0, 0f); uvs[v + 1] = new Vector2(u0, 1f);
                uvs[v + 2] = new Vector2(u1, 1f); uvs[v + 3] = new Vector2(u1, 0f);
                tris[t] = v; tris[t + 1] = v + 1; tris[t + 2] = v + 2;
                tris[t + 3] = v; tris[t + 4] = v + 2; tris[t + 5] = v + 3;
            }

            _verts = new Vector3[_n * 4];
            _colors = new Color32[_n * 4];
            _mesh.vertices = _verts;
            _mesh.uv = uvs;
            _mesh.colors32 = _colors;
            _mesh.triangles = tris;
            _mesh.bounds = new Bounds(Vector3.zero, new Vector3(1000f, 1000f, 10f));
        }

        public void Pulse(Vector3 worldPos, Color color, int chain, int blockCount)
        {
            if (_cam == null || _n == 0) return;
            chain = Mathf.Max(1, chain);
            Vector3 local = _cam.transform.InverseTransformPoint(worldPos);

            var w = new Wave
            {
                Center = new Vector2(local.x, local.y),
                Color = color,
                Start = _time,
                Strength = Mathf.Min(2.2f, 0.55f + 0.35f * (chain - 1) + 0.03f * blockCount),
                Swirl = chain < 2 ? 0f : 0.6f * Mathf.Min(chain, 5),
            };
            if (_waves.Count >= MaxWaves) _waves.RemoveAt(0);
            _waves.Add(w);
            _energy = Mathf.Min(3f, _energy + 0.35f * chain);
        }

        // ================================================================ Güncelleme

        void LateUpdate()
        {
            if (_cam == null || _mesh == null) return;
            float dt = Mathf.Min(Time.deltaTime, 0.05f);
            if (dt <= 0f) return;
            _time += dt;
            var gs = GameSettings.Instance;

            float viewH = _cam.orthographicSize * 2f;
            float viewW = viewH * _cam.aspect;
            float fw = viewW * FieldScale, fh = viewH * FieldScale;

            // --- Alanın toplu hareketi
            _scroll += _flowVel * dt;
            _flowVel *= Mathf.Exp(-dt * FlowDecay);
            float drift = gs.stardustDrift * (1f + _energy * 0.6f);
            _scroll += DriftDir * (drift * dt);

            float prevDrag = _dragShift;
            _dragShift = Mathf.Lerp(_dragShift, _dragTarget, 1f - Mathf.Exp(-dt * gs.stardustDragResponse));
            _dragVel = Mathf.Lerp(_dragVel, (_dragShift - prevDrag) / dt, 1f - Mathf.Exp(-dt * 20f));
            float flowX = _flowVel.x + _dragVel; // yatay akış hızı (uzama için)

            // Süresi dolan dalgaları at
            for (int k = _waves.Count - 1; k >= 0; k--)
                if (_time - _waves[k].Start > waveLife) _waves.RemoveAt(k);

            float glowDecay = Mathf.Exp(-dt * 2f);
            float tintDecay = Mathf.Exp(-dt * gs.stardustTintFade);
            float tintStrength = gs.stardustTintStrength;
            float tintHold = gs.stardustTintHold;
            float bright = gs.stardustBrightness * (1f + 0.15f * _energy);

            for (int i = 0; i < _n; i++)
            {
                float p = _par[i];
                var ph = _phase[i];

                // Paralakslı konum + ekran dışında sarmalama
                float x = _home[i].x * fw + (_scroll.x + _dragShift) * p;
                float y = _home[i].y * fh + _scroll.y * p;
                x = Mathf.Repeat(x, fw) - fw * 0.5f;
                y = Mathf.Repeat(y, fh) - fh * 0.5f;

                // Kişisel küçük yörünge (yakındakiler daha geniş)
                float o = orbit * (0.4f + p);
                var basePos = new Vector2(
                    x + Mathf.Sin(_time * 0.37f * ph.w + ph.x) * o,
                    y + Mathf.Cos(_time * 0.29f * ph.w + ph.y) * o);

                var pos = basePos + _off[i];
                var acc = -stiffness * _off[i] - damping * _vel[i];
                float resp = 0.45f + 0.6f * p; // yakındakiler dalgaya daha çok tepki verir

                // Patlama dalgaları
                for (int k = 0; k < _waves.Count; k++)
                {
                    var w = _waves[k];
                    float age = _time - w.Start;
                    float r = waveSpeed * age;
                    var d = pos - w.Center;
                    float dist = d.magnitude + 1e-4f;
                    float xx = (dist - r) / waveWidth;
                    if (xx > 3f || xx < -3f) continue; // cepheden uzak → etkisiz
                    float life = 1f - age / waveLife;
                    float inf = w.Strength * Mathf.Exp(-xx * xx) * life * Mathf.Sqrt(life) * resp;
                    var dir = d / dist;
                    acc += dir * (inf * push);
                    if (w.Swirl > 0f) acc += new Vector2(-dir.y, dir.x) * (inf * push * w.Swirl);

                    float c = Mathf.Min(1f, inf);
                    if (c > _glow[i]) _glow[i] = c;
                    if (c > 0.12f)
                    {
                        // Dalga değdi → yıldız hızla patlayan bloğun rengine geçer ve bir süre öyle kalır
                        _tint[i] = Color.Lerp(_tint[i], w.Color, Mathf.Min(1f, c * 3f));
                        float tw = Mathf.Min(1f, c * 2.5f);
                        if (tw > _tintW[i]) _tintW[i] = tw;
                        _tintHold[i] = tintHold;
                    }
                }

                _vel[i] += acc * dt;
                _off[i] += _vel[i] * dt;
                _glow[i] *= glowDecay;
                if (_tintHold[i] > 0f) _tintHold[i] -= dt; // renk tutuluyor
                else _tintW[i] *= tintDecay;              // sonra yavaşça eski rengine döner
                if (_tintW[i] < 0.01f) { _tintW[i] = 0f; _tint[i] = _base[i]; }
                float tintK = _tintW[i] * tintStrength;

                // Parıltı: her zerre kendi hızında ve derinliğinde
                float twk = 1f - _twA[i] * (0.5f + 0.5f * Mathf.Sin(_time * _twF[i] + ph.z));
                float glowBoost = _kind[i] == Kind.Bokeh ? 0.25f : 0.9f; // bokeh patlamada az parlasın
                // Renklenen yıldız biraz parlak kalsın ki renk silik tozda kaybolmasın
                float a = Mathf.Clamp01(_alpha[i] * twk * bright + _glow[i] * glowBoost + tintK * glowBoost * 0.35f);
                var col = Color.Lerp(_base[i], _tint[i], tintK);
                col.a = a;

                // Boyut: patlamada büyür; akış hızlıysa hareket yönünde uzar
                float s = _size[i] * (1f + _glow[i] * (_kind[i] == Kind.Bokeh ? 0.2f : 1.1f));
                // Bokeh uzamaz (odak dışı disk ovalleşince yapay durur)
                float stretch = _kind[i] == Kind.Bokeh ? 1f : 1f + Mathf.Min(0.9f, Mathf.Abs(flowX) * p * 0.35f);
                float sx = s * stretch, sy = s / Mathf.Sqrt(stretch);

                pos = basePos + _off[i];
                int v = i * 4;
                _verts[v] = new Vector3(pos.x - sx, pos.y - sy, 0f);
                _verts[v + 1] = new Vector3(pos.x - sx, pos.y + sy, 0f);
                _verts[v + 2] = new Vector3(pos.x + sx, pos.y + sy, 0f);
                _verts[v + 3] = new Vector3(pos.x + sx, pos.y - sy, 0f);
                Color32 c32 = col;
                _colors[v] = c32; _colors[v + 1] = c32; _colors[v + 2] = c32; _colors[v + 3] = c32;
            }

            _energy *= Mathf.Exp(-dt * 0.55f);
            _mesh.vertices = _verts;
            _mesh.colors32 = _colors;
        }

        // ================================================================ Doku

        /// <summary>
        /// 3 hücreli atlas (192x64):
        ///   0: keskin çekirdek + dar hale (toz ve yıldızlar)
        ///   1: 4 kollu parıltı (ince yatay/dikey ışık çizgileri + çekirdek)
        ///   2: bokeh — yumuşak kenarlı, kenarı hafif parlak odak dışı disk
        /// </summary>
        static Texture2D AtlasTexture()
        {
            const int n = 64, w = n * 3;
            var t = new Texture2D(w, n, TextureFormat.RGBA32, false);
            var px = new Color[w * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = (x + 0.5f) / n * 2f - 1f, dy = (y + 0.5f) / n * 2f - 1f;
                    float r2 = dx * dx + dy * dy, r = Mathf.Sqrt(r2);
                    float edge = Mathf.Clamp01((1f - r2) * 3f); // kenarda tam sıfır → atlas taşması olmaz

                    // 0: yıldız
                    float core = Mathf.Exp(-r2 / (2f * 0.13f * 0.13f));
                    float halo = Mathf.Exp(-r2 / (2f * 0.38f * 0.38f)) * 0.22f;
                    float a0 = Mathf.Clamp01(core + halo) * edge;

                    // 1: parıltı — ince çapraz ışınlar uca doğru incelir
                    float rayH = Mathf.Exp(-(dy * dy) / (2f * 0.035f * 0.035f)) * Mathf.Clamp01(1f - Mathf.Abs(dx));
                    float rayV = Mathf.Exp(-(dx * dx) / (2f * 0.035f * 0.035f)) * Mathf.Clamp01(1f - Mathf.Abs(dy));
                    float spCore = Mathf.Exp(-r2 / (2f * 0.09f * 0.09f));
                    float spHalo = Mathf.Exp(-r2 / (2f * 0.30f * 0.30f)) * 0.18f;
                    float a1 = Mathf.Clamp01(spCore + spHalo + (rayH + rayV) * 0.75f) * edge;

                    // 2: bokeh — düz iç, yumuşak kenar, kenarda hafif halka
                    float disc = 1f - Mathf.SmoothStep(0.72f, 0.92f, r);
                    float ring = Mathf.Exp(-((r - 0.8f) * (r - 0.8f)) / (2f * 0.05f * 0.05f)) * 0.35f;
                    float a2 = Mathf.Clamp01(disc * 0.75f + ring) * edge;

                    px[y * w + x] = new Color(1f, 1f, 1f, a0);
                    px[y * w + x + n] = new Color(1f, 1f, 1f, a1);
                    px[y * w + x + 2 * n] = new Color(1f, 1f, 1f, a2);
                }
            t.SetPixels(px);
            t.wrapMode = TextureWrapMode.Clamp;
            t.filterMode = FilterMode.Bilinear;
            t.Apply();
            return t;
        }
    }
}
