using UnityEngine;

namespace BlockRise
{
    /// <summary>İlerleme kaydı (PlayerPrefs).</summary>
    public static class SaveSystem
    {
        const string KeyBest = "br_best_endless";
        const string KeyUnlocked = "br_unlocked";
        const string KeyStars = "br_stars_";
        const string KeyTutorial = "br_tutorial_seen";
        const string KeySound = "br_sound_on";
        const string KeyHaptics = "br_haptics_on";
        const string KeyLevelPack = "br_level_pack";
        const string KeyAdsRemoved = "br_ads_removed";

        /// <summary>Bölüm seti değiştiğinde artır: eski bölümlere ait yıldızlar ve açık bölüm sıfırlanır.</summary>
        public const int LevelPackVersion = 2;

        /// <summary>Kayıtlı bölüm seti eskiyse bölüm ilerlemesini sıfırlar (en iyi skor, ses ve tutorial korunur).</summary>
        public static void MigrateLevelPack(int maxLevels = 1000)
        {
            if (PlayerPrefs.GetInt(KeyLevelPack, 1) == LevelPackVersion) return;
            PlayerPrefs.DeleteKey(KeyUnlocked);
            for (int i = 0; i < maxLevels; i++) PlayerPrefs.DeleteKey(KeyStars + i);
            ForgetStarCache();
            PlayerPrefs.SetInt(KeyLevelPack, LevelPackVersion);
            PlayerPrefs.Save();
        }

        public static bool SoundOn
        {
            get => PlayerPrefs.GetInt(KeySound, 1) == 1;
            set { PlayerPrefs.SetInt(KeySound, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        /// <summary>Reklam kaldırma satın alındı mı (banner ve geçiş reklamları kapanır).</summary>
        public static bool AdsRemoved
        {
            get => PlayerPrefs.GetInt(KeyAdsRemoved, 0) == 1;
            set { PlayerPrefs.SetInt(KeyAdsRemoved, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        public static bool HapticsOn
        {
            get => PlayerPrefs.GetInt(KeyHaptics, 1) == 1;
            set { PlayerPrefs.SetInt(KeyHaptics, value ? 1 : 0); PlayerPrefs.Save(); }
        }


        public static int BestEndless
        {
            get => PlayerPrefs.GetInt(KeyBest, 0);
            set { PlayerPrefs.SetInt(KeyBest, value); PlayerPrefs.Save(); }
        }

        /// <summary>Açık olan en yüksek level index'i (0 tabanlı).</summary>
        public static int UnlockedLevel
        {
            get => PlayerPrefs.GetInt(KeyUnlocked, 0);
            set { PlayerPrefs.SetInt(KeyUnlocked, value); PlayerPrefs.Save(); }
        }

        // PERFORMANS: yıldızlar bellekte önbelleklenir. 1000 bölümde menü/Adventure her açılışta binlerce PlayerPrefs okuması
        // yapıyordu (Android'de her biri bir JNI çağrısı). İlk erişimde bir kez okunur, yazmalar önbelleği de günceller.
        static int[] _stars;

        static void EnsureStars(int levelIndex)
        {
            if (_stars != null && levelIndex < _stars.Length) return;
            int n = Mathf.Max(LevelDatabase.MaxLevels, levelIndex + 1);
            var arr = new int[n];
            int from = 0;
            if (_stars != null) { System.Array.Copy(_stars, arr, _stars.Length); from = _stars.Length; }
            for (int i = from; i < n; i++) arr[i] = PlayerPrefs.GetInt(KeyStars + i, 0);
            _stars = arr;
        }

        /// <summary>Önbelleği unutur (veri sıfırlama / bölüm seti göçünden sonra).</summary>
        public static void ForgetStarCache() => _stars = null;

        public static int GetStars(int levelIndex)
        {
            if (levelIndex < 0) return 0;
            EnsureStars(levelIndex);
            return _stars[levelIndex];
        }

        public static void SetStars(int levelIndex, int stars)
        {
            if (levelIndex < 0) return;
            if (stars > GetStars(levelIndex))
            {
                _stars[levelIndex] = stars;
                PlayerPrefs.SetInt(KeyStars + levelIndex, stars);
                PlayerPrefs.Save();
            }
        }

        public static int TotalStars(int levelCount)
        {
            int t = 0;
            for (int i = 0; i < levelCount; i++) t += GetStars(i);
            return t;
        }

        public static bool TutorialSeen
        {
            get => PlayerPrefs.GetInt(KeyTutorial, 0) == 1;
            set { PlayerPrefs.SetInt(KeyTutorial, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        const string KeyResetVersion = "br_data_reset_version";

        /// <summary>
        /// GameSettings.dataResetVersion değiştiyse tüm oyuncu verisini bir kez siler (oyun ilk kez indirilmiş gibi).
        /// Açılışta her şeyden önce çağrılmalı. true: sıfırlama yapıldı.
        /// Satın almalar (reklam kaldırma) KORUNUR: para ödeyen oyuncu güncellemeyle hakkını kaybetmez.
        /// </summary>
        public static bool ApplyDataReset(int version)
        {
            if (version <= 0) return false;
            if (PlayerPrefs.GetInt(KeyResetVersion, 0) == version) return false;
            ResetAll(keepPurchases: true);
            PlayerPrefs.SetInt(KeyResetVersion, version); // DeleteAll'dan sonra yazılır, bir daha çalışmaz
            PlayerPrefs.Save();
            Debug.Log("[BlockRise] Oyuncu verisi sıfırlandı (reset version " + version + ").");
            return true;
        }

        /// <summary>
        /// Tüm oyuncu verisini siler: en iyi skor, yıldızlar, açık bölümler, madalyalar, seri,
        /// ayarlar, tutorial, yarım kalmış Classic oyunu ve yerel istatistikler.
        /// keepPurchases true ise reklam kaldırma satın alımı korunur (canlı güncellemede sıfırlama). false yalnızca geliştirici içindir (Editor menüsü: tam temiz kurulum).
        /// </summary>
        public static void ResetAll(bool keepPurchases = true)
        {
            bool adsRemoved = keepPurchases && AdsRemoved;

            PlayerPrefs.DeleteAll();
            ForgetStarCache();
            if (adsRemoved) PlayerPrefs.SetInt(KeyAdsRemoved, 1);
            PlayerPrefs.Save();
            EndlessSave.Clear();
            LocalStats.Reset();
            PlayerModel.ForgetCache();
        }
    }
}
