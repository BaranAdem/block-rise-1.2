using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Efekt sesleri. Sesler Resources/BlockRiseSounds/ klasöründen isimle yüklenir.
    /// Küçük bir AudioSource havuzundan çalınır, böylece her ses kendi perdesiyle (pitch) çalabilir.
    /// Ses açık-kapalı durumu SaveSystem'de saklanır.
    /// </summary>
    public class SoundManager : MonoBehaviour
    {
        public static SoundManager Instance { get; private set; }

        const string Folder = "BlockRiseSounds/";
        const int PoolSize = 10;

        readonly List<AudioSource> _pool = new List<AudioSource>();
        int _next;
        readonly Dictionary<string, AudioClip> _cache = new Dictionary<string, AudioClip>();
        readonly HashSet<string> _missing = new HashSet<string>();

        public bool SoundOn { get; private set; }

        GameSettings S => GameSettings.Instance;

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            for (int i = 0; i < PoolSize; i++)
            {
                var src = gameObject.AddComponent<AudioSource>();
                src.loop = false;
                src.playOnAwake = false;
                _pool.Add(src);
            }

            SoundOn = SaveSystem.SoundOn;
        }

        void Start() => StartCoroutine(Warmup());

        /// <summary>
        /// PERFORMANS: tüm efekt seslerini açılışta, karelere yayarak arka planda yükler. Önceden her ses oyunda
        /// İLK KEZ çaldığında o karede diskten okunup çözülüyordu (ilk patlama/zincir/bomba anında takılma).
        /// </summary>
        System.Collections.IEnumerator Warmup()
        {
            var s = S;
            var lists = new[]
            {
                s.sfxButton, s.sfxPick, s.sfxDrag, s.sfxPlace, s.sfxLand, s.sfxPop, s.sfxChain, s.sfxRise,
                s.sfxBomb, s.sfxBolt, s.sfxPraise, s.sfxWin, s.sfxPerfect, s.sfxMedal, s.sfxLose,
            };
            foreach (var names in lists)
            {
                if (names == null) continue;
                foreach (var name in names)
                {
                    if (string.IsNullOrEmpty(name) || _cache.ContainsKey(name)) continue;
                    var req = Resources.LoadAsync<AudioClip>(Folder + name);
                    yield return req;
                    if (_cache.ContainsKey(name)) continue; // bu arada PlaySFX zaten yükledi
                    var clip = req.asset as AudioClip;
                    if (clip == null) continue;         // eksik ses: uyarıyı Load versin
                    _cache[name] = clip;
                    if (clip.loadState == AudioDataLoadState.Unloaded) clip.LoadAudioData();
                }
            }
        }

        AudioClip Load(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            if (_cache.TryGetValue(name, out var c)) return c;
            c = Resources.Load<AudioClip>(Folder + name);
            if (c == null && _missing.Add(name))
                Debug.LogWarning("[BlockRise] Ses bulunamadı: Resources/" + Folder + name);
            _cache[name] = c;
            return c;
        }

        // ---------------------------------------------------------------- SFX

        public void PlaySFX(string soundName, float pitch = 1f, float volume = 1f)
        {
            if (!SoundOn) return;
            var clip = Load(soundName);
            if (clip == null) return;
            var src = _pool[_next];
            _next = (_next + 1) % _pool.Count;
            src.pitch = Mathf.Clamp(pitch, 0.1f, 3f);
            src.volume = S.sfxVolume * volume;
            src.clip = clip;
            src.Play();
        }

        /// <summary>Listeden rastgele bir ses, verilen perdeyle.</summary>
        public void PlayFrom(string[] soundNames, float pitch = 1f, float volume = 1f)
        {
            if (soundNames == null || soundNames.Length == 0) return;
            PlaySFX(soundNames[Random.Range(0, soundNames.Length)], pitch, volume);
        }

        readonly Dictionary<string[], int> _lastIndex = new Dictionary<string[], int>();
        readonly Dictionary<string[], float> _lastTime = new Dictionary<string[], float>();

        /// <summary>
        /// Dokunsal (ASMR) sesler için: her çalışta hafif rastgele perde ve ses düzeyi,
        /// aynı varyasyon üst üste gelmez ve çok sık tetiklenirse (minGap saniye) atlanır.
        /// </summary>
        public void PlayOrganic(string[] soundNames, float volume = 1f, float pitch = 1f, float minGap = 0.035f)
        {
            int idx = PickVariant(soundNames, minGap);
            if (idx < 0) return;
            float j = S.organicPitchJitter;
            PlaySFX(soundNames[idx], pitch * Semitones(Random.Range(-j, j)), volume * Random.Range(0.88f, 1f));
        }

        /// <summary>
        /// Müzikal hareket sesi (Tetris Effect gibi): blok her hücre kaydığında pentatonik dizide bir nota çalar.
        /// step = başlangıçtan kaç hücre uzakta (sağa +, sola −) → sağa kaydırmak tizleşen, sola pesleşen bir melodi.
        /// Sesler köke (D) akortludur; perde rastgele kaydırılmaz, yalnızca ses düzeyi ve tını varyasyonu değişir.
        /// </summary>
        public void PlayScaleNote(string[] soundNames, int step, float volume = 1f, float minGap = 0.03f)
        {
            int idx = PickVariant(soundNames, minGap);
            if (idx < 0) return;
            int semis = PentatonicSemitones(Mathf.Clamp(step, -7, 7));
            PlaySFX(soundNames[idx], Semitones(semis), volume * Random.Range(0.9f, 1f));
        }

        /// <summary>Listeden, bir öncekiyle aynı olmayan bir varyasyon seçer. Çok sık tetiklenirse -1.</summary>
        int PickVariant(string[] soundNames, float minGap)
        {
            if (!SoundOn || soundNames == null || soundNames.Length == 0) return -1;
            float now = Time.unscaledTime;
            if (_lastTime.TryGetValue(soundNames, out var last) && now - last < minGap) return -1;
            _lastTime[soundNames] = now;

            int idx = Random.Range(0, soundNames.Length);
            if (soundNames.Length > 1 && _lastIndex.TryGetValue(soundNames, out var prev) && idx == prev)
                idx = (idx + 1 + Random.Range(0, soundNames.Length - 1)) % soundNames.Length;
            _lastIndex[soundNames] = idx;
            return idx;
        }

        static readonly int[] Pentatonic = { 0, 2, 4, 7, 9 };

        /// <summary>
        /// Majör pentatonik dizide n basamağın yarım ton karşılığı: yukarı 0,2,4,7,9,12,14…; aşağı −3,−5,−8,−10,−12…
        /// </summary>
        public static int PentatonicSemitones(int steps)
        {
            int oct = Mathf.FloorToInt(steps / 5f);
            return 12 * oct + Pentatonic[steps - oct * 5];
        }

        /// <summary>Yarım ton sayısını pitch çarpanına çevirir (12 yarım ton = 1 oktav = 2x).</summary>
        public static float Semitones(float semis) => Mathf.Pow(2f, semis / 12f);

        // ---------------------------------------------------------------- Toggles

        public void SetSoundOn(bool on)
        {
            SoundOn = on;
            SaveSystem.SoundOn = on;
            if (!on) foreach (var s in _pool) s.Stop();
        }
    }
}
