using System;

namespace BlockRise
{
    /// <summary>
    /// Oyunun reklama ihtiyaç duyduğu noktalar. Reklam SDK'sı (LevelPlay) entegre edilince bu alanlar
    /// SDK'ya bağlanır (ShowRewarded / ShowInterstitial / SetBannerVisible'a yeni fonksiyon atanır).
    ///
    ///  • ShowRewarded(placement, onReward, onFail): ödüllü reklam.
    ///    Varsayılan: editörde ve Development Build'de ödülü hemen verir (test için); yayın derlemesinde
    ///    onFail çağırır ("reklam yok").
    ///    Böylece SDK bağlanmadan çıkan bir derlemede revive bedavaya dağıtılmaz.
    ///  • ShowInterstitial(placement, onClosed): oyunlar arası zorunlu kısa reklam. Varsayılan: hemen devam eder.
    ///    Reklam gösterilemezse de onClosed MUTLAKA çağrılmalı (oyuncu takılı kalmasın).
    ///  • SetBannerVisible(bool): oyun ekranının altındaki banner. Varsayılan: hiçbir şey yapmaz.
    ///    Tahta, banner için GameSettings.bannerReserveHeight kadar alt boşluk bırakır.
    ///
    /// Oyun kodu bu alanları doğrudan değil, Rewarded() / Interstitial() üzerinden çağırır: ölçüm (analytics) orada yapılır,
    /// SDK bağlanınca da kaybolmaz.
    ///
    /// Reklam kaldırma satın alındıysa (SaveSystem.AdsRemoved) banner ve geçiş reklamları gösterilmez;
    /// ödüllü reklam (revive) oyuncunun kendi seçimi olduğu için açık kalır.
    /// </summary>
    public static class AdHooks
    {
        public static Action<string, Action, Action> ShowRewarded = (placement, onReward, onFail) =>
        {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            onReward?.Invoke();
#else
            onFail?.Invoke();
#endif
        };
        public static Action<string, Action> ShowInterstitial = (placement, onClosed) => onClosed?.Invoke();
        public static Action<bool> SetBannerVisible = visible => { };

        /// <summary>Ödüllü reklam göster + ölç (ad_rewarded: rewarded / failed).</summary>
        public static void Rewarded(string placement, Action onReward, Action onFail)
        {
            Analytics.AdRewardedRequest(placement);
            ShowRewarded(placement,
                () => { Analytics.AdRewardedResult(placement, true); onReward?.Invoke(); },
                () => { Analytics.AdRewardedResult(placement, false); onFail?.Invoke(); });
        }

        /// <summary>Geçiş reklamı göster + ölç (ad_interstitial).</summary>
        public static void Interstitial(string placement, Action onClosed)
        {
            Analytics.AdInterstitial(placement);
            ShowInterstitial(placement, onClosed);
        }
    }
}
