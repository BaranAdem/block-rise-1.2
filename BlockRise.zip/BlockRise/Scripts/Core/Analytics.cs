using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
#if BLOCKRISE_GAMEANALYTICS
using GameAnalyticsSDK;
#endif
#if BLOCKRISE_FIREBASE
using Firebase.Analytics;
using Firebase.Extensions;
#endif

namespace BlockRise
{
    /// <summary>
    /// Oyun ölçümü. Oyun kodu yalnızca bu sınıfı çağırır; veri nereye gidecekse burada karar verilir.
    ///
    ///  • Her zaman: cihazda yerel istatistik (LocalStats) → ana menüde gizli panelde görülebilir.
    ///  • GameAnalytics SDK kuruluysa: Player Settings > Scripting Define Symbols'a BLOCKRISE_GAMEANALYTICS ekle.
    ///  • Firebase Analytics kuruluysa:  Scripting Define Symbols'a BLOCKRISE_FIREBASE ekle.
    ///  İkisi birden de açılabilir. Hiçbiri yoksa oyun yine derlenir ve sadece yerel kayıt tutulur.
    ///
    /// Olaylar:
    ///   game_session · tutorial_begin / tutorial_step / tutorial_complete
    ///   level_start · level_complete · level_fail · level_quit · revive
    ///   endless_start · endless_end
    ///   ad_rewarded_request / ad_rewarded · ad_interstitial
    ///   iap_start · iap_purchase · iap_fail · iap_restore
    ///
    /// Not: "session_start", "ad_reward", "in_app_purchase" gibi adlar Firebase'e AYRILMIŞTIR; bu adlarla gönderilen olay
    /// Firebase tarafından atılır. Gelir için Firebase in_app_purchase'ı mağazadan kendisi toplar; ad_impression
    /// (reklam geliri) LevelPlay ILRD entegrasyonunda gönderilecek. Buradaki olaylar sayım/huni içindir, gelir taşımaz.
    /// </summary>
    public static class Analytics
    {
        static bool _inited;

        public static void Init()
        {
            if (_inited) return;
            _inited = true;
            LocalStats.Load();
            LocalStats.Data.sessions++;
            if (LocalStats.Data.installUnixDay == 0) LocalStats.Data.installUnixDay = UnixDay();
            LocalStats.Save();

#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.Initialize();
#endif
#if BLOCKRISE_FIREBASE
            Firebase.FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(t =>
            {
                if (t.Result == Firebase.DependencyStatus.Available)
                {
                    _firebaseReady = true;
                    foreach (var a in _firebaseQueue) a();
                    _firebaseQueue.Clear();
                }
                else Debug.LogWarning("[BlockRise] Firebase kullanılamıyor: " + t.Result);
            });
#endif
            Send("game_session", "session", LocalStats.Data.sessions, "days_since_install", DaysSinceInstall);
        }

        public static int DaysSinceInstall => Mathf.Max(0, UnixDay() - LocalStats.Data.installUnixDay);
        static int UnixDay() => (int)(DateTimeOffset.UtcNow.ToUnixTimeSeconds() / 86400);

        // ================================================================ Tutorial

        public static void TutorialBegin()
        {
            LocalStats.Data.tutorialStarted++;
            LocalStats.Save();
            Send("tutorial_begin");
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("tutorial:begin");
#endif
        }

        public static void TutorialStep(int step)
        {
            if (step > LocalStats.Data.tutorialMaxStep) { LocalStats.Data.tutorialMaxStep = step; LocalStats.Save(); }
            Send("tutorial_step", "step", step);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("tutorial:step:" + step.ToString("00"));
#endif
        }

        public static void TutorialComplete(bool skipped, int reachedStep)
        {
            if (skipped) LocalStats.Data.tutorialSkipped++;
            else LocalStats.Data.tutorialCompleted++;
            LocalStats.Save();
            Send("tutorial_complete", "skipped", skipped ? 1 : 0, "step", reachedStep);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent(skipped ? "tutorial:skipped" : "tutorial:complete", reachedStep);
#endif
        }

        // ================================================================ Level

        /// <param name="index">0 tabanlı bölüm</param>
        public static void LevelStart(int index)
        {
            var st = LocalStats.Level(index);
            st.attempts++;
            LocalStats.Save();
            Send("level_start", "level", index + 1, "attempt", st.attempts);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewProgressionEvent(GAProgressionStatus.Start, LevelId(index));
#endif
        }

        public static void LevelComplete(int index, int stars, int score, int movesLeft, int turns, float seconds, bool revived)
        {
            var st = LocalStats.Level(index);
            st.wins++;
            if (st.firstWinAttempt == 0) st.firstWinAttempt = st.attempts;
            st.bestStars = Mathf.Max(st.bestStars, stars);
            st.seconds += seconds;
            if (revived) st.winsAfterRevive++;
            LocalStats.Save();

            Send("level_complete", "level", index + 1, "attempt", st.attempts, "stars", stars, "score", score,
                 "moves_left", movesLeft, "turns", turns, "seconds", Mathf.RoundToInt(seconds), "revived", revived ? 1 : 0);
#if BLOCKRISE_GAMEANALYTICS
            string id = LevelId(index);
            GameAnalytics.NewProgressionEvent(GAProgressionStatus.Complete, id, score);
            GameAnalytics.NewDesignEvent("level:stars:" + id, stars);
            GameAnalytics.NewDesignEvent("level:moves_left:" + id, movesLeft);
            GameAnalytics.NewDesignEvent("level:attempts_to_win:" + id, st.attempts);
            GameAnalytics.NewDesignEvent("level:seconds:" + id, Mathf.RoundToInt(seconds));
#endif
        }

        /// <param name="reason">"moves" (hamle bitti) veya "height" (duvar tepeye ulaştı)</param>
        /// <param name="goalProgress">0..1 hedeflerin ortalama tamamlanma oranı (ne kadar yaklaşmıştı)</param>
        public static void LevelFail(int index, string reason, float goalProgress, int score, int turns, float seconds, bool revived)
        {
            var st = LocalStats.Level(index);
            st.fails++;
            st.seconds += seconds;
            st.goalProgressSum += goalProgress;
            if (reason == "moves") st.failsMoves++; else st.failsHeight++;
            LocalStats.Save();

            int pct = Mathf.RoundToInt(goalProgress * 100f);
            Send("level_fail", "level", index + 1, "attempt", st.attempts, "reason", reason, "goal_pct", pct,
                 "score", score, "turns", turns, "seconds", Mathf.RoundToInt(seconds), "revived", revived ? 1 : 0);
#if BLOCKRISE_GAMEANALYTICS
            string id = LevelId(index);
            GameAnalytics.NewProgressionEvent(GAProgressionStatus.Fail, id, score);
            GameAnalytics.NewDesignEvent("level:fail_" + reason + ":" + id, pct);
#endif
        }

        /// <summary>Bölüm bitmeden çıkıldı (duraklat → ana menü / yeniden başlat).</summary>
        public static void LevelQuit(int index, float goalProgress, int turns, float seconds)
        {
            var st = LocalStats.Level(index);
            st.quits++;
            st.seconds += seconds;
            LocalStats.Save();

            int pct = Mathf.RoundToInt(goalProgress * 100f);
            Send("level_quit", "level", index + 1, "attempt", st.attempts, "goal_pct", pct, "turns", turns, "seconds", Mathf.RoundToInt(seconds));
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("level:quit:" + LevelId(index), pct);
#endif
        }

        // ================================================================ Revive

        public static void Revive(GameMode mode, int levelIndex, string reason)
        {
            if (mode == GameMode.Level) { LocalStats.Level(levelIndex).revives++; }
            else LocalStats.Data.endlessRevives++;
            LocalStats.Save();

            string where = mode == GameMode.Level ? LevelId(levelIndex) : "endless";
            Send("revive", "where", where, "reason", reason);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("revive:" + reason + ":" + where);
#endif
        }

        // ================================================================ Endless

        public static void EndlessStart(float ease = -1f, bool hotStart = false)
        {
            LocalStats.Data.endlessGames++;
            LocalStats.Save();
            Send("endless_start", "game", LocalStats.Data.endlessGames, "ease", Mathf.RoundToInt(ease * 100f), "hot_start", hotStart ? 1 : 0);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewProgressionEvent(GAProgressionStatus.Start, "endless");
#endif
        }

        /// <param name="quit">true = oyun bitmeden çıkıldı</param>
        /// <param name="rescues">Bu oyunda verilen kıl payı kurtuluş sayısı (casual akış)</param>
        /// <param name="maxChain">Bu oyundaki en uzun zincir</param>
        public static void EndlessEnd(int score, int turns, float seconds, bool revived, bool newBest, bool quit, int rescues = 0, int maxChain = 0)
        {
            var d = LocalStats.Data;
            d.endlessBest = Mathf.Max(d.endlessBest, score);
            d.endlessScoreSum += score;
            d.endlessSeconds += seconds;
            if (quit) d.endlessQuits++;
            LocalStats.Save();

            Send("endless_end", "score", score, "turns", turns, "seconds", Mathf.RoundToInt(seconds),
                 "revived", revived ? 1 : 0, "new_best", newBest ? 1 : 0, "quit", quit ? 1 : 0,
                 "rescues", rescues, "max_chain", maxChain);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewProgressionEvent(quit ? GAProgressionStatus.Fail : GAProgressionStatus.Complete, "endless", score);
            GameAnalytics.NewDesignEvent("endless:seconds", Mathf.RoundToInt(seconds));
            GameAnalytics.NewDesignEvent("endless:turns", turns);
#endif
        }

        // ================================================================ Reklam / satın alma

        /// <summary>Oyuncu ödüllü reklam butonuna bastı (placement: revive).</summary>
        public static void AdRewardedRequest(string placement)
        {
            Send("ad_rewarded_request", "placement", placement);
        }

        /// <summary>Ödüllü reklamın sonucu: rewarded = ödül verildi, değilse reklam yok / yarıda kapandı.</summary>
        public static void AdRewardedResult(string placement, bool rewarded)
        {
            if (rewarded) { LocalStats.Data.adsRewarded++; LocalStats.Save(); }
            Send("ad_rewarded", "placement", placement, "result", rewarded ? "rewarded" : "failed");
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("ad:rewarded:" + placement + ":" + (rewarded ? "ok" : "fail"));
#endif
        }

        /// <summary>Geçiş reklamı gösterilmek üzere (sıra geldi).</summary>
        public static void AdInterstitial(string placement)
        {
            LocalStats.Data.adsInterstitial++;
            LocalStats.Save();
            Send("ad_interstitial", "placement", placement);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("ad:interstitial:" + placement);
#endif
        }

        public static void PurchaseStart(string product, string source)
        {
            Send("iap_start", "product", product, "source", source);
        }

        /// <summary>Satın alma onaylandı. price: mağazanın gösterdiği fiyat metni (yalnızca bilgi; gelir Firebase'in kendi in_app_purchase'ından gelir).</summary>
        public static void Purchase(string product, string source, string price)
        {
            LocalStats.Data.purchases++;
            LocalStats.Save();
            Send("iap_purchase", "product", product, "source", source, "price_label", price ?? "",
                 "games_total", AdPolicy.TotalGames, "days_since_install", DaysSinceInstall);
#if BLOCKRISE_GAMEANALYTICS
            GameAnalytics.NewDesignEvent("iap:purchase:" + product + ":" + source);
#endif
        }

        public static void PurchaseFail(string product, string source, string reason)
        {
            Send("iap_fail", "product", product, "source", source, "reason", string.IsNullOrEmpty(reason) ? "cancel" : reason);
        }

        public static void PurchaseRestore(bool found)
        {
            Send("iap_restore", "found", found ? 1 : 0);
        }

        // ================================================================ Gönderim

        static string LevelId(int index) => "level_" + (index + 1).ToString("000");

        /// <summary>Olay adı + (anahtar, değer) çiftleri. Konsola (ayarlıysa) ve Firebase'e (kuruluysa) gider.</summary>
        static void Send(string name, params object[] kv)
        {
            if (GameSettings.Instance.analyticsLogToConsole)
            {
                var sb = new StringBuilder("[Analytics] ").Append(name);
                for (int i = 0; i + 1 < kv.Length; i += 2) sb.Append("  ").Append(kv[i]).Append('=').Append(kv[i + 1]);
                Debug.Log(sb.ToString());
            }
#if BLOCKRISE_FIREBASE
            var ps = new List<Parameter>();
            for (int i = 0; i + 1 < kv.Length; i += 2)
            {
                string k = kv[i].ToString();
                object v = kv[i + 1];
                if (v is int iv) ps.Add(new Parameter(k, (long)iv));
                else if (v is float fv) ps.Add(new Parameter(k, (double)fv));
                else ps.Add(new Parameter(k, v != null ? v.ToString() : ""));
            }
            var arr = ps.ToArray();
            if (_firebaseReady) FirebaseAnalytics.LogEvent(name, arr);
            else if (_firebaseQueue.Count < 50) _firebaseQueue.Add(() => FirebaseAnalytics.LogEvent(name, arr));
#endif
        }

#if BLOCKRISE_FIREBASE
        static bool _firebaseReady;
        static readonly List<Action> _firebaseQueue = new List<Action>();
#endif
    }

    // ==================================================================== Yerel istatistik

    /// <summary>
    /// Cihazda tutulan özet istatistik (persistentDataPath/blockrise_stats.json).
    /// SDK olmadan test oyuncularının nerede zorlandığını görmek için. Ana menüde gizli panelden okunur.
    /// </summary>
    public static class LocalStats
    {
        [Serializable]
        public class LevelStat
        {
            public int index;
            public int attempts, wins, fails, quits, revives;
            public int failsMoves, failsHeight, winsAfterRevive;
            public int firstWinAttempt, bestStars;
            public float seconds, goalProgressSum;
        }

        [Serializable]
        public class StatsData
        {
            public int sessions, installUnixDay;
            public int tutorialStarted, tutorialCompleted, tutorialSkipped, tutorialMaxStep;
            public int endlessGames, endlessQuits, endlessRevives, endlessBest;
            public long endlessScoreSum;
            public float endlessSeconds;
            public int adsRewarded, adsInterstitial, purchases;
            public List<LevelStat> levels = new List<LevelStat>();
        }

        public static StatsData Data { get; private set; } = new StatsData();
        static string FilePath => Path.Combine(Application.persistentDataPath, "blockrise_stats.json");

        public static void Load()
        {
            try
            {
                if (File.Exists(FilePath)) Data = JsonUtility.FromJson<StatsData>(File.ReadAllText(FilePath)) ?? new StatsData();
            }
            catch (Exception e)
            {
                Debug.LogWarning("[BlockRise] İstatistik okunamadı, sıfırdan başlanıyor: " + e.Message);
                Data = new StatsData();
            }
            if (Data.levels == null) Data.levels = new List<LevelStat>();
        }

        public static void Save()
        {
            try { File.WriteAllText(FilePath, JsonUtility.ToJson(Data)); }
            catch (Exception e) { Debug.LogWarning("[BlockRise] İstatistik yazılamadı: " + e.Message); }
        }

        public static void Reset()
        {
            int install = Data.installUnixDay;
            Data = new StatsData { installUnixDay = install };
            Save();
        }

        public static LevelStat Level(int index)
        {
            foreach (var l in Data.levels) if (l.index == index) return l;
            var n = new LevelStat { index = index };
            Data.levels.Add(n);
            return n;
        }

        /// <summary>Panelde gösterilen ve panoya kopyalanan düz metin rapor.</summary>
        public static string Report()
        {
            var d = Data;
            var sb = new StringBuilder();
            sb.AppendLine("BLOCK RISE — TEST İSTATİSTİKLERİ");
            sb.AppendLine("Oturum: " + d.sessions + "   Kurulumdan beri: " + Analytics.DaysSinceInstall + " gün");
            sb.AppendLine();
            sb.AppendLine("TUTORIAL  başladı " + d.tutorialStarted + " · bitirdi " + d.tutorialCompleted
                          + " · atladı " + d.tutorialSkipped + " · en ileri adım " + d.tutorialMaxStep);
            if (d.endlessGames > 0)
            {
                float avg = d.endlessGames > 0 ? (float)d.endlessScoreSum / d.endlessGames : 0f;
                float avgSec = d.endlessGames > 0 ? d.endlessSeconds / d.endlessGames : 0f;
                sb.AppendLine("ENDLESS   oyun " + d.endlessGames + " · rekor " + d.endlessBest + " · ort. skor " + Mathf.RoundToInt(avg)
                              + " · ort. süre " + Mathf.RoundToInt(avgSec) + " sn · yarıda " + d.endlessQuits + " · revive " + d.endlessRevives);
            }
            sb.AppendLine("PARA      ödüllü reklam " + d.adsRewarded
                          + " · geçiş reklamı " + d.adsInterstitial + " · satın alma " + d.purchases);
            sb.AppendLine(PlayerModel.Summary());
            sb.AppendLine("ZORLUK    kolaylık %" + Mathf.RoundToInt(Adaptive.EndlessEase * 100f) + " (0 = en zor) · hedef " + GameSettings.Instance.targetGameTurns + " tur · uyarlanan oyun " + Adaptive.EndlessGames);
            sb.AppendLine();
            sb.AppendLine("BÖLÜMLER (denenenler)");
            var list = new List<LevelStat>(d.levels);
            list.Sort((a, b) => a.index.CompareTo(b.index));
            foreach (var l in list)
            {
                if (l.attempts == 0) continue;
                int ended = l.wins + l.fails + l.quits;
                sb.Append("Lv ").Append(l.index + 1).Append(" — ").Append(l.attempts).Append(" deneme");
                if (l.wins > 0) sb.Append(" · ").Append(l.wins).Append(" kazanç (ilki ").Append(l.firstWinAttempt).Append(". denemede, ").Append(l.bestStars).Append(" yıldız)");
                if (l.fails > 0)
                    sb.Append(" · ").Append(l.fails).Append(" kayıp (hamle ").Append(l.failsMoves).Append(" / duvar ").Append(l.failsHeight)
                      .Append(", hedefe ort. %").Append(Mathf.RoundToInt(l.goalProgressSum / l.fails * 100f)).Append(")");
                if (l.quits > 0) sb.Append(" · ").Append(l.quits).Append(" bırakma");
                if (l.revives > 0) sb.Append(" · ").Append(l.revives).Append(" revive");
                if (ended > 0) sb.Append(" · ort. ").Append(Mathf.RoundToInt(l.seconds / ended)).Append(" sn");
                sb.AppendLine();
            }
            return sb.ToString();
        }

    }
}
