using System;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Oyunlar arası akış kuralları: geçiş reklamı ve değerlendirme isteği.
    ///
    /// Geçiş reklamı: her N oyunda bir (GameSettings.interstitialEveryGames), oyun bitip oyuncu sonuç
    /// ekranından ilerlerken gösterilir. O oyunda ödüllü reklam izlendiyse gösterilmez ve sayaç sıfırlanır
    /// (oyuncu zaten reklam izledi). Reklamlar kaldırıldıysa hiç gösterilmez.
    ///
    /// Değerlendirme isteği: toplam N oyundan sonra (GameSettings.rateAfterGames), tercihen iyi bir anın
    /// (kazanma / rekor) ardından, bir kez sorulur. O geçişte reklam gösterilmez.
    /// </summary>
    public static class AdPolicy
    {
        const string KeySince = "br_ads_since";
        const string KeyGames = "br_games_total";
        const string KeyRateDone = "br_rate_done";

        static bool _rewardedThisGame, _gameOpen;
        static GameSettings S => GameSettings.Instance;

        public static int TotalGames => PlayerPrefs.GetInt(KeyGames, 0);
        public static bool RateDone
        {
            get => PlayerPrefs.GetInt(KeyRateDone, 0) == 1;
            set { PlayerPrefs.SetInt(KeyRateDone, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        /// <summary>Her yeni oyun (tekrar dahil) başında çağrılır. Öğretici sayılmaz.</summary>
        public static void GameStarted(GameMode mode)
        {
            _gameOpen = mode != GameMode.Tutorial;
            _rewardedThisGame = false;
        }

        /// <summary>Oyuncu bu oyunda ödüllü reklam izledi (revive).</summary>
        public static void RewardedWatched() => _rewardedThisGame = true;

        /// <summary>
        /// Oyuncu sonuç ekranından ilerlerken çağrılır. Sırası gelmişse önce değerlendirme isteğini ya da
        /// geçiş reklamını gösterir, sonra next'i çalıştırır.
        /// </summary>
        /// <param name="positive">Bu oyun iyi bitti mi (kazanma / rekor): değerlendirme için iyi an</param>
        /// <param name="showRatePrompt">Değerlendirme penceresini açar; kapanınca verilen eylemi çağırmalı</param>
        public static void AfterGame(bool positive, Action next, Action<Action> showRatePrompt)
        {
            if (!_gameOpen) { next?.Invoke(); return; }
            _gameOpen = false;

            int games = TotalGames + 1;
            PlayerPrefs.SetInt(KeyGames, games);
            int since = _rewardedThisGame ? 0 : PlayerPrefs.GetInt(KeySince, 0) + 1;

            // 1) Değerlendirme: N oyundan sonra iyi bir anda; iyi an gelmezse birkaç oyun sonra yine de sor
            if (!RateDone && showRatePrompt != null && games >= S.rateAfterGames && (positive || games >= S.rateAfterGames + 3))
            {
                RateDone = true;
                PlayerPrefs.SetInt(KeySince, since);
                PlayerPrefs.Save();
                showRatePrompt(next);
                return;
            }

            // 2) Geçiş reklamı
            bool show = !SaveSystem.AdsRemoved && !_rewardedThisGame && S.interstitialEveryGames > 0
                        && since >= S.interstitialEveryGames;
            PlayerPrefs.SetInt(KeySince, show ? 0 : since);
            PlayerPrefs.Save();
            if (show) AdHooks.Interstitial("between_games", next);
            else next?.Invoke();
        }
    }
}
