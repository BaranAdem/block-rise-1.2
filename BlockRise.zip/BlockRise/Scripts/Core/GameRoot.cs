using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Oyunun giriş noktası. Sahneye elle ekleyebilirsin; eklemezsen Bootstrap otomatik oluşturur.
    /// Kamera, tahta, efektler, UI ve oyun kontrolcüsünü kodla kurar (prefab/asset gerekmez).
    /// </summary>
    public class GameRoot : MonoBehaviour
    {
    /// <summary>
    /// Kare hızı. 60: her telefonda akıcı, pil dostu. 120: ProMotion iPhone'larda ve 120 Hz Android'lerde çok daha
    /// akıcı kaydırma (pil biraz daha çabuk biter). 0: ekranın kendi yenileme hızı (en fazla 120).
    /// </summary>
    static void ApplyFrameRate(GameSettings s)
    {
        int fps = s.targetFrameRate;
        if (fps <= 0)
        {
            double hz = Screen.currentResolution.refreshRateRatio.value;
            fps = hz > 1 ? Mathf.RoundToInt((float)hz) : 60;
        }
        QualitySettings.vSyncCount = 0; // mobilde zaten yok sayılır; editörde targetFrameRate'in çalışması için
        Application.targetFrameRate = Mathf.Clamp(fps, 30, 120);
    }

    void Awake()
    {
        var s = GameSettings.Instance;
        Loc.Init(); // dil: kayıtlı seçim ya da cihaz dili (arayüz kurulmadan önce)
        ApplyFrameRate(s);
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Input.multiTouchEnabled = false;
        Input.simulateMouseWithTouches = true;

        SaveSystem.ApplyDataReset(s.dataResetVersion); // her şeyden önce: istenirse tüm kayıtları bir kez sıfırla
        SaveSystem.MigrateLevelPack(); // yeni bölüm seti: eski bölümlerin yıldızlarını/kilidini sıfırla
        Analytics.Init();             // ölçüm: yerel istatistik + (kuruluysa) GameAnalytics / Firebase
        DailyStreak.Check();          // günlük giriş serisi (yeni gün mü)

        var cam = Camera.main;
        if (cam == null)
        {
            var cgo = new GameObject("Main Camera");
            cgo.tag = "MainCamera";
            cam = cgo.AddComponent<Camera>();
        }

        cam.orthographic = true;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.transform.position = new Vector3(0, 0, -10);
        cam.transform.rotation = Quaternion.identity;
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 100f;

        // Önce yalnızca hafif ve canlı görünen parçalar: arka plan, yıldız tozu ve yükleme ekranı. Böylece ilk karede
        // oyuncu donuk siyah ekran yerine oyunun kendi dünyasını görür; ağır hazırlıklar bu ekranın arkasında yapılır.
        var bg = gameObject.AddComponent<BackgroundGradient>();   // iki renkli gradyan + alacalı doku
        bg.Init(cam);
        var dust = gameObject.AddComponent<StardustField>();      // patlama ve chain'lerde dalgalanan yıldız tozu
        dust.Init(cam);

        var sound = new GameObject("Sound").AddComponent<SoundManager>(); // sesler hemen arka planda yüklenmeye başlasın
        sound.transform.SetParent(transform, false);

        _loading = LoadingScreen.Create();
        _loading.transform.SetParent(transform, false);
        StartCoroutine(SpriteLibrary.WarmupTiles()); // blok karoları arka plan thread'inde, arayüz kurulurken paralel
        StartCoroutine(Boot(cam, sound));
    }

    LoadingScreen _loading;

    /// <summary>
    /// Yükleme ekranı açıkken oyunu adım adım kurar ve ilk kullanımda takılma yapacak her şeyi önceden hazırlar:
    /// arayüz, bölüm haritası, blok karoları, sesler, font dokusu, shader'lar ve titreşim servisi.
    /// Her adımdan sonra bir kare beklenir ki yükleme ekranı canlı kalsın. Bitince menü (ya da yarım kalan oyun)
    /// açılır ve yükleme ekranı üstünden yumuşakça kaybolur.
    /// </summary>
    System.Collections.IEnumerator Boot(Camera cam, SoundManager sound)
    {
        yield return null; // yükleme ekranı bir kez çizilsin

        var fx = new GameObject("Fx").AddComponent<FxManager>();
        fx.transform.SetParent(transform, false);
        fx.Init(cam);

        var board = new GameObject("Board").AddComponent<BoardView>();
        board.transform.SetParent(transform, false);
        board.Init(cam, fx);
        board.SetVisible(false);
        _loading.SetProgress(0.08f);
        yield return null;

        var ctrl = gameObject.AddComponent<GameController>();
        var ui = new GameObject("UIRoot").AddComponent<UIManager>();
        ui.transform.SetParent(transform, false);
        ctrl.Init(board, fx, ui);
        ui.Init(ctrl, board);   // tüm ekranlar (en ağır adım)
        _loading.SetProgress(0.3f);
        yield return null;

        ui.PrewarmLevels();     // bölüm haritası: "Levels" ilk açıldığında kurulmasın
        _loading.SetProgress(0.4f);
        yield return null;

        // Karolar (arka plan thread'i) ve sesler (arka plan yüklemesi) bitene kadar bekle. Güvenlik: en fazla 15 sn.
        float limit = Time.realtimeSinceStartup + 15f;
        while (Time.realtimeSinceStartup < limit && (SpriteLibrary.WarmupProgress < 1f || !sound.IsWarm))
        {
            _loading.SetProgress(0.4f + 0.5f * (0.6f * SpriteLibrary.WarmupProgress + 0.4f * sound.WarmProgress));
            yield return null;
        }
        _loading.SetProgress(0.9f);
        yield return null;

        ui.PrewarmFont();            // tüm yazıların karakterleri font dokusuna (ilk görünüşte doku büyüyüp her şey yeniden kurulmasın)
        Haptics.Prewarm();           // Android titreşim servisi (JNI): ilk dokunuşta takılmasın
        Shader.WarmupAllShaders();   // sprite / UI / font shader'ları GPU sürücüsünde şimdi derlensin
        System.GC.Collect();         // kurulumun geçici çöpü menü açıkken değil, şimdi toplansın
        _loading.SetProgress(1f);
        yield return null;

        // Yarım kalmış endless oyunu varsa menüyü atlayıp doğrudan oyunun içinden aç
        if (SaveSystem.TutorialSeen && EndlessSave.Exists)
        {
            if (!ctrl.TryResumeEndless()) ui.ShowMainMenu();
        }
        else ui.ShowMainMenu();
        yield return _loading.FinishAndHide();
        _loading = null;
    }

        void OnApplicationPause(bool paused)
        {
            if (paused)
            {
                Achievements.Flush(); // uygulama kapatılırsa ilerleme kaybolmasın
                var ctrl = GetComponent<GameController>();
                if (ctrl != null && ctrl.State == GameState.Playing) ctrl.Pause();
            }
        }
    }

    public static class Bootstrap
    {
        /// <summary>false yaparsan oyun sadece sahnede GameRoot varsa çalışır.</summary>
        public static bool AutoCreate = true;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Init()
        {
            if (!AutoCreate) return;
            if (Object.FindObjectOfType<GameRoot>() != null) return;
            new GameObject("BlockRiseGame").AddComponent<GameRoot>();
        }
    }
}