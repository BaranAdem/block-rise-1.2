using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Oyunun giriş noktası. Sahneye elle ekleyebilirsin; eklemezsen Bootstrap otomatik oluşturur.
    /// Kamera, tahta, efektler, UI ve oyun kontrolcüsünü kodla kurar (prefab/asset gerekmez).
    /// </summary>
    public class GameRoot : MonoBehaviour
    {
    /// <summary>
    /// Kare hızı. 60: her telefonda akıcı, pil dostu. 120: ProMotion iPhone'larda ve 120 Hz Android'lerde çok daha
    /// akıcı kaydırma (pil biraz daha çabuk biter). 0: ekranın kendi yenileme hızı (en fazla 120).
    /// </summary>
    static void ApplyFrameRate(GameSettings s)
    {
        int fps = s.targetFrameRate;
        if (fps <= 0)
        {
            double hz = Screen.currentResolution.refreshRateRatio.value;
            fps = hz > 1 ? Mathf.RoundToInt((float)hz) : 60;
        }
        QualitySettings.vSyncCount = 0; // mobilde zaten yok sayılır; editörde targetFrameRate'in çalışması için
        Application.targetFrameRate = Mathf.Clamp(fps, 30, 120);
    }

    void Awake()
    {
        var s = GameSettings.Instance;
        Loc.Init(); // dil: kayıtlı seçim ya da cihaz dili (arayüz kurulmadan önce)
        ApplyFrameRate(s);
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Input.multiTouchEnabled = false;
        Input.simulateMouseWithTouches = true;

        SaveSystem.ApplyDataReset(s.dataResetVersion); // her şeyden önce: istenirse tüm kayıtları bir kez sıfırla
        SaveSystem.MigrateLevelPack(); // yeni bölüm seti: eski bölümlerin yıldızlarını/kilidini sıfırla
        Analytics.Init();             // ölçüm: yerel istatistik + (kuruluysa) GameAnalytics / Firebase
        DailyStreak.Check();          // günlük giriş serisi (yeni gün mü)

        var cam = Camera.main;
        if (cam == null)
        {
            var cgo = new GameObject("Main Camera");
            cgo.tag = "MainCamera";
            cam = cgo.AddComponent<Camera>();
        }

        cam.orthographic = true;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.transform.position = new Vector3(0, 0, -10);
        cam.transform.rotation = Quaternion.identity;
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 100f;

        var fx = new GameObject("Fx").AddComponent<FxManager>();
        fx.transform.SetParent(transform, false);
        fx.Init(cam);

        var sound = new GameObject("Sound").AddComponent<SoundManager>();
        sound.transform.SetParent(transform, false);

        // Arka plan: iki renkli gradyan + hafif alacalı doku, paletler arası yumuşak geçiş
        var bg = gameObject.AddComponent<BackgroundGradient>();
        bg.Init(cam);

        // Arka plan yıldız tozu (patlama ve chain'lerde dalgalanır)
        var dust = gameObject.AddComponent<StardustField>();
        dust.Init(cam);

        var board = new GameObject("Board").AddComponent<BoardView>();
        board.transform.SetParent(transform, false);
        board.Init(cam, fx);
        board.SetVisible(false);

        var ctrl = gameObject.AddComponent<GameController>();
        var ui = new GameObject("UIRoot").AddComponent<UIManager>();
        ui.transform.SetParent(transform, false);

        ctrl.Init(board, fx, ui);
        ui.Init(ctrl, board);
        StartCoroutine(SpriteLibrary.WarmupTiles()); // blok karoları arka planda hazırlansın (oyunda ilk görünüşte takılmasın)
        // PERFORMANS: açılıştaki "zaten donuk" karede tek seferlik hazırlıklar. Yapılmazsa her biri ilk kullanıldığı
        // anda (ilk çizim, ilk dokunuş) oyunun ortasında takılma olarak görünür.
        Haptics.Prewarm();           // Android titreşim servisi (JNI)
        Shader.WarmupAllShaders();   // sprite / UI / font shader'ları GPU sürücüsünde şimdi derlensin
        // Yarım kalmış endless oyunu varsa menüyü atlayıp doğrudan oyunun içinden aç
        if (SaveSystem.TutorialSeen && EndlessSave.Exists) StartCoroutine(ResumeOnLaunch(ctrl, ui));
        else ui.ShowMainMenu();
    }

        /// <summary>
        /// Bir kare bekler (kamera ve arayüz ekran boyutuna yerleşsin), sonra kayıtlı oyunu açar.
        /// Kayıt bozuksa ya da tahta boyutu değiştiyse ana menüyü gösterir.
        /// </summary>
        System.Collections.IEnumerator ResumeOnLaunch(GameController ctrl, UIManager ui)
        {
            yield return null;
            if (!ctrl.TryResumeEndless()) ui.ShowMainMenu();
        }

        void OnApplicationPause(bool paused)
        {
            if (paused)
            {
                Achievements.Flush(); // uygulama kapatılırsa ilerleme kaybolmasın
                var ctrl = GetComponent<GameController>();
                if (ctrl != null && ctrl.State == GameState.Playing) ctrl.Pause();
            }
        }
    }

    public static class Bootstrap
    {
        /// <summary>false yaparsan oyun sadece sahnede GameRoot varsa çalışır.</summary>
        public static bool AutoCreate = true;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Init()
        {
            if (!AutoCreate) return;
            if (Object.FindObjectOfType<GameRoot>() != null) return;
            new GameObject("BlockRiseGame").AddComponent<GameRoot>();
        }
    }
}