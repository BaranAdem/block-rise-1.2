using System;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Level hedefi. type değerleri:
    ///  "color"     -> color renginden amount kadar blok patlat
    ///  "blocks"    -> toplam amount blok patlat
    ///  "score"     -> amount puana ulaş
    ///  "bomb"      -> amount bomba patlat
    ///  "lightning" -> amount şimşek patlat
    /// </summary>
    [Serializable]
    public class GoalData
    {
        public string type = "color";
        public int color;
        public int amount = 10;
    }

    [Serializable]
    public class LevelData
    {
        public int moves = 15;
        public int colors = 5;
        public int startRows = 4;
        public float bombChance;
        public float lightningChance;
        public int minGaps = 2;
        public int maxGaps = 3;
        public int riseEvery = 1;
        public int star2MovesLeft = 2;
        public int star3MovesLeft = 5;
        [Tooltip("0 = rastgele. Sabit bir sayı verirsen level her seferinde aynı başlar.")]
        public int seed;
        public GoalData[] goals = new GoalData[0];
    }

    [Serializable]
    public class LevelList
    {
        public LevelData[] levels = new LevelData[0];
    }

    /// <summary>
    /// Leveller her zaman Resources/BlockRiseLevels.json dosyasından okunur (100 el yapımı, simülasyonla dengelenmiş bölüm).
    /// </summary>
    public static class LevelDatabase
    {
        public const string ResourcePath = "BlockRiseLevels";
        /// <summary>Adventure modundaki bölüm sayısı. JSON'da daha fazla bölüm olsa bile sonrası oyunda görünmez.</summary>
        public const int MaxLevels = 250;
        static LevelList _list;

        public static LevelList List
        {
            get
            {
                if (_list == null) Load();
                return _list;
            }
        }

        public static int Count => Mathf.Min(List.levels.Length, MaxLevels);

        public static LevelData Get(int index)
        {
            if (Count == 0) return new LevelData();
            return List.levels[Mathf.Clamp(index, 0, Count - 1)];
        }

        public static void Load()
        {
            _list = new LevelList();
            var ta = Resources.Load<TextAsset>(ResourcePath);
            if (ta == null)
            {
                Debug.LogError("[BlockRise] Resources/" + ResourcePath + ".json bulunamadı.");
                return;
            }
            try
            {
                _list = JsonUtility.FromJson<LevelList>(ta.text) ?? new LevelList();
                if (_list.levels == null) _list.levels = new LevelData[0];
            }
            catch (Exception e)
            {
                Debug.LogError("[BlockRise] Level JSON okunamadı: " + e.Message);
                _list = new LevelList();
            }
        }
    }
}
