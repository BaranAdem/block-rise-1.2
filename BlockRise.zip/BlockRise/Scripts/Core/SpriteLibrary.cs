using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Sprite'ları Resources/BlockRiseSprites klasöründen yükler.
    /// PNG'leri aynı isimle değiştirerek görünümü tamamen değiştirebilirsin.
    /// Texture import ayarı ne olursa olsun çalışır (Sprite ya da Default).
    /// </summary>
    public static class SpriteLibrary
    {
        public const string Folder = "BlockRiseSprites/";

        // 9-slice kenar boşlukları (piksel). Kendi PNG'ni koyarsan bunları güncelle.
        static readonly Dictionary<string, Vector4> Borders = new Dictionary<string, Vector4>
        {
            { "panel",  new Vector4(44, 44, 44, 44) },
            { "cell",   new Vector4(30, 30, 30, 30) },
        };

        static readonly Dictionary<string, Sprite> Cache = new Dictionary<string, Sprite>();
        static Font _font;

        public static Sprite Get(string name)
        {
            if (Cache.TryGetValue(name, out var s) && s != null) return s;

            Texture2D tex = Resources.Load<Texture2D>(Folder + name);
            if (tex == null)
            {
                Debug.LogWarning("[BlockRise] Sprite bulunamadı: Resources/" + Folder + name + ".png — beyaz kare kullanılıyor.");
                tex = Texture2D.whiteTexture;
            }

            Vector4 border;
            Borders.TryGetValue(name, out border);
            // Sprite 1 birim genişliğinde olsun: ppu = genişlik
            s = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f),
                tex.width, 0, SpriteMeshType.FullRect, border);
            s.name = name;
            Cache[name] = s;
            return s;
        }

        public static Sprite Block(int color) => Get("block_" + color);

        // ================================================================ Gri sprite (Classic stil game over)

        static readonly Dictionary<string, Sprite> GrayCache = new Dictionary<string, Sprite>();

        /// <summary>Verilen sprite'ın gri tonlu kopyası (texture okunabilir olmasa da çalışır).</summary>
        public static Sprite GetGray(string name)
        {
            if (GrayCache.TryGetValue(name, out var s) && s != null) return s;
            var src = Get(name);
            var tex = ReadableCopy(src.texture);
            var px = tex.GetPixels();
            for (int i = 0; i < px.Length; i++)
            {
                float l = px[i].r * 0.3f + px[i].g * 0.59f + px[i].b * 0.11f;
                l = Mathf.Lerp(l, 0.6f, 0.35f);
                px[i] = new Color(l, l, l, px[i].a);
            }
            tex.SetPixels(px);
            tex.Apply();
            s = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), tex.width);
            s.name = name + "_gray";
            GrayCache[name] = s;
            return s;
        }

        static Texture2D ReadableCopy(Texture2D src)
        {
            var rt = RenderTexture.GetTemporary(src.width, src.height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
            Graphics.Blit(src, rt);
            var prev = RenderTexture.active;
            RenderTexture.active = rt;
            var tex = new Texture2D(src.width, src.height, TextureFormat.RGBA32, false);
            tex.ReadPixels(new Rect(0, 0, src.width, src.height), 0, 0);
            tex.Apply();
            RenderTexture.active = prev;
            RenderTexture.ReleaseTemporary(rt);
            tex.wrapMode = TextureWrapMode.Clamp;
            return tex;
        }

        // ================================================================ Yekpare (Unified) blok karoları
        //
        // Her karo, 3x3 komşuluğundaki (4 kenar + 4 çapraz) aynı renk bloklara göre
        // tek bir işaretli mesafe alanından (SDF) üretilir. Bu alan dünya geometrisine bağlı
        // olduğu için komşu iki karo, ortak kenarlarında birebir aynı pikselleri üretir:
        // birleşik gruplar dikişsiz tek parça görünür.
        //
        //  • Dış köşeler: büyük yarıçapla yuvarlatılır (unifiedCornerRadius)
        //  • İç (L) köşeler: çapraz komşuya bakılarak yumuşak kavis (fillet) verilir
        //  • Işık: tam üstten, izleyiciye doğru eğik. Kenar eğimi (bevel) yüzey normali üretir,
        //    Lambert + Blinn-Phong ile gölge/ışık hesaplanır. Düz iç yüzey her karoda aynı tondur.
        //  • Body: gri tonlu, blok rengiyle boyanır. Shine: beyaz parlama (ayrı katman).

        /// <summary>Komşu maskesi bitleri: 4 kenar + 4 çapraz.</summary>
        public const int MaskRight = 1, MaskUp = 2, MaskLeft = 4, MaskDown = 8;
        public const int MaskUpRight = 16, MaskUpLeft = 32, MaskDownLeft = 64, MaskDownRight = 128;

        // Karo çözünürlüğü GameSettings.unifiedTileResolution'dan gelir (SyncTileRes).
        static int TileCell = 96;                    // bir hücre kaç piksel
        static int TileMargin = 2;                   // bağlı kenarlarda komşuya taşma (dikiş olmasın), çözünürlükle orantılı
        static int TileTex => TileCell + TileMargin * 2;
        /// <summary>UI buton blokları sabit 128 px dokuda üretilir; bevel/köşe birimi için referans hücre boyu.</summary>
        const int UIRefCell = 96;

        static void SyncTileRes()
        {
            int r = Mathf.Clamp(GameSettings.Instance.unifiedTileResolution, 64, 256);
            TileCell = r;
            TileMargin = Mathf.Max(2, Mathf.RoundToInt(r / 48f));
        }

        /// <summary>Body sprite'ının dünya boyutu (hücre = 1). BlockView bunu kullanır.</summary>
        public static float TileBodyWorldSize
        {
            get { SyncTileRes(); return (float)TileTex / TileCell; }
        }
        /// <summary>Shine sprite'ı tam hücre boyutundadır.</summary>
        public const float TileShineWorldSize = 1f;

        static readonly Sprite[] TileBody = new Sprite[256];
        static readonly Sprite[] TileShine = new Sprite[256];

        // ---- Işık ayarları (üstten gelen ışık)
        static readonly Vector3 LightDir = new Vector3(-0.55f, 0.60f, 0.75f).normalized;
        static readonly Vector3 HalfDir = (LightDir + Vector3.forward).normalized;
        const float FlatTone = 1f;      // düz iç yüzeyin tonu (her karoda aynı → ton farkı yok)
        const float BevelHeight = 1.2f;    // kenar kabarıklığı (3D derinliği)
        const float ChamferSlope = 1.0f;   // düz pahın eğimi (1 = 45°)
        const float Big = 10f;

        // Keskin (0) ve yumuşak (1) uçlarda kullanılan değerler.
        // Yumuşaklık arttıkça kenar eğimi azalır, parlama genişler, dış hat açılır.
        const float MaxSlopeSharp = 3.5f, MaxSlopeSoft = 1.4f;
        const float SpecPowerSharp = 48f, SpecPowerSoft = 12f;
        const float SpecStrengthSharp = 0.85f, SpecStrengthSoft = 0.50f;
        const float RimDarkSharp = 0.70f, RimDarkSoft = 0.90f;
        // Ambient = ışık görmeyen yüzeylerin taban aydınlığı. Düşükse alt kenar kapkara olur
        // ve küçük ekranda sert bir bant gibi görünür; yükseldikçe geçiş yumuşar.
        const float AmbientSharp = 0.45f, AmbientSoft = 0.80f;

        /// <summary>
        /// Karo üretiminin tüm girdileri. Ana thread'de ayarlardan bir kez okunur; hesap yalnızca bu yapıyı kullanır,
        /// GameSettings'e ya da Unity API'sine dokunmaz → arka plan thread'inde güvenle çalışır.
        /// </summary>
        struct TileShape
        {
            public int cell, margin, version;
            public float inset, rad, fillet, shineAmount;
            public bool sharpInner;
            public Lighting L;
            public int Tex => cell + margin * 2;
        }

        static TileShape CurrentShape()
        {
            var s = GameSettings.Instance;
            SyncTileRes();
            var p = new TileShape { cell = TileCell, margin = TileMargin, version = TileVersion };
            p.inset = Mathf.Clamp(s.unifiedInset, 0.005f, 0.12f);
            p.rad = Mathf.Clamp(s.unifiedCornerRadius, 0.02f, 0.45f - p.inset);
            p.sharpInner = s.unifiedSharpInnerCorners;
            p.fillet = p.sharpInner ? 0f : p.inset + 0.07f;
            p.L = Lighting.FromSettings();
            p.L.aa = 1f / p.cell;
            p.shineAmount = p.L.shineAmount;
#if UNITY_EDITOR
            if (!_loggedBuild)
            {
                _loggedBuild = true;
                Debug.Log(string.Format(
                    "[BlockRise] Karo uretildi — softness={0}, bevel={1}, height={2}, chamfer={3}, inset={4}, radius={5}, shine={6}, res={7}",
                    p.L.soft, p.L.bevel, p.L.height, p.L.chamfer, p.inset, p.rad, s.unifiedShine, p.cell));
            }
#endif
            return p;
        }
#if UNITY_EDITOR
        static bool _loggedBuild;
#endif

        /// <summary>
        /// Aynı renkli komşulara göre şekillenen karo. Maske 8 bittir (kenarlar + çaprazlar);
        /// sadece 4 bit verilirse de çalışır (iç köşeler o durumda keskin kalır).
        /// </summary>
        public static Sprite UnifiedTile(int mask, bool shine)
        {
            mask = CanonicalMask(mask);
            var arr = shine ? TileShine : TileBody;
            if (arr[mask] == null) BuildTile(mask);
            return arr[mask];
        }

        /// <summary>
        /// PERFORMANS: tüm blok karolarını (161 şekil) açılışta önceden üretir. Karolar her açılışta kodla çiziliyor;
        /// bir şekil oyunda İLK KEZ göründüğünde üretilirse o kare takılır.
        ///
        /// Önceden bu iş ana thread'de kare başına 2 karo olarak yapılıyordu: telefonda açılıştan sonraki ~80 kare
        /// boyunca her karede birkaç ms hesap + ~22 MB geçici dizi (GC duraklamaları) → menü ilk saniyelerde kasıyordu.
        /// Şimdi piksel hesabı arka plan thread'inde, sınırlı sayıda yeniden kullanılan tamponla yapılır; ana thread
        /// yalnızca hazır pikselleri dokuya yükler (kare başına ~1.5 ms bütçeyle). WebGL'de thread yok: eski yöntem.
        /// </summary>
        public static System.Collections.IEnumerator WarmupTiles()
        {
            WarmupProgress = 0f;
            var inner = WarmupTilesInner();
            try
            {
                while (inner.MoveNext()) yield return inner.Current;
            }
            finally
            {
                (inner as System.IDisposable)?.Dispose(); // iç döngünün finally'si (thread iptali) de çalışsın
                WarmupProgress = 1f;                      // yükleme ekranı hiçbir durumda sonsuza kadar beklemesin
            }
        }

        /// <summary>Karo ön üretiminin ilerlemesi (0..1). Yükleme ekranı bunu gösterir.</summary>
        public static float WarmupProgress { get; private set; } = 1f;

        static System.Collections.IEnumerator WarmupTilesInner()
        {
            if (GameSettings.Instance.blockStyle != BlockStyle.Unified) yield break;
            var masks = new List<int>();
            for (int m = 0; m < 256; m++)
                if (CanonicalMask(m) == m && TileBody[m] == null) masks.Add(m);
            if (masks.Count == 0) yield break;
            var shape = CurrentShape();

#if UNITY_WEBGL && !UNITY_EDITOR
            var sw = System.Diagnostics.Stopwatch.StartNew();
            foreach (int m in masks)
            {
                if (TileVersion != shape.version) yield break;
                if (TileBody[m] == null) BuildTile(m);
                WarmupProgress = (masks.IndexOf(m) + 1f) / masks.Count;
                if (sw.ElapsedMilliseconds >= 3) { yield return null; sw.Restart(); }
            }
#else
            const int Buffers = 6;
            var ready = new System.Collections.Concurrent.ConcurrentQueue<TileResult>();
            var free = new System.Collections.Concurrent.ConcurrentBag<TileResult>();
            var slots = new System.Threading.SemaphoreSlim(Buffers, Buffers);
            var cancel = new System.Threading.CancellationTokenSource();
            for (int k = 0; k < Buffers; k++)
                free.Add(new TileResult { body = new Color32[shape.Tex * shape.Tex], shine = new Color32[shape.cell * shape.cell] });

            var task = System.Threading.Tasks.Task.Run(() =>
            {
                foreach (int m in masks)
                {
                    slots.Wait(cancel.Token);
                    free.TryTake(out var r);
                    r.mask = m;
                    ComputeTile(m, shape, r.body, r.shine);
                    ready.Enqueue(r);
                }
            }, cancel.Token);

            int done = 0;
            var sw = new System.Diagnostics.Stopwatch();
            try
            {
                while (done < masks.Count)
                {
                    if (TileVersion != shape.version) yield break;   // editörde ayar değişti: kalanlar istendikçe üretilir
                    if (task.IsFaulted || task.IsCanceled)
                    {
                        Debug.LogWarning("[BlockRise] Karo ön üretimi arka planda başarısız oldu; karolar istendikçe üretilecek. " + task.Exception);
                        yield break;
                    }
                    sw.Restart();
                    while (sw.Elapsed.TotalMilliseconds < 1.5 && ready.TryDequeue(out var r))
                    {
                        if (TileBody[r.mask] == null) // oyun bu arada istediyse zaten üretilmiştir
                        {
                            TileBody[r.mask] = MakeTileSprite(r.body, shape.Tex, shape.cell, "tile_" + r.mask);
                            TileShine[r.mask] = MakeTileSprite(r.shine, shape.cell, shape.cell, "tile_shine_" + r.mask);
                        }
                        free.Add(r);
                        slots.Release();
                        done++;
                    }
                    WarmupProgress = (float)done / masks.Count;
                    yield return null;
                }
            }
            finally
            {
                cancel.Cancel(); // coroutine durdurulursa thread beklemede kalmasın
            }
#endif
        }

        class TileResult
        {
            public int mask;
            public Color32[] body, shine;
        }

        /// <summary>Şekli etkilemeyen çapraz bitleri temizler (aynı karonun tekrar üretilmesini önler).</summary>
        public static int CanonicalMask(int mask)
        {
            mask &= 255;
            bool r = (mask & MaskRight) != 0, u = (mask & MaskUp) != 0, l = (mask & MaskLeft) != 0, d = (mask & MaskDown) != 0;
            if (!r && !u) mask &= ~MaskUpRight;
            if (!l && !u) mask &= ~MaskUpLeft;
            if (!l && !d) mask &= ~MaskDownLeft;
            if (!r && !d) mask &= ~MaskDownRight;
            return mask;
        }

        /// <summary>Ayarları değiştirdikten sonra karoları yeniden üretmek için.</summary>
        public static void ClearTileCache()
        {
            for (int i = 0; i < 256; i++) { TileBody[i] = null; TileShine[i] = null; }
            _uiBlockBody = _uiBlockShine = _uiGlassBody = _uiGlassRim = null;
            _uiGlassBtnBody = _uiGlassBtnRim = null;
            RoundRectCache.Clear(); // tahta köşe ayarları değişince zemin/hücre sprite'ları da yenilensin
            TileVersion++;
#if UNITY_EDITOR
            _loggedBuild = false;
#endif
        }

        /// <summary>Karolar her yeniden üretildiğinde artar. Görseller sprite'larını buna bakarak tazeler.</summary>
        public static int TileVersion { get; private set; }

        /// <summary>Blok ışıklandırmasının ayarları (karolar ve UI butonları aynı değerleri kullanır).</summary>
        struct Lighting
        {
            public float bevel, shineAmount, soft, maxSlope, specPower, specStrength, rimDark, ambient;
            public float shadow;    // gölgeli kenarların koyuluğu (0 = gölge yok, 1 = tam)
            public float chamfer;   // 0 = yuvarlak profil, 1 = düz pah
            public float height;    // eğim çarpanı (pahın yüksekliği)
            public float aa;        // bir pikselin hücre birimindeki karşılığı (hat yumuşatma + dış çizgi)

            public static Lighting FromSettings()
            {
                var s = GameSettings.Instance;
                float soft = Mathf.Clamp01(s.unifiedSoftness); // 0 = keskin/metalik, 1 = yumuşak/plastik
                return new Lighting
                {
                    bevel = Mathf.Clamp(s.unifiedBevel, 0.05f, 0.45f),
                    height = Mathf.Clamp(s.unifiedBevelHeight, 0.2f, 3f),
                    shineAmount = Mathf.Lerp(0.35f, 1f, Mathf.Clamp01(s.unifiedShine)),
                    soft = soft,
                    maxSlope = Mathf.Lerp(MaxSlopeSharp, MaxSlopeSoft, soft),
                    specPower = Mathf.Lerp(SpecPowerSharp, SpecPowerSoft, soft),
                    specStrength = Mathf.Lerp(SpecStrengthSharp, SpecStrengthSoft, soft),
                    shadow = Mathf.Clamp01(s.unifiedShadow),
                    // Dış hattaki ince karartma da gölge ayarıyla birlikte açılır
                    rimDark = Mathf.Lerp(1f, Mathf.Lerp(RimDarkSharp, RimDarkSoft, soft), Mathf.Clamp01(s.unifiedShadow)),
                    ambient = Mathf.Lerp(AmbientSharp, AmbientSoft, soft),
                    chamfer = Mathf.Clamp01(s.unifiedChamfer),
                    aa = 1f / 96f,
                };
            }
        }

        /// <summary>
        /// Kenardan uzaklık d (hücre birimi, içeride +) ve kenara dik iç yön (gx, gy) için
        /// gövde tonu (val) ve beyaz parlama (glow) hesaplar.
        /// </summary>
        static void Shade(float d, float gx, float gy, in Lighting L, out float val, out float glow)
        {
            val = FlatTone; glow = 0f;
            if (d >= L.bevel) return;

            // Kenar profili → eğim.
            // Dairesel profil dış kenarda dikleşir (keskin ışık hattı);
            // smoothstep profilinin eğimi iki uçta da sıfırdır (yumuşak geçiş).
            float t = Mathf.Clamp01(d / L.bevel);
            float k = 1f - t;
            float circular = BevelHeight * k / Mathf.Sqrt(Mathf.Max(1f - k * k, 0.04f));
            float rounded = BevelHeight * 9.6f * k * (1f - k);
            float slope = Mathf.Min(Mathf.Lerp(circular, rounded, L.soft), L.maxSlope);
            // Düz pah: kenar boyunca sabit eğim → her kenar tek ton, yüzeyle arasında net hat
            slope = Mathf.Lerp(slope, ChamferSlope, L.chamfer);
            slope *= L.height; // yükseklik: iki profilde de eğimi ölçekler

            var n = new Vector3(-slope * gx, -slope * gy, 1f).normalized;
            float lambert = Mathf.Max(0f, Vector3.Dot(n, LightDir)) / LightDir.z;
            val = FlatTone * (L.ambient + (1f - L.ambient) * lambert);
            // Yalnızca ışık almayan (koyu) yüzeyler gölge ayarıyla açılır; aydınlık kenar ve parlama değişmez
            if (val < FlatTone) val = Mathf.Lerp(FlatTone, val, L.shadow);

            float spec = Mathf.Pow(Mathf.Max(0f, Vector3.Dot(n, HalfDir)), L.specPower);
            float over = Mathf.Max(0f, val - 1f);   // 1'i aşan ışık beyaz parlamaya aktarılır
            val = Mathf.Min(val, 1f);
            glow = Mathf.Min(1f, over * 1.2f + spec * L.specStrength);

            // Pah ile düz yüzey arasındaki hattı tam 1 piksellik geçişle çiz (tırtıklanmasın)
            if (L.chamfer > 0f)
            {
                float inner = Mathf.Clamp01((L.bevel - d) / L.aa + 0.5f);
                float w = Mathf.Lerp(1f, inner, L.chamfer);
                val = Mathf.Lerp(FlatTone, val, w);
                glow *= w;
            }

            float rim = 2f * L.aa;
            if (d < rim) val *= Mathf.Lerp(L.rimDark, 1f, Mathf.Max(d, 0f) / rim);
        }

        // Oyun sırasında eksik bir karo istenirse (ön üretim bitmeden) kullanılan tek seferlik tamponlar: çöp üretmez.
        static Color32[] _syncBody, _syncShine;

        static void BuildTile(int mask)
        {
            var p = CurrentShape();
            if (_syncBody == null || _syncBody.Length != p.Tex * p.Tex) _syncBody = new Color32[p.Tex * p.Tex];
            if (_syncShine == null || _syncShine.Length != p.cell * p.cell) _syncShine = new Color32[p.cell * p.cell];
            ComputeTile(mask, p, _syncBody, _syncShine);
            TileBody[mask] = MakeTileSprite(_syncBody, p.Tex, p.cell, "tile_" + mask);
            TileShine[mask] = MakeTileSprite(_syncShine, p.cell, p.cell, "tile_shine_" + mask);
        }

        /// <summary>Karonun piksellerini hesaplar. Saf hesap (Unity nesnesi kullanmaz): arka plan thread'inde çalışabilir.</summary>
        static void ComputeTile(int mask, in TileShape p, Color32[] body, Color32[] shine)
        {
            int cell = p.cell, margin = p.margin, tex = p.Tex;
            float bevel = p.L.bevel, shineAmount = p.shineAmount;
            float eps = 0.35f / cell;
            System.Array.Clear(shine, 0, shine.Length);

            for (int j = 0; j < tex; j++)
                for (int i = 0; i < tex; i++)
                {
                    // Hücre merkezine göre koordinat (hücre = -0.5..0.5, kenar payı dışarı taşar)
                    float px = (i + 0.5f - margin) / cell - 0.5f;
                    float py = (j + 0.5f - margin) / cell - 0.5f;

                    float d = TileSdf(px, py, mask, p);
                    float a = Mathf.Clamp01(d * cell + 0.5f);   // 1 piksellik doğru anti-aliasing
                    if (a <= 0f) { body[j * tex + i] = default; continue; }

                    float val = FlatTone, glow = 0f;
                    if (d < bevel)
                    {
                        // Kenara dik yön (içeri doğru)
                        float gx = TileSdf(px + eps, py, mask, p) - TileSdf(px - eps, py, mask, p);
                        float gy = TileSdf(px, py + eps, mask, p) - TileSdf(px, py - eps, mask, p);
                        float gl = Mathf.Sqrt(gx * gx + gy * gy);
                        if (gl > 1e-6f) { gx /= gl; gy /= gl; } else { gx = 0f; gy = 0f; }
                        Shade(d, gx, gy, p.L, out val, out glow);
                    }

                    body[j * tex + i] = new Color(val, val, val, a);

                    int ci = i - margin, cj = j - margin;
                    if (ci >= 0 && ci < cell && cj >= 0 && cj < cell)
                        shine[cj * cell + ci] = new Color(1f, 1f, 1f, glow * shineAmount * a);
                }
        }

        /// <summary>
        /// Karonun işaretli mesafe alanı (içeride pozitif, hücre birimi).
        /// Piksel hangi çeyrekteyse o çeyreğin köşesindeki 2x2 hücre düzenine bakılır:
        /// kenar komşusu + dikey komşu + çapraz komşu.
        /// </summary>
        static float TileSdf(float px, float py, int mask, in TileShape p)
        {
            bool right = px >= 0f, up = py >= 0f;
            // Yerel çerçeve: köşe noktası orijinde, bu hücre x<0, y<0 bölgesinde
            float x = Mathf.Abs(px) - 0.5f, y = Mathf.Abs(py) - 0.5f;
            bool h = (mask & (right ? MaskRight : MaskLeft)) != 0;
            bool v = (mask & (up ? MaskUp : MaskDown)) != 0;
            int diagBit = right ? (up ? MaskUpRight : MaskDownRight) : (up ? MaskUpLeft : MaskDownLeft);
            bool dg = (mask & diagBit) != 0 && (h || v);

            if (h && v) return dg ? Big : Notch(x, y, p);     // 4'ü dolu → iç | çapraz boş → iç köşe
            if (h) return dg ? Notch(-x, y, p) : -y - p.inset; // yatay kenar | dikey komşu boş ama çapraz dolu
            if (v) return dg ? Notch(x, -y, p) : -x - p.inset; // dikey kenar | yatay komşu boş ama çapraz dolu
            return Convex(x, y, p);                            // dış köşe
        }

        /// <summary>Dış köşe: yuvarlatılmış kutu köşesi.</summary>
        static float Convex(float x, float y, in TileShape p)
        {
            float c = -p.inset - p.rad;
            float dx = x - c, dy = y - c;
            float ox = Mathf.Max(dx, 0f), oy = Mathf.Max(dy, 0f);
            return -(Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(dx, dy), 0f) - p.rad);
        }

        /// <summary>İç köşe: (+,+) çeyreğindeki boşluk, yumuşak kavisle (fillet).</summary>
        static float Notch(float x, float y, in TileShape p)
        {
            float c = -p.inset + p.fillet;
            float dx = c - x, dy = c - y;
            // Keskin iç köşe: uzaklık köşe noktasına değil, iki kenar çizgisine göre ölçülür.
            // Böylece pah L şeklinde ilerler ve köşede dış köşelerdeki gibi çapraz hatla birleşir.
            if (p.sharpInner) return Mathf.Max(dx, dy);
            float ox = Mathf.Max(dx, 0f), oy = Mathf.Max(dy, 0f);
            return Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(dx, dy), 0f) - p.fillet;
        }

        // ================================================================ UI: blok butonlar ve cam paneller
        //
        // Butonlar, tahtadaki blokların birebir aynı ışıklandırmasıyla (bevel, sol üst ışık, parlama)
        // üretilen 9-dilimli sprite'lar kullanır: yatayda uzatılmış bir blok gibi görünürler.
        // Body gri tonludur ve Image.color ile boyanır; Shine beyaz parlamadır (ayrı katman).
        // Body'nin altında hafif bir gölge vardır (siyah olduğu için boyamadan etkilenmez).

        /// <summary>UI blok sprite'ının kenar payları (piksel). Alt kenara gölge payı eklenir.</summary>
        public const int UIBlockBorder = 44, UIBlockShadowPad = 12;
        /// <summary>UI blok dokusunun yüksekliği (gölge payı dahil).</summary>
        public const int UIBlockTexH = 128 + UIBlockShadowPad;
        public const int UIGlassBorder = 44;

        static Sprite _uiBlockBody, _uiBlockShine, _uiGlassBody, _uiGlassRim;

        /// <summary>Blok görünümlü buton gövdesi (shine=false) veya parlama katmanı (shine=true).</summary>
        public static Sprite UIBlock(bool shine)
        {
            if (_uiBlockBody == null) BuildUIBlock();
            return shine ? _uiBlockShine : _uiBlockBody;
        }

        /// <summary>Board gibi koyu cam panel gövdesi (rim=false) veya ince ışık kenarı (rim=true).</summary>
        public static Sprite UIGlass(bool rim)
        {
            if (_uiGlassBody == null) BuildUIGlass();
            return rim ? _uiGlassRim : _uiGlassBody;
        }

        /// <summary>Yuvarlak kutunun içeride pozitif işaretli uzaklığı (piksel).</summary>
        static float RoundBoxInside(float x, float y, float cx, float cy, float hx, float hy, float r)
        {
            float qx = Mathf.Abs(x - cx) - (hx - r), qy = Mathf.Abs(y - cy) - (hy - r);
            float ox = Mathf.Max(qx, 0f), oy = Mathf.Max(qy, 0f);
            return -(Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(qx, qy), 0f) - r);
        }

        static void BuildUIBlock()
        {
            var s = GameSettings.Instance;
            var L = Lighting.FromSettings();
            const int w = 128, h = UIBlockTexH, pad = UIBlockShadowPad;
            // Blok alanı: x 2..126, y pad+2..h-2 (gölge alttaki payda)
            float cx = w * 0.5f, cy = pad + (h - pad) * 0.5f;
            float hx = w * 0.5f - 2f, hy = (h - pad) * 0.5f - 2f;
            float r = Mathf.Clamp(s.unifiedCornerRadius, 0.02f, 0.45f) * UIRefCell; // karo ile aynı köşe
            r = Mathf.Min(r, UIBlockBorder - 4f);
            const float eps = 0.35f;

            var body = new Color[w * h];
            var shine = new Color[w * h];
            for (int j = 0; j < h; j++)
                for (int i = 0; i < w; i++)
                {
                    float x = i + 0.5f, y = j + 0.5f;
                    float dp = RoundBoxInside(x, y, cx, cy, hx, hy, r);       // piksel
                    float a = Mathf.Clamp01(dp + 0.5f);

                    // Gölge: aşağı kaydırılmış, yumuşak kenarlı koyu şekil (sadece blok dışında görünür)
                    float ds = RoundBoxInside(x, y + pad * 0.6f, cx, cy, hx - 1f, hy - 1f, r);
                    float sh = Mathf.Clamp01((ds + 5f) / 10f) * 0.38f;

                    float val = FlatTone, glow = 0f;
                    if (a > 0f)
                    {
                        float d = dp / UIRefCell; // karo ile aynı birim (hücre)
                        if (d < L.bevel)
                        {
                            float gx = RoundBoxInside(x + eps, y, cx, cy, hx, hy, r) - RoundBoxInside(x - eps, y, cx, cy, hx, hy, r);
                            float gy = RoundBoxInside(x, y + eps, cx, cy, hx, hy, r) - RoundBoxInside(x, y - eps, cx, cy, hx, hy, r);
                            float gl = Mathf.Sqrt(gx * gx + gy * gy);
                            if (gl > 1e-6f) { gx /= gl; gy /= gl; } else { gx = 0f; gy = 0f; }
                            Shade(d, gx, gy, L, out val, out glow);
                        }
                    }
                    // Blok, gölgenin üstüne biner: renk = val*a (gölge siyah), alfa = a + gölge*(1-a)
                    float outA = a + sh * (1f - a);
                    float v = outA > 0f ? val * a / outA : 0f;
                    body[j * w + i] = new Color(v, v, v, outA);
                    shine[j * w + i] = new Color(1f, 1f, 1f, glow * L.shineAmount * a);
                }

            var border = new Vector4(UIBlockBorder, UIBlockBorder + pad, UIBlockBorder, UIBlockBorder); // sol, alt, sağ, üst
            _uiBlockBody = MakeUISprite(body, w, h, border, "ui_block");
            _uiBlockShine = MakeUISprite(shine, w, h, border, "ui_block_shine");
        }

        static Sprite _uiGlassBtnBody, _uiGlassBtnRim;
        static Sprite _softGlow, _roundedSquare;

        /// <summary>
        /// Köşeleri yumuşatılmış beyaz kare (patlama kırıntıları için). "square" sprite'ıyla aynı dünya boyutunda üretilir,
        /// böylece efektlerdeki ölçekler aynı kalır. Köşe yarıçapı kenarın %30'u.
        /// </summary>
        public static Sprite RoundedSquare()
        {
            if (_roundedSquare != null) return _roundedSquare;
            const int n = 64;
            const float half = n * 0.5f - 0.5f, radius = n * 0.3f;
            var px = new Color[n * n];
            for (int j = 0; j < n; j++)
                for (int i = 0; i < n; i++)
                {
                    // Yuvarlatılmış kutu uzaklığı (piksel cinsinden), kenarda 1 piksellik yumuşak geçiş
                    float qx = Mathf.Abs(i + 0.5f - n * 0.5f) - (half - radius);
                    float qy = Mathf.Abs(j + 0.5f - n * 0.5f) - (half - radius);
                    float outside = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude;
                    float d = outside + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
                    px[j * n + i] = new Color(1f, 1f, 1f, Mathf.Clamp01(0.5f - d));
                }
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply();
            var sq = Get("square");
            float ppu = sq != null && sq.bounds.size.x > 0f ? n / sq.bounds.size.x : n;
            _roundedSquare = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), ppu);
            _roundedSquare.name = "fx_rounded_square";
            return _roundedSquare;
        }

        /// <summary>Kenarı belli olmayan buğulu ışık (merkezden dışa yumuşakça söner). Beyaz; renk SpriteRenderer.color ile.</summary>
        public static Sprite SoftGlow()
        {
            if (_softGlow != null) return _softGlow;
            return _softGlow = MakeFxSprite("fx_soft_glow", (r, th) =>
                Mathf.Exp(-r * r / (2f * 0.28f * 0.28f)) * 0.85f + Mathf.Exp(-r * r / (2f * 0.5f * 0.5f)) * 0.25f);
        }

        static Sprite MakeFxSprite(string name, System.Func<float, float, float> alpha)
        {
            const int n = 128;
            var px = new Color[n * n];
            for (int j = 0; j < n; j++)
                for (int i = 0; i < n; i++)
                {
                    float dx = (i + 0.5f) / n * 2f - 1f, dy = (j + 0.5f) / n * 2f - 1f;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float edge = Mathf.Clamp01((1f - r) * 2.5f); // kenarda tam sıfır: kare kesik görünmesin
                    px[j * n + i] = new Color(1f, 1f, 1f, Mathf.Clamp01(alpha(r, Mathf.Atan2(dy, dx))) * edge);
                }
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply();
            var sp = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), n);
            sp.name = name;
            return sp;
        }

        /// <summary>
        /// Cam BUTON gövdesi (rim=false) veya ışık kenarı (rim=true). UIBlock ile birebir aynı geometri:
        /// aynı köşe (unifiedCornerRadius), aynı alt gölge payı ve 9-dilim kenarları. Böylece cam buton ile
        /// blok buton yan yana/üst üste geldiğinde (ör. revive çubuğu) şekilleri tam örtüşür.
        /// </summary>
        public static Sprite UIGlassButton(bool rim)
        {
            if (_uiGlassBtnBody == null) BuildUIGlassButton();
            return rim ? _uiGlassBtnRim : _uiGlassBtnBody;
        }

        static void BuildUIGlassButton()
        {
            var s = GameSettings.Instance;
            const int w = 128, h = UIBlockTexH, pad = UIBlockShadowPad;
            float cx = w * 0.5f, cy = pad + (h - pad) * 0.5f;
            float hx = w * 0.5f - 2f, hy = (h - pad) * 0.5f - 2f;
            float r = Mathf.Clamp(s.unifiedCornerRadius, 0.02f, 0.45f) * UIRefCell; // UIBlock ile aynı köşe
            r = Mathf.Min(r, UIBlockBorder - 4f);
            var l2 = new Vector2(LightDir.x, LightDir.y).normalized;
            const float eps = 0.35f;

            var body = new Color[w * h];
            var rim = new Color[w * h];
            for (int j = 0; j < h; j++)
                for (int i = 0; i < w; i++)
                {
                    float x = i + 0.5f, y = j + 0.5f;
                    float d = RoundBoxInside(x, y, cx, cy, hx, hy, r);
                    float a = Mathf.Clamp01(d + 0.5f);
                    body[j * w + i] = new Color(1f, 1f, 1f, a);

                    float gx = RoundBoxInside(x - eps, y, cx, cy, hx, hy, r) - RoundBoxInside(x + eps, y, cx, cy, hx, hy, r);
                    float gy = RoundBoxInside(x, y - eps, cx, cy, hx, hy, r) - RoundBoxInside(x, y + eps, cx, cy, hx, hy, r);
                    float gl = Mathf.Sqrt(gx * gx + gy * gy);
                    float facing = gl > 1e-6f ? Mathf.Clamp01((gx * l2.x + gy * l2.y) / gl) : 0f;
                    float band = Mathf.Clamp01(1f - Mathf.Abs(d - 1.8f) / 1.5f);
                    rim[j * w + i] = new Color(1f, 1f, 1f, band * (0.10f + 0.45f * facing) * a);
                }

            var border = new Vector4(UIBlockBorder, UIBlockBorder + pad, UIBlockBorder, UIBlockBorder); // UIBlock ile aynı
            _uiGlassBtnBody = MakeUISprite(body, w, h, border, "ui_glass_button");
            _uiGlassBtnRim = MakeUISprite(rim, w, h, border, "ui_glass_button_rim");
        }

        static void BuildUIGlass()
        {
            const int n = 128;
            const float r = 34f;
            float c = n * 0.5f, half = n * 0.5f - 1f;
            // Işığın ekrandaki yönü (sol üst): kenarın bu yöne bakan kısmı parlar
            var l2 = new Vector2(LightDir.x, LightDir.y).normalized;
            const float eps = 0.35f;

            var body = new Color[n * n];
            var rim = new Color[n * n];
            for (int j = 0; j < n; j++)
                for (int i = 0; i < n; i++)
                {
                    float x = i + 0.5f, y = j + 0.5f;
                    float d = RoundBoxInside(x, y, c, c, half, half, r);
                    float a = Mathf.Clamp01(d + 0.5f);
                    body[j * n + i] = new Color(1f, 1f, 1f, a);

                    // İnce ışık kenarı: kenardan ~1.5 px içeride, ışığa bakan tarafta daha parlak
                    float gx = RoundBoxInside(x - eps, y, c, c, half, half, r) - RoundBoxInside(x + eps, y, c, c, half, half, r);
                    float gy = RoundBoxInside(x, y - eps, c, c, half, half, r) - RoundBoxInside(x, y + eps, c, c, half, half, r);
                    float gl = Mathf.Sqrt(gx * gx + gy * gy);
                    float facing = gl > 1e-6f ? Mathf.Clamp01((gx * l2.x + gy * l2.y) / gl) : 0f;
                    float band = Mathf.Clamp01(1f - Mathf.Abs(d - 1.8f) / 1.5f);
                    rim[j * n + i] = new Color(1f, 1f, 1f, band * (0.10f + 0.45f * facing) * a);
                }

            var border = new Vector4(UIGlassBorder, UIGlassBorder, UIGlassBorder, UIGlassBorder);
            _uiGlassBody = MakeUISprite(body, n, n, border, "ui_glass");
            _uiGlassRim = MakeUISprite(rim, n, n, border, "ui_glass_rim");
        }

        static Sprite MakeUISprite(Color[] px, int w, int h, Vector4 border, string name)
        {
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply(false, true); // CPU kopyası gereksiz (FullRect sprite piksel okumaz)
            // ppu 100 = Canvas'ın varsayılan referans ppu'su → Image.pixelsPerUnitMultiplier ile ölçeklenir
            var sp = Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
            sp.name = name;
            return sp;
        }

        // ================================================================ Tahta: yuvarlak köşeli zemin ve hücreler

        /// <summary>Köşe yayının dokudaki çözünürlüğü (piksel). Büyüdükçe kenar daha pürüzsüz.</summary>
        const int RoundRectRes = 48;
        static readonly Dictionary<int, Sprite> RoundRectCache = new Dictionary<int, Sprite>();

        /// <summary>
        /// Beyaz, yuvarlak köşeli 9-dilimli sprite. SpriteRenderer.drawMode = Sliced ile kullan;
        /// hangi boyuta çekilirse çekilsin köşe yarıçapı dünya biriminde sabit kalır.
        /// radiusWorld: köşe yarıçapı (1 = bir hücre). 0 = sivri köşe.
        /// </summary>
        public static Sprite RoundedRect(float radiusWorld)
        {
            int key = Mathf.RoundToInt(Mathf.Max(0f, radiusWorld) * 1000f);
            if (RoundRectCache.TryGetValue(key, out var s) && s != null) return s;

            Texture2D tex;
            if (key <= 0)
            {
                // Sivri köşe: düz beyaz kare, kenar payı yok
                const int q = 4;
                var flat = new Color[q * q];
                for (int i = 0; i < flat.Length; i++) flat[i] = Color.white;
                tex = new Texture2D(q, q, TextureFormat.RGBA32, false);
                tex.wrapMode = TextureWrapMode.Clamp;
                tex.filterMode = FilterMode.Bilinear;
                tex.SetPixels(flat);
                tex.Apply();
                s = Sprite.Create(tex, new Rect(0, 0, q, q), new Vector2(0.5f, 0.5f), q, 0, SpriteMeshType.FullRect, Vector4.zero);
            }
            else
            {
                const int R = RoundRectRes;
                const int n = R * 2 + 8;          // ortada 4 px'lik uzatılabilir şerit kalır
                float c = n * 0.5f, half = n * 0.5f;
                var px = new Color[n * n];
                for (int j = 0; j < n; j++)
                    for (int i = 0; i < n; i++)
                    {
                        float d = RoundBoxInside(i + 0.5f, j + 0.5f, c, c, half, half, R);
                        px[j * n + i] = new Color(1f, 1f, 1f, Mathf.Clamp01(d + 0.5f));
                    }
                tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
                tex.wrapMode = TextureWrapMode.Clamp;
                tex.filterMode = FilterMode.Bilinear;
                tex.SetPixels(px);
                tex.Apply(false, true); // CPU kopyası gereksiz (FullRect sprite piksel okumaz)
                // ppu öyle seçilir ki R piksel = radiusWorld dünya birimi olsun
                float ppu = R / (key / 1000f);
                const int b = R + 2;
                s = Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), ppu, 0,
                    SpriteMeshType.FullRect, new Vector4(b, b, b, b));
            }
            s.name = "round_rect_" + key;
            RoundRectCache[key] = s;
            return s;
        }

        static Sprite MakeTileSprite(Color32[] px, int size, int ppu, string name)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels32(px);
            tex.Apply(false, true); // PERFORMANS: CPU'daki kopya silinir (yalnızca GPU'da kalır; 161 karo ≈ 20+ MB RAM)
            var sp = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), ppu, 0, SpriteMeshType.FullRect);
            sp.name = name;
            return sp;
        }

        public static Font Font
        {
            get
            {
                if (_font == null)
                {
                    _font = Resources.Load<Font>("BlockRiseFont");
                    if (_font == null) _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                }
                return _font;
            }
        }
    }
}