using System;
using System.IO;
using UnityEngine;

namespace BlockRise
{
    /// <summary>Kaydedilmiş endless oyunu (oyuncu uygulamayı kapatıp açınca kaldığı yerden devam eder).</summary>
    [Serializable]
    public class EndlessSaveData
    {
        public int version = 1;
        public int width, height;
        // Hücreler x + y * width sırasıyla; renk -1 = boş
        public int[] colors, specials;
        public int[] nextColors, nextSpecials;

        public int score, turn, totalCleared, bombs, lightnings;
        public int[] clearedByColor;
        public int turnsSinceRise, comboStreak, dryTurns;
        // Casual akış sayaçları (kapatıp açmak yeni kurtuluş hakkı vermesin). Eski kayıtlarda yoksa 0 gelir.
        public int turnsSinceSpecial, rescueUsed, rescueLeft, nextRescueTurn, maxChain;
        public bool reviveUsed;
        // Bu oyunun zorluk ayarları (devam edince aynı oyun aynı zorlukta sürsün)
        public int bestAtStart, hotStartTurns;
        public float ease;
        // Classic yönetmeni v2 (kademe, dalga, can simidi). Eski kayıtlarda yoksa 0 gelir (kademe 1, build).
        public int stage, wavePhase, phaseTurn, phaseLength, waveIndex, waveSeed, lifelineUsed, nextLifelineTurn;
        public bool skipUsed;
    }

    /// <summary>
    /// Endless kaydı: Application.persistentDataPath/endless_save.json. Her tur sonunda yazılır, oyun bitince silinir.
    /// Yazma önce geçici dosyaya yapılır, sonra yerine konur: yazarken uygulama kapanırsa kayıt bozulmaz.
    /// </summary>
    public static class EndlessSave
    {
        const int Version = 1;
        static string FilePath => Path.Combine(Application.persistentDataPath, "endless_save.json");

        public static bool Exists => File.Exists(FilePath);

        public static void Write(EndlessSaveData data)
        {
            try
            {
                data.version = Version;
                string tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonUtility.ToJson(data));
                if (File.Exists(FilePath)) File.Delete(FilePath);
                File.Move(tmp, FilePath);
            }
            catch (Exception e) { Debug.LogWarning("[BlockRise] Endless kaydı yazılamadı: " + e.Message); }
        }

        /// <summary>Geçerli bir kayıt varsa döndürür; bozuk ya da bu tahta boyutuna uymuyorsa siler ve null döner.</summary>
        public static EndlessSaveData Load(int width, int height)
        {
            if (!Exists) return null;
            try
            {
                var d = JsonUtility.FromJson<EndlessSaveData>(File.ReadAllText(FilePath));
                int n = width * height;
                bool ok = d != null && d.version == Version && d.width == width && d.height == height
                          && d.colors != null && d.colors.Length == n && d.specials != null && d.specials.Length == n
                          && d.nextColors != null && d.nextColors.Length == width
                          && d.nextSpecials != null && d.nextSpecials.Length == width;
                if (ok) return d;
            }
            catch (Exception e) { Debug.LogWarning("[BlockRise] Endless kaydı okunamadı: " + e.Message); }
            Clear();
            return null;
        }

        public static void Clear()
        {
            try { if (File.Exists(FilePath)) File.Delete(FilePath); }
            catch (Exception e) { Debug.LogWarning("[BlockRise] Endless kaydı silinemedi: " + e.Message); }
        }
    }
}
