using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    [Serializable]
    public class AdventureColor
    {
        public string code;   // resim satırlarındaki tek harf
        public string color;  // "#RRGGBB"
    }

    [Serializable]
    public class AdventurePicture
    {
        public string key;
        /// <summary>İngilizce ad; Loc tablosundaki anahtar (resim tamamlanınca gösterilir).</summary>
        public string name;
        /// <summary>Üst satır önce. '.' = boş hücre, diğer harfler paletteki renkler.</summary>
        public string[] rows = new string[0];
    }

    [Serializable]
    public class AdventureList
    {
        public int levelsPerPicture = 20;
        public AdventureColor[] palette = new AdventureColor[0];
        public AdventurePicture[] pictures = new AdventurePicture[0];
    }

    /// <summary>
    /// Adventure resimleri (Resources/BlockRiseAdventures.json). Her resim art arda gelen levelsPerPicture bölümle
    /// açılır: bölüm tamamlandıkça resmin blokları ALTTAN YUKARI (Block Rise!) ortaya çıkar, son bölümle resim tamamlanır.
    /// </summary>
    public static class AdventureDatabase
    {
        public const string ResourcePath = "BlockRiseAdventures";
        const string KeySeen = "br_adv_seen_";

        static AdventureList _list;
        static Dictionary<char, Color> _palette;
        static readonly Dictionary<int, Vector2Int[]> _order = new Dictionary<int, Vector2Int[]>();

        public static AdventureList List
        {
            get
            {
                if (_list == null) Load();
                return _list;
            }
        }

        public static int LevelsPerPicture => Mathf.Max(1, List.levelsPerPicture);

        /// <summary>Bölüm sayısının gerektirdiği resim sayısı (resim verisi eksikse son resimler tekrar kullanılır).</summary>
        public static int Count => Mathf.Max(1, Mathf.CeilToInt(LevelDatabase.Count / (float)LevelsPerPicture));

        public static AdventurePicture Picture(int index)
        {
            var pics = List.pictures;
            if (pics == null || pics.Length == 0) return Fallback;
            return pics[Mathf.Clamp(index, 0, int.MaxValue) % pics.Length];
        }

        /// <summary>Bölümün ait olduğu resim.</summary>
        public static int PictureOfLevel(int levelIndex) => Mathf.Clamp(levelIndex / LevelsPerPicture, 0, Count - 1);

        public static int FirstLevel(int picture) => picture * LevelsPerPicture;

        /// <summary>Resimdeki bölüm sayısı (son resim eksik olabilir).</summary>
        public static int LevelCount(int picture) => Mathf.Clamp(LevelDatabase.Count - FirstLevel(picture), 0, LevelsPerPicture);

        /// <summary>Resmin tamamlanmış (en az 1 yıldızlı) bölüm sayısı.</summary>
        public static int CompletedLevels(int picture)
        {
            int n = 0, first = FirstLevel(picture), count = LevelCount(picture);
            for (int i = 0; i < count; i++) if (SaveSystem.GetStars(first + i) > 0) n++;
            return n;
        }

        public static bool IsComplete(int picture) => LevelCount(picture) > 0 && CompletedLevels(picture) >= LevelCount(picture);

        /// <summary>Oyuncunun şu an oynadığı resim: açık olan en yüksek bölümün resmi.</summary>
        public static int CurrentPicture => PictureOfLevel(SaveSystem.UnlockedLevel);

        public static Color ColorOf(char code)
        {
            if (_palette == null) Load();
            return _palette.TryGetValue(code, out var c) ? c : Color.white;
        }

        /// <summary>
        /// Açılma sırası: alt satırdan üste, satır içinde soldan sağa. Hücre (x, y): y = 0 üst satır (rows ile aynı).
        /// </summary>
        public static Vector2Int[] RevealOrder(int picture)
        {
            int key = picture % Mathf.Max(1, List.pictures.Length);
            if (_order.TryGetValue(key, out var o)) return o;
            var rows = Picture(picture).rows;
            var list = new List<Vector2Int>();
            for (int y = rows.Length - 1; y >= 0; y--)
                for (int x = 0; x < rows[y].Length; x++)
                    if (rows[y][x] != '.') list.Add(new Vector2Int(x, y));
            o = list.ToArray();
            _order[key] = o;
            return o;
        }

        /// <summary>
        /// Bölüm konumuna göre açılan blok payı (20'lik macera): zor bölümler (9, 15, 18), ara boss (10), boss (19) ve
        /// resmi tamamlayan final (20) daha büyük parça açar. Toplam 256 (16x16 resim için blok blok).
        /// </summary>
        static readonly int[] RevealWeights = { 10, 10, 10, 10, 10, 10, 10, 10, 14, 22, 10, 10, 10, 10, 14, 10, 10, 14, 24, 28 };

        static int RevealWeight(int pos) => pos >= 0 && pos < RevealWeights.Length ? RevealWeights[pos] : 10;

        /// <summary>completed bölüm tamamlanınca açık olan blok sayısı. Son bölüm resmi her zaman tamamlar.</summary>
        public static int RevealedCells(int picture, int completed)
        {
            int n = RevealOrder(picture).Length, total = Mathf.Max(1, LevelCount(picture));
            if (completed >= total) return n;
            if (completed <= 0) return 0;
            int sum = 0, part = 0;
            for (int i = 0; i < total; i++)
            {
                int w = RevealWeight(i);
                sum += w;
                if (i < completed) part += w;
            }
            return Mathf.Clamp(Mathf.FloorToInt(n * part / (float)sum), 0, n);
        }

        /// <summary>
        /// Oyuncunun bu resimde en son GÖRDÜĞÜ tamamlanmış bölüm sayısı (yeni açılan blokların animasyonu için).
        /// Hiç kaydı yoksa (ör. güncellemeyle gelen oyuncu) mevcut ilerleme görülmüş sayılır: eski bölümler için animasyon olmaz.
        /// </summary>
        public static int Seen(int picture)
        {
            int v = PlayerPrefs.GetInt(KeySeen + picture, -1);
            if (v >= 0) return v;
            int done = CompletedLevels(picture);
            SetSeen(picture, done);
            return done;
        }

        public static void SetSeen(int picture, int completed)
        {
            PlayerPrefs.SetInt(KeySeen + picture, completed);
            PlayerPrefs.Save();
        }

        /// <summary>Henüz görülmemiş açılması olan en eski resim (yoksa -1). Kazanılan bölümden dönünce o resim gösterilir.</summary>
        public static int PendingReveal(int upTo)
        {
            for (int p = 0; p <= upTo && p < Count; p++)
            {
                int key = PlayerPrefs.GetInt(KeySeen + p, -1);
                if (key < 0) continue;                         // hiç bakılmamış eski resim: bekleyen animasyon yok
                if (CompletedLevels(p) > key) return p;
            }
            return -1;
        }

        public static void Load()
        {
            _list = new AdventureList();
            _palette = new Dictionary<char, Color>();
            _order.Clear();
            var ta = Resources.Load<TextAsset>(ResourcePath);
            if (ta == null) Debug.LogError("[BlockRise] Resources/" + ResourcePath + ".json bulunamadı.");
            else
            {
                try { _list = JsonUtility.FromJson<AdventureList>(ta.text) ?? new AdventureList(); }
                catch (Exception e) { Debug.LogError("[BlockRise] Adventure JSON okunamadı: " + e.Message); _list = new AdventureList(); }
            }
            if (_list.pictures == null) _list.pictures = new AdventurePicture[0];
            if (_list.palette != null)
                foreach (var p in _list.palette)
                    if (p != null && !string.IsNullOrEmpty(p.code) && ColorUtility.TryParseHtmlString(p.color, out var c))
                        _palette[p.code[0]] = c;
        }

        static readonly AdventurePicture Fallback = new AdventurePicture
        {
            key = "block", name = "BLOCK RISE",
            rows = new[] { "kkkkkkkk", "kbbbbbbk", "kbccccbk", "kbccccbk", "kbccccbk", "kbccccbk", "kbbbbbbk", "kkkkkkkk" },
        };
    }
}
