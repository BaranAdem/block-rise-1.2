using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>Oyunun desteklediği diller (mobil oyun pazarında en büyük paya sahip ülkelerin dilleri).</summary>
    public enum Language
    {
        English, Turkish, German, French, Spanish, Portuguese, Italian, Russian,
        Japanese, Korean, ChineseSimplified, ChineseTraditional
    }

    /// <summary>
    /// Yerelleştirme. Çeviriler Resources/BlockRiseLoc.txt dosyasındadır (sekmeyle ayrılmış tablo):
    /// ilk sütun İngilizce metnin kendisidir ve ANAHTAR olarak kullanılır, diğer sütunlar sırayla
    /// tr, de, fr, es, pt-BR, it, ru, ja, ko, zh-Hans, zh-Hant. Satır içi yeni satır "\n" olarak yazılır.
    /// Dosyayı Google Sheets / Excel'de açıp çevirmene gönderebilirsin; boş bırakılan hücre İngilizce gösterilir.
    ///
    /// Kullanım:
    ///   Loc.T("GAME OVER")              → seçili dilde metin (çevirisi yoksa İngilizce)
    ///   Loc.F("LEVEL {0} CLEAR!", 12)   → çevrilmiş biçim + değerler
    ///   Loc.Bind(text, () => ...)        → dil değişince bu yazı kendiliğinden yenilenir
    /// UIFactory.Text / Button / SetLabel, UIManager.Toast ve FxManager yazıları anahtarları kendisi çevirir.
    ///
    /// Dil ilk açılışta cihaz dilinden seçilir; oyuncu ana menüdeki dil düğmesinden değiştirebilir.
    /// </summary>
    public static class Loc
    {
        const string KeyLang = "br_language";
        const string ResourceName = "BlockRiseLoc";

        public static Language Current { get; private set; } = Language.English;
        public static bool IsEnglish => Current == Language.English;
        /// <summary>Dil değişince (Set) tetiklenir.</summary>
        public static event Action Changed;

        static Dictionary<string, string[]> _table;
        static bool _inited;

        /// <summary>Dil menüsünde gösterilen adlar (her dil kendi dilinde).</summary>
        public static readonly string[] NativeNames =
        {
            "English", "Türkçe", "Deutsch", "Français", "Español", "Português (Brasil)", "Italiano", "Русский",
            "日本語", "한국어", "简体中文", "繁體中文"
        };

        /// <summary>Dil düğmesinde gösterilen kısa kod.</summary>
        public static readonly string[] ShortCodes = { "EN", "TR", "DE", "FR", "ES", "PT", "IT", "RU", "JA", "KO", "中文", "繁中" };

        public static int Count => NativeNames.Length;

        // ================================================================ Kurulum

        /// <summary>Açılışta her şeyden önce (UI kurulmadan) çağrılır.</summary>
        public static void Init()
        {
            if (_inited) return;
            _inited = true;
            Load();
            int saved = PlayerPrefs.GetInt(KeyLang, -1);
            Current = saved >= 0 && saved < Count ? (Language)saved : FromSystem(Application.systemLanguage);
            ApplyFontFallbacks();
        }

        static void Load()
        {
            _table = new Dictionary<string, string[]>();
            var asset = Resources.Load<TextAsset>(ResourceName);
            if (asset == null)
            {
                Debug.LogWarning("[BlockRise] Resources/" + ResourceName + ".txt bulunamadı — oyun İngilizce açılır.");
                return;
            }
            var lines = asset.text.Split('\n');
            for (int i = 1; i < lines.Length; i++) // 0. satır başlık
            {
                var line = lines[i].TrimEnd('\r');
                if (line.Length == 0) continue;
                var cols = line.Split('\t');
                for (int c = 0; c < cols.Length; c++) cols[c] = cols[c].Replace("\\n", "\n");
                var key = cols[0];
                if (key.Length == 0 || _table.ContainsKey(key)) continue;
                _table[key] = cols;
            }
        }

        static Language FromSystem(SystemLanguage s)
        {
            switch (s)
            {
                case SystemLanguage.Turkish: return Language.Turkish;
                case SystemLanguage.German: return Language.German;
                case SystemLanguage.French: return Language.French;
                case SystemLanguage.Spanish: return Language.Spanish;
                case SystemLanguage.Portuguese: return Language.Portuguese;
                case SystemLanguage.Italian: return Language.Italian;
                case SystemLanguage.Russian: return Language.Russian;
                case SystemLanguage.Japanese: return Language.Japanese;
                case SystemLanguage.Korean: return Language.Korean;
                case SystemLanguage.ChineseTraditional: return Language.ChineseTraditional;
                case SystemLanguage.Chinese:
                case SystemLanguage.ChineseSimplified: return Language.ChineseSimplified;
                default: return Language.English;
            }
        }

        /// <summary>Dili değiştirir, kaydeder ve bağlı yazıları yeniler.</summary>
        public static void Set(Language lang)
        {
            if (!_inited) Init();
            PlayerPrefs.SetInt(KeyLang, (int)lang);
            PlayerPrefs.Save();
            if (lang == Current) return;
            Current = lang;
            ApplyFontFallbacks();
            RefreshBindings();
            Changed?.Invoke();
        }

        // ================================================================ Çeviri

        /// <summary>Anahtar (İngilizce metin) için seçili dildeki karşılık. Yoksa metnin kendisi.</summary>
        public static string T(string en)
        {
            if (string.IsNullOrEmpty(en) || Current == Language.English || _table == null) return en;
            if (_table.TryGetValue(en, out var cols))
            {
                int i = (int)Current;
                if (i < cols.Length && !string.IsNullOrEmpty(cols[i])) return cols[i];
            }
            return en;
        }

        /// <summary>Çevrilmiş biçim metni + değerler (string.Format).</summary>
        public static string F(string enFormat, params object[] args)
        {
            var fmt = T(enFormat);
            try { return string.Format(fmt, args); }
            catch (FormatException) { return string.Format(enFormat, args); } // bozuk çeviri oyunu düşürmesin
        }

        /// <summary>Bu metin tabloda anahtar olarak var mı.</summary>
        public static bool Has(string en)
        {
            if (!_inited) Init();
            return !string.IsNullOrEmpty(en) && _table != null && _table.ContainsKey(en);
        }

        /// <summary>Büyük harfe çevirir (Türkçede i → İ doğru olsun diye dile göre).</summary>
        public static string Upper(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            if (Current == Language.Turkish)
                return s.ToUpper(System.Globalization.CultureInfo.GetCultureInfo("tr-TR"));
            return s.ToUpperInvariant();
        }

        /// <summary>Haftanın günleri (Pazartesi'den başlar), tek harf / tek karakter.</summary>
        public static string[] WeekLetters()
        {
            switch (Current)
            {
                case Language.Turkish: return new[] { "P", "S", "Ç", "P", "C", "C", "P" };
                case Language.German: return new[] { "M", "D", "M", "D", "F", "S", "S" };
                case Language.French: return new[] { "L", "M", "M", "J", "V", "S", "D" };
                case Language.Spanish: return new[] { "L", "M", "X", "J", "V", "S", "D" };
                case Language.Portuguese: return new[] { "S", "T", "Q", "Q", "S", "S", "D" };
                case Language.Italian: return new[] { "L", "M", "M", "G", "V", "S", "D" };
                case Language.Russian: return new[] { "П", "В", "С", "Ч", "П", "С", "В" };
                case Language.Japanese: return new[] { "月", "火", "水", "木", "金", "土", "日" };
                case Language.Korean: return new[] { "월", "화", "수", "목", "금", "토", "일" };
                case Language.ChineseSimplified:
                case Language.ChineseTraditional: return new[] { "一", "二", "三", "四", "五", "六", "日" };
                default: return new[] { "M", "T", "W", "T", "F", "S", "S" };
            }
        }

        // ================================================================ Yazı bağlama

        class Binding
        {
            public UnityEngine.UI.Text text;
            public Func<string> source;
            public string last;
        }

        static readonly List<Binding> _bindings = new List<Binding>();
        static int _pruneAt = 256;

        /// <summary>
        /// Yazıyı bir kaynağa bağlar: şimdi yazar ve dil değişince yeniden yazar. Kod bu yazıyı sonradan başka bir
        /// şeyle değiştirdiyse (ör. "SCORE" → "NEW BEST") bağlama ona dokunmaz; o yazıyı kodun kendisi
        /// bir sonraki gösterimde güncel dilde yazar.
        /// </summary>
        public static void Bind(UnityEngine.UI.Text t, Func<string> source)
        {
            if (t == null || source == null) return;
            // Yok edilmiş yazıların kayıtlarını ara ara temizle (liste ekranlar yeniden kuruldukça büyümesin)
            if (_bindings.Count >= _pruneAt)
            {
                _bindings.RemoveAll(x => x.text == null);
                _pruneAt = Mathf.Max(256, _bindings.Count * 2);
            }
            for (int i = 0; i < _bindings.Count; i++)
                if (ReferenceEquals(_bindings[i].text, t)) { _bindings.RemoveAt(i); break; }
            var b = new Binding { text = t, source = source };
            b.last = t.text = source();
            _bindings.Add(b);
        }

        static void RefreshBindings()
        {
            for (int i = _bindings.Count - 1; i >= 0; i--)
            {
                var b = _bindings[i];
                if (b.text == null) { _bindings.RemoveAt(i); continue; } // yok edilmiş yazı
                if (b.text.text != b.last) continue;                    // kod değiştirmiş: dokunma
                b.last = b.text.text = b.source();
            }
        }

        // ================================================================ Yazı tipi

        /// <summary>
        /// Oyunun yazı tipi (Poppins) Latin harflerini içerir; Kiril, Japonca, Korece ve Çince karakterler cihazın
        /// sistem yazı tipinden çizilir. Japonca ve Çince aynı karakterleri farklı biçimde yazar: doğru biçim
        /// gelsin diye dile göre önce o dilin sistem yazı tipi denenir.
        /// </summary>
        static void ApplyFontFallbacks()
        {
            var font = SpriteLibrary.Font;
            if (font == null) return;
            string[] names;
            switch (Current)
            {
                case Language.Japanese:
                    names = new[] { "Poppins", "Hiragino Sans", "Hiragino Kaku Gothic ProN", "Noto Sans CJK JP", "Noto Sans JP", "Droid Sans Japanese", "Arial Unicode MS" };
                    break;
                case Language.Korean:
                    names = new[] { "Poppins", "Apple SD Gothic Neo", "Noto Sans CJK KR", "Noto Sans KR", "Malgun Gothic", "Arial Unicode MS" };
                    break;
                case Language.ChineseSimplified:
                    names = new[] { "Poppins", "PingFang SC", "Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "Arial Unicode MS" };
                    break;
                case Language.ChineseTraditional:
                    names = new[] { "Poppins", "PingFang TC", "Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", "Arial Unicode MS" };
                    break;
                default:
                    names = new[] { "Poppins", "Helvetica Neue", "Roboto", "Arial" };
                    break;
            }
            try { font.fontNames = names; } catch { /* bazı platformlarda salt okunur olabilir: sistem yine yedek yazı tipine düşer */ }
        }
    }
}
