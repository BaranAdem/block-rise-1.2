using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Oyun arka planı: iki renkli dikey gradyan + üzerine çok hafif alacalı (bulutsu) doku.
    /// Paletler arasında yumuşak geçiş yapar; hiçbir anda sert renk sıçraması olmaz.
    /// Tüm dokular kodda üretilir, PNG gerekmez.
    ///
    /// Katmanlar (hepsi kameranın çocuğu, ekranı tam kaplar):
    ///   Top    (sortingOrder -103) → üst renk, düz dolgu
    ///   Ramp   (sortingOrder -102) → alt renk, yukarı doğru saydamlaşan dikey geçiş
    ///   Mottle (sortingOrder -101) → alacalı doku, çok düşük opaklık, yavaşça kayar
    /// </summary>
    [DisallowMultipleComponent]
    public class BackgroundGradient : MonoBehaviour
    {
        /// <summary>Bir paletin üst ve alt rengi.</summary>
        public struct Palette
        {
            public Color Top, Bottom;
            public Palette(float tr, float tg, float tb, float br, float bg, float bb)
            {
                Top = new Color(tr, tg, tb);
                Bottom = new Color(br, bg, bb);
            }
        }

        /// <summary>
        /// Göz yormayan, bloklarla kontrast veren koyu-orta tonlu palet çiftleri.
        /// Bloklar doygun renkte olduğu için arka plan bilerek düşük doygunlukta tutuldu.
        /// </summary>
        public static readonly Palette[] Palettes =
        {
            new Palette(0.11f, 0.15f, 0.26f, 0.24f, 0.35f, 0.50f), // gece mavisi
            new Palette(0.15f, 0.12f, 0.24f, 0.33f, 0.24f, 0.44f), // mürdüm
            new Palette(0.08f, 0.18f, 0.23f, 0.17f, 0.36f, 0.41f), // derin deniz
            new Palette(0.19f, 0.11f, 0.19f, 0.39f, 0.22f, 0.31f), // kadife bordo
            new Palette(0.11f, 0.17f, 0.15f, 0.24f, 0.36f, 0.29f), // zeytin gece
            new Palette(0.17f, 0.14f, 0.13f, 0.36f, 0.29f, 0.25f), // sıcak arduvaz
        };

        [Tooltip("Bir palette kaç saniye kalınır")]
        public float holdSeconds = 14f;
        [Tooltip("İki palet arası geçiş kaç saniye sürer")]
        public float blendSeconds = 6f;
        [Tooltip("Alacalı dokunun belirginliği (0 = düz gradyan)")]
        [Range(0f, 0.25f)] public float mottleStrength = 0.07f;
        [Tooltip("Alacalı dokunun kayma hızı (birim/saniye)")]
        public float mottleDrift = 0.012f;

        Camera _cam;
        SpriteRenderer _top, _ramp, _mottle;
        int _from, _to;
        float _t;
        int _lastW, _lastH;
        float _lastOrtho;
        Vector2 _drift;

        public void Init(Camera cam)
        {
            _cam = cam;
            if (_cam == null) return;

            _top = MakeLayer("BgTop", SolidTexture(), -103);
            _ramp = MakeLayer("BgRamp", RampTexture(), -102);
            _mottle = MakeLayer("BgMottle", MottleTexture(), -101);

            _from = Random.Range(0, Palettes.Length);
            _to = (_from + 1) % Palettes.Length;
            _t = 0f;
            Apply(Palettes[_from]);
            Layout(true);
        }

        SpriteRenderer MakeLayer(string name, Texture2D tex, int order)
        {
            var go = new GameObject(name);
            go.transform.SetParent(_cam.transform, false);
            // Kamera z = -10, bloklar z = 0. Arka planı blokların arkasına al.
            go.transform.localPosition = new Vector3(0f, 0f, 20f);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect);
            sr.sortingOrder = order;
            return sr;
        }

        void Update()
        {
            if (_cam == null) return;
            Layout(false);

            float cycle = Mathf.Max(0.5f, holdSeconds + blendSeconds);
            _t += Time.deltaTime / cycle;
            if (_t >= 1f)
            {
                _t -= 1f;
                _from = _to;
                _to = (_to + 1) % Palettes.Length;
            }

            // Geçiş, döngünün sadece blendSeconds kadarlık son kısmında olur
            float blendFrac = blendSeconds / cycle;
            float k = blendFrac <= 0f ? 0f : Mathf.Clamp01((_t - (1f - blendFrac)) / blendFrac);
            k = k * k * (3f - 2f * k); // yumuşak giriş/çıkış

            var a = Palettes[_from];
            var b = Palettes[_to];
            Palette cur;
            cur.Top = Color.Lerp(a.Top, b.Top, k);
            cur.Bottom = Color.Lerp(a.Bottom, b.Bottom, k);
            Apply(cur);

            // Alacalı doku çok yavaş kayar → sabit desen hissi vermez
            if (_mottle != null && mottleDrift > 0f)
            {
                _drift.x += mottleDrift * Time.deltaTime;
                _drift.y += mottleDrift * 0.6f * Time.deltaTime;
                var p = _mottle.transform.localPosition;
                float amp = _lastOrtho * 0.05f;
                _mottle.transform.localPosition = new Vector3(
                    Mathf.Sin(_drift.x) * amp, Mathf.Cos(_drift.y) * amp, p.z);
            }
        }

        void Apply(Palette p)
        {
            if (_top != null) _top.color = p.Top;
            if (_ramp != null) _ramp.color = p.Bottom;
            if (_mottle != null)
            {
                // Alacalık üst rengin biraz açığı → ton uyumu bozulmaz
                var m = Color.Lerp(p.Top, Color.white, 0.55f);
                m.a = mottleStrength;
                _mottle.color = m;
            }
            if (_cam != null) _cam.backgroundColor = p.Top;
        }

        /// <summary>Katmanları ekranı tam kaplayacak şekilde ölçekler.</summary>
        void Layout(bool force)
        {
            if (!force && Screen.width == _lastW && Screen.height == _lastH
                && Mathf.Approximately(_cam.orthographicSize, _lastOrtho)) return;

            _lastW = Screen.width;
            _lastH = Screen.height;
            _lastOrtho = _cam.orthographicSize;

            float h = _lastOrtho * 2f;
            float w = h * _cam.aspect;
            // Kaymaya ve güvenli alan farklarına pay bırak
            Fit(_top, w * 1.25f, h * 1.25f);
            Fit(_ramp, w * 1.25f, h * 1.25f);
            Fit(_mottle, w * 1.4f, h * 1.4f);
        }

        static void Fit(SpriteRenderer sr, float w, float h)
        {
            if (sr == null || sr.sprite == null) return;
            var b = sr.sprite.bounds.size;
            sr.transform.localScale = new Vector3(w / Mathf.Max(0.0001f, b.x), h / Mathf.Max(0.0001f, b.y), 1f);
        }

        // ---------------------------------------------------------------- dokular

        static Texture2D SolidTexture()
        {
            var t = new Texture2D(4, 4, TextureFormat.RGBA32, false);
            var px = new Color[16];
            for (int i = 0; i < px.Length; i++) px[i] = Color.white;
            t.SetPixels(px);
            t.wrapMode = TextureWrapMode.Clamp;
            t.Apply();
            return t;
        }

        /// <summary>Aşağıda opak, yukarıda saydam dikey geçiş.</summary>
        static Texture2D RampTexture()
        {
            const int h = 512;
            var t = new Texture2D(4, h, TextureFormat.RGBA32, false);
            var px = new Color[4 * h];
            for (int y = 0; y < h; y++)
            {
                float k = 1f - y / (float)(h - 1);      // 0 = üst, 1 = alt
                k = k * k * (3f - 2f * k);              // yumuşak geçiş
                for (int x = 0; x < 4; x++) px[y * 4 + x] = new Color(1f, 1f, 1f, k);
            }
            t.SetPixels(px);
            t.wrapMode = TextureWrapMode.Clamp;
            t.filterMode = FilterMode.Bilinear;
            t.Apply();
            return t;
        }

        /// <summary>Yumuşak, bulutsu alacalı doku (üst üste binmiş value noise).</summary>
        static Texture2D MottleTexture()
        {
            const int n = 256;
            var t = new Texture2D(n, n, TextureFormat.RGBA32, false);
            var px = new Color[n * n];
            // Sabit tohum: her açılışta aynı doku
            var rnd = new System.Random(20260928);
            float ox1 = (float)rnd.NextDouble() * 100f, oy1 = (float)rnd.NextDouble() * 100f;
            float ox2 = (float)rnd.NextDouble() * 100f, oy2 = (float)rnd.NextDouble() * 100f;
            float ox3 = (float)rnd.NextDouble() * 100f, oy3 = (float)rnd.NextDouble() * 100f;

            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float u = x / (float)n, v = y / (float)n;
                    float a = Mathf.PerlinNoise(ox1 + u * 2.5f, oy1 + v * 2.5f);
                    float b = Mathf.PerlinNoise(ox2 + u * 5.5f, oy2 + v * 5.5f);
                    float c = Mathf.PerlinNoise(ox3 + u * 11f, oy3 + v * 11f);
                    float k = a * 0.6f + b * 0.28f + c * 0.12f;
                    k = Mathf.Clamp01((k - 0.35f) / 0.3f);
                    k = k * k * (3f - 2f * k);
                    px[y * n + x] = new Color(1f, 1f, 1f, k);
                }
            t.SetPixels(px);
            t.wrapMode = TextureWrapMode.Clamp;
            t.filterMode = FilterMode.Bilinear;
            t.Apply();
            return t;
        }
    }
}
