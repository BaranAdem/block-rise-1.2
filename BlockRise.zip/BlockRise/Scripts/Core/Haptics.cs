using UnityEngine;
#if UNITY_IOS && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif

namespace BlockRise
{
    /// <summary>
    /// Kısa, ince dokunsal geri bildirim (haptics).
    ///   iOS     → Taptic Engine (Plugins/iOS/BlockRiseHaptics.mm)
    ///   Android → VibrationEffect (API 29+: hazır tık efektleri, 26+: şiddeti ayarlı kısa titreşim)
    ///   Editör  → hiçbir şey yapmaz
    /// Oyuncu duraklat menüsünden kapatabilir (SaveSystem.HapticsOn).
    /// </summary>
    public static class Haptics
    {
        public static bool Enabled
        {
            get => SaveSystem.HapticsOn;
            set => SaveSystem.HapticsOn = value;
        }

        // Aynı anda gelen titreşimler (patlama + zincir + bomba) üst üste binip vızıltıya dönmesin:
        // kısa aralıkta yalnızca daha güçlü olan geçer.
        const float MinGap = 0.035f;
        static float _lastTime = -1f;
        static int _lastLevel;

        static bool Gate(int level)
        {
            if (!Enabled) return false;
            float t = Time.unscaledTime;
            if (t - _lastTime < MinGap && level <= _lastLevel) return false;
            _lastTime = t;
            _lastLevel = level;
            return true;
        }

        /// <summary>Çok hafif "tık": blok tutma, kaydırırken hücre geçişi.</summary>
        public static void Selection()
        {
            if (!Gate(0)) return;
#if UNITY_IOS && !UNITY_EDITOR
            BRHaptics_Selection();
#elif UNITY_ANDROID && !UNITY_EDITOR
            Android(EffectTick, 8, 50, 16);
#endif
        }

        /// <summary>Hafif darbe: hamle bırakma, butonlar.</summary>
        public static void Light() => Impact(0.2f);

        /// <summary>Orta darbe: normal patlama.</summary>
        public static void Medium() => Impact(0.55f);

        /// <summary>Sert darbe: bomba, şimşek, büyük zincir.</summary>
        public static void Heavy() => Impact(1f);

        /// <summary>0..1 güç: 0-0.33 hafif, 0.33-0.66 orta, üstü sert (zincir büyüdükçe artırmak için).</summary>
        public static void Impact(float strength)
        {
            strength = Mathf.Clamp01(strength);
            int style = strength < 0.34f ? 0 : strength < 0.67f ? 1 : 2;
            if (!Gate(style + 1)) return;
#if UNITY_IOS && !UNITY_EDITOR
            BRHaptics_Impact(style, Mathf.Lerp(0.6f, 1f, strength));
#elif UNITY_ANDROID && !UNITY_EDITOR
            int effect = style == 0 ? EffectTick : style == 1 ? EffectClick : EffectHeavyClick;
            Android(effect, 12 + style * 10, Mathf.RoundToInt(Mathf.Lerp(70f, 255f, strength)), 20 + style * 14);
#endif
        }

        /// <summary>Başarı: bölüm kazanma, tahtayı tamamen temizleme.</summary>
        public static void Success()
        {
            if (!Gate(5)) return;
#if UNITY_IOS && !UNITY_EDITOR
            BRHaptics_Notify(0);
#elif UNITY_ANDROID && !UNITY_EDITOR
            AndroidPattern(EffectDoubleClick, new long[] { 0, 35, 70, 45 }, 180);
#endif
        }

        /// <summary>Hata: kaybetme.</summary>
        public static void Error()
        {
            if (!Gate(5)) return;
#if UNITY_IOS && !UNITY_EDITOR
            BRHaptics_Notify(2);
#elif UNITY_ANDROID && !UNITY_EDITOR
            AndroidPattern(-1, new long[] { 0, 70, 60, 110 }, 220);
#endif
        }

        // ================================================================ iOS

#if UNITY_IOS && !UNITY_EDITOR
        [DllImport("__Internal")] static extern void BRHaptics_Impact(int style, float intensity);
        [DllImport("__Internal")] static extern void BRHaptics_Selection();
        [DllImport("__Internal")] static extern void BRHaptics_Notify(int type);
#endif

        // ================================================================ Android

        // VibrationEffect.EFFECT_* sabitleri (API 29+)
        const int EffectClick = 0, EffectDoubleClick = 1, EffectTick = 2, EffectHeavyClick = 5;

#if UNITY_ANDROID && !UNITY_EDITOR
        static AndroidJavaObject _vibrator;
        static AndroidJavaClass _effectClass;
        static int _sdk = -1;
        static bool _ready, _hasVibrator, _ampControl, _usePredefined;

        static void Init()
        {
            if (_ready) return;
            _ready = true;
            using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                _vibrator = activity.Call<AndroidJavaObject>("getSystemService", "vibrator");
            using (var version = new AndroidJavaClass("android.os.Build$VERSION"))
                _sdk = version.GetStatic<int>("SDK_INT");
            string maker;
            using (var build = new AndroidJavaClass("android.os.Build"))
                maker = (build.GetStatic<string>("MANUFACTURER") ?? "").ToLowerInvariant();
            if (_sdk >= 26) _effectClass = new AndroidJavaClass("android.os.VibrationEffect");

            _hasVibrator = _vibrator != null && _vibrator.Call<bool>("hasVibrator");
            _ampControl = _hasVibrator && _sdk >= 26 && _vibrator.Call<bool>("hasAmplitudeControl");
            // Xiaomi (MIUI/HyperOS) hazır tık efektlerini çoğu modelde çalmıyor ya da çok zayıf çalıyor;
            // şiddet ayarı olmayan basit motorlar da bu efektleri hissettiremiyor → onlarda kısa titreşim kullan.
            bool xiaomi = maker.Contains("xiaomi") || maker.Contains("redmi") || maker.Contains("poco");
            _usePredefined = _sdk >= 29 && _ampControl && !xiaomi;

            // Tanı: Logcat'te "BlockRise" diye filtrele
            Debug.Log("[BlockRise] Haptics hazır — " + maker + ", Android API " + _sdk + ", titreşim motoru: " + _hasVibrator
                      + ", şiddet ayarı: " + _ampControl + ", hazır efekt: " + _usePredefined);
        }

        /// <param name="predefined">API 29+ hazır efekt (-1 = kullanma)</param>
        /// <param name="ms">Şiddet ayarlı motorlar için süre</param>
        /// <param name="amplitude">1..255 şiddet</param>
        /// <param name="basicMs">Basit motorlar / Xiaomi için süre (çok kısa titreşimi bu motorlar hissettiremez)</param>
        static void Android(int predefined, long ms, int amplitude, long basicMs)
        {
            try
            {
                Init();
                if (!_hasVibrator) return;

                if (_usePredefined && predefined >= 0)
                {
                    using (var fx = _effectClass.CallStatic<AndroidJavaObject>("createPredefined", predefined))
                        _vibrator.Call("vibrate", fx);
                }
                else if (_sdk >= 26)
                {
                    long dur = _ampControl ? ms : basicMs;
                    int amp = _ampControl ? Mathf.Clamp(amplitude, 1, 255) : -1; // -1 = DEFAULT_AMPLITUDE
                    using (var fx = _effectClass.CallStatic<AndroidJavaObject>("createOneShot", dur, amp))
                        _vibrator.Call("vibrate", fx);
                }
                else _vibrator.Call("vibrate", basicMs);
            }
            catch (System.Exception e)
            {
                // İzin eksikse burada "SecurityException ... VIBRATE" görünür
                Debug.LogWarning("[BlockRise] Titreşim çalışmadı: " + e.Message);
            }
        }

        /// <summary>İki vuruşlu desen (başarı / hata). timings: bekle, titreş, bekle, titreş… (ms)</summary>
        static void AndroidPattern(int predefined, long[] timings, int amplitude)
        {
            try
            {
                Init();
                if (!_hasVibrator) return;

                if (_usePredefined && predefined >= 0)
                {
                    using (var fx = _effectClass.CallStatic<AndroidJavaObject>("createPredefined", predefined))
                        _vibrator.Call("vibrate", fx);
                }
                else if (_sdk >= 26)
                {
                    if (_ampControl)
                    {
                        var amps = new int[timings.Length];
                        for (int i = 0; i < amps.Length; i++) amps[i] = i % 2 == 1 ? Mathf.Clamp(amplitude, 1, 255) : 0;
                        using (var fx = _effectClass.CallStatic<AndroidJavaObject>("createWaveform", timings, amps, -1))
                            _vibrator.Call("vibrate", fx);
                    }
                    else
                    {
                        using (var fx = _effectClass.CallStatic<AndroidJavaObject>("createWaveform", timings, -1))
                            _vibrator.Call("vibrate", fx);
                    }
                }
                else _vibrator.Call("vibrate", timings, -1);
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("[BlockRise] Titreşim çalışmadı: " + e.Message);
            }
        }

        // Hiç çağrılmaz. Unity, projede Handheld.Vibrate referansı görünce Android manifestine
        // VIBRATE iznini otomatik ekler; bu satır o izin için orada duruyor.
        static void RequestVibratePermission() => Handheld.Vibrate();
#endif
    }
}
