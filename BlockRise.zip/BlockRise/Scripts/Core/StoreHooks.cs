using System;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Uygulama içi satın alma noktaları (reklam kaldırma). Unity IAP paketi kurulunca bu fonksiyonlar
    /// mağazaya bağlanır. O zamana kadar:
    ///   • Editörde satın alma test için hemen başarılı olur.
    ///   • Cihaz derlemesinde "mağaza kullanılamıyor" döner — reklam kaldırma bedavaya verilmez.
    ///
    /// Fiyat metni mağazadan gelir (yerel para birimiyle). Mağaza bağlanana kadar GameSettings.removeAdsPrice gösterilir.
    /// </summary>
    public static class StoreHooks
    {
        /// <summary>Mağazadan gelen yerelleştirilmiş fiyat (ör. "$2.49", "₺89,99"). Boşsa ayardaki metin kullanılır.</summary>
        public static Func<string> RemoveAdsPrice = () => "";

        /// <summary>Reklam kaldırmayı satın al. onSuccess: satın alma onaylandı. onFail: iptal / hata (mesajla).</summary>
        public static Action<Action, Action<string>> BuyRemoveAds = (onSuccess, onFail) =>
        {
#if UNITY_EDITOR
            onSuccess?.Invoke();
#else
            onFail?.Invoke("STORE NOT AVAILABLE");
#endif
        };

        /// <summary>Önceki satın almaları geri yükle (iOS'ta zorunlu). Sonuç: reklam kaldırma bulundu mu.</summary>
        public static Action<Action<bool>> RestorePurchases = done =>
        {
#if UNITY_EDITOR
            done?.Invoke(SaveSystem.AdsRemoved);
#else
            done?.Invoke(false);
#endif
        };

        /// <summary>
        /// Oyun kodu satın almayı buradan başlatır: BuyRemoveAds'i çağırır ve sonucu ölçer (purchase / purchase_fail).
        /// source: satın almanın başladığı ekran ("menu", "energy_popup").
        /// </summary>
        public static void PurchaseRemoveAds(string source, Action onSuccess, Action<string> onFail)
        {
            Analytics.PurchaseStart("remove_ads", source);
            BuyRemoveAds(
                () => { Analytics.Purchase("remove_ads", source, PriceLabel); onSuccess?.Invoke(); },
                msg => { Analytics.PurchaseFail("remove_ads", source, msg); onFail?.Invoke(msg); });
        }

        /// <summary>Geri yüklemeyi başlatır ve sonucu ölçer (purchase_restore).</summary>
        public static void Restore(Action<bool> done)
        {
            RestorePurchases(found => { Analytics.PurchaseRestore(found); done?.Invoke(found); });
        }

        public static string PriceLabel
        {
            get
            {
                string p = RemoveAdsPrice?.Invoke();
                return string.IsNullOrEmpty(p) ? GameSettings.Instance.removeAdsPrice : p;
            }
        }
    }

    /// <summary>Mağaza değerlendirmesi: iOS'ta yerel değerlendirme penceresi, Android'de mağaza sayfası.</summary>
    public static class Rating
    {
        public static void RequestReview()
        {
#if UNITY_IOS && !UNITY_EDITOR
            UnityEngine.iOS.Device.RequestStoreReview();
#elif UNITY_ANDROID && !UNITY_EDITOR
            Application.OpenURL("market://details?id=" + Application.identifier);
#else
            Debug.Log("[BlockRise] Değerlendirme isteği (editörde gösterilmez)");
#endif
        }

        public static void SendFeedback()
        {
            string mail = GameSettings.Instance.feedbackEmail;
            if (string.IsNullOrEmpty(mail)) return;
            string subject = Uri.EscapeDataString("Block Rise feedback");
            string body = Uri.EscapeDataString("\n\n---\nVersion " + Application.version + " · " + SystemInfo.deviceModel);
            Application.OpenURL("mailto:" + mail + "?subject=" + subject + "&body=" + body);
        }
    }
}
