using UnityEngine;

namespace BlockRise
{
    /// <summary>Inspector'da alanın üstünde gri açıklama kutusu gösterir (çizimi Editor/HelpDrawer.cs).</summary>
    public class HelpAttribute : PropertyAttribute
    {
        public readonly string text;
        public HelpAttribute(string text) { this.text = text; order = 10; } // Header'dan sonra çizilsin
    }

    /// <summary>Bomba davranışı. Recolor: satır+sütunu bombanın rengine boyar. Explode: eski davranış, satır+sütunu patlatır.</summary>
    public enum BombMode { Recolor, Explode }

    /// <summary>Blok görünümü. Unified: aynı renk komşular tek parça (yekpare) şekil. Classic: eski PNG blok + köprüler.</summary>
    public enum BlockStyle { Unified, Classic }

    /// <summary>
    /// Tüm ayarlanabilir değerler burada. Unity menüsünden
    /// "Block Rise > Create Settings Asset" ile bir asset oluşturursan
    /// Inspector'dan düzenleyebilirsin (Resources/BlockRiseSettings.asset).
    /// Asset yoksa aşağıdaki varsayılan değerler kullanılır.
    /// </summary>
    [CreateAssetMenu(fileName = "BlockRiseSettings", menuName = "Block Rise/Game Settings")]
    public class GameSettings : ScriptableObject
    {
        public const string ResourcePath = "BlockRiseSettings";

        [Header("Board")]
        public int boardWidth = 8;
        public int boardHeight = 12;
        [Tooltip("Kaç aynı renk blok birleşince patlar")]
        public int popSize = 4;

        [Header("Block Colors (bağlantı parçaları ve efektler için; sprite renkleriyle uyumlu tut)")]
        public Color[] blockColors =
        {
            new Color(1.00f, 0.30f, 0.37f), // kırmızı
            new Color(0.30f, 0.85f, 0.39f), // yeşil
            new Color(0.24f, 0.55f, 1.00f), // mavi
            new Color(1.00f, 0.79f, 0.24f), // sarı
            new Color(0.65f, 0.42f, 1.00f), // mor
        };
        public string[] colorNames = { "Red", "Green", "Blue", "Yellow", "Purple" };

        [Header("Block Look")]
        [Tooltip("Unified = birleşen bloklar tek parça şekil. Classic = eski görünüm (ayrı bloklar + köprü).")]
        public BlockStyle blockStyle = BlockStyle.Unified;
        [Tooltip("Unified: dış köşe yuvarlaklığı (hücre oranı)")]
        [Range(0.02f, 0.5f)] public float unifiedCornerRadius = 0f;
        [Tooltip("Unified: açık kenarlardaki boşluk (hücre oranı)")]
        [Range(0f, 0.2f)] public float unifiedInset = 0f;
        [Tooltip("Unified: pahın GENİŞLİĞİ — kenardan içeri ne kadar uzandığı (hücre oranı)")]
        [Range(0.05f, 0.45f)] public float unifiedBevel = 0.15f;
        [Tooltip("Unified: pahın YÜKSEKLİĞİ — kenar ne kadar dik/kabarık. Düşük = alçak, yumuşak ton farkı. Yüksek = dik, ışıklı ve gölgeli kenarlar arasında güçlü kontrast")]
        [Range(0.2f, 3f)] public float unifiedBevelHeight = 0.5f;
        [Tooltip("Unified: gölgeli kenarların (sağ ve alt pah, dış hat) koyuluğu. 1 = tam gölge, 0.5 = yarı yarıya açık, 0 = gölge yok. Aydınlık kenarı ve parlamayı etkilemez.")]
        [Range(0f, 1f)] public float unifiedShadow = 0.6f;
        [Tooltip("Unified: üstteki parlama ne kadar belirgin")]
        [Range(0f, 1f)] public float unifiedShine = 1f;
        [Tooltip("Unified: kenar yumuşaklığı. 0 = keskin/metalik hat, 1 = yumuşak/plastik geçiş")]
        [Range(0f, 1f)] public float unifiedSoftness = 0f;
        [Tooltip("Unified: kenar profili. 0 = yuvarlak kabarık kenar (yüzeye yumuşak geçiş). 1 = düz pah: her kenar tek ton, pah ile yüzey arasında keskin hat")]
        [Range(0f, 1f)] public float unifiedChamfer = 1f;
        [Tooltip("Unified: L şeklindeki birleşimlerdeki iç (içbükey) köşeler. True = keskin köşe, pah çapraz hatla birleşir. False = eski kavisli iç köşe")]
        public bool unifiedSharpInnerCorners = true;
        [Tooltip("Unified: blok dokusunun çözünürlüğü (hücre başına piksel). Kenarlar bulanıksa artır.\nYüksek değer = daha net ama biraz daha fazla bellek ve ilk üretim süresi. iPhone için 160-192 yeterli.")]
        [Range(64, 256)] public int unifiedTileResolution = 128;

        [Header("Board Look")]
        [Tooltip("Tahtanın dış çerçeve/zemin paneli. Kapalıyken sadece hücre ızgarası ve alttaki önizleme şeridi görünür; arka plandaki yıldızlar daha görünür olur.")]
        public bool showBoardPanel = false;
        [Tooltip("True: tahta zemini ve hücre kareleri koddan üretilir, köşeleri aşağıdaki ayarlarla değişir.\nFalse: eski görünüm, Resources/BlockRiseSprites içindeki panel.png ve cell.png kullanılır.")]
        public bool proceduralBoardShapes = true;
        [Tooltip("Tahtanın dış çerçevesinin köşe yarıçapı (hücre cinsinden). 0 = sivri köşe")]
        [Range(0f, 1.5f)] public float boardCornerRadius = 0f;
        [Tooltip("Tahta içindeki boş hücre karelerinin köşe yarıçapı (hücre cinsinden). 0 = sivri, 0.44 = neredeyse daire")]
        [Range(0f, 0.46f)] public float cellCornerRadius = 0f;

        [Header("Special Blocks")]
        [Tooltip("Recolor = satır+sütundaki blokları bombanın rengine boyar (patlatmaz). Explode = eski davranış.")]
        public BombMode bombMode = BombMode.Recolor;
        [Tooltip("Özel blokların (bomba, satır, sütun, şimşek) arkasındaki yumuşak ışıma nefes alsın (ikonlar hareket etmez)")]
        public bool animateSpecialIcons = true;
        [Tooltip("Işımanın nefes alma hızı")]
        [Range(0.3f, 3f)] public float specialBlinkSpeed = 1f;

        [Header("Endless Mode")]
        [Range(2, 5)] public int endlessColors = 5;
        public int endlessStartRows = 4;
        [Range(0f, 0.5f)] public float endlessBombChance = 0.005f;
        [Range(0f, 0.5f)] public float endlessLightningChance = 0.005f;
        [Tooltip("Endless: yeni bloğun satır bombası (sağ-sol oklar, yalnızca kendi satırına etki eder) olma ihtimali")]
        [Range(0f, 0.5f)] public float endlessRowBombChance = 0.009f;
        [Tooltip("Endless: yeni bloğun sütun bombası (yukarı-aşağı oklar, yalnızca kendi sütununa etki eder) olma ihtimali")]
        [Range(0f, 0.5f)] public float endlessColumnBombChance = 0.009f;
        [Tooltip("Bölümler: satır bombası ihtimali (bütün bölümlerde aynı; bomba ve şimşek ihtimali bölümün kendi verisinden gelir)")]
        [Range(0f, 0.5f)] public float levelRowBombChance = 0.003f;
        [Tooltip("Bölümler: sütun bombası ihtimali (bütün bölümlerde aynı)")]
        [Range(0f, 0.5f)] public float levelColumnBombChance = 0.003f;
        [Tooltip("Her kaç hamlede bir yeni sıra yükselir (forceRiseEveryTurn kapalıysa)")]
        public int endlessRiseEvery = 1;
        [Tooltip("Başlangıçta yeni sıradaki boşluk sayısı (min/max)")]
        public int endlessGapsStartMin = 2, endlessGapsStartMax = 3;
        [Tooltip("Zorluk tavanına ulaşınca boşluk sayısı (min/max)")]
        public int endlessGapsEndMin = 1, endlessGapsEndMax = 2;
        [Tooltip("Zorluğun tavana ulaşması için gereken tur sayısı")]
        public int endlessRampTurns = 15; //25 yap olmadı

        [Header("Adaptive Difficulty (uyarlanabilir zorluk)")]
        [Help("ANA ANAHTAR. Açıkken zorluk her oyuncunun geçmişine göre fark ettirmeden ayarlanır. Kapalıyken Classic her zaman aşağıdaki sabit kolaylıkla oynanır, bölümlerde yardım/hediye hamle verilmez. (Player Model de bu anahtara bağlıdır.)")]
        public bool adaptiveDifficulty = true;

        [Help("Uyarlama KAPALIYKEN kullanılan sabit kolaylık. 0 = en zor, 1 = en kolay.")]
        [Range(0f, 1f)] public float fixedEndlessEase = 0.5f;

        [Help("KOLAYLIK (ease) nedir: her oyuncu için tutulan 0..1 arası sayı. 0 = en zor, 1 = en kolay. Classic'te sıraların ne kadar yardımcı geleceğini, zorluğun ne kadar hızlı artacağını ve özel blok (bomba, şimşek) sıklığını belirler. Aşağıdaki ayarlar bu sayının nasıl değiştiğini anlatır.\n\nHEDEF OYUN UZUNLUĞU (bu alan, tur): kolaylık, oyuncunun oyunları bu uzunluk civarında bitecek şekilde ayarlanır. 65 tur ≈ 3-4 dakika.")]
        [Tooltip("Oyuncunun güncel kolaylık değeri istatistik raporundaki ZORLUK satırında görünür.")]
        public int targetGameTurns = 65;

        [Help("Her oyundan sonra kolaylığın hedefe ne kadar hızlı yaklaşacağı. Oyun hedef turdan (yukarıda, 65 ≈ 3-4 dk) uzun sürdüyse zorlaşır, kısa sürdüyse kolaylaşır. Büyük = hızlı tepki, küçük = yavaş ve sakin.")]
        [Range(0.05f, 1f)] public float easeGain = 0.35f;

        [Help("Tek bir oyunun ardından kolaylığın en fazla ne kadar değişebileceği. Ani zorluk sıçramalarını önler.")]
        [Range(0.02f, 0.5f)] public float easeMaxStep = 0.15f;

        [Help("Rekor kırılan oyundan sonra zorluğa eklenen küçük artış (kolaylıktan düşülür). Rekor kıran oyuncu bir sonraki oyunda biraz daha zorlanır.")]
        [Range(0f, 0.5f)] public float easeStepOnRecord = 0.03f;

        [Help("BALAYI: oyuncunun ilk bu kadar Classic oyunu kolay tutulur (ilk izlenim). Bu oyunlarda kolaylık aşağıdaki değerin altına inmez.")]
        public int honeymoonGames = 3;

        [Help("Balayı oyunlarında kolaylığın en düşük değeri. 0.8 = ilk oyunlar belirgin şekilde cömert.")]
        [Range(0f, 1f)] public float honeymoonMinEase = 0.8f;

        [Help("SICAK BAŞLANGIÇ: hedef uzunluğun yarısından kısa süren bu kadar oyun üst üste gelirse, sonraki oyunun başı cömert olur.")]
        public int hotStartAfterBadGames = 3;

        [Help("Sıcak başlangıçta zorluğun artmaya başlaması bu kadar tur gecikir.")]
        public int hotStartTurns = 25;

        [Header("Adaptive Difficulty — Classic sıra yardımı")]
        [Help("Oyunun BAŞINDA sıraların yardım gücü. 0 = tamamen rastgele sıralar, 1 = sıralar sürekli tamamlanmaya yakın gruplar oluşturur. Başlangıç cömert olsun ki oyuncu ısınsın.")]
        [Range(0f, 1f)] public float assistStart = 0f;

        [Help("Zorluk tam oturduğunda (rampa bitince) yardım gücü: USTA oyuncu için (kolaylık 0). Düşük = usta oyuncu kendi becerisiyle ilerler.")]
        [Range(0f, 1f)] public float assistEndHard = 0f;

        [Help("Zorluk tam oturduğunda yardım gücü: ZORLANAN oyuncu için (kolaylık 1). Aradaki oyuncular ara değer alır.")]
        [Range(0f, 1f)] public float assistEndEasy = 0.6f;

        [Help("Yardımın başlangıç değerinden son değerine inmesi kaç tur sürer: USTA oyuncu için. Kısa = zorluk hızlı artar.")]
        public float rampTurnsHard = 24f;

        [Help("Yardımın son değerine inmesi kaç tur sürer: ZORLANAN oyuncu için. Uzun = oyun uzun süre rahat kalır.")]
        public float rampTurnsEasy = 120f;

        [Help("Zorlanan oyuncuda bütün özel blok ihtimallerinin (bomba, satır, sütun, şimşek) en fazla kaç katına çıkacağı. 1 = artmaz, 2 = en kolay oyuncuda iki katı. İhtimali 0 olan tür hiç çıkmaz.")]
        [Range(1f, 4f)] public float easySpecialMultiplier = 2f;

        [Header("Adaptive Difficulty — bölümler")]
        [Help("Aynı bölümde 2. kayıptan itibaren her kayıpta sıralara eklenen görünmez yardım.")]
        public float levelAssistPerFail = 0.12f;

        [Help("Kayıplardan gelebilecek en fazla görünmez yardım.")]
        public float levelAssistMax = 0.45f;

        [Help("Aynı bölümde bu kadar art arda kayıptan sonra oyuncuya görünür HEDİYE HAMLE verilir.")]
        public int giftAfterFails = 3;

        [Help("İlk hediyede verilen hamle sayısı.")]
        public int giftMoves = 2;

        [Help("Bu kadar art arda kayıptan sonra büyük hediye verilir.")]
        public int bigGiftAfterFails = 5;

        [Help("Büyük hediyede verilen hamle sayısı.")]
        public int bigGiftMoves = 4;

        [Header("Sıra üretimi — yardım ağırlıkları")]
        [Help("Yardım açıkken, yeni bloğun mevcut gruba eklenip onu TEK HAMLEDE patlatılabilir hale getirmesine verilen ağırlık. Büyük = sıralar bariz fırsat taşır.")]
        public float assistNearWeight = 5f;

        [Help("Yeni bloğun patlamaya iki adım kalan grup oluşturmasına verilen ağırlık.")]
        public float assistMidWeight = 2.5f;

        [Help("Sıra yükselince KENDİLİĞİNDEN patlayacak grup oluşturma ağırlığı (bedava patlama). Küçük = oyuncu patlamayı kendisi yapmalı.")]
        public float assistAutoPopWeight = 0.35f;

        [Help("Bölümlerde temel yardım gücü (0 = saf rastgele). 100 bölüm bu değerle dengelendi; değiştirirsen bölüm zorlukları da değişir.")]
        [Range(0f, 1f)] public float levelAssist = 0.15f;

        [Header("Casual akış — zincir kurulumu (Classic)")]
        [Help("ZİNCİR KURULUMU: yeni sıra, bir grup patlayınca üstündeki bloğun düşüp ikinci bir patlama yapacağı dizilimleri tercih eder (sandviç: aynı renk – farklı renk – aynı renk). Zincir oyunun en büyük ödül anı. 0 = kapalı, 4 = belirgin, 8 = çok sık zincir.")]
        public float chainWeight = 4f;

        [Help("USTA oyuncuda zincir kurulumunun gücü (0..1). Ustalar zinciri kendileri kurmalı: küçük tut.")]
        [Range(0f, 1f)] public float chainAssistHard = 0.15f;

        [Help("ZORLANAN / YENİ oyuncuda zincir kurulumunun gücü (0..1). Büyük = yeni oyuncu ilk dakikalarda zincir görür ve 'iyiyim' hisseder.")]
        [Range(0f, 1f)] public float chainAssistEasy = 0.8f;

        [Help("Bölümlerde zincir kurulumu. 100 bölüm zincirsiz dengelendi: 0 bırakırsan bölüm zorlukları değişmez.")]
        [Range(0f, 1f)] public float levelChainAssist = 0f;

        [Header("Casual akış — kuraklık koruması (Classic)")]
        [Help("ÖLÜ TAHTA KORUMASI: üst üste bu kadar tur HİÇ patlama olmazsa sonraki sıra patlatılabilir fırsatlarla gelir. Zorlanan oyuncu için. Sıkıcı 'hiçbir şey olmuyor' anlarını keser.")]
        public int dryGuardTurnsEasy = 3;

        [Help("Aynı koruma USTA oyuncu için (daha geç devreye girer). 0 = ustada kapalı.")]
        public int dryGuardTurnsHard = 6;

        [Help("Koruma devreye girince sıranın yardım gücü (0..1).")]
        [Range(0f, 1f)] public float dryGuardAssist = 0.85f;

        [Header("Casual akış — özel blok ritmi (Classic)")]
        [Help("DEĞİŞKEN ÖDÜL: bu kadar tur bomba/şimşek patlatılmazsa özel blok ihtimali her tur artmaya başlar. Böylece özel bloklar ne çok sık ne çok seyrek: beklenti doğar.")]
        public int specialGraceTurns = 10;

        [Help("Bekleme süresi dolduktan sonra HER TUR özel blok ihtimaline eklenen çarpan (zorlanan oyuncuda tam, ustada hiç). 0.1 = 10 tur sonra 2 kat.")]
        public float specialGrowthPerTurn = 0.1f;

        [Help("Özel blok ihtimali en fazla bu kata çıkar.")]
        [Range(1f, 5f)] public float specialMaxMultiplier = 3f;

        [Header("Gerilim — alçak tahta baskısı (Classic)")]
        [Help("GERİLİM: oyuncu iyi oynayıp tahtayı aşağıda tuttukça gelen sıralar zorlaşır (yardım azalır, boşluk azalır, renkler dağınık gelir). Tahta yükselince baskı kendiliğinden kalkar. Sonuç: iyi oyuncu da tahtanın orta-üst kısmında, tepeye birkaç sıra kala oynar. Kapalı = eski davranış.")]
        public bool pressureEnabled = true;

        [Help("Tahta bu doluluğun ALTINDAYKEN baskı başlar. 0.67 ≈ 12 sıralık tahtada 8. sıra: oyun çoğunlukla 7-9. sıralar arasında geçer. Büyük = daha gergin.")]
        [Range(0.3f, 0.9f)] public float pressureTarget = 0.67f;

        [Help("Tahta bu doluluk ve altındaysa baskı TAM güçtedir; hedefle arasında orantılı.")]
        [Range(0f, 0.8f)] public float pressureFloor = 0.35f;

        [Help("Tam baskıda yeni sıradaki boşluk sayısından düşülen miktar (sıra daha dolu gelir, tahta daha hızlı yükselir). En az 1 boşluk her zaman kalır.")]
        [Range(0, 3)] public int pressureGapCut = 1;

        [Help("Tam baskıda yeni bloğun mevcut gruplara eklenme ihtimalinin düşme oranı (0..1). 0.5 = belirgin ama adil. Çok yüksek tutma: tahta okunmaz hale gelir.")]
        [Range(0f, 0.9f)] public float pressureSpoil = 0.5f;

        [Help("Baskı oyunun ilk bu kadar turunda devreye girmez (açılış rahat olsun) ve sonraki 10 turda yavaşça açılır.")]
        public int pressureStartTurn = 10;

        [Help("Zorlanan oyuncuda baskının ne kadar hafifleyeceği. Kolaylık (ease) 1 olan oyuncuda baskı bu oranda azalır (0.6 = %60 daha hafif). Usta oyuncu (ease 0) tam baskıyı alır.")]
        [Range(0f, 1f)] public float pressureEaseRelief = 0.6f;

        [Header("Casual akış — kıl payı kurtuluş (yalnızca yeni / zorlanan oyuncu)")]
        [Help("KURTULUŞ: tahta bu doluluğa gelince sonraki sıralar zincir ve fırsatla dolu gelir, daha seyrek olur. Oyuncu doğru hamleyi bulursa zincir zincir rahatlar: 'son anda kurtuldum' anı. 0.75 ≈ 12 sıralık tahtada 9. sıra.")]
        [Range(0.5f, 1f)] public float rescueDanger = 0.75f;

        [Help("Bir kurtuluş kaç sıra sürer.")]
        public int rescueRows = 2;

        [Help("Kurtuluş sıralarına eklenen boşluk (sıra daha seyrek gelir, tahta daha yavaş yükselir).")]
        public int rescueExtraGaps = 1;

        [Help("YENİ oyuncuya bir oyunda en fazla kaç kurtuluş verilir. Zorlanan oyuncu kolaylığına göre bundan azını alır, USTA hiç almaz.")]
        public int rescueMaxNovice = 3;

        [Help("Kolaylık (ease) bu değerin ALTINDAYSA oyuncu usta sayılır: kurtuluş yok. (0 = en zor, 1 = en kolay)")]
        [Range(0f, 1f)] public float rescueEaseFrom = 0.5f;

        [Help("Kolaylık bu değerin üstündeyse oyuncu tam kurtuluş hakkı alır (rescueMaxNovice). Arada orantılı.")]
        [Range(0f, 1f)] public float rescueEaseFull = 0.85f;

        [Help("İki kurtuluş arasında en az bu kadar tur geçer.")]
        public int rescueCooldownTurns = 15;

        [Header("Levels")]
        // Bölümler Resources/BlockRiseLevels.json'dadır. 100 bölüm levelAssist = 0.15 ve
        // forceRiseEveryTurn = true ile dengelendi; bunları değiştirirsen zorluk eğrisi de değişir.
        [Tooltip("True: her hamleden sonra yeni sıra gelir (levelin riseEvery değeri yok sayılır)")]
        public bool forceRiseEveryTurn = true;

        [Header("Scoring")]
        public int pointsPerBlock = 10;
        public int bonusPerExtraBlock = 5;
        public int bombBonus = 50;
        public int lightningBonus = 75;
        public int movesLeftBonus = 50;
        public int perfectClearBonus = 500;

        [Header("Revive (rewarded ad bağlanacak yer)")]
        public int reviveClearRows = 6;
        public int reviveExtraMoves = 5;

        [Header("Animation")]
        public float slideSnapTime = 0.08f;
        public float fallTimePerCell = 0.045f;
        public float popTime = 0.22f;
        public float riseTime = 0.16f;
        public float chainDelay = 0.08f;

        [Header("Performans")]
        [Help("Kare hızı. 60 = her cihazda akıcı ve pil dostu. 120 = ProMotion iPhone ve 120 Hz Android'de çok daha akıcı (pil biraz daha çabuk biter; iOS'ta Info.plist'te CADisableMinimumFrameDurationOnPhone = true gerekir). 0 = ekranın kendi yenileme hızı.")]
        public int targetFrameRate = 60;

        [Header("Effects")]
        [Tooltip("Tüm parçacık sayılarının çarpanı (0 = kapalı)")]
        [Range(0f, 3f)] public float particleMultiplier = 3f;
        public bool shakeOnChain = true;

        [Header("Hints")]
        [Tooltip("Oyuncu bir süre hamle yapmazsa patlama yapacak bir hamleyi parmak animasyonuyla göster")]
        public bool showHints = true;
        [Tooltip("İpucu gösterilmeden önce hamlesiz geçmesi gereken süre (saniye)")]
        [Range(2f, 30f)] public float hintDelay = 7f;

        [Header("Monetization")]
        [Tooltip("Her kaç oyunda bir oyunlar arası zorunlu reklam (0 = kapalı). O oyunda ödüllü reklam izlendiyse gösterilmez.")]
        public int interstitialEveryGames = 3;
        [Tooltip("Kaç oyundan sonra 'oyunu beğendiniz mi?' sorulsun (bir kez sorulur)")]
        public int rateAfterGames = 5;
        [Tooltip("'Beğenmedim' diyen oyuncunun geri bildirim e-postası (boşsa geri bildirim butonu çıkmaz)")]
        public string feedbackEmail = "";
        [Tooltip("Reklam kaldırma fiyat metni: mağaza bağlanana kadar gösterilir. Gerçek fiyat App Store Connect / Play Console'da belirlenir.")]
        public string removeAdsPrice = "$2.99";
        [Tooltip("Reklam kaldırma satın alınınca bir kez verilen enerji")]
        public int removeAdsEnergyBonus = 25;

        // ================================================================ PLAYER MODEL
        // Gri kutular her alanın ne yaptığını anlatır. Fareyle alanın adının üstüne gelince daha ayrıntılı not çıkar.
        // Değerlerin canlı hali: istatistik raporundaki "OYUNCU" satırı (beceri, düşünme, hayal kırıklığı, sıkılma...).

        [Header("Player Model (oyuncuya özel algoritma)")]
        [Help("ANA ANAHTAR. Açıkken oyun her oyuncuyu hamlelerinden tanır ve zorluğu ona göre ayarlar. Kapatırsan sadece eski Adaptive sistemi çalışır. (Adaptive Difficulty de açık olmalı.)")]
        [Tooltip("Kapalıyken: kişisel ipucu süresi ve oturum/duygu ayarları devre dışı kalır.")]
        public bool playerModel = true;

        [Help("Kaç dakika ara verilirse YENİ OTURUM sayılır. Yeni oturumun ilk oyunu 'hoş geldin' oyunudur (biraz daha kolay). Örn. 25 = öğle arası oynayıp akşam dönen oyuncu iyi bir oyunla karşılanır.")]
        [Tooltip("Küçültürsen 'hoş geldin' oyunu daha sık gelir. Büyütürsen sadece uzun aralardan sonra gelir.")]
        public float sessionGapMinutes = 25f;

        [Help("Hayal kırıklığı ve sıkılma, oyuncu oynamadığı sürede söner. Bu değer YARILANMA SÜRESİ (dakika). 40 = 40 dk ara verince duygular yarıya iner, 80 dk'da çeyreğe.")]
        [Tooltip("Küçük değer: oyuncu kısa bir aradan sonra 'temiz sayfa' ile döner. Büyük değer: kötü seri ertesi güne kadar hatırlanır.")]
        public float emotionHalfLifeMinutes = 40f;

        [Help("Yeni oturumun ilk oyununa eklenen KOLAYLIK. 0 = etkisi yok, 0.12 = fark edilmeyecek kadar cömert bir başlangıç, 0.3 = belirgin kolay.")]
        [Tooltip("Kolaylık (ease) 0..1 arasıdır: 0 en zor, 1 en kolay. Bu değer o oyun için ease'e eklenir.")]
        [Range(0f, 0.3f)] public float welcomeBackEase = 0.12f;

        [Help("Hayal kırıklığı tam doluyken (üst üste hızlı kayıplar) sonraki oyuna eklenen EN FAZLA kolaylık. Hayal kırıklığı yarıysa bunun yarısı eklenir.")]
        [Tooltip("Oyuncu sinirlenip oyunu bırakmadan önce oyun ona 'nefes aldırır'. Çok büyük yaparsan kayıplar anlamsızlaşır.")]
        [Range(0f, 0.5f)] public float frustrationEaseMax = 0.3f;

        [Help("Sıkılma tam doluyken (uzun ama hiç tehlikeye girmeyen oyunlar) sonraki oyundan düşülen EN FAZLA kolaylık. Yani sıkılan oyuncunun oyunu daha baskılı başlar.")]
        [Tooltip("Usta oyuncular için. Oyun fazla rahat geçtiyse bir sonraki daha heyecanlı olur.")]
        [Range(0f, 0.4f)] public float boredomEaseMax = 0.2f;

        [Help("İlk bu kadar ölçülen hamlede oyuncu YENİ sayılır: ipucu daha erken gelir. Beceri %30'un altındaysa da yeni sayılır. 80 hamle ≈ ilk 2-3 oyun.")]
        public int noviceMoves = 80;

        [Header("Player Model — kişisel ipucu ve bölüm yardımı")]
        [Help("Açıkken ipucu gecikmesi oyuncunun KENDİ düşünme hızına göre ayarlanır. Kapalıysa yukarıdaki sabit Hint Delay kullanılır.")]
        public bool adaptiveHintDelay = true;

        [Help("İpucu gecikmesi = oyuncunun ortalama hamle düşünme süresi × bu sayı. Örn. oyuncu hamle başına 3 sn düşünüyorsa ve değer 2.5 ise, 7.5 sn hareketsiz kalınca ipucu çıkar. Yeni oyuncuda %25 daha erken.")]
        public float hintThinkMultiplier = 2.5f;

        [Help("İpucu bundan DAHA ERKEN çıkmaz (saniye). Çok hızlı oyuncuları ipucuyla rahatsız etmemek için.")]
        public float hintDelayMin = 4f;

        [Help("İpucu en geç bu sürede çıkar (saniye). Çok yavaş düşünen oyuncu da sonunda yardım alır.")]
        public float hintDelayMax = 14f;

        [Help("Becerisi DÜŞÜK oyuncuya bölümlerde ilk denemeden itibaren verilen görünmez yardım (sıralar eşleşmeye daha yatkın gelir). Beceri %45'in üstündeyse sıfır, %20'nin altındaysa tam değer.")]
        [Tooltip("Eskiden bölüm yardımı ancak 2. kayıptan sonra geliyordu. Bu, yeni oyuncunun ilk bölümlerde takılıp oyunu bırakmasını önler.")]
        [Range(0f, 0.3f)] public float lowSkillLevelAssist = 0.12f;

        [Header("Data Reset")]
        [Tooltip("Bu sayıyı değiştirince oyun bir sonraki açılışta TÜM oyuncu verisini bir kez sıfırlar " +
                 "(en iyi skor, yıldızlar, bölümler, madalyalar, seri, enerji, satın alımlar, ayarlar, tutorial). " +
                 "Her cihazda yalnızca bir kez çalışır. Test için tekrar sıfırlamak istersen sayıyı 1 artır. " +
                 "Yayına çıktıktan sonra DEĞİŞTİRME: gerçek oyuncuların ilerlemesi silinir. 0 = kapalı.")]
        public int dataResetVersion = 1;

        [Header("Energy")]
        [Tooltip("Kapalı: enerji sistemi devre dışı, oyunlar sınırsız")]
        public bool energyEnabled = true;
        [Tooltip("Zamanla dolan en yüksek enerji (bonuslar bunu aşabilir)")]
        public int maxEnergy = 5;
        [Tooltip("Kaç dakikada 1 enerji dolar")]
        public float energyRegenMinutes = 30f;
        [Tooltip("Ödüllü reklam başına verilen enerji")]
        public int energyFromAd = 1;
        [Tooltip("Açık: CLASSIC (sonsuz) mod da enerji harcar. Kapalı: enerji sadece Adventure bölümlerinde kullanılır.")]
        public bool energyForClassic = false;

        [Header("Ads")]
        [Tooltip("Oyun ekranının altında banner reklam alanı ayrılsın (tahta yukarı kayar). Reklamın kendisi LevelPlay entegrasyonuyla gelir.")]
        public bool bannerAds = true;
        [Tooltip("Banner için ayrılan yükseklik (canvas birimi, referans genişlik 1080). Telefon banner'ı 50dp ≈ 130-140.")]
        public float bannerReserveHeight = 140f;
        [Tooltip("Editörde banner alanını koyu bir yer tutucuyla göster (cihazda görünmez)")]
        public bool showBannerPlaceholder = true;

        [Header("Analytics")]
        [Tooltip("Ölçüm olaylarını konsola da yaz (test için). Mağaza sürümünde kapatılabilir.")]
        public bool analyticsLogToConsole = true;
        [Tooltip("Ana menüdeki blok sırasına art arda 5 kez dokununca açılan gizli istatistik paneli. Mağaza sürümünde kapat.")]
        public bool enableStatsPanel = true;

        [Header("Stardust (arka plan zerreleri)")]
        [Tooltip("Zerrelerin genel parlaklığı")]
        [Range(0f, 1.5f)] public float stardustBrightness = 1.5f;
        [Tooltip("Blok sürüklenirken arka plan parmağa ne kadar eşlik eder (0 = hiç, 1 = blokla aynı). Yakındakiler daha çok, uzaktakiler daha az kayar.")]
        [Range(0f, 2f)] public float stardustDragAmount = 1f;
        [Tooltip("Sürüklemeye eşlik tepkisi (yüksek = parmağı daha sıkı takip eder, düşük = daha yumuşak/gecikmeli)")]
        [Range(1f, 20f)] public float stardustDragResponse = 5f;
        [Tooltip("Hamle bırakıldığında arka plana o yönde verilen itiş")]
        [Range(0f, 8f)] public float stardustReleasePush = 3f;
        [Tooltip("Boştayken alanın yukarı doğru süzülme hızı (0 = durağan)")]
        [Range(0f, 0.5f)] public float stardustDrift = 0.5f;
        [Tooltip("Patlama dalgasının değdiği yıldızlar bloğun rengine ne kadar boyansın (0 = hiç, 1 = tam renk)")]
        [Range(0f, 1f)] public float stardustTintStrength = 1f;
        [Tooltip("Yıldızlar bloğun renginde ne kadar kalsın (sn), sonra eski rengine döner")]
        [Range(0f, 2f)] public float stardustTintHold = 0.50f;
        [Tooltip("Renk tutulduktan sonra eski rengine dönüş hızı (yüksek = daha hızlı)")]
        [Range(0.3f, 10f)] public float stardustTintFade = 2.5f;

        [Header("Praise")]
        public bool showPraise = true;
        [Tooltip("Övgü kelimeleri, zayıftan güçlüye sıralı")]
        public string[] praiseWords = { "Nice!", "Great!", "Amazing!", "Awesome!", "Perfect!", "Incredible!", "Unbelievable!" };
        public Color[] praiseColors =
        {
            new Color(1f, 1f, 1f),
            new Color(0.55f, 0.95f, 1f),
            new Color(0.6f, 1f, 0.55f),
            new Color(1f, 0.85f, 0.3f),
            new Color(1f, 0.6f, 0.25f),
            new Color(1f, 0.45f, 0.75f),
            new Color(0.85f, 0.55f, 1f),
        };
        [Tooltip("{0} = zincir sayısı")]
        public string chainWordFormat = "Chain x{0}!";
        [Tooltip("{0} = üst üste patlatan hamle sayısı")]
        public string comboWordFormat = "Combo x{0}";
        [Tooltip("Kaç hamle üst üste patlatınca Combo yazısı çıksın")]
        public int comboShowFrom = 3;
        public string perfectClearWord = "PERFECT CLEAR!";

        [Header("Icons (boş bırakılırsa kodla çizilen simge kullanılır)")]
        [Tooltip("Günlük seri alev simgesi. Kendi PNG'ni buraya sürükle (ya da Resources/BlockRiseSprites/icon_flame.png olarak koy). Kendi renkleriyle gösterilir.")]
        public Sprite streakFlameIcon;
        [Tooltip("Enerji simgesi. Kendi PNG'ni buraya sürükle (ya da Resources/BlockRiseSprites/icon_energy.png olarak koy). Boşsa kodla çizilen şimşek kullanılır. Kendi renkleriyle gösterilir.")]
        public Sprite energyIcon;

        [Header("Sound")]
        [Range(0f, 1f)] public float sfxVolume = 1f;
        [Tooltip("Açık: zincir/combo sesleri D majör pentatonik dizide basamak basamak yükselir (ses paketi bu diziye akortlu). Kapalı: eski yarım ton hesabı.")]
        public bool musicalPitch = true;
        [Tooltip("Müzikal mod: her zincir adımında kaç dizi basamağı yükselir")]
        public int chainScaleSteps = 1;
        [Tooltip("Müzikal mod: her üst üste combo hamlesinde kaç dizi basamağı yükselir")]
        public int comboScaleSteps = 1;
        [Tooltip("Müzikal mod kapalıyken: her zincir adımında ses kaç yarım ton tizleşir")]
        public float chainPitchStep = 2f;
        [Tooltip("Müzikal mod kapalıyken: her üst üste combo hamlesinde ses kaç yarım ton tizleşir")]
        public float comboPitchStep = 1f;
        [Tooltip("Tizleşme sınırı (1 = normal, 2 = bir oktav)")]
        public float maxPitch = 2f;
        [Tooltip("Aynı listede birden fazla isim varsa rastgele biri çalar")]
        public string[] sfxPop = { "pop", "pop2"};
        public string[] sfxChain = { "chain" };
        [Tooltip("Blok tutulduğunda (yumuşak kavrama sesi)")]
        public string[] sfxPick = { "asmr_pick" };
        [Tooltip("Sürüklerken her hücre geçişinde (kısa tahta tık)")]
        public string[] sfxDrag = { "asmr_tick1", "asmr_tick2", "asmr_tick3", "asmr_tick4" };
        [Tooltip("Bırakılan blok yerine oturduğunda")]
        public string[] sfxPlace = { "asmr_place1", "asmr_place2", "asmr_place3" };
        [Tooltip("Patlamadan sonra bloklar düşüp oturduğunda")]
        public string[] sfxLand = { "asmr_land1", "asmr_land2", "asmr_land3" };
        [Range(0f, 1f)] public float pickVolume = 0.35f;
        [Range(0f, 1f)] public float dragVolume = 0.40f;
        [Range(0f, 1f)] public float placeVolume = 0.85f;
        [Range(0f, 1f)] public float landVolume = 0.65f;
        [Tooltip("Organik sesler her çalışta bu kadar yarım ton rastgele kayar (aynı ses makine gibi tekrarlamasın)")]
        [Range(0f, 2f)] public float organicPitchJitter = 0.7f;
        public string[] sfxRise = { "rise" };
        public string[] sfxBomb = { "bomb" };
        public string[] sfxBolt = { "bolt" };
        public string[] sfxWin = { "win" };
        [Tooltip("Tahta tamamen temizlendiğinde")]
        public string[] sfxPerfect = { "perfect" };
        [Tooltip("Madalya kazanıldığında")]
        public string[] sfxMedal = { "medal" };
        public string[] sfxLose = { "lose" };
        public string[] sfxPraise = { "UI2" };
        public string[] sfxButton = { "UI3" };

        [Header("Game Over")]
        public Color grayColor = new Color(0.55f, 0.56f, 0.6f);
        [Tooltip("Tüm blokların griye dönmesi için toplam süre")]
        public float grayOutTime = 0.6f;

        [Header("Layout")]
        [Tooltip("Alt kısımda boş bırakılacak alan (canvas birimi). Banner reklam eklersen ~170 yap.")]
        public float bottomReserve = 70f;

        [Header("Look")]
        public Color backgroundColor = new Color(0.29f, 0.50f, 0.80f);
        public Color boardColor = new Color(0f, 0f, 0f, 0.15f);   // koyu cam
        public Color cellColor  = new Color(1f, 1f, 1f, 0.07f);  // hücre izleri hafif

        static GameSettings _instance;
        public static GameSettings Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = Resources.Load<GameSettings>(ResourcePath);
                    if (_instance == null) _instance = CreateInstance<GameSettings>();
                }
                return _instance;
            }
        }

#if UNITY_EDITOR
        /// <summary>Inspector'da bir değer değişince karoları yeniden ürettir (Play sırasında da çalışır).</summary>
        void OnValidate()
        {
            SpriteLibrary.ClearTileCache();
        }
#endif

        public Color GetColor(int c)
        {
            if (blockColors == null || blockColors.Length == 0) return Color.white;
            return blockColors[Mathf.Clamp(c, 0, blockColors.Length - 1)];
        }

        public string GetColorName(int c)
        {
            if (colorNames == null || c < 0 || c >= colorNames.Length) return "Color " + c;
            return colorNames[c];
        }
    }
}