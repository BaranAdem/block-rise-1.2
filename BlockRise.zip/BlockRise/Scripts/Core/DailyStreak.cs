using System;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Günlük giriş serisi: oyun her gün açıldığında seri 1 artar; bir gün atlanırsa 1'e döner.
    /// Gün, cihazın yerel takvimine göre sayılır. Oyun açılışında (GameRoot) bir kez Check() çağrılır.
    /// </summary>
    public static class DailyStreak
    {
        const string KeyLastDay = "br_streak_last";
        const string KeyStreak = "br_streak";
        const string KeyBest = "br_streak_best";
        const string KeyShownDay = "br_streak_shown";

        public static int Current => PlayerPrefs.GetInt(KeyStreak, 0);
        public static int Best => PlayerPrefs.GetInt(KeyBest, 0);

        static int Today => (int)(DateTime.Now.Date - new DateTime(2000, 1, 1)).TotalDays;

        /// <summary>Bugünü işler. Dönüş: seri bugün değişti mi (yeni gün).</summary>
        public static bool Check()
        {
            int today = Today, last = PlayerPrefs.GetInt(KeyLastDay, -1);
            if (last == today) return false;
            int streak = last == today - 1 ? Current + 1 : 1;
            PlayerPrefs.SetInt(KeyStreak, streak);
            PlayerPrefs.SetInt(KeyLastDay, today);
            if (streak > Best) PlayerPrefs.SetInt(KeyBest, streak);
            PlayerPrefs.Save();
            Achievements.ReportMax("streak", Best);
            return true;
        }

        /// <summary>Günlük seri penceresi bugün gösterilmeli mi (günde bir kez). Sorulunca işaretlenir.</summary>
        public static bool ConsumeShowToday()
        {
            int today = Today;
            if (PlayerPrefs.GetInt(KeyShownDay, -1) == today) return false;
            PlayerPrefs.SetInt(KeyShownDay, today);
            PlayerPrefs.Save();
            return true;
        }
    }
}
