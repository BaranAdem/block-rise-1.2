using System;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Enerji sistemi (kalp sistemi). Her yeni oyun 1 enerji harcar; enerji maxEnergy'nin altındaysa
    /// her energyRegenMinutes dakikada 1 dolar. Süre gerçek saatle (UTC) tutulur: uygulama kapalıyken de dolar.
    ///
    /// • Kayıtlı oyuna devam etmek (CLASSIC resume), revive ve tutorial enerji harcamaz.
    /// • Reklam kaldırma satın alınınca bir kez removeAdsEnergyBonus enerji eklenir. Bonus maxEnergy'yi aşabilir;
    ///   enerji max'ın üstündeyken dolum sayacı çalışmaz.
    /// • Ödüllü reklam energyFromAd enerji verir.
    /// • Adventure'da kazanılan bölümün enerjisi iade edilir (Refund): enerji sadece kayıpta ve yarıda bırakmada gider.
    /// </summary>
    public static class Energy
    {
        const string KeyCount = "br_energy";
        const string KeyStamp = "br_energy_stamp";   // dolum sayacının başladığı an (UTC ticks)
        /// <summary>Reklam kaldırma bonusu verildi mi. Satın almaya bağlı olduğu için veri sıfırlamada korunur.</summary>
        public const string KeyBonusGiven = "br_noads_energy_given";

        static GameSettings S => GameSettings.Instance;

        public static event Action Changed;

        public static bool Enabled => S.energyEnabled;
        public static int Max => Mathf.Max(1, S.maxEnergy);
        static long Period => TimeSpan.FromMinutes(Mathf.Max(0.05f, S.energyRegenMinutes)).Ticks;
        static long Now => DateTime.UtcNow.Ticks;

        public static int Current
        {
            get { Tick(); return PlayerPrefs.GetInt(KeyCount, Max); }
        }

        public static bool CanPlay => !Enabled || Current > 0;

        /// <summary>Bir sonraki enerjiye kalan süre. Enerji doluysa sıfır.</summary>
        public static TimeSpan TimeToNext
        {
            get
            {
                Tick();
                if (PlayerPrefs.GetInt(KeyCount, Max) >= Max) return TimeSpan.Zero;
                long left = ReadStamp() + Period - Now;
                return TimeSpan.FromTicks(Math.Max(0, left));
            }
        }

        /// <summary>"12:05" biçiminde kalan süre (bir saati aşarsa "1:02:05").</summary>
        public static string TimeToNextLabel
        {
            get
            {
                var t = TimeToNext;
                int secs = (int)Math.Ceiling(t.TotalSeconds);
                int h = secs / 3600, m = (secs / 60) % 60, s = secs % 60;
                return h > 0 ? $"{h}:{m:00}:{s:00}" : $"{m}:{s:00}";
            }
        }

        /// <summary>Yeni bir oyun başlarken çağrılır. true: gerçekten 1 enerji düştü (iade edilebilir).</summary>
        public static bool Spend()
        {
            if (!Enabled) return false;
            Tick();
            int before = PlayerPrefs.GetInt(KeyCount, Max);
            if (before <= 0) return false;
            int after = before - 1;
            // Dolu depodan ilk düşüşte sayaç şimdi başlar; zaten eksikse çalışan sayaç bozulmaz
            Save(after, before >= Max && after < Max ? Now : ReadStamp());
            return true;
        }

        /// <summary>
        /// Harcanan 1 enerjiyi geri verir (kazanılan bölüm). Enerji, harcamadan önceki miktarı (capAt) ya da
        /// Max'ı aşmaz: oyun sırasında zaten dolan enerji iadeyle depoyu taşırmaz.
        /// </summary>
        public static void Refund(int capAt)
        {
            if (!Enabled) return;
            Tick();
            int e = PlayerPrefs.GetInt(KeyCount, Max);
            int cap = Mathf.Max(Max, capAt);
            if (e >= cap) return;
            int after = e + 1;
            // Depo doldu: sayaç durur (Tick max'ta çalışmaz, sonraki Spend yeniden başlatır)
            Save(after, after >= Max ? Now : ReadStamp());
        }

        /// <summary>Enerji ekler (reklam, satın alma). Max'ı aşabilir.</summary>
        public static void Add(int amount)
        {
            if (amount <= 0) return;
            Tick();
            int e = PlayerPrefs.GetInt(KeyCount, Max) + amount;
            Save(e, ReadStamp());
        }

        /// <summary>Reklam kaldırma satın alındığında: bonus yalnızca bir kez verilir (Restore tekrar vermez).</summary>
        public static bool GrantRemoveAdsBonus()
        {
            if (PlayerPrefs.GetInt(KeyBonusGiven, 0) == 1) return false;
            PlayerPrefs.SetInt(KeyBonusGiven, 1);
            Add(S.removeAdsEnergyBonus);
            return true;
        }

        /// <summary>Geçen süreye göre dolan enerjiyi ekler.</summary>
        static void Tick()
        {
            int e = PlayerPrefs.GetInt(KeyCount, Max);
            if (e >= Max) return;
            long now = Now, stamp = ReadStamp();
            if (stamp > now) { Save(e, now); return; } // saat geri alındı: sayaç yeniden başlar
            long n = (now - stamp) / Period;
            if (n <= 0) return;
            int filled = (int)Math.Min(Max, e + n);
            Save(filled, filled >= Max ? now : stamp + n * Period);
        }

        static long ReadStamp()
        {
            return long.TryParse(PlayerPrefs.GetString(KeyStamp, ""), out var v) ? v : Now;
        }

        static void Save(int count, long stamp)
        {
            int old = PlayerPrefs.GetInt(KeyCount, Max);
            PlayerPrefs.SetInt(KeyCount, Mathf.Max(0, count));
            PlayerPrefs.SetString(KeyStamp, stamp.ToString());
            PlayerPrefs.Save();
            if (old != count) Changed?.Invoke();
        }
    }
}
