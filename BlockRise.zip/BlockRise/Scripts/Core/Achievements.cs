using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Madalyalar: her başarımın bronz / gümüş / altın olmak üzere üç kademesi var.
    /// Değerler kalıcıdır (PlayerPrefs). Yeni kademe kazanılınca Unlocked olayı tetiklenir (UI madalya bildirimi gösterir).
    /// </summary>
    public static class Achievements
    {
        public enum Kind { Max, Sum }

        public class Def
        {
            public string id, title, format; // format: "{0}" yerine kademe hedefi yazılır
            public Kind kind;
            public int[] tiers;              // bronz, gümüş, altın
            public Def(string id, string title, string format, Kind kind, int b, int s, int g)
            { this.id = id; this.title = title; this.format = format; this.kind = kind; tiers = new[] { b, s, g }; }
        }

        public static readonly Def[] All =
        {
            new Def("chain",    "Chain Reaction", "Trigger a {0}-chain",            Kind.Max, 3, 5, 7),
            new Def("score",    "High Scorer",    "Score {0} in Classic",           Kind.Max, 5000, 20000, 50000),
            new Def("survivor", "Survivor",       "Survive {0} turns in Classic",   Kind.Max, 50, 150, 300),
            new Def("blocks",   "Block Breaker",  "Clear {0} blocks",               Kind.Sum, 1000, 10000, 50000),
            new Def("atoms",    "Atom Smasher",   "Blast {0} atoms",                Kind.Sum, 10, 50, 200),
            new Def("stars",    "Star Catcher",   "Catch {0} stars",                Kind.Sum, 10, 50, 200),
            new Def("levels",   "Adventurer",     "Complete {0} levels",            Kind.Max, 10, 100, 250),
            new Def("perfect",  "Perfectionist",  "Earn 3 stars on {0} levels",     Kind.Max, 10, 50, 150),
            new Def("sweep",    "Clean Sweep",    "Clear the whole board {0} times", Kind.Sum, 1, 5, 20),
            new Def("streak",   "Dedicated",      "Play {0} days in a row",         Kind.Max, 3, 7, 30),
            new Def("games",    "Regular",        "Play {0} Classic games",         Kind.Sum, 10, 50, 200),
        };

        public static readonly string[] TierNames = { "BRONZE", "SILVER", "GOLD" };
        public static readonly Color[] TierColors =
        {
            new Color(0.86f, 0.55f, 0.30f),
            new Color(0.80f, 0.85f, 0.92f),
            new Color(1.00f, 0.80f, 0.25f),
        };
        public static readonly Color LockedColor = new Color(0.36f, 0.36f, 0.48f);

        /// <summary>Yeni kademe kazanıldı: (başarım, kademe 0..2)</summary>
        public static event Action<Def, int> Unlocked;

        static Def Find(string id)
        {
            foreach (var d in All) if (d.id == id) return d;
            return null;
        }

        public static long Value(string id) => long.TryParse(PlayerPrefs.GetString("br_ach_v_" + id, "0"), out var v) ? v : 0;
        /// <summary>Kazanılmış kademe sayısı (0 = hiç, 3 = altın).</summary>
        public static int Tier(string id) => PlayerPrefs.GetInt("br_ach_t_" + id, 0);

        public static int TotalTiers()
        {
            int n = 0;
            foreach (var d in All) n += Tier(d.id);
            return n;
        }

        public static void ReportMax(string id, long value)
        {
            if (value > Value(id)) Set(id, value);
        }

        public static void ReportAdd(string id, long amount)
        {
            if (amount > 0) Set(id, Value(id) + amount);
        }

        static bool _dirty;

        /// <summary>
        /// Bekleyen madalya ilerlemesini diske yazar. Her patlamada PlayerPrefs.Save() çağırmak (Android'de bütün kayıt
        /// dosyasını baştan yazar) patlama anında kare düşüşüne yol açıyordu; artık oyun bitince ve uygulama arka plana
        /// geçince yazılıyor. Yeni madalya kazanıldığında ise hemen yazılır (nadir olay).
        /// </summary>
        public static void Flush()
        {
            if (!_dirty) return;
            _dirty = false;
            PlayerPrefs.Save();
        }

        static void Set(string id, long value)
        {
            var d = Find(id);
            if (d == null) return;
            PlayerPrefs.SetString("br_ach_v_" + id, value.ToString());
            int old = Tier(id), tier = 0;
            for (int i = 0; i < d.tiers.Length; i++) if (value >= d.tiers[i]) tier = i + 1;
            if (tier > old)
            {
                PlayerPrefs.SetInt("br_ach_t_" + id, tier);
                for (int t = old; t < tier; t++) Unlocked?.Invoke(d, t);
                _dirty = true;
                Flush();
                return;
            }
            _dirty = true;
        }

        /// <summary>Bölüm ilerlemesinden türeyen başarımları günceller (bölüm kazanılınca çağrılır).</summary>
        public static void ReportLevels()
        {
            int done = 0, perfect = 0;
            for (int i = 0; i < LevelDatabase.Count; i++)
            {
                int s = SaveSystem.GetStars(i);
                if (s > 0) done++;
                if (s >= 3) perfect++;
            }
            ReportMax("levels", done);
            ReportMax("perfect", perfect);
        }
    }
}
