using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Oyuncu modeline veri toplayan kısım (bkz. PlayerModel): hamle kalitesi, düşünme süresi, en yüksek doluluk.
    ///
    /// Gerilim eğrisi (baskı dalgası / kıl payı kurtuluş) kaldırıldı: zorluk yalnızca Adaptive + PlayerModel ile belirlenir.
    ///
    /// PERFORMANS: hamle kalitesi için "tahtadaki en iyi patlatan hamle" hesabı pahalıdır (her öbek × her kaydırma
    /// için yerçekimi simülasyonu). Bu hesap hamle anında değil, girdi açıldığında arka planda birkaç kareye
    /// yayılarak yapılır (BestPopRoutine). Oyuncu hesap bitmeden hamle yaparsa o hamle ölçülmez (-1).
    /// </summary>
    public partial class GameController
    {
        int _resolveChain;          // son Resolve'daki zincir uzunluğu
        float _inputReadyAt;        // oyuncunun hamle yapabildiği an (düşünme süresi ölçümü)
        bool _inputWasReady, _moveAfterHint;
        float _maxDanger;

        // Hamle kalitesi önbelleği: tahtadaki en büyük patlatabilir öbek (0 = patlatan hamle yok)
        int _bestPopSize;
        bool _bestReady;
        Coroutine _bestRoutine;

        /// <summary>Bir karede en fazla bu kadar PredictLanding denemesi (düşük segment cihazda takılma olmasın).</summary>
        const int BestPredictionsPerFrame = 40;

        /// <summary>Tahtanın doluluğu: 0 = boş, 1 = en üst sıra dolu.</summary>
        float Danger => _model == null ? 0f : (_model.HighestFilledRow() + 1) / (float)Mathf.Max(1, _s.boardHeight);

        void TrackInputReady()
        {
            bool ready = State == GameState.Playing && !_busy && _view != null && _view.InputEnabled;
            if (ready && !_inputWasReady)
            {
                _inputReadyAt = Time.unscaledTime;
                StartBestPopScan(); // tahta yerine oturdu: en iyi hamleyi arka planda hesapla
            }
            _inputWasReady = ready;
        }

        void StartBestPopScan()
        {
            if (_bestRoutine != null) StopCoroutine(_bestRoutine);
            _bestRoutine = null;
            _bestReady = false;
            _bestPopSize = 0;
            if (_model == null || (Mode != GameMode.Endless && Mode != GameMode.Level)) return;
            _bestRoutine = StartCoroutine(BestPopRoutine(_model));
        }

        /// <summary>Hamle kalitesi hesabını iptal eder (hamle başladı ya da tahta değişti).</summary>
        void CancelBestPopScan()
        {
            if (_bestRoutine != null) StopCoroutine(_bestRoutine);
            _bestRoutine = null;
        }

        IEnumerator BestPopRoutine(BoardModel model)
        {
            var clumps = model.GetAllClumps();
            clumps.Sort((a, b) => b.Count.CompareTo(a.Count)); // büyükten küçüğe: ilk bulunan patlatan en büyüğüdür
            int budget = BestPredictionsPerFrame;
            int best = 0;
            foreach (var clump in clumps)
            {
                if (clump.Count < 1) continue;
                model.GetMoveRange(clump, out int minShift, out int maxShift);
                bool found = false;
                for (int s = minShift; s <= maxShift && !found; s++)
                {
                    if (s == 0) continue;
                    if (model != _model) yield break; // yeni oyun başladı
                    model.PredictLanding(clump, s, out bool pop);
                    if (pop) found = true;
                    if (--budget <= 0)
                    {
                        budget = BestPredictionsPerFrame;
                        yield return null;
                    }
                }
                if (found) { best = clump.Count; break; }
            }
            if (model != _model) yield break;
            _bestPopSize = best;
            _bestReady = true;
            _bestRoutine = null;
        }

        /// <summary>
        /// Hamle kalitesi (0..1): tahtada patlatan hamle varken oyuncu patlatan hamle seçtiyse 0.55 + grup büyüklüğü
        /// payı; seçmediyse 0. Patlatan hamle hiç yoksa ya da hesap henüz bitmediyse ölçülemez (-1).
        /// </summary>
        float MeasureMoveQuality(List<Vector2Int> cells, int shift)
        {
            bool ready = _bestReady;
            int best = _bestPopSize;
            CancelBestPopScan();
            _bestReady = false;
            if (Mode != GameMode.Endless && Mode != GameMode.Level) return -1f;
            if (!ready || best == 0) return -1f;
            if (cells == null || cells.Count == 0 || shift == 0) return -1f;
            try
            {
                _model.PredictLanding(cells, shift, out bool mine);
                return mine ? 0.55f + 0.45f * Mathf.Clamp01(cells.Count / (float)best) : 0f;
            }
            catch { return -1f; }
        }

        /// <summary>Her tur sonunda: oyunun ulaştığı en yüksek doluluk (oyuncu modeli için).</summary>
        void TrackDanger()
        {
            float d = Danger;
            if (d > _maxDanger) _maxDanger = d;
        }
    }
}
