using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// İlk açılış tutorial'ı: hazır dizilmiş mini tahtalarla birleşme, patlatma, bomba, satır bombası,
    /// sütun bombası, renk temizleyici (şimşek) ve yükselme adım adım gösterilir. Satır ve sütun bombası
    /// adımları ne yaptıklarının yanında ne zaman kullanılmaları gerektiğini de öğretir (karışık satır → zincir,
    /// en yüksek kule → tek hamlede temizlik). Oyuncu hamleyi kendisi yapar; parmak işareti ve yanıp sönen
    /// blok doğru hamleyi gösterir. Yanlış hamlede tahta sıfırlanır ve adım tekrarlanır.
    /// </summary>
    public partial class GameController
    {
        enum TutGoal { Merge, Pop, Bomb, Lightning, None }

        class TutStep
        {
            public string Title, Body;
            public string[] Rows;          // yukarıdan aşağı; "." boş, R G B Y P renk, * bomba, - satır bombası, | sütun bombası, ! şimşek
            public Vector2Int From, To;    // parmak işaretinin başlangıç / bitiş hücresi
            public TutGoal Goal;
            public int[] NextRow;          // yalnızca yükselme adımı için
        }

        // Renk harfleri GameSettings.colorNames sırasıyla aynı: Red, Green, Blue, Yellow, Purple
        const string ColorLetters = "RGBYP";

        List<TutStep> _tutSteps;
        int _tutIndex;
        bool _tutSkipped;
        bool _tutStepDone;
        bool _tutActionPressed;
        int _tutTrackedId;             // birleşme adımında izlenen blok
        GameMode _tutAfterMode;
        int _tutAfterLevel;
        bool _tutReturnToMenu;

        Coroutine _tutGuide;
        Transform _tutFinger, _tutRing;
        SpriteRenderer _tutFingerSr, _tutRingSr;
        static Sprite _tutDotSprite, _tutRingSprite;

        // ================================================================ Başlat / bitir

        void StartTutorial(GameMode after, int levelIndex, bool returnToMenu)
        {
            StopAllCoroutines();
            Time.timeScale = 1f;
            _tutAfterMode = after;
            _tutAfterLevel = levelIndex;
            _tutReturnToMenu = returnToMenu;
            _tutSteps = BuildTutorialSteps();
            AttemptClose();
            Mode = GameMode.Tutorial;
            _tutSkipped = false;
            Analytics.TutorialBegin();
            Level = null;
            StartCoroutine(TutorialRoutine());
        }

        /// <summary>Tutorial panelindeki SKIP düğmesi.</summary>
        public void SkipTutorial()
        {
            if (Mode != GameMode.Tutorial) return;
            _tutSkipped = true;
            FinishTutorial();
        }

        void FinishTutorial()
        {
            StopTutorialGuide();
            StopAllCoroutines();
            _busy = false;
            SaveSystem.TutorialSeen = true;
            Analytics.TutorialComplete(_tutSkipped, Mathf.Min(_tutIndex + 1, _tutSteps != null ? _tutSteps.Count : 0));
            _ui.HideTutorial();

            if (_tutReturnToMenu) { GoHome(); return; }
            if (_tutAfterMode == GameMode.Level) StartLevel(_tutAfterLevel);
            else StartEndless();
        }

        // ================================================================ Adımlar

        List<TutStep> BuildTutorialSteps()
        {
            bool recolor = _s.bombMode == BombMode.Recolor;
            int n = _s.popSize;
            return new List<TutStep>
            {
                new TutStep
                {
                    Title = "SLIDE & MERGE",
                    Body = "Drag the blue block to the left.\nSame colors stick together and move as one!",
                    Rows = new[] { "B B . . . B R G" },
                    From = new Vector2Int(5, 0), To = new Vector2Int(2, 0),
                    Goal = TutGoal.Merge,
                },
                new TutStep
                {
                    Title = "POP!",
                    Body = Loc.F("Connect {0} or more of the same color to pop them.\nBlocks fall down to fill the gaps.", n),
                    Rows = new[] { ". . . . . . B .", "B B B . . . Y Y" },
                    From = new Vector2Int(6, 1), To = new Vector2Int(3, 1),
                    Goal = TutGoal.Pop,
                },
                new TutStep
                {
                    Title = "BOMB",
                    Body = recolor
                        ? "Pop a bomb to paint its row and column\nin its color. Watch the chain reaction!"
                        : "Pop a bomb to blast its whole row and column!",
                    Rows = new[] { ". . . . . . . R", "R R* R . G B Y P" },
                    From = new Vector2Int(7, 1), To = new Vector2Int(3, 1),
                    Goal = TutGoal.Bomb,
                },
                // Satır bombası: karışık renkli dolu satırda patlayınca satırı tek renge boyar → ikinci patlama (zincir).
                // Üstteki iki blok etkilenmez, yalnızca düşer: bombanın yalnızca satıra etki ettiği görülür.
                new TutStep
                {
                    Title = "ROW BOMB",
                    Body = recolor
                        ? "It paints its whole row. Pop it in a row\nfull of mixed colors for a chain!"
                        : "It blasts its whole row.\nPop it in your fullest row!",
                    Rows = new[] { ". G . . . . . .", ". Y . . . . . R", "R R- R . B P G Y" },
                    From = new Vector2Int(7, 1), To = new Vector2Int(3, 1),
                    Goal = TutGoal.Bomb,
                },
                // Sütun bombası: tahtadaki tek yüksek kulenin dibinde. Kule bombanın rengine boyanır, düşer ve
                // kendi kendine patlar → tehlikeli kule tek hamlede gider.
                new TutStep
                {
                    Title = "COLUMN BOMB",
                    Body = recolor
                        ? "It paints its whole column.\nSave it for your tallest stack!"
                        : "It blasts its whole column.\nSave it for your tallest stack!",
                    Rows = new[] { ". . . . . . G .", ". . . . . . P .", ". . . . . . Y .", ". . . . . . B .", "R . . . R R R| P" },
                    From = new Vector2Int(0, 0), To = new Vector2Int(3, 0),
                    Goal = TutGoal.Bomb,
                },
                new TutStep
                {
                    Title = "COLOR CLEAR",
                    Body = "Pop this block to clear every block\nof its color on the board!",
                    Rows = new[] { "B G . . Y . B G", "Y Y! Y . B G Y P" },
                    From = new Vector2Int(4, 1), To = new Vector2Int(3, 1),
                    Goal = TutGoal.Lightning,
                },
                new TutStep
                {
                    Title = "WATCH THE TOP",
                    Body = "After every move, a new row rises from below.\nIf blocks reach the dashed line, it's game over!",
                    Rows = new[] { ". G . . R . . .", "B Y P . G R B Y" },
                    NextRow = new[] { 4, -1, 0, 1, 2, -1, 3, 2 },
                    Goal = TutGoal.None,
                },
            };
        }

        IEnumerator TutorialRoutine()
        {
            for (_tutIndex = 0; _tutIndex < _tutSteps.Count; _tutIndex++)
            {
                var step = _tutSteps[_tutIndex];
                SetupTutorialBoard(step, true);
                yield return new WaitForSeconds(0.35f);

                if (step.Goal == TutGoal.None)
                {
                    // Bilgi adımı: yükselmeyi canlı göster, sonra oyuna geçiş düğmesi
                    _view.InputEnabled = false;
                    yield return new WaitForSeconds(1.2f);
                    _model.Rise();
                    Sfx(_s.sfxRise);
                    yield return _view.AnimateToModel(_s.riseTime, 0f, BoardView.Ease.OutQuad);
                    yield return new WaitForSeconds(0.4f);

                    _tutActionPressed = false;
                    _ui.ShowTutorialAction(_tutReturnToMenu ? "GOT IT!" : "LET'S PLAY!", () => _tutActionPressed = true);
                    while (!_tutActionPressed) yield return null;
                    continue;
                }

                // Etkileşimli adım: doğru hamle yapılana kadar bekle
                _tutStepDone = false;
                StartTutorialGuide(step);
                while (!_tutStepDone) yield return null;
                StopTutorialGuide();

                // Tahta tamamen temizlendiyse oyunun kendi "PERFECT" övgüsü zaten çıkıyor
                if (!_model.IsEmpty())
                    _fx.Praise(_view.BoardCenter, _tutIndex == 0 ? "NICE!" : _tutIndex == 1 ? "GREAT!" : "AWESOME!",
                        new Color(1f, 0.85f, 0.3f), 1.6f);
                yield return new WaitForSeconds(1.3f);
            }
            FinishTutorial();
        }

        void SetupTutorialBoard(TutStep step, bool showPanel)
        {
            _busy = false;
            State = GameState.Playing;

            _model = new BoardModel(_s.boardWidth, _s.boardHeight, _s.popSize, 1);
            _model.BombMode = _s.bombMode;
            _model.Rules = CurrentRules(); // yükselmeden sonraki önizleme sırası üretilebilsin
            for (int r = 0; r < step.Rows.Length; r++)
            {
                int y = step.Rows.Length - 1 - r; // en alttaki satır y = 0
                var tokens = step.Rows[r].Split(' ');
                for (int x = 0; x < tokens.Length && x < _model.Width; x++)
                {
                    string t = tokens[x];
                    if (t == "." || t.Length == 0) continue;
                    int col = ColorLetters.IndexOf(t[0]);
                    var sp = t.EndsWith("*") ? SpecialType.Bomb
                           : t.EndsWith("-") ? SpecialType.Row
                           : t.EndsWith("|") ? SpecialType.Column
                           : t.EndsWith("!") ? SpecialType.Lightning
                           : SpecialType.None;
                    _model.Place(x, y, col, sp);
                }
            }
            var next = step.NextRow ?? new int[_model.Width];
            if (step.NextRow == null) for (int i = 0; i < next.Length; i++) next[i] = -1;
            _model.SetNextRow(next);

            var tracked = _model.Get(step.From.x, step.From.y);
            _tutTrackedId = tracked != null ? tracked.Id : -1;

            if (showPanel)
            {
                _ui.ShowHUD(this);
                _ui.ShowTutorial(_tutIndex + 1, _tutSteps.Count, step.Title, step.Body);
                Analytics.TutorialStep(_tutIndex + 1);
            }
            _view.SetVisible(true);
            _view.SetModel(_model);
            _view.FitCamera(_ui.TopReservePixels, _ui.BottomReservePixels);
            _view.InputEnabled = step.Goal != TutGoal.None;
        }

        // ================================================================ Hamle

        IEnumerator TutorialMove(List<Vector2Int> cells, int shift)
        {
            if (!_model.ApplyMove(cells, shift))
            {
                yield return _view.AnimateToModel(_s.slideSnapTime, 0f, BoardView.Ease.OutQuad);
                yield break;
            }

            _busy = true;
            _view.InputEnabled = false;
            SetTutorialGuideVisible(false);
            int bombs0 = Bombs, bolts0 = Lightnings;

            yield return _view.AnimateToModel(_s.slideSnapTime, 0.02f, BoardView.Ease.OutQuad);
            SfxOrganic(_s.sfxPlace, _s.placeVolume);
            Haptics.Light();
            yield return Resolve();

            var step = _tutSteps[_tutIndex];
            bool ok;
            switch (step.Goal)
            {
                case TutGoal.Merge:
                    var p = _model.FindBlock(_tutTrackedId);
                    ok = p.x >= 0 && _model.GetClump(p.x, p.y).Count >= 3;
                    break;
                case TutGoal.Pop: ok = _resolvePopped > 0; break;
                case TutGoal.Bomb: ok = Bombs > bombs0; break;
                case TutGoal.Lightning: ok = Lightnings > bolts0; break;
                default: ok = true; break;
            }

            if (ok)
            {
                _tutStepDone = true;
                _busy = false;
                yield break;
            }

            // Olmadı: kısa ipucu, tahtayı sıfırla, tekrar dene
            _ui.Toast("Almost! Try the highlighted move.", 1.4f);
            yield return new WaitForSeconds(1.0f);
            StopTutorialGuide();
            SetupTutorialBoard(step, false);
            StartTutorialGuide(step);
        }

        // ================================================================ Parmak işareti

        void StartTutorialGuide(TutStep step)
        {
            StopTutorialGuide();
            EnsureFinger();
            _tutGuide = StartCoroutine(GuideRoutine(step));
        }

        void StopTutorialGuide()
        {
            if (_tutGuide != null) { StopCoroutine(_tutGuide); _tutGuide = null; }
            SetTutorialGuideVisible(false);
            if (_view != null) _view.ClearHighlight();
        }

        void SetTutorialGuideVisible(bool v)
        {
            if (_tutFinger != null) _tutFinger.gameObject.SetActive(v);
            if (_tutRing != null) _tutRing.gameObject.SetActive(v);
        }

        IEnumerator GuideRoutine(TutStep step)
        {
            var clump = _model.GetClump(step.From.x, step.From.y);
            float t0 = Time.time;

            while (true)
            {
                // Aşama 1: parmak kaynakta belirir ve "basar"
                Vector3 a = _view.CellCenter(step.From.x, step.From.y);
                Vector3 b = _view.CellCenter(step.To.x, step.To.y);
                SetTutorialGuideVisible(true);

                float t = 0f;
                while (t < 1.9f)
                {
                    if (_view.IsDragging)
                    {
                        // Oyuncu sürüklerken işaret karışmasın
                        SetTutorialGuideVisible(false);
                        t = 0f;
                        yield return null;
                        continue;
                    }
                    SetTutorialGuideVisible(true);
                    t += Time.deltaTime;
                    // Hedef küme nabız gibi parlar
                    _view.HighlightCells(clump, 0.18f + 0.18f * Mathf.Sin((Time.time - t0) * 6f));

                    float press = Mathf.Clamp01(t / 0.3f);                 // 0-0.3: belir + bas
                    float slide = Mathf.Clamp01((t - 0.35f) / 0.85f);      // 0.35-1.2: kaydır
                    slide = slide * slide * (3f - 2f * slide);
                    float fade = 1f - Mathf.Clamp01((t - 1.45f) / 0.35f); // 1.45-1.8: sön

                    var pos = Vector3.Lerp(a, b, slide);
                    _tutFinger.position = pos + new Vector3(0.18f, -0.28f, 0f); // parmak ucu hücrenin biraz altında
                    _tutRing.position = pos;

                    float s = Mathf.Lerp(1.25f, 1f, press);
                    _tutFinger.localScale = new Vector3(s, s, 1f) * 0.9f;
                    _tutFingerSr.color = new Color(1f, 1f, 1f, 0.95f * press * fade);

                    float ring = Mathf.Repeat(t * 1.6f, 1f);
                    _tutRing.localScale = Vector3.one * Mathf.Lerp(0.6f, 1.25f, ring);
                    _tutRingSr.color = new Color(1f, 1f, 1f, 0.7f * (1f - ring) * press * fade);
                    yield return null;
                }
                SetTutorialGuideVisible(false);

                t = 0f;
                while (t < 0.35f)
                {
                    t += Time.deltaTime;
                    _view.HighlightCells(clump, 0.18f + 0.18f * Mathf.Sin((Time.time - t0) * 6f));
                    yield return null;
                }
            }
        }

        void EnsureFinger()
        {
            if (_tutFinger != null) return;
            if (_tutDotSprite == null) _tutDotSprite = MakeCircleSprite(false);
            if (_tutRingSprite == null) _tutRingSprite = MakeCircleSprite(true);

            var f = new GameObject("TutorialFinger");
            _tutFingerSr = f.AddComponent<SpriteRenderer>();
            _tutFingerSr.sprite = _tutDotSprite;
            _tutFingerSr.sortingOrder = 120;
            _tutFinger = f.transform;

            var r = new GameObject("TutorialRing");
            _tutRingSr = r.AddComponent<SpriteRenderer>();
            _tutRingSr.sprite = _tutRingSprite;
            _tutRingSr.sortingOrder = 119;
            _tutRing = r.transform;
            SetTutorialGuideVisible(false);
        }

        /// <summary>Parmak ucu: gölgeli beyaz daire. Halka: ince dokunma dalgası.</summary>
        static Sprite MakeCircleSprite(bool ring)
        {
            const int n = 128;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = (x + 0.5f) / n * 2f - 1f, dy = (y + 0.5f) / n * 2f - 1f;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    Color c;
                    if (ring)
                    {
                        float d = Mathf.Abs(r - 0.85f) - 0.06f;
                        c = new Color(1f, 1f, 1f, Mathf.Clamp01(0.5f - d * n * 0.5f));
                    }
                    else
                    {
                        // beyaz disk + altta hafif gölge (koyu halka)
                        float disk = Mathf.Clamp01(0.5f - (r - 0.62f) * n * 0.5f);
                        float shadow = Mathf.Clamp01(1f - (r - 0.62f) / 0.3f) * 0.35f * (1f - disk);
                        float edge = Mathf.Clamp01(0.5f - (Mathf.Abs(r - 0.62f) - 0.035f) * n * 0.5f);
                        float v = Mathf.Lerp(1f, 0.75f, edge);
                        float a = disk + shadow * (1f - disk);          // beyaz disk gölgenin üstünde
                        float w = a > 0f ? disk / a : 0f;               // pikselde beyazın payı
                        c = new Color(v * w, v * w, v * w, a);
                    }
                    px[y * n + x] = c;
                }
            tex.SetPixels(px);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.Apply();
            // 128 px = 0.9 birim → hücreden biraz küçük
            return Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), n / 0.9f);
        }
    }
}
