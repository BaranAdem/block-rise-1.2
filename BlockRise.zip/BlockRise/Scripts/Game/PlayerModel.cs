using System;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// OYUNCU MODELİ — her oyuncuyu kendi oynanışından tanır ve zorluğu ona göre anlık ayarlar.
    ///
    /// Mevcut Adaptive sistemi "uzun vadeli zemin"dir (oyun uzunluğunu hedefe çeker). Bu model onun üstüne
    /// oyuncunun o anki durumunu ekler:
    ///
    ///   BECERİ (skill)        Her hamlenin kalitesi: o an tahtadaki en iyi patlatan hamleye göre ne seçti,
    ///                         zincir kurdu mu. Yavaş ortalama = gerçek beceri, hızlı ortalama = son form.
    ///   ÖĞRENME (trend)       Hızlı − yavaş ortalama. Pozitifse oyuncu gelişiyor. Zorluk bilerek beceriyi
    ///                         GERİDEN takip eder: gelişen oyuncu bir süre "güçlendiğini" hisseder.
    ///   DÜŞÜNME SÜRESİ        Hamle başına ortalama karar süresi. İpucu gecikmesi buna göre: yavaş öğrenen
    ///                         oyuncuya erken yardım, hızlı oyuncuyu ipucuyla rahatsız etme.
    ///   HAYAL KIRIKLIĞI       Kayıplar, özellikle hızlı ve rekorun çok altındaki kayıplar artırır; rekor,
    ///                         büyük zincir, galibiyet ve geçen gerçek zaman azaltır. Yüksekse sonraki oyun cömert.
    ///   SIKILMA               Uzun ama hiç tehlikeye girmeyen oyunlar artırır, kıl payı anlar azaltır.
    ///                         Yüksekse sonraki oyun daha baskılı.
    ///   OTURUM                25 dk aradan sonra gelen ilk oyun "hoş geldin" oyunudur (cömert, iyi his).
    ///
    /// Tüm veriler PlayerPrefs'te tek JSON olarak tutulur ("br_pm").
    /// </summary>
    public static class PlayerModel
    {
        const string Key = "br_pm";
        static GameSettings S => GameSettings.Instance;

        [Serializable]
        class Data
        {
            public float skill = 0.35f;      // yavaş ortalama (gerçek beceri)
            public float skillFast = 0.35f;  // hızlı ortalama (son form)
            public float thinkSec = 5f;      // ortalama karar süresi (sn)
            public float frustration;        // 0..1
            public float boredom;            // 0..1
            public int sessionGames;         // bu oturumda başlanan oyun
            public long lastPlayTicks;       // UTC
            public int lossStreak;
            public int gamesSinceRecord;     // yalnızca istatistik (zorluğu etkilemez)
            public int moves;                // ölçülen toplam hamle
        }

        static Data _d;
        static Data D
        {
            get
            {
                if (_d != null) return _d;
                string json = PlayerPrefs.GetString(Key, "");
                try { _d = string.IsNullOrEmpty(json) ? new Data() : JsonUtility.FromJson<Data>(json); }
                catch { _d = null; }
                return _d ??= new Data();
            }
        }

        static void Save()
        {
            PlayerPrefs.SetString(Key, JsonUtility.ToJson(D));
            PlayerPrefs.Save();
        }

        /// <summary>Kayıtlar silindiğinde bellekteki kopyayı da unut.</summary>
        public static void ForgetCache() => _d = null;

        static bool On => S.adaptiveDifficulty && S.playerModel;

        /// <summary>Oyuncu modeli açık mı (kapalıyken IsNovice güvenilir değildir: hamle sayılmaz).</summary>
        public static bool Enabled => On;

        // ================================================================ Okunan değerler

        public static float Skill => D.skill;
        public static float Trend => D.skillFast - D.skill;
        public static float ThinkSeconds => D.thinkSec;
        public static float Frustration => D.frustration;
        public static float Boredom => D.boredom;
        public static int SessionGames => D.sessionGames;
        public static bool IsNovice => D.moves < S.noviceMoves || D.skill < 0.3f;

        // ================================================================ Oyun başı

        /// <summary>Yeni oyun (kayıttan devam değil) başlarken çağrılır: oturumu ve zamanla sönen duyguları günceller.</summary>
        public static void BeginGame()
        {
            if (!On) return;
            var d = D;
            long now = DateTime.UtcNow.Ticks;
            double minutes = d.lastPlayTicks > 0 ? TimeSpan.FromTicks(Math.Max(0, now - d.lastPlayTicks)).TotalMinutes : 1e6;

            // Duygular gerçek zamanla söner: ara vermek "temiz sayfa" demek
            float decay = Mathf.Exp(-(float)minutes / Mathf.Max(1f, S.emotionHalfLifeMinutes) * 0.693f);
            d.frustration *= decay;
            d.boredom *= decay;

            if (minutes >= S.sessionGapMinutes) d.sessionGames = 0;
            d.sessionGames++;
            d.lastPlayTicks = now;
            Save();
        }

        /// <summary>
        /// Bu oyun için ease'e eklenecek kısa vadeli düzeltme (+ kolaylaştırır, − zorlaştırır).
        /// Uzun vadeli zemin (Adaptive.EndlessEase) değişmez; bu sadece bu oyunun ayarıdır.
        /// </summary>
        public static float EaseOffset()
        {
            if (!On) return 0f;
            var d = D;
            float o = 0f;

            // Oturumun ilk oyunu: iyi bir başlangıç, oyuncu geri geldiğine sevinsin
            if (d.sessionGames == 1) o += S.welcomeBackEase;

            // Hayal kırıklığı → cömertlik, sıkılma → baskı
            o += S.frustrationEaseMax * d.frustration;
            o -= S.boredomEaseMax * d.boredom;

            // Hızla gelişen oyuncu: zorluk bir adım geride kalsın (güçlenme hissi)
            if (Trend > 0.05f) o += Mathf.Min(0.08f, Trend * 0.6f);

            return Mathf.Clamp(o, -0.3f, 0.4f);
        }

        // ================================================================ Hamle

        /// <param name="quality">0..1 hamle kalitesi; &lt;0 = ölçülemedi (tahtada patlatan hamle yoktu)</param>
        /// <param name="thinkSec">Hamle için düşünme süresi</param>
        /// <param name="chain">Hamlenin başlattığı zincir uzunluğu</param>
        public static void OnMove(float quality, float thinkSec, int chain)
        {
            if (!On) return;
            var d = D;
            if (quality >= 0f)
            {
                d.skillFast = Mathf.Lerp(d.skillFast, quality, 0.08f);
                d.skill = Mathf.Lerp(d.skill, quality, d.moves < 60 ? 0.04f : 0.015f); // ilk hamlelerde hızlı tanı
                d.moves++;
            }
            if (thinkSec > 0.2f && thinkSec < 40f)
                d.thinkSec = Mathf.Lerp(d.thinkSec, thinkSec, 0.1f);
            if (chain >= 3) d.frustration *= 0.85f; // büyük zincir: an itibarıyla iyi hissediyor
            // Kayıt her hamlede değil (performans): oyun sonunda ve birkaç hamlede bir
            if ((d.moves & 7) == 0) Save();
        }

        // ================================================================ Oyun sonu

        /// <param name="lost">Kaybetti (bölüm: hamle/yükseklik, endless: yükseklik)</param>
        /// <param name="turns">Oyunun sürdüğü tur</param>
        /// <param name="scoreRatio">Endless: skor / oyun başı rekor (rekor yoksa -1). Bölüm: hedef tamamlanma oranı.</param>
        /// <param name="newRecord">Endless'ta rekor kırıldı</param>
        /// <param name="maxDanger">Oyun boyunca tahtanın ulaştığı en yüksek doluluk (0..1)</param>
        public static void OnGameEnd(bool endless, bool lost, int turns, float scoreRatio, bool newRecord, float maxDanger)
        {
            if (!On) return;
            var d = D;
            float target = Mathf.Max(10, S.targetGameTurns);

            if (lost)
            {
                d.lossStreak++;
                float f = 0.1f;
                if (endless && turns < target * 0.5f) f += 0.1f;              // hızlı kayıp
                if (scoreRatio >= 0f && scoreRatio < 0.5f) f += 0.08f;         // rekorun/hedefin çok gerisinde
                if (scoreRatio >= 0.8f) f -= 0.05f;                            // kıl payı: motive edici, cezalandırma
                f += 0.03f * Mathf.Min(4, d.lossStreak - 1);                   // üst üste kayıplar katlanır
                d.frustration = Mathf.Clamp01(d.frustration + f);
            }
            else
            {
                d.lossStreak = 0;
                d.frustration *= 0.55f;
            }

            if (endless)
            {
                if (newRecord) { d.gamesSinceRecord = 0; d.frustration *= 0.4f; }
                else d.gamesSinceRecord++;

                // Sıkılma: uzun ama hiç tehlikeye girmemiş oyun
                if (maxDanger < 0.6f && turns > target * 1.2f) d.boredom = Mathf.Clamp01(d.boredom + 0.2f);
                else if (maxDanger >= 0.85f) d.boredom *= 0.5f;   // kıl payı anlar sıkılmayı siler
                else d.boredom *= 0.85f;
            }
            Save();
        }

        // ================================================================ Kişisel ayarlar

        /// <summary>İpucu gecikmesi: oyuncunun kendi düşünme hızına göre (yeni oyuncuya erken, hızlıya geç).</summary>
        public static float HintDelay(float fallback)
        {
            if (!On || !S.adaptiveHintDelay) return fallback;
            float t = D.thinkSec * S.hintThinkMultiplier;
            if (IsNovice) t *= 0.75f;
            return Mathf.Clamp(t, S.hintDelayMin, S.hintDelayMax);
        }

        /// <summary>Bölümlerde ilk denemeden itibaren beceriye göre görünmez yardım.</summary>
        public static float LevelAssistOffset()
        {
            if (!On) return 0f;
            float low = Mathf.InverseLerp(0.45f, 0.2f, D.skill);   // düşük beceri → 1
            return S.lowSkillLevelAssist * low + 0.1f * D.frustration;
        }

        /// <summary>Geliştirici özeti (istatistik raporu için).</summary>
        public static string Summary()
        {
            var d = D;
            return "OYUNCU    beceri %" + Mathf.RoundToInt(d.skill * 100) + " · form %" + Mathf.RoundToInt(d.skillFast * 100)
                   + " · düşünme " + d.thinkSec.ToString("0.0") + " sn · hayal kırıklığı %" + Mathf.RoundToInt(d.frustration * 100)
                   + " · sıkılma %" + Mathf.RoundToInt(d.boredom * 100) + " · rekorsuz " + d.gamesSinceRecord
                   + " oyun · oturumda " + d.sessionGames + ". oyun";
        }
    }
}
