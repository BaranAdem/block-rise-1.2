using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// İpucu: oyuncu GameSettings.hintDelay saniye hamle yapmazsa oynanabilecek bir hamleyi gösterir.
    /// Öğreticideki parmak animasyonu kullanılır: grup nabız gibi parlar, parmak bloğu gideceği yöne kaydırır.
    ///
    /// Hamle seçimi: önce patlama yapan hamleler (büyük grup + kısa kaydırma öncelikli); hiç yoksa bloğu
    /// kendi rengindeki en çok komşunun yanına götüren hamle. Hamle yapılınca, sürükleme başlayınca ya da
    /// oyun durunca ipucu kaybolur ve süre baştan sayılır.
    /// </summary>
    public partial class GameController
    {
        float _idleTime;
        bool _hintShown;

        void Update()
        {
            TrackInputReady();
            UpdateHint();
        }

        void UpdateHint()
        {
            bool eligible = _s.showHints && State == GameState.Playing && Mode != GameMode.Tutorial
                            && !_busy && _model != null && _view != null;
            if (!eligible)
            {
                if (_hintShown) HideHint();
                _idleTime = 0f;
                return;
            }
            if (_view.IsDragging)
            {
                // Oyuncu zaten bir şey deniyor: ipucunu kaldır, süreyi baştan say
                if (_hintShown) HideHint();
                _idleTime = 0f;
                return;
            }
            if (_hintShown) return;

            _idleTime += Time.deltaTime;
            if (_idleTime < PlayerModel.HintDelay(_s.hintDelay)) return; // oyuncunun kendi düşünme hızına göre

            var step = FindHintMove();
            if (step == null) { _idleTime = 0f; return; } // oynanabilir hamle yok: bir süre sonra tekrar bak
            _hintShown = true;
            StartTutorialGuide(step);
        }

        /// <summary>Hamle yapıldığında (ya da oyun sıfırlanınca) çağrılır.</summary>
        void HideHint()
        {
            _idleTime = 0f;
            if (!_hintShown) return;
            _hintShown = false;
            StopTutorialGuide();
        }

        TutStep FindHintMove()
        {
            List<Vector2Int> bestClump = null;
            int bestShift = 0;
            float bestScore = float.MinValue;

            foreach (var clump in _model.GetAllClumps())
            {
                if (clump == null || clump.Count == 0) continue;
                _model.GetMoveRange(clump, out int minShift, out int maxShift);
                var first = _model.Get(clump[0].x, clump[0].y);
                if (first == null) continue;

                for (int shift = minShift; shift <= maxShift; shift++)
                {
                    if (shift == 0) continue;
                    var landing = _model.PredictLanding(clump, shift, out bool willPop);
                    float score;
                    if (willPop)
                        score = 1000f + clump.Count * 10f - Mathf.Abs(shift); // patlatan hamle: her zaman önde
                    else
                        score = SameColorNeighbors(landing, clump, first.Color) * 10f - Mathf.Abs(shift);
                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestClump = clump;
                        bestShift = shift;
                    }
                }
            }
            if (bestClump == null) return null;

            // Parmak: grubun hareket yönündeki ucundaki hücreden başlar (kaydırma yönü net okunur)
            var from = bestClump[0];
            foreach (var c in bestClump)
                if (bestShift > 0 ? (c.x > from.x || (c.x == from.x && c.y < from.y))
                                  : (c.x < from.x || (c.x == from.x && c.y < from.y)))
                    from = c;
            return new TutStep { From = from, To = new Vector2Int(from.x + bestShift, from.y) };
        }

        /// <summary>İnen hücrelerin, grubun dışındaki aynı renkli komşu sayısı.</summary>
        int SameColorNeighbors(List<Vector2Int> landing, List<Vector2Int> clump, int color)
        {
            if (landing == null) return 0;
            var own = new HashSet<Vector2Int>(clump);
            var land = new HashSet<Vector2Int>(landing);
            var seen = new HashSet<Vector2Int>();
            int n = 0;
            foreach (var p in landing)
            {
                for (int d = 0; d < 4; d++)
                {
                    var q = p + (d == 0 ? Vector2Int.right : d == 1 ? Vector2Int.left : d == 2 ? Vector2Int.up : Vector2Int.down);
                    if (land.Contains(q) || own.Contains(q) || !seen.Add(q)) continue;
                    var b = _model.Get(q.x, q.y);
                    if (b != null && b.Color == color) n++;
                }
            }
            return n;
        }
    }
}
