using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Deneme (attempt) takibi: her bölüm/endless oyunu başlangıçtan bitişe izlenir ve tam olarak bir kez
    /// "kazandı", "kaybetti" ya da "yarıda bıraktı" olarak kapatılır.
    ///
    /// Revive yüzünden kayıp hemen yazılmaz: oyun bitince kayıp "bekliyor" olur; oyuncu revive alırsa iptal edilir,
    /// almazsa (yeniden başlat / ana menü / sonraki deneme) o an kesinleşir. Revive hakkı kalmadıysa hemen yazılır.
    /// </summary>
    public partial class GameController
    {
        bool _attemptOpen, _failPending, _attemptRevived;
        float _attemptStart;
        string _failReason;
        bool _endlessNewBest;

        // Uyarlanabilir zorluk (bkz. Adaptive)
        int _bonusMoves, _bestAtStart, _hotStartTurns;
        int _achBlocks, _achBombs, _achStars; // madalyalara son bildirilen sayaçlar
        float _ease = 1f;

        float AttemptSeconds => Time.unscaledTime - _attemptStart;

        void AttemptBegin()
        {
            AttemptClose();
            if (Mode != GameMode.Level && Mode != GameMode.Endless) return;
            _attemptOpen = true;
            _failPending = false;
            _attemptRevived = false;
            _endlessNewBest = false;
            _attemptStart = Time.unscaledTime;
            if (Mode == GameMode.Level) Analytics.LevelStart(LevelIndex);
            else Analytics.EndlessStart(_ease, _hotStartTurns > 0);
        }

        void AttemptWin(int stars)
        {
            if (!_attemptOpen || Mode != GameMode.Level) return;
            _attemptOpen = false;
            _failPending = false;
            Analytics.LevelComplete(LevelIndex, stars, Score, MovesLeft, Turn, AttemptSeconds, _attemptRevived);
            Adaptive.OnLevelResult(LevelIndex, true);
            PlayerModel.OnGameEnd(false, false, Turn, 1f, false, _maxDanger);
        }

        void AttemptGameOver(bool outOfMoves, bool newBest)
        {
            if (!_attemptOpen) return;
            _failPending = true;
            _failReason = outOfMoves ? "moves" : "height";
            _endlessNewBest |= newBest;
            if (_reviveUsed) AttemptClose(); // revive hakkı yok → kayıp kesin
        }

        void AttemptRevived()
        {
            if (!_attemptOpen) return;
            Analytics.Revive(Mode, LevelIndex, _failReason ?? "unknown");
            _failPending = false;
            _attemptRevived = true;
        }

        /// <summary>Açık denemeyi kapatır: bekleyen kayıp varsa kayıp, yoksa yarıda bırakma olarak.</summary>
        void AttemptClose()
        {
            Achievements.Flush(); // oyun boyunca bellekte biriken madalya ilerlemesi
            if (!_attemptOpen) return;
            _attemptOpen = false;
            if (Mode == GameMode.Level)
            {
                if (_failPending)
                {
                    Analytics.LevelFail(LevelIndex, _failReason, GoalProgress01(), Score, Turn, AttemptSeconds, _attemptRevived);
                    Adaptive.OnLevelResult(LevelIndex, false);
                    PlayerModel.OnGameEnd(false, true, Turn, GoalProgress01(), false, _maxDanger);
                }
                else Analytics.LevelQuit(LevelIndex, GoalProgress01(), Turn, AttemptSeconds);
            }
            else if (Mode == GameMode.Endless)
            {
                Analytics.EndlessEnd(Score, Turn, AttemptSeconds, _attemptRevived, _endlessNewBest, !_failPending, _rescueUsed, _maxChainThisGame);
                if (_failPending)
                {
                    Adaptive.OnEndlessEnd(Score, _bestAtStart, Turn); // yarıda bırakılan oyun zorluğu etkilemez
                    PlayerModel.OnGameEnd(true, true, Turn, _bestAtStart > 0 ? Score / (float)_bestAtStart : -1f,
                                          _endlessNewBest, 1f); // endless kaybı = tahta tepeye ulaştı
                    Achievements.ReportAdd("games", 1);
                }
            }
            _failPending = false;
        }

        /// <summary>Hedeflerin ortalama tamamlanma oranı (0..1): oyuncu kaybettiğinde ne kadar yaklaşmıştı.</summary>
        float GoalProgress01()
        {
            if (Level == null || Level.goals == null || Level.goals.Length == 0) return 0f;
            float sum = 0f;
            foreach (var g in Level.goals)
                sum += g.amount > 0 ? Mathf.Clamp01(GoalProgress(g) / (float)g.amount) : 1f;
            return sum / Level.goals.Length;
        }

        void OnApplicationQuit() => AttemptClose();

        /// <summary>
        /// Kayıp ekranındaki "kıl payı" metni. Tekrar denemenin en güçlü tetikleyicisi: ne kadar yaklaştığını görmek.
        /// Boş dönerse sonuç ekranı kendi varsayılan metnini kullanır.
        /// </summary>
        public string NearMissText(out bool close)
        {
            close = false;
            if (Mode == GameMode.Level && Level != null && Level.goals != null)
            {
                var parts = new System.Collections.Generic.List<string>();
                foreach (var g in Level.goals)
                {
                    int rem = g.amount - GoalProgress(g);
                    if (rem <= 0) continue;
                    switch (g.type)
                    {
                        case "color": parts.Add(Loc.F("{0} {1}", rem, Loc.T(_s.GetColorName(g.color)))); break;
                        case "score": parts.Add(Loc.F("{0} points", rem)); break;
                        case "bomb": parts.Add(Loc.F(rem > 1 ? "{0} bombs" : "{0} bomb", rem)); break;
                        case "lightning": parts.Add(Loc.F("{0} lightning", rem)); break;
                        case "blocks": parts.Add(Loc.F("{0} blocks", rem)); break;
                    }
                }
                if (parts.Count == 0) return "";
                close = GoalProgress01() >= 0.7f;
                string list = string.Join(" • ", parts);
                return close ? Loc.F("SO CLOSE! ONLY {0} LEFT", list) : Loc.F("{0} LEFT", list);
            }
            if (Mode == GameMode.Endless && _bestAtStart > 0 && Score < _bestAtStart && Score >= _bestAtStart * 0.7f)
            {
                close = true;
                return Loc.F("ONLY {0} TO BEAT YOUR BEST!", _bestAtStart - Score);
            }
            return "";
        }
    }
}
