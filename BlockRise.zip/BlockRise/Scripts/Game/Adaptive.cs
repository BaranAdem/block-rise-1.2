using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Uyarlanabilir zorluk: oyuncunun geçmişine bakıp zorluğu ona fark ettirmeden ayarlar. Uzun vadeli ZEMİN budur;
    /// oyuncunun o anki durumu (oturum, hayal kırıklığı, sıkılma) PlayerModel'dedir.
    ///
    /// CLASSIC — "ease" (0 = en zor, 1 = en kolay), her oyunun sonunda güncellenir. Hedef oyun uzunluğu yaklaşımı:
    ///   • Her oyuncunun oyunları, becerisi ne olursa olsun, hedef uzunluk (targetGameTurns, ≈3-4 dk) civarında bitsin.
    ///     Oyun hedeften uzun sürdüyse zorlaşır, kısa sürdüyse kolaylaşır (adım sınırlı: ani sıçrama yok).
    ///   • Rekor kırılan oyundan sonra küçük ek zorlaşma.
    ///   • Balayı: ilk birkaç oyun kolay tutulur (ilk izlenim).
    ///   • Hedefin yarısından kısa üst üste oyunlar → bir sonraki oyun "sıcak başlangıç" (ilk turlar cömert).
    /// Ease, GameController.CurrentRules'ta sıraların yardım gücüne, rampa süresine ve özel blok sıklığına çevrilir.
    ///
    /// LEVEL — aynı bölümde art arda kayıp:
    ///   • 2. kayıptan sonra sıralar giderek daha yardımcı gelir (görünmez).
    ///   • 3. kayıptan sonra +2, 5. kayıptan sonra +4 hediye hamle (görünür, "hediye" olarak sunulur).
    ///   • Bölüm geçilince sıfırlanır.
    /// </summary>
    public static class Adaptive
    {
        const string KeyEase = "br_dda_ease";
        const string KeyGames = "br_dda_games";
        const string KeyLowStreak = "br_dda_low";
        const string KeyHotStart = "br_dda_hot";
        const string KeyLevelFails = "br_dda_lvfail_";

        static GameSettings S => GameSettings.Instance;

        // ================================================================ Endless

        public static float EndlessEase
        {
            get => S.adaptiveDifficulty ? PlayerPrefs.GetFloat(KeyEase, 1f) : S.fixedEndlessEase;
            private set => PlayerPrefs.SetFloat(KeyEase, Mathf.Clamp01(value));
        }

        public static int EndlessGames => PlayerPrefs.GetInt(KeyGames, 0);

        /// <summary>Bu oyun "sıcak başlangıç" mı (oyun başında bir kez sorulur, bayrağı tüketir).</summary>
        public static bool ConsumeHotStart()
        {
            if (!S.adaptiveDifficulty || PlayerPrefs.GetInt(KeyHotStart, 0) == 0) return false;
            PlayerPrefs.SetInt(KeyHotStart, 0);
            PlayerPrefs.Save();
            return true;
        }

        /// <param name="bestBefore">Oyun başındaki rekor (oyun içinde güncellenen değil)</param>
        /// <param name="turns">Bu oyunun sürdüğü tur sayısı</param>
        public static void OnEndlessEnd(int score, int bestBefore, int turns)
        {
            if (!S.adaptiveDifficulty) return;
            int games = EndlessGames + 1;
            PlayerPrefs.SetInt(KeyGames, games);

            float target = Mathf.Max(10, S.targetGameTurns);
            float step = Mathf.Clamp(S.easeGain * (target - turns) / target, -S.easeMaxStep, S.easeMaxStep);
            if (bestBefore > 0 && score > bestBefore) step -= S.easeStepOnRecord;

            float e = EndlessEase + step;
            if (games <= S.honeymoonGames) e = Mathf.Max(e, S.honeymoonMinEase);
            EndlessEase = e;

            int low = turns < target * 0.5f ? PlayerPrefs.GetInt(KeyLowStreak, 0) + 1 : 0;
            if (low >= S.hotStartAfterBadGames)
            {
                PlayerPrefs.SetInt(KeyHotStart, 1);
                low = 0;
            }
            PlayerPrefs.SetInt(KeyLowStreak, low);
            PlayerPrefs.Save();
        }

        // ================================================================ Level

        public static int LevelFails(int index) => PlayerPrefs.GetInt(KeyLevelFails + index, 0);

        public static void OnLevelResult(int index, bool win)
        {
            if (!S.adaptiveDifficulty) return;
            PlayerPrefs.SetInt(KeyLevelFails + index, win ? 0 : LevelFails(index) + 1);
            PlayerPrefs.Save();
        }

        /// <summary>Bu bölümde art arda kayıplara göre sıralara eklenen görünmez yardım.</summary>
        public static float LevelAssistBonus(int index)
        {
            if (!S.adaptiveDifficulty) return 0f;
            int f = LevelFails(index);
            return Mathf.Clamp((f - 1) * S.levelAssistPerFail, 0f, S.levelAssistMax);
        }

        /// <summary>Bu bölümde art arda kayıplara göre verilen hediye hamle.</summary>
        public static int LevelBonusMoves(int index)
        {
            if (!S.adaptiveDifficulty) return 0;
            int f = LevelFails(index);
            if (f >= S.bigGiftAfterFails) return S.bigGiftMoves;
            if (f >= S.giftAfterFails) return S.giftMoves;
            return 0;
        }
    }
}
