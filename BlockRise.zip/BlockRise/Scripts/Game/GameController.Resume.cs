using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Endless'ta kaldığı yerden devam: oyuncu uygulamayı kapatıp açınca (ya da menüye dönüp CLASSIC'e basınca)
    /// oyun aynı tahta, skor ve zorlukla sürer.
    ///   • Kayıt her tur sonunda, revive'dan sonra ve oyun başında yazılır.
    ///   • Oyun bitince silinir. Restart / Retry her zaman yeni oyun başlatır.
    ///   • Tur ortasında kapanırsa son tamamlanan tur yüklenir (yarım hamle kaybolur).
    /// </summary>
    public partial class GameController
    {
        void SaveEndless()
        {
            if (Mode != GameMode.Endless || _model == null || State == GameState.Over) return;
            _model.Export(out var colors, out var specials, out var nextColors, out var nextSpecials);
            var data = new EndlessSaveData
            {
                width = _model.Width,
                height = _model.Height,
                colors = colors,
                specials = specials,
                nextColors = nextColors,
                nextSpecials = nextSpecials,
                score = Score,
                turn = Turn,
                totalCleared = TotalCleared,
                bombs = Bombs,
                lightnings = Lightnings,
                clearedByColor = (int[])ClearedByColor.Clone(),
                turnsSinceRise = _turnsSinceRise,
                comboStreak = _comboStreak,
                maxChain = _maxChainThisGame,
                reviveUsed = _reviveUsed,
                bestAtStart = _bestAtStart,
            };
            _director.SaveTo(data); // zorluk ve casual akış sayaçları (kolaylık, sıcak başlangıç, kurtuluş, dalga...)
            EndlessSave.Write(data);
        }

        void ApplyResumeState(EndlessSaveData d)
        {
            Score = d.score;
            Turn = d.turn;
            TotalCleared = d.totalCleared;
            Bombs = d.bombs;
            Lightnings = d.lightnings;
            if (d.clearedByColor != null)
                for (int i = 0; i < ClearedByColor.Length && i < d.clearedByColor.Length; i++) ClearedByColor[i] = d.clearedByColor[i];
            _turnsSinceRise = d.turnsSinceRise;
            _comboStreak = d.comboStreak;
            _maxChainThisGame = d.maxChain; // yönetmen sayaçları BeginGame'de EndlessDirector.LoadFrom ile yüklenir

            _reviveUsed = d.reviveUsed;
            // Madalyalara zaten bildirilmiş sayılar tekrar sayılmasın
            _achBlocks = TotalCleared;
            _achBombs = Bombs;
            _achStars = Lightnings;
        }
    }
}
