using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// CASUAL AKIŞ (yalnızca Classic): sıraların tur tur kuralları EndlessDirector'dadır (saf mantık; simülatör de
    /// aynı sınıfı kullanır). Burada yalnızca GameController'ın ona bağlandığı küçük parçalar ve oyuncuya görünen
    /// geri bildirimler (kademe duyurusu, oyun içinde rekor anı) kalır.
    /// </summary>
    public partial class GameController
    {
        EndlessDirector _director;
        int _maxChainThisGame;  // ölçüm: oyunun en uzun zinciri
        bool _newBestAnnounced; // bu oyunda "NEW BEST!" anı yaşandı mı

        /// <summary>Bu oyunda verilen kurtuluş sayısı (ölçüm için).</summary>
        public int RescuesUsed => _director != null ? _director.RescueUsed : 0;

        /// <summary>Classic'te o anki kademe (HUD / ölçüm).</summary>
        public int Stage => _director != null ? _director.Stage : 1;

        void ResetCasualFlow()
        {
            _maxChainThisGame = 0;
            _newBestAnnounced = false;
        }

        /// <summary>Yönetmen yeni kademeye geçtiyse kısa bir duyuru (toast + ses + yıldız tozu dalgası).</summary>
        void AnnounceStage()
        {
            if (!_director.ConsumeStageUp()) return;
            _ui.Toast(Loc.F("STAGE {0}", _director.Stage), 1.3f);
            Sfx(_s.sfxPraise, 1f, 0.7f);
            Haptics.Medium();
            StardustField.Emit(_view.BoardCenter, new Color(1f, 0.85f, 0.4f), 3, 12);
        }

        /// <summary>
        /// Oyun içinde rekor geçildiği AN: "NEW BEST!" + ses + titreşim (bir kez). Rekor kovalamanın en güçlü anı,
        /// sonuç ekranını beklemeden yaşanır; oyuncu rekoru geçtiğini bilerek daha da uzağa gitmeye çalışır.
        /// </summary>
        void CheckNewBestMoment()
        {
            if (Mode != GameMode.Endless || _newBestAnnounced || _bestAtStart <= 0 || Score <= _bestAtStart) return;
            _newBestAnnounced = true;
            _ui.Toast("NEW BEST!", 1.5f);
            Sfx(_s.sfxMedal, 1f, 0.9f);
            Haptics.Success();
            _fx.Confetti(_view.BoardTopCenter, _s.blockColors, 24, 1.1f);
        }
    }
}
