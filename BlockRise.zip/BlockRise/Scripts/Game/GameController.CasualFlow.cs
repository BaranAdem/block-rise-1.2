using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// CASUAL AKIŞ (yalnızca Classic). Amaç: oyuncu sık sık "iyi hamle yaptım" hissetsin, büyük anlar (zincir, özel blok,
    /// son anda kurtuluş) belli bir ritimle gelsin, ama usta oyuncu bunları hak ederek alsın.
    ///
    ///   ZİNCİR KURULUMU    Sıralar, bir grup patlayınca üstteki bloğun düşüp ikinci patlama yapacağı dizilimleri tercih eder
    ///                      (BoardModel.GenerateAssistedRow). Gücü kolaylığa göre: yeni/zorlanan oyuncuda belirgin, ustada hafif.
    ///   ÖLÜ TAHTA KORUMASI Üst üste N tur hiç patlama olmazsa sonraki sıra fırsatlarla gelir. Zorlanan oyuncuda erken, ustada geç.
    ///   ÖZEL BLOK RİTMİ    Uzun süre bomba/şimşek patlatılmazsa özel blok ihtimali yavaşça artar (değişken ödül).
    ///                      Ustada artış yok (kolaylıkla ölçeklenir).
    ///   KIL PAYI KURTULUŞ  Tahta tepeye yaklaşınca birkaç sıra zincir ve fırsatla dolu ve daha seyrek gelir.
    ///                      YALNIZCA yeni oyuncu ve zorlanan oyuncu alır; usta (kolaylık rescueEaseFrom altında) hiç almaz.
    ///                      Garanti değil: oyuncunun fırsatı görmesi gerekir.
    ///
    /// Kurallar tur sonundaki yükselmede üretilen ÖNİZLEME sırasına işler: yardım bir tur sonra görünür,
    /// oyuncu gelen fırsatı önceden görür ("umut" anı).
    /// Sayaçlar endless kaydına yazılır: uygulamayı kapatıp açmak yeni kurtuluş hakkı vermez.
    /// </summary>
    public partial class GameController
    {
        int _dryTurns;          // üst üste patlamasız tur
        int _turnsSinceSpecial; // son bomba/şimşek patlamasından beri geçen tur
        int _rescueUsed, _rescueLeft, _nextRescueTurn;
        int _maxChainThisGame;  // ölçüm: oyunun en uzun zinciri

        /// <summary>Bu oyunda verilen kurtuluş sayısı (ölçüm için).</summary>
        public int RescuesUsed => _rescueUsed;

        void ResetCasualFlow()
        {
            _dryTurns = 0;
            _turnsSinceSpecial = 0;
            _rescueUsed = 0;
            _rescueLeft = 0;
            _nextRescueTurn = 0;
            _maxChainThisGame = 0;
        }

        /// <summary>Özel blok kuraklığı çarpanı: bekleme süresinden sonra her tur artar, kolaylıkla ölçeklenir (ustada 1).</summary>
        float SpecialDroughtMultiplier(float ease)
        {
            int over = _turnsSinceSpecial - _s.specialGraceTurns;
            if (over <= 0) return 1f;
            float m = 1f + over * _s.specialGrowthPerTurn * ease;
            return Mathf.Min(Mathf.Max(1f, _s.specialMaxMultiplier), m);
        }

        /// <summary>
        /// Kurtuluş hakkı oranı (0..1): yeni oyuncu 1; değilse kolaylığa göre rescueEaseFrom (0) → rescueEaseFull (1).
        /// Usta oyuncu (kolaylık düşük) 0 alır.
        /// </summary>
        float RescueShare(float ease)
        {
            if (PlayerModel.Enabled && PlayerModel.IsNovice) return 1f;
            if (_s.rescueEaseFull <= _s.rescueEaseFrom) return ease >= _s.rescueEaseFull ? 1f : 0f;
            return Mathf.InverseLerp(_s.rescueEaseFrom, _s.rescueEaseFull, ease);
        }

        int DryGuardTurns(float ease)
        {
            if (_s.dryGuardTurnsHard <= 0 && ease < 0.5f) return 0; // ustada kapalı
            int hard = _s.dryGuardTurnsHard > 0 ? _s.dryGuardTurnsHard : _s.dryGuardTurnsEasy * 2;
            return Mathf.Max(1, Mathf.RoundToInt(Mathf.Lerp(hard, _s.dryGuardTurnsEasy, ease)));
        }

        /// <summary>Yükselmede üretilecek sıranın kurallarına casual akışı uygular (Classic).</summary>
        void ApplyCasualFlow(ref RowRules r, float ease)
        {
            // 0) Alçak tahta baskısı: tahta hedefin altındaysa sıralar zorlaşır (gerilim). Bu durumda tahta zaten
            //    rahat olduğu için kurtuluş ve ölü tahta koruması gerekmez.
            if (ApplyPressure(ref r, ease)) return;

            // 1) Süren kurtuluş
            if (_rescueLeft > 0)
            {
                _rescueLeft--;
                RescueRow(ref r);
                return;
            }

            // 2) Yeni kurtuluş: tahta tepeye yakın, hak var, bekleme süresi doldu
            int max = Mathf.RoundToInt(Mathf.Max(0, _s.rescueMaxNovice) * RescueShare(ease));
            if (max > 0 && Danger >= _s.rescueDanger && _rescueUsed < max && Turn >= _nextRescueTurn)
            {
                _rescueUsed++;
                _rescueLeft = Mathf.Max(0, _s.rescueRows - 1);
                _nextRescueTurn = Turn + Mathf.Max(1, _s.rescueCooldownTurns);
                RescueRow(ref r);
                return;
            }

            // 3) Ölü tahta koruması
            int dry = DryGuardTurns(ease);
            if (dry > 0 && _dryTurns >= dry)
            {
                r.assist = Mathf.Max(r.assist, _s.dryGuardAssist);
                r.chainAssist = Mathf.Max(r.chainAssist, _s.chainAssistEasy * 0.5f);
            }
        }

        /// <summary>
        /// GERİLİM (alçak tahta baskısı). İyi oynayan oyuncu tahtayı hep aşağıda tutabiliyordu (6. sıra civarı) ve oyun
        /// sıkıcılaşıyordu. Tahta hedef yüksekliğin altındaysa gelen sıra, ne kadar alçaksa o kadar:
        ///   • yardımsız gelir (yardım ve zincir kurulumu söner),
        ///   • daha dolu gelir (boşluk azalır),
        ///   • dağınık gelir (renkler mevcut gruplara daha az eklenir → patlatmak zorlaşır).
        /// Tahta hedefe yükselince baskı kalkar ve normal (yardımlı) sıralar döner. Böylece oyun kendiliğinden
        /// "tepeye birkaç sıra kala" bölgesinde dengelenir: ne rahat ne haksız. Zorlanan oyuncuda hafifler.
        /// true: baskı uygulandı.
        /// </summary>
        bool ApplyPressure(ref RowRules r, float ease)
        {
            if (!_s.pressureEnabled || Turn < _s.pressureStartTurn || Turn < _hotStartTurns) return false;
            float target = _s.pressureTarget;
            float floor = Mathf.Min(_s.pressureFloor, target - 0.01f);
            float d = Danger;
            if (d >= target) return false;

            float k = Mathf.Clamp01((target - d) / Mathf.Max(0.01f, target - floor)); // 0 = hedefte, 1 = çok alçak
            k *= Mathf.Clamp01((Turn - _s.pressureStartTurn) / 10f);                    // açılıştan sonra yavaşça gelir
            k *= 1f - Mathf.Clamp01(ease) * _s.pressureEaseRelief;                       // zorlanan oyuncuda hafif
            if (k <= 0.01f) return false;

            r.assist *= 1f - k;
            r.chainAssist *= 1f - k;
            r.spoil = Mathf.Max(r.spoil, _s.pressureSpoil * k);
            int cut = Mathf.RoundToInt(_s.pressureGapCut * k);
            r.minGaps = Mathf.Max(1, r.minGaps - cut);
            r.maxGaps = Mathf.Max(r.minGaps, r.maxGaps - cut);
            return true;
        }

        /// <summary>Kurtuluş sırası: en yüksek yardım, güçlü zincir kurulumu ve fazladan boşluk.</summary>
        void RescueRow(ref RowRules r)
        {
            r.assist = 1f;
            r.chainAssist = 1f;
            int extra = Mathf.Max(0, _s.rescueExtraGaps);
            r.minGaps += extra;
            r.maxGaps += extra;
        }
    }
}
