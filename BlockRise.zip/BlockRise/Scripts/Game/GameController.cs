using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    public enum GameMode { Endless, Level, Tutorial }
    public enum GameState { Menu, Playing, Paused, Over }

    /// <summary>
    /// Tur akışı: hamle -> yerçekimi/patlama zinciri -> sıra yükselmesi -> tekrar zincir -> kazan/kaybet kontrolü.
    /// </summary>
    public partial class GameController : MonoBehaviour
    {
        public GameMode Mode { get; private set; }
        public GameState State { get; private set; } = GameState.Menu;
        public int LevelIndex { get; private set; }
        public LevelData Level { get; private set; }

        public int Score { get; private set; }
        public int MovesLeft { get; private set; }
        public int Turn { get; private set; }
        public int TotalCleared { get; private set; }
        public int Bombs { get; private set; }
        public int Lightnings { get; private set; }
        public readonly int[] ClearedByColor = new int[8];

        GameSettings _s;
        BoardModel _model;
        BoardView _view;
        FxManager _fx;
        UIManager _ui;
        bool _busy;
        bool _reviveUsed;
        int _turnsSinceRise;
        bool _outOfMoves;
        int _comboStreak;   // üst üste patlama yapan hamle sayısı
        int _resolvePopped; // son Resolve'da patlayan blok sayısı

        SoundManager _sound;

        public void Init(BoardView view, FxManager fx, UIManager ui)
        {
            _s = GameSettings.Instance;
            _view = view;
            _fx = fx;
            _ui = ui;
            _sound = SoundManager.Instance;
            _director = new EndlessDirector(_s);
            _view.MoveRequested += OnMoveRequested;
        }

        // ================================================================ Mode start

        /// <summary>Menüdeki CLASSIC: kaydedilmiş oyun varsa kaldığı yerden devam eder, yoksa yeni oyun başlar.</summary>
        public void StartEndless()
        {
            // İlk oyunda önce tutorial, bitince sonsuz mod başlar
            if (!SaveSystem.TutorialSeen) { StartTutorial(GameMode.Endless, 0, false); return; }
            var save = EndlessSave.Load(_s.boardWidth, _s.boardHeight);
            Mode = GameMode.Endless;
            Level = null;
            BeginGame(0, _s.endlessStartRows, save);
        }

        /// <summary>Açılışta: geçerli endless kaydı varsa oyunu kaldığı yerden açar. Kayıt yoksa / bozuksa false.</summary>
        public bool TryResumeEndless()
        {
            var save = EndlessSave.Load(_s.boardWidth, _s.boardHeight);
            if (save == null) return false;
            Mode = GameMode.Endless;
            Level = null;
            BeginGame(0, _s.endlessStartRows, save);
            return true;
        }

        /// <summary>Her zaman yeni endless oyunu (Restart / Retry). Eski kayıt yeni oyunla üzerine yazılır.</summary>
        public void StartNewEndless()
        {
            Mode = GameMode.Endless;
            Level = null;
            BeginGame(0, _s.endlessStartRows);
        }

        public void StartLevel(int index)
        {
            if (LevelDatabase.Count == 0) { Debug.LogError("[BlockRise] Level yok."); return; }
            if (!SaveSystem.TutorialSeen) { StartTutorial(GameMode.Level, index, false); return; }
            Mode = GameMode.Level;
            LevelIndex = Mathf.Clamp(index, 0, LevelDatabase.Count - 1);
            Level = LevelDatabase.Get(LevelIndex);
            BeginGame(Level.seed, Level.startRows);
        }

        public void Restart()
        {
            Time.timeScale = 1f;
            if (Mode == GameMode.Endless) StartNewEndless();
            else StartLevel(LevelIndex);
        }

        /// <summary>Bölümlerin simülasyonla dengelendiği tahta yüksekliği.</summary>
        const int LevelCalibratedHeight = 10;
        int _movePenalty;

        /// <summary>
        /// Tahta 10 satırdan uzunsa bölümler kolaylaşır (tavana çarpma riski azalır). Bunu dengelemek için her fazla satır başına
        /// ilk 40 bölümde yarım, sonrasında 1 hamle eksilir. Simülasyonda 12 satır + bu eksiltme, 10 satırdaki dengeyi korur.
        /// Yıldız hesabı eksilen hamleyi geri ekler: 3 yıldız zorlaşmaz.
        /// </summary>
        int LevelMovePenalty(int index)
        {
            int extra = _s.boardHeight - LevelCalibratedHeight;
            if (extra <= 0) return 0;
            return Mathf.RoundToInt(extra * (index < 40 ? 0.5f : 1f));
        }

        public void NextLevel()
        {
            if (LevelIndex + 1 < LevelDatabase.Count) StartLevel(LevelIndex + 1);
            else GoToAdventure();
        }

        /// <summary>Oyunu kapatıp Adventure ekranına döner (kazanılan bölümün açtığı bloklar orada belirir).</summary>
        public void GoToAdventure()
        {
            AttemptClose();
            StopTutorialGuide();
            StopAllCoroutines();
            Time.timeScale = 1f;
            _busy = false;
            State = GameState.Menu;
            _view.InputEnabled = false;
            _view.SetVisible(false);
            _ui.ShowLevelSelect();
        }

        /// <param name="resume">Endless kaydı: verilirse tahta ve oyun durumu kayıttan yüklenir</param>
        void BeginGame(int seed, int startRows, EndlessSaveData resume = null)
        {
            StopAllCoroutines();
            Time.timeScale = 1f;
            _busy = false;
            _reviveUsed = false;
            _outOfMoves = false;
            Score = 0;
            Turn = 0;
            TotalCleared = 0;
            Bombs = 0;
            Lightnings = 0;
            _turnsSinceRise = 0;
            _comboStreak = 0;
            for (int i = 0; i < ClearedByColor.Length; i++) ClearedByColor[i] = 0;
            _achBlocks = _achBombs = _achStars = 0;
            ResetCasualFlow();
            if (resume != null) ApplyResumeState(resume);
            // Uyarlanabilir zorluk: bu denemenin ayarları oyun başında bir kez belirlenir (devam eden oyunda kayıttan gelir)
            _bonusMoves = Mode == GameMode.Level ? Adaptive.LevelBonusMoves(LevelIndex) : 0;
            _bestAtStart = resume != null ? resume.bestAtStart : SaveSystem.BestEndless;
            if (resume == null && (Mode == GameMode.Endless || Mode == GameMode.Level)) PlayerModel.BeginGame();
            // Uzun vadeli zemin (Adaptive) + oyuncunun o anki durumu (PlayerModel: oturum, hayal kırıklığı, sıkılma)
            _ease = resume != null ? resume.ease : Mathf.Clamp01(Adaptive.EndlessEase + PlayerModel.EaseOffset());
            _maxDanger = 0f;
            _inputWasReady = false; // yeni tahta: en iyi hamle hesabı girdi açılınca yeniden başlar
            _bestReady = false;
            _bestPopSize = 0;
            _hotStartTurns = resume != null ? resume.hotStartTurns
                           : Mode == GameMode.Endless && Adaptive.ConsumeHotStart() ? _s.hotStartTurns : 0;
            bool novice = PlayerModel.Enabled && PlayerModel.IsNovice;
            if (resume != null) _director.LoadFrom(resume, novice);
            else _director.Begin(_ease, _hotStartTurns, novice);
            _newBestAnnounced = resume != null && _bestAtStart > 0 && Score > _bestAtStart; // kayıttan devam: an zaten yaşandı
            // Tahta, bölümlerin dengelendiği yükseklikten (10) uzunsa bölüm aynı zorlukta kalsın diye hamle eksilir
            _movePenalty = Mode == GameMode.Level ? LevelMovePenalty(LevelIndex) : 0;
            MovesLeft = Mode == GameMode.Level ? Mathf.Max(5, Level.moves + _bonusMoves - _movePenalty) : 0;

            _model = new BoardModel(_s.boardWidth, _s.boardHeight, _s.popSize, seed);
            _model.BombMode = _s.bombMode;
            _model.Rules = CurrentRules();
            if (resume != null) _model.Restore(resume.colors, resume.specials, resume.nextColors, resume.nextSpecials);
            else _model.Fill(startRows);

            State = GameState.Playing;
            _ui.ShowHUD(this);
            _view.SetVisible(true);
            _view.SetModel(_model);
            _view.FitCamera(_ui.TopReservePixels, _ui.BottomReservePixels);
            _view.InputEnabled = true;
            _ui.UpdateHUD(this);

            if (Mode == GameMode.Level)
                _ui.Toast((Level.hard >= 2 ? Loc.T("BOSS LEVEL") + "\n" : Level.hard == 1 ? Loc.T("HARD LEVEL") + "\n" : "")
                          + Loc.F("LEVEL {0}", LevelIndex + 1) + "\n" + GoalSummary()
                          + (_bonusMoves > 0 ? "\n" + Loc.F("+{0} BONUS MOVES!", _bonusMoves) : ""), _bonusMoves > 0 ? 2.8f : 2.2f);

            AttemptBegin(); // ölçüm: önceki deneme varsa kapanır, yenisi başlar
            HideHint();
            AdPolicy.GameStarted(Mode); // geçiş reklamı sayacı: bu oyunda ödüllü reklam izlendi mi

            if (Mode == GameMode.Endless)
            {
                SaveEndless(); // yeni oyun eski kaydın üzerine yazılır; devam eden oyunda kayıt tazelenir
                if (resume != null) _ui.Toast("WELCOME BACK!", 1.4f);
            }
        }

        /// <param name="forRise">true: bu kurallar tur sonundaki yükselmede kullanılacak (casual akış sayaçları yalnızca o zaman işler)</param>
        RowRules CurrentRules(bool forRise = false)
        {
            RowRules r;
            if (Mode == GameMode.Level && Level != null)
            {
                r = new RowRules
                {
                    colorCount = Level.colors,
                    bombChance = Level.bombChance,
                    lightningChance = Level.lightningChance,
                    rowBombChance = Level.rowBombChance >= 0f ? Level.rowBombChance : _s.levelRowBombChance,
                    columnBombChance = Level.columnBombChance >= 0f ? Level.columnBombChance : _s.levelColumnBombChance,
                    minGaps = Level.minGaps,
                    maxGaps = Level.maxGaps,
                    // Aynı bölümde art arda kayıp → sıralar fark ettirmeden daha yardımcı gelir
                    assist = Mathf.Clamp01(_s.levelAssist + Adaptive.LevelAssistBonus(LevelIndex) + PlayerModel.LevelAssistOffset()),
                    chainAssist = Level.chainAssist >= 0f ? Level.chainAssist : _s.levelChainAssist
                };
            }
            else
            {
                // CLASSIC (ve tutorial): EndlessDirector. Casual akış yalnızca Classic'te ve yükselme sırasında işler.
                _director.Novice = PlayerModel.Enabled && PlayerModel.IsNovice;
                r = _director.Rules(Turn, Danger, forRise && Mode == GameMode.Endless);
            }
            r.chainWeight = _s.chainWeight;
            r.nearWeight = _s.assistNearWeight;
            r.midWeight = _s.assistMidWeight;
            r.autoPopWeight = _s.assistAutoPopWeight;
            return r;
        }

        int RiseEvery
        {
            get
            {
                if (_s.forceRiseEveryTurn) return 1; // her hamleden sonra yükselir
                if (Mode == GameMode.Level && Level != null) return Mathf.Max(1, Level.riseEvery);
                return Mathf.Max(1, _s.endlessRiseEvery);
            }
        }

        // ================================================================ Pause / Home

        public void Pause()
        {
            if (State != GameState.Playing) return;
            State = GameState.Paused;
            Time.timeScale = 0f;
            _view.InputEnabled = false;
            _ui.ShowPause();
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            State = GameState.Playing;
            Time.timeScale = 1f;
            _view.InputEnabled = !_busy;
            _ui.HidePause();
        }

        public void GoHome()
        {
            AttemptClose(); // bitmemiş oyun → yarıda bırakma; sonuç ekranından dönüş → kayıp kesinleşir
            StopTutorialGuide();
            StopAllCoroutines();
            Time.timeScale = 1f;
            _busy = false;
            State = GameState.Menu;
            _view.InputEnabled = false;
            _view.SetVisible(false);
            _ui.ShowMainMenu();
        }

        // ================================================================ Turn

        void OnMoveRequested(List<Vector2Int> cells, int shift)
        {
            if (State != GameState.Playing || _busy) return;
            _moveAfterHint = _hintShown; // ipucunu bekleyip yapılan hamlenin süresi düşünme süresi sayılmaz
            HideHint();
            if (Mode == GameMode.Tutorial) StartCoroutine(TutorialMove(cells, shift));
            else StartCoroutine(TurnRoutine(cells, shift));
        }

        IEnumerator TurnRoutine(List<Vector2Int> cells, int shift)
        {
            float quality = MeasureMoveQuality(cells, shift); // hamle uygulanmadan önce: tahtadaki en iyi seçeneğe göre
            float think = _moveAfterHint ? -1f : Time.unscaledTime - _inputReadyAt;
            if (!_model.ApplyMove(cells, shift))
            {
                yield return _view.AnimateToModel(_s.slideSnapTime, 0f, BoardView.Ease.OutQuad);
                yield break;
            }

            _busy = true;
            _view.InputEnabled = false;
            Turn++;
            _director.OnMove(Turn);
            if (Mode == GameMode.Level) MovesLeft--;
            _ui.UpdateHUD(this);
            yield return _view.AnimateToModel(_s.slideSnapTime, 0.02f, BoardView.Ease.OutQuad);
            SfxOrganic(_s.sfxPlace, _s.placeVolume); // ses ve titreşim blok yerine oturduğu an
            Haptics.Light();

            // Combo: hamle bir patlama başlattıysa seri artar, başlatmadıysa sıfırlanır.
            // Seri önceden artırılır ki bu hamlenin sesleri/övgüsü yeni seriyi kullansın.
            _comboStreak++;
            yield return Resolve();
            if (_resolvePopped == 0) _comboStreak = 0;
            _director.OnTurnResolved(_resolvePopped, _resolveChain); // patlamasız tur serisi, gerilim dalgası vb.
            // Zincir kuran hamle, o an patlamasa bile ustalıktır
            if (_resolveChain >= 2) quality = Mathf.Max(quality, 1f);
            if (Mode == GameMode.Endless || Mode == GameMode.Level) PlayerModel.OnMove(quality, think, _resolveChain);

            if (CheckWin()) yield break;

            // Yeni sıra
            _turnsSinceRise++;
            // Classic: yönetmen rahatlama anında bir yükselmeyi atlayabilir (büyük temizlikten sonra nefes payı)
            bool rise = _turnsSinceRise >= RiseEvery && (Mode != GameMode.Endless || _director.ShouldRise(Turn, Danger));
            if (rise)
            {
                _turnsSinceRise = 0;
                if (_model.TopRowOccupied())
                {
                    GameOver(false);
                    yield break;
                }
                _model.Rules = CurrentRules(forRise: true);
                _model.Rise();
                Sfx(_s.sfxRise);
                yield return _view.AnimateToModel(_s.riseTime, 0f, BoardView.Ease.OutQuad);
                yield return Resolve();
                if (CheckWin()) yield break;
                if (Mode == GameMode.Endless) AnnounceStage();

                // Yükselme + patlamalardan sonra en üst sırada blok kaldıysa → kaybettin
                if (_model.TopRowOccupied())
                {
                    GameOver(false);
                    yield break;
                }
            }

            if (Mode == GameMode.Level && MovesLeft <= 0)
            {
                GameOver(true);
                yield break;
            }

            // Hamle kalmadıysa karıştır
            int tries = 0;
            while (!_model.HasAnyMove() && tries++ < 3)
            {
                _ui.Toast("SHUFFLE!", 1f);
                _model.ReshuffleColors();
                yield return _view.PlayReshuffle();
                yield return Resolve();
            }
            // Hâlâ hamle yoksa ücretsiz yükselme zorla. Tek yükselme yetmeyebilir (simülasyonda bulundu: dolu alt sıra +
            // tek boşluklu sıra, boşluğun yanındaki öbek alttan kilitli → oyuncu hiçbir şey oynatamıyor, oyun kilitleniyordu).
            // Hamle açılana ya da tahta tavana dayanana kadar tekrarlanır.
            for (int forced = 0; !_model.HasAnyMove() && forced < _model.Height; forced++)
            {
                if (_model.TopRowOccupied()) { GameOver(false); yield break; }
                _model.Rise();
                Sfx(_s.sfxRise);
                yield return _view.AnimateToModel(_s.riseTime, 0f, BoardView.Ease.OutQuad);
                yield return Resolve();
                if (_model.TopRowOccupied()) { GameOver(false); yield break; }
            }

            TrackDanger();
            _ui.UpdateHUD(this);
            if (Mode == GameMode.Endless) SaveEndless(); // tur bitti: kaldığı yer burası
            _busy = false;
            if (State == GameState.Playing) _view.InputEnabled = true;
        }

        /// <summary>Yerçekimi + patlama zinciri (combo).</summary>
        IEnumerator Resolve()
        {
            int chain = 0;
            int poppedTotal = 0;
            while (true)
            {
                if (_model.ApplyGravity())
                {
                    yield return _view.AnimateToModel(0.05f, _s.fallTimePerCell, BoardView.Ease.InQuad);
                    SfxOrganic(_s.sfxLand, _s.landVolume);
                }

                var pops = _model.FindAndRemovePops();
                if (pops == null || pops.Count == 0) break;

                chain++;
                poppedTotal += pops.Count;
                if (pops.BombCenters.Count + pops.LightningCenters.Count > 0) _director.OnSpecialPopped();
                int gained = ScorePops(pops, chain);
                PlayPopSounds(pops, chain);

                yield return _view.PlayPops(pops, chain);

                // puan yazısı
                Vector3 center = Vector3.zero;
                foreach (var p in pops.Positions) center += _view.CellCenter(p.x, p.y);
                center /= Mathf.Max(1, pops.Positions.Count);
                _fx.Text(center, "+" + gained, Color.white, chain > 1 ? 1.15f : 0.95f);

                ShowPraise(pops, chain);
                CheckNewBestMoment();

                _ui.UpdateHUD(this);
                if (_s.chainDelay > 0) yield return new WaitForSeconds(_s.chainDelay);
            }

            _resolvePopped = poppedTotal;
            _resolveChain = chain;
            if (chain > _maxChainThisGame) _maxChainThisGame = chain;

            // Madalyalar: zincir, temizlenen blok, atom (bomba), yıldız (şimşek), endless skoru/turu
            if (Mode != GameMode.Tutorial)
            {
                Achievements.ReportMax("chain", chain);
                Achievements.ReportAdd("blocks", TotalCleared - _achBlocks);
                Achievements.ReportAdd("atoms", Bombs - _achBombs);
                Achievements.ReportAdd("stars", Lightnings - _achStars);
                _achBlocks = TotalCleared; _achBombs = Bombs; _achStars = Lightnings;
                if (Mode == GameMode.Endless)
                {
                    Achievements.ReportMax("score", Score);
                    Achievements.ReportMax("survivor", Turn);
                }
            }

            // Tahta tamamen temizlendi → bonus
            if (poppedTotal > 0 && _model.IsEmpty())
            {
                Score += _s.perfectClearBonus;
                if (Mode != GameMode.Tutorial) Achievements.ReportAdd("sweep", 1);
                if (_s.showPraise) _fx.Praise(_view.BoardCenter, _s.perfectClearWord, new Color(1f, 0.85f, 0.3f), 1.9f);
                _fx.Confetti(_view.BoardCenter, _s.blockColors, 40, 1.4f);
                Sfx(_s.sfxPerfect);
                Haptics.Success();
                _ui.UpdateHUD(this);
            }
        }

        // ================================================================ Sound / Praise

        void Sfx(string[] names, float pitch = 1f, float volume = 1f)
        {
            if (_sound != null) _sound.PlayFrom(names, pitch, volume);
        }

        void SfxOrganic(string[] names, float volume = 1f)
        {
            if (_sound != null) _sound.PlayOrganic(names, volume);
        }

        /// <summary>Zincir ve combo büyüdükçe ses tizleşir (ayarlar: chainPitchStep, comboPitchStep, maxPitch).</summary>
        float RewardPitch(int chain)
        {
            if (_s.musicalPitch)
            {
                int steps = _s.chainScaleSteps * Mathf.Max(0, chain - 1)
                          + _s.comboScaleSteps * Mathf.Max(0, _comboStreak - 1);
                return Mathf.Min(_s.maxPitch, SoundManager.Semitones(SoundManager.PentatonicSemitones(steps)));
            }
            float semis = _s.chainPitchStep * Mathf.Max(0, chain - 1)
                        + _s.comboPitchStep * Mathf.Max(0, _comboStreak - 1);
            return Mathf.Min(_s.maxPitch, SoundManager.Semitones(semis));
        }

        void PlayPopSounds(PopResult pops, int chain)
        {
            float pitch = RewardPitch(chain);
            if (pops.BombCenters.Count > 0) Sfx(_s.sfxBomb);
            if (pops.LightningCenters.Count > 0) Sfx(_s.sfxBolt);
            Sfx(_s.sfxPop, pitch);
            if (chain > 1)
            {
                Sfx(_s.sfxChain, pitch);
            }

            // Titreşim: bomba/şimşek sert; normal patlama orta, zincir büyüdükçe sertleşir
            if (pops.BombCenters.Count > 0 || pops.LightningCenters.Count > 0) Haptics.Heavy();
            else Haptics.Impact(0.5f + 0.17f * (chain - 1));
        }

        /// <summary>
        /// Övgü seviyesi: zincir, patlayan grup büyüklüğü, özel bloklar ve combo serisine göre hesaplanır.
        /// Seviye 0 = yazı yok.
        /// </summary>
        void ShowPraise(PopResult pops, int chain)
        {
            if (!_s.showPraise || _s.praiseWords == null || _s.praiseWords.Length == 0) return;

            int biggest = 0;
            foreach (var g in pops.GroupSizes) biggest = Mathf.Max(biggest, g);
            int tier = (chain - 1) * 2
                     + Mathf.Max(0, biggest - _s.popSize) / 2
                     + (pops.BombCenters.Count + pops.LightningCenters.Count > 0 ? 1 : 0)
                     + (chain == 1 && _comboStreak >= _s.comboShowFrom ? 1 : 0);

            var pos = _view.BoardCenter + Vector3.up * 1.5f;
            if (tier > 0)
            {
                int idx = Mathf.Clamp(tier - 1, 0, _s.praiseWords.Length - 1);
                Color c = _s.praiseColors != null && _s.praiseColors.Length > 0
                    ? _s.praiseColors[Mathf.Clamp(idx, 0, _s.praiseColors.Length - 1)] : Color.white;
                _fx.Praise(pos, _s.praiseWords[idx], c, 1.4f + idx * 0.08f);
                Sfx(_s.sfxPraise, RewardPitch(chain), 0.8f);
                if (idx >= 3) _fx.Confetti(pos, _s.blockColors, 18 + idx * 4, 1f);
            }
            if (chain > 1)
                _fx.Text(pos + Vector3.down * 1.1f, Loc.F(_s.chainWordFormat, chain), new Color(1f, 0.85f, 0.3f), 1.2f);
            else if (_comboStreak >= _s.comboShowFrom)
                _fx.Text(pos + Vector3.down * 1.1f, Loc.F(_s.comboWordFormat, _comboStreak), new Color(0.6f, 0.9f, 1f), 1.05f);
        }

        int ScorePops(PopResult r, int chain)
        {
            int pts = 0;
            foreach (var b in r.Blocks)
            {
                pts += _s.pointsPerBlock;
                if (b.Color >= 0 && b.Color < ClearedByColor.Length) ClearedByColor[b.Color]++;
            }
            foreach (var g in r.GroupSizes) pts += Mathf.Max(0, g - _s.popSize) * _s.bonusPerExtraBlock;
            pts += r.BombCenters.Count * _s.bombBonus;
            pts += r.LightningCenters.Count * _s.lightningBonus;
            pts *= chain;

            TotalCleared += r.Count;
            Bombs += r.BombCenters.Count;
            Lightnings += r.LightningCenters.Count;
            Score += pts;
            return pts;
        }

        // ================================================================ Goals

        public int GoalProgress(GoalData g)
        {
            switch (g.type)
            {
                case "color": return g.color >= 0 && g.color < ClearedByColor.Length ? ClearedByColor[g.color] : 0;
                case "score": return Score;
                case "bomb": return Bombs;
                case "lightning": return Lightnings;
                case "blocks": return TotalCleared;
                default: return 0;
            }
        }

        public int GoalRemaining(GoalData g) => Mathf.Max(0, g.amount - GoalProgress(g));

        public bool AllGoalsDone()
        {
            if (Level == null || Level.goals == null || Level.goals.Length == 0) return false;
            foreach (var g in Level.goals) if (GoalRemaining(g) > 0) return false;
            return true;
        }

        string GoalSummary()
        {
            if (Level == null || Level.goals == null) return "";
            var parts = new List<string>();
            foreach (var g in Level.goals)
            {
                switch (g.type)
                {
                    case "color": parts.Add(Loc.F("Clear {0} {1}", g.amount, Loc.T(_s.GetColorName(g.color)))); break;
                    case "score": parts.Add(Loc.F("Score {0}", g.amount)); break;
                    case "bomb": parts.Add(Loc.F(g.amount > 1 ? "Blast {0} bombs" : "Blast {0} bomb", g.amount)); break;
                    case "lightning": parts.Add(Loc.F("Zap {0} lightning", g.amount)); break;
                    case "blocks": parts.Add(Loc.F("Clear {0} blocks", g.amount)); break;
                }
            }
            return string.Join("  •  ", parts);
        }

        bool CheckWin()
        {
            if (Mode != GameMode.Level || !AllGoalsDone()) return false;

            // Hediye hamleler yıldızı şişirmesin: yıldız, bölümün kendi hamlesine göre hesaplanır
            int earned = Mathf.Max(0, MovesLeft - _bonusMoves + _movePenalty);
            int stars = 1;
            if (earned >= Level.star3MovesLeft) stars = 3;
            else if (earned >= Level.star2MovesLeft) stars = 2;

            Score += MovesLeft * _s.movesLeftBonus;
            SaveSystem.SetStars(LevelIndex, stars);
            Achievements.ReportLevels();
            if (SaveSystem.UnlockedLevel < LevelIndex + 1)
                SaveSystem.UnlockedLevel = Mathf.Min(LevelIndex + 1, LevelDatabase.Count - 1);

            State = GameState.Over;
            _busy = false;
            _view.InputEnabled = false;
            _ui.UpdateHUD(this);
            _fx.Praise(_view.BoardCenter, "LEVEL CLEAR!", new Color(1f, 0.9f, 0.35f), 1.7f);
            _fx.Confetti(_view.BoardCenter, _s.blockColors, 40, 1.3f);
            Sfx(_s.sfxWin);
            Haptics.Success();
            AttemptWin(stars);
            StartCoroutine(ShowResultDelayed(true, stars, 0.8f));
            return true;
        }

        void GameOver(bool outOfMoves)
        {
            State = GameState.Over;
            _busy = false;
            _outOfMoves = outOfMoves;
            _view.InputEnabled = false;
            bool newBest = false;
            if (Mode == GameMode.Endless && Score > SaveSystem.BestEndless)
            {
                SaveSystem.BestEndless = Score;
                newBest = true;
            }
            _fx.Shake(0.25f, 0.4f);
            _fx.Text(_view.BoardTopCenter, outOfMoves ? "OUT OF MOVES" : "TOO HIGH!", new Color(1f, 0.4f, 0.45f), 1.4f);
            Sfx(_s.sfxLose);
            Haptics.Error();
            if (Mode == GameMode.Endless) EndlessSave.Clear(); // biten oyun devam ettirilemez (revive edilirse yeniden kaydedilir)
            AttemptGameOver(outOfMoves, newBest);
            _ui.UpdateHUD(this);
            StartCoroutine(_view.PlayGrayOut());
            StartCoroutine(ShowResultDelayed(false, 0, Mathf.Max(0.9f, _s.grayOutTime + 0.3f), newBest));
        }

        IEnumerator ShowResultDelayed(bool win, int stars, float delay, bool newBest = false)
        {
            yield return new WaitForSeconds(delay);
            _ui.ShowResult(this, win, stars, newBest, !win && !_reviveUsed, _outOfMoves);
        }

        // ================================================================ Revive

        /// <summary>
        /// Oyunu kurtarır. Buraya ödüllü reklam (rewarded ad) bağlanacak:
        /// reklam başarıyla izlendiğinde Revive() çağır.
        /// </summary>
        public void Revive()
        {
            if (State != GameState.Over || _reviveUsed) return;
            AttemptRevived(); // _reviveUsed değişmeden önce: bekleyen kayıp iptal
            _reviveUsed = true;
            State = GameState.Playing;
            _ui.HideResult();
            StartCoroutine(ReviveRoutine());
        }

        IEnumerator ReviveRoutine()
        {
            _busy = true;
            _view.InputEnabled = false;
            _view.SetGrayAll(false);
            if (_outOfMoves)
            {
                MovesLeft += _s.reviveExtraMoves;
                _ui.Toast(Loc.F("+{0} MOVES", _s.reviveExtraMoves), 1.2f);
            }
            else
            {
                var removed = _model.ClearTopRows(_s.reviveClearRows);
                yield return _view.PlayRemove(removed);
                yield return Resolve();
                // Adventure: son hamlede tavana değdiyse hamle de bitmiştir. Sadece sıra temizlemek oyuncuya
                // tek bir hamle bile bırakmaz (sayaç eksiye düşer, oyun hemen yeniden biter): hamle de ver.
                if (Mode == GameMode.Level && MovesLeft <= 0)
                {
                    MovesLeft = _s.reviveExtraMoves;
                    _ui.Toast(Loc.F("+{0} MOVES", _s.reviveExtraMoves), 1.2f);
                }
            }
            _outOfMoves = false;
            _ui.UpdateHUD(this);
            if (Mode == GameMode.Endless) SaveEndless(); // revive ile kurtulan oyun yeniden kaydedilir
            _busy = false;
            _view.InputEnabled = true;
        }
    }
}