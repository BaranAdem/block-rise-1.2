using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// CLASSIC (endless) YÖNETMENİ — yeni sıraların kurallarını tur tur belirleyen saf mantık (Unity nesnesi yok).
    /// GameController her yükselmede buradan kural alır; simülatör (LevelSim) aynı dosyayı derleyip oyunu birebir oynatır.
    ///
    /// Girdiler: oyunun başında belirlenen KOLAYLIK (ease, 0 = zor, 1 = kolay; Adaptive + PlayerModel) ve sıcak başlangıç;
    /// her turda tur sayısı ve tahtanın doluluğu (danger, 0..1). Durum sayaçları endless kaydına yazılır.
    /// </summary>
    public sealed class EndlessDirector
    {
        readonly GameSettings _s;

        // Oyun başında belirlenenler
        public float Ease;
        public int HotStartTurns;
        public bool Novice;

        // Casual akış sayaçları (kayda yazılır)
        public int DryTurns;          // üst üste patlamasız tur
        public int TurnsSinceSpecial; // son bomba/şimşek patlamasından beri geçen tur
        public int RescueUsed, RescueLeft, NextRescueTurn;

        /// <summary>O anki kademe (1'den başlar). Kademe arttıkça zorluk tırmanır.</summary>
        public int Stage = 1;
        bool _stageUp;

        public EndlessDirector(GameSettings s) { _s = s; }

        /// <summary>Son çağrıdan beri kademe arttıysa true (duyuru için, bir kez).</summary>
        public bool ConsumeStageUp()
        {
            bool v = _stageUp;
            _stageUp = false;
            return v;
        }

        // ================================================================ v2: kademe + dalga + ödül penceresi + can simidi

        public enum Phase { Build, Peak, Relax }

        /// <summary>Dalganın şu anki evresi ve evrenin kaçıncı turu.</summary>
        public Phase WavePhase = Phase.Build;
        public int PhaseTurn, PhaseLength = 10, WaveIndex, Seed;
        public bool SkipUsed;            // bu rahatlamada yükselme atlandı mı
        public int LifelineUsed, NextLifelineTurn;
        public int TurnsPlayed;

        bool V2 => _s.directorV2;

        /// <summary>Kolaylığa göre kademe süresi (tur).</summary>
        float StageTurns => Mathf.Max(5f, Mathf.Lerp(_s.stageTurnsHard, _s.stageTurnsEasy, Ease));

        /// <summary>Kademenin taban zorluğu (0..1).</summary>
        public float Heat => _s.heatFloor + (1f - _s.heatFloor) * Mathf.Clamp01((Stage - 1) / (float)Mathf.Max(1, _s.stagesToPeak));

        /// <summary>
        /// Uzatma: zirve kademesinden sonra her kademe biraz daha sert (bozuk sıra, daha az boşluk/yardım/özel blok).
        /// Böylece her oyun eninde sonunda biter; beceri yalnızca nerede biteceğini belirler (20+ dakikalık maratonlar olmaz).
        /// </summary>
        public float Overtime => Mathf.Clamp((Stage - 1 - _s.stagesToPeak) * _s.overtimeStep, 0f, _s.overtimeMax);

        /// <summary>Dalga yoğunluğu: build boyunca 0 → 1, peak 1, relax 0.</summary>
        public float WaveIntensity => WavePhase == Phase.Peak ? 1f
            : WavePhase == Phase.Relax ? 0f
            : Mathf.Clamp01(PhaseTurn / (float)Mathf.Max(1, PhaseLength));

        /// <summary>Bu tur sonunda yeni sıra yükselsin mi: rahatlamanın ilk turunda tahta yüksekse bir kez atlanır (nefes).</summary>
        public bool ShouldRise(int turn, float danger)
        {
            if (!V2 || WavePhase != Phase.Relax || SkipUsed) return true;
            if (danger < _s.relaxSkipRiseDanger || Overtime >= 0.3f) return true;
            SkipUsed = true;
            return false;
        }

        int Roll(int lo, int hi, int salt)
        {
            if (hi <= lo) return lo;
            unchecked
            {
                uint h = (uint)Seed * 2654435761u ^ (uint)(WaveIndex * 40503 + salt * 977);
                h ^= h >> 13; h *= 0x5bd1e995; h ^= h >> 15;
                return lo + (int)(h % (uint)(hi - lo + 1));
            }
        }

        void EnterPhase(Phase p)
        {
            WavePhase = p;
            PhaseTurn = 0;
            if (p == Phase.Build) { WaveIndex++; PhaseLength = Roll(_s.waveBuildMin, _s.waveBuildMax, 1); }
            else if (p == Phase.Peak) PhaseLength = Roll(_s.wavePeakMin, _s.wavePeakMax, 2);
            else { PhaseLength = Roll(_s.waveRelaxMin, _s.waveRelaxMax, 3); SkipUsed = false; }
        }

        /// <summary>Dalgayı bir tur ilerletir ve kademeyi günceller (her hamlede).</summary>
        void Advance(int turn)
        {
            TurnsPlayed = turn;
            int stage = 1 + Mathf.FloorToInt(turn / StageTurns);
            if (stage > Stage) { Stage = stage; _stageUp = true; }
            PhaseTurn++;
            if (PhaseTurn < PhaseLength) return;
            EnterPhase(WavePhase == Phase.Build ? Phase.Peak : WavePhase == Phase.Peak ? Phase.Relax : Phase.Build);
        }

        /// <summary>v2 zorluğu (0..1): kademe tabanı + dalga ± tahta çok alçaksa ek baskı, kolaylıkla hafifler.</summary>
        public float Difficulty(int turn, float danger)
        {
            float d = Heat + _s.waveAmplitude * (WaveIntensity - 0.5f);
            if (WavePhase != Phase.Relax && danger < _s.lowBoardDanger) d += (_s.lowBoardDanger - danger) * 0.9f;
            d *= 1f - Ease * _s.easeDifficultyRelief;
            return Mathf.Clamp01(d);
        }

        RowRules RulesV2(int turn, float danger, bool forRise)
        {
            float e = Ease;
            float d = Difficulty(turn, danger);
            float assistTop = Mathf.Lerp(0.35f, 0.7f, e);
            float chainTop = Mathf.Lerp(0.35f, 0.85f, e);
            float late = Mathf.Lerp(1f, _s.lateSpecialFactor, Mathf.Clamp01((Heat - _s.heatFloor) / Mathf.Max(0.01f, 1f - _s.heatFloor)) * (1f - 0.6f * e));
            float specialScale = Mathf.Lerp(1f, Mathf.Max(1f, _s.easySpecialMultiplier), e) * SpecialDroughtMultiplier(e)
                               * (WavePhase == Phase.Peak ? _s.peakSpecialMultiplier : 1f) * late;
            var r = new RowRules
            {
                colorCount = turn < _s.openingTurns ? Mathf.Min(_s.openingColors, _s.endlessColors) : _s.endlessColors,
                bombChance = _s.endlessBombChance * specialScale,
                lightningChance = _s.endlessLightningChance * specialScale,
                rowBombChance = _s.endlessRowBombChance * specialScale,
                columnBombChance = _s.endlessColumnBombChance * specialScale,
                minGaps = d < 0.35f ? 2 : 1,
                maxGaps = d < 0.2f ? 3 : d < 0.85f ? 2 : 1,
                assist = Mathf.Lerp(assistTop, 0f, d),
                chainAssist = Mathf.Lerp(chainTop, 0.05f, d),
                spoil = Mathf.Clamp01((d - 0.6f) / 0.4f) * _s.pressureSpoil,
            };
            if (WavePhase == Phase.Relax)
            {
                // Rahatlama: zincir dostu, yardımlı, seyrek sıralar → ödül anı
                r.assist = Mathf.Max(r.assist, 0.45f);
                r.chainAssist = Mathf.Max(r.chainAssist, 0.7f);
                r.maxGaps = Mathf.Max(r.maxGaps, 2) + 1;
                r.spoil = 0f;
            }
            float ot = Overtime * (1f - 0.5f * e);
            if (ot > 0f)
            {
                bool relax = WavePhase == Phase.Relax;
                r.spoil = Mathf.Clamp01(r.spoil + ot * (relax ? 0.5f : 2f));
                r.assist *= 1f - Mathf.Clamp01(ot * 1.5f);
                r.chainAssist *= 1f - Mathf.Clamp01(ot);
                float sp = 1f - Mathf.Clamp01(ot);
                r.bombChance *= sp; r.lightningChance *= sp; r.rowBombChance *= sp; r.columnBombChance *= sp;
                if (!relax && ot >= 0.15f) { r.minGaps = 1; r.maxGaps = 1; }
            }
            if (forRise) ApplyFairnessV2(ref r, e, turn, danger);
            r.chainWeight = _s.chainWeight;
            r.nearWeight = _s.assistNearWeight;
            r.midWeight = _s.assistMidWeight;
            r.autoPopWeight = _s.assistAutoPopWeight;
            return r;
        }

        /// <summary>
        /// Adil ölüm: (1) can simidi — tahta yüksek ve oyuncu üst üste patlatamıyorsa sıra mutlaka fırsat taşır (herkese,
        /// bekleme süreli); (2) kıl payı kurtuluş — yalnızca yeni / zorlanan oyuncuya (eski sistem); (3) ölü tahta koruması.
        /// </summary>
        void ApplyFairnessV2(ref RowRules r, float ease, int turn, float danger)
        {
            if (RescueLeft > 0) { RescueLeft--; RescueRow(ref r); return; }
            int max = Mathf.RoundToInt(Mathf.Max(0, _s.rescueMaxNovice) * RescueShare(ease));
            if (max > 0 && danger >= _s.rescueDanger && RescueUsed < max && turn >= NextRescueTurn)
            {
                RescueUsed++;
                RescueLeft = Mathf.Max(0, _s.rescueRows - 1);
                NextRescueTurn = turn + Mathf.Max(1, _s.rescueCooldownTurns);
                RescueRow(ref r);
                return;
            }
            if (danger >= _s.lifelineDanger && DryTurns >= _s.lifelineDryTurns && turn >= NextLifelineTurn)
            {
                LifelineUsed++;
                NextLifelineTurn = turn + Mathf.Max(1, _s.lifelineCooldown);
                r.assist = 1f;
                r.chainAssist = Mathf.Max(r.chainAssist, 0.8f);
                r.spoil = 0f;
                r.minGaps += 1;
                r.maxGaps += 1;
                return;
            }
            int dry = DryGuardTurns(ease);
            if (dry > 0 && DryTurns >= dry)
            {
                r.assist = Mathf.Max(r.assist, _s.dryGuardAssist);
                r.chainAssist = Mathf.Max(r.chainAssist, _s.chainAssistEasy * 0.5f);
                r.spoil = 0f;
            }
        }

        public void Begin(float ease, int hotStartTurns, bool novice, int seed = 0)
        {
            Stage = 1;
            _stageUp = false;
            Seed = seed != 0 ? seed : System.Environment.TickCount;
            WaveIndex = 0;
            EnterPhase(Phase.Build);
            LifelineUsed = 0;
            NextLifelineTurn = 0;
            TurnsPlayed = 0;
            Ease = Mathf.Clamp01(ease);
            HotStartTurns = hotStartTurns;
            Novice = novice;
            DryTurns = 0;
            TurnsSinceSpecial = 0;
            RescueUsed = 0;
            RescueLeft = 0;
            NextRescueTurn = 0;
        }

        /// <summary>Hamlenin çözülmesinden sonra: patlayan blok sayısı ve zincir uzunluğu.</summary>
        public void OnTurnResolved(int popped, int chain)
        {
            DryTurns = popped > 0 ? 0 : DryTurns + 1;
            // Ödül penceresi: büyük temizlik / uzun zincir gerilim yükselirken gelirse hemen rahatlamaya geç
            if (V2 && (popped >= _s.bigClearBlocks || chain >= 3)
                && (WavePhase == Phase.Peak || (WavePhase == Phase.Build && WaveIntensity >= 0.5f)))
                EnterPhase(Phase.Relax);
        }

        /// <summary>Her hamlede (tur sayısı arttıktan sonra) çağrılır.</summary>
        public void OnMove(int turn)
        {
            TurnsSinceSpecial++;
            if (V2) Advance(turn);
        }

        /// <summary>Bir patlama dalgasında bomba/şimşek patladı.</summary>
        public void OnSpecialPopped() => TurnsSinceSpecial = 0;

        /// <summary>
        /// Yeni sıra kuralları. forRise: tur sonundaki yükselmede kullanılacak (casual akış sayaçları yalnızca o zaman işler).
        /// </summary>
        public RowRules Rules(int turn, float danger, bool forRise)
        {
            if (V2) return RulesV2(turn, danger, forRise);
            // CLASSIC: oyuncuya özel zorluk eğrisi. Kolaylık (ease)
            //   • yardımın son değerini (usta oyuncu az, zorlanan oyuncu çok yardım),
            //   • yardımın ne kadar sürede o değere ineceğini (rampa),
            //   • özel blok (bomba, şimşek) sıklığını belirler.
            // Sıcak başlangıç: ilk HotStartTurns tur rampa işlemez (cömert açılış).
            float t = _s.endlessRampTurns > 0 ? Mathf.Clamp01((float)turn / _s.endlessRampTurns) : 1f;
            float e = Ease;
            float ramp = Mathf.Lerp(_s.rampTurnsHard, _s.rampTurnsEasy, e);
            float ft = ramp > 0f ? Mathf.Clamp01(Mathf.Max(0, turn - HotStartTurns) / ramp) : 1f;
            float assist = Mathf.Lerp(_s.assistStart, Mathf.Lerp(_s.assistEndHard, _s.assistEndEasy, e), ft);
            // Özel bloklar: ayardaki ihtimaller × kolaylık çarpanı. Çarpan olduğu için ihtimali 0 olan tür hiç çıkmaz.
            float specialScale = Mathf.Lerp(1f, Mathf.Max(1f, _s.easySpecialMultiplier), e) * SpecialDroughtMultiplier(e);
            var r = new RowRules
            {
                colorCount = _s.endlessColors,
                bombChance = _s.endlessBombChance * specialScale,
                lightningChance = _s.endlessLightningChance * specialScale,
                rowBombChance = _s.endlessRowBombChance * specialScale,
                columnBombChance = _s.endlessColumnBombChance * specialScale,
                minGaps = Mathf.RoundToInt(Mathf.Lerp(_s.endlessGapsStartMin, _s.endlessGapsEndMin, t)),
                maxGaps = Mathf.RoundToInt(Mathf.Lerp(_s.endlessGapsStartMax, _s.endlessGapsEndMax, t)),
                assist = Mathf.Clamp01(assist),
                chainAssist = Mathf.Lerp(_s.chainAssistHard, _s.chainAssistEasy, e),
            };
            // Casual akış: ölü tahta koruması ve (yalnızca yeni / zorlanan oyuncuya) kıl payı kurtuluş
            if (forRise) ApplyCasualFlow(ref r, e, turn, danger);
            r.chainWeight = _s.chainWeight;
            r.nearWeight = _s.assistNearWeight;
            r.midWeight = _s.assistMidWeight;
            r.autoPopWeight = _s.assistAutoPopWeight;
            return r;
        }

        // ================================================================ Casual akış

        /// <summary>Özel blok kuraklığı çarpanı: bekleme süresinden sonra her tur artar, kolaylıkla ölçeklenir (ustada 1).</summary>
        float SpecialDroughtMultiplier(float ease)
        {
            int over = TurnsSinceSpecial - _s.specialGraceTurns;
            if (over <= 0) return 1f;
            float m = 1f + over * _s.specialGrowthPerTurn * ease;
            return Mathf.Min(Mathf.Max(1f, _s.specialMaxMultiplier), m);
        }

        /// <summary>Kurtuluş hakkı oranı (0..1): yeni oyuncu 1; değilse kolaylığa göre. Usta oyuncu 0 alır.</summary>
        float RescueShare(float ease)
        {
            if (Novice) return 1f;
            if (_s.rescueEaseFull <= _s.rescueEaseFrom) return ease >= _s.rescueEaseFull ? 1f : 0f;
            return Mathf.InverseLerp(_s.rescueEaseFrom, _s.rescueEaseFull, ease);
        }

        int DryGuardTurns(float ease)
        {
            if (_s.dryGuardTurnsHard <= 0 && ease < 0.5f) return 0; // ustada kapalı
            int hard = _s.dryGuardTurnsHard > 0 ? _s.dryGuardTurnsHard : _s.dryGuardTurnsEasy * 2;
            return Mathf.Max(1, Mathf.RoundToInt(Mathf.Lerp(hard, _s.dryGuardTurnsEasy, ease)));
        }

        void ApplyCasualFlow(ref RowRules r, float ease, int turn, float danger)
        {
            // 0) Alçak tahta baskısı (bu durumda kurtuluş ve ölü tahta koruması gerekmez)
            if (ApplyPressure(ref r, ease, turn, danger)) return;

            // 1) Süren kurtuluş
            if (RescueLeft > 0)
            {
                RescueLeft--;
                RescueRow(ref r);
                return;
            }

            // 2) Yeni kurtuluş: tahta tepeye yakın, hak var, bekleme süresi doldu
            int max = Mathf.RoundToInt(Mathf.Max(0, _s.rescueMaxNovice) * RescueShare(ease));
            if (max > 0 && danger >= _s.rescueDanger && RescueUsed < max && turn >= NextRescueTurn)
            {
                RescueUsed++;
                RescueLeft = Mathf.Max(0, _s.rescueRows - 1);
                NextRescueTurn = turn + Mathf.Max(1, _s.rescueCooldownTurns);
                RescueRow(ref r);
                return;
            }

            // 3) Ölü tahta koruması
            int dry = DryGuardTurns(ease);
            if (dry > 0 && DryTurns >= dry)
            {
                r.assist = Mathf.Max(r.assist, _s.dryGuardAssist);
                r.chainAssist = Mathf.Max(r.chainAssist, _s.chainAssistEasy * 0.5f);
            }
        }

        bool ApplyPressure(ref RowRules r, float ease, int turn, float danger)
        {
            if (!_s.pressureEnabled || turn < _s.pressureStartTurn || turn < HotStartTurns) return false;
            float target = _s.pressureTarget;
            float floor = Mathf.Min(_s.pressureFloor, target - 0.01f);
            if (danger >= target) return false;

            float k = Mathf.Clamp01((target - danger) / Mathf.Max(0.01f, target - floor)); // 0 = hedefte, 1 = çok alçak
            k *= Mathf.Clamp01((turn - _s.pressureStartTurn) / 10f);                       // açılıştan sonra yavaşça gelir
            k *= 1f - Mathf.Clamp01(ease) * _s.pressureEaseRelief;                          // zorlanan oyuncuda hafif
            if (k <= 0.01f) return false;

            r.assist *= 1f - k;
            r.chainAssist *= 1f - k;
            r.spoil = Mathf.Max(r.spoil, _s.pressureSpoil * k);
            int cut = Mathf.RoundToInt(_s.pressureGapCut * k);
            r.minGaps = Mathf.Max(1, r.minGaps - cut);
            r.maxGaps = Mathf.Max(r.minGaps, r.maxGaps - cut);
            return true;
        }

        /// <summary>Kurtuluş sırası: en yüksek yardım, güçlü zincir kurulumu ve fazladan boşluk.</summary>
        void RescueRow(ref RowRules r)
        {
            r.assist = 1f;
            r.chainAssist = 1f;
            int extra = Mathf.Max(0, _s.rescueExtraGaps);
            r.minGaps += extra;
            r.maxGaps += extra;
        }

        // ================================================================ Kayıt

        public void SaveTo(EndlessSaveData d)
        {
            d.dryTurns = DryTurns;
            d.turnsSinceSpecial = TurnsSinceSpecial;
            d.rescueUsed = RescueUsed;
            d.rescueLeft = RescueLeft;
            d.nextRescueTurn = NextRescueTurn;
            d.hotStartTurns = HotStartTurns;
            d.ease = Ease;
            d.stage = Stage;
            d.wavePhase = (int)WavePhase;
            d.phaseTurn = PhaseTurn;
            d.phaseLength = PhaseLength;
            d.waveIndex = WaveIndex;
            d.waveSeed = Seed;
            d.skipUsed = SkipUsed;
            d.lifelineUsed = LifelineUsed;
            d.nextLifelineTurn = NextLifelineTurn;
        }

        public void LoadFrom(EndlessSaveData d, bool novice)
        {
            Ease = Mathf.Clamp01(d.ease);
            HotStartTurns = d.hotStartTurns;
            Novice = novice;
            DryTurns = d.dryTurns;
            TurnsSinceSpecial = d.turnsSinceSpecial;
            RescueUsed = d.rescueUsed;
            RescueLeft = d.rescueLeft;
            NextRescueTurn = d.nextRescueTurn;
            Stage = Mathf.Max(1, d.stage);
            _stageUp = false;
            WavePhase = (Phase)Mathf.Clamp(d.wavePhase, 0, 2);
            PhaseTurn = d.phaseTurn;
            PhaseLength = Mathf.Max(1, d.phaseLength);
            WaveIndex = d.waveIndex;
            Seed = d.waveSeed != 0 ? d.waveSeed : System.Environment.TickCount;
            SkipUsed = d.skipUsed;
            LifelineUsed = d.lifelineUsed;
            NextLifelineTurn = d.nextLifelineTurn;
            TurnsPlayed = d.turn;
        }
    }
}
