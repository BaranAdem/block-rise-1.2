using System;
using System.Collections.Generic;
using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Adventure bölüm haritası: aşağıdan yukarı tırmanan piramitler.
    ///
    ///  • Her 10 bölüm bir DÜNYA. Dünya, bloklardan dizilmiş bir piramittir:
    ///      satır 0 → 4 bölüm, satır 1 → 3, satır 2 → 2, tepe → 1 (boss).  4+3+2+1 = 10
    ///  • Yol yılan gibi kıvrılır (sol→sağ, sağ→sol, sol→sağ, tepe) ve noktalı çizgiyle bağlanır.
    ///  • Her dünyanın altında bir "kapı" şeridi: dünya adı, rengi ve kazanılan yıldızlar.
    ///  • Yıldızlar blok üstünde değil, bloğun altındaki küçük cam rozette.
    ///  • Sıradaki bölüm turuncu, hafifçe süzülür ve etrafında ışık halkası atar.
    ///  • Kilitli bölümler cam görünümlü ve soluk; boss bölümleri daha büyük ve "BOSS" etiketli.
    ///
    /// İçerik (content) üstten çapalı olmalı; Build yüksekliği ayarlar ve odaklanılacak
    /// bölümün alttan yüksekliğini döndürür (ScrollRect'i oraya kaydırmak için).
    /// </summary>
    public static class LevelMap
    {
        public const int PerWorld = 10;
        static readonly int[] RowCounts = { 4, 3, 2 };   // tepe (boss) ayrıca

        // Ölçüler (canvas birimi, referans 1080 genişlik)
        const float Node = 176f;          // normal bölüm bloğu
        const float BossNode = 226f;      // boss bloğu
        const float SpacingX = 248f;      // aynı satırda iki blok merkezi arası
        const float RowStep = 262f;       // satırlar arası dikey mesafe (yıldız rozeti sığsın)
        const float ApexExtra = 40f;      // tepe biraz daha yukarıda (boss büyük)
        const float GateH = 150f;         // dünya kapısı şeridinin kapladığı alan
        const float GateToRow = 70f;      // kapı ile ilk satır arası
        const float WorldGap = 60f;       // boss rozeti ile sonraki kapı arası
        const float BottomPad = 40f, TopPad = 260f;
        const float DotStep = 38f, DotSize = 13f;

        static float WorldHeight =>
            GateH + GateToRow + Node * 0.5f + RowStep * 2f + RowStep + ApexExtra + BossNode * 0.5f + 70f + WorldGap;

        struct NodeInfo
        {
            public int index;
            public Vector2 pos;
            public bool boss;
        }

        /// <summary>
        /// Haritayı content içine kurar. content: anchorMin (0,1), anchorMax (1,1), pivot (0.5,1).
        /// Dönüş: odaklanılacak bölümün content altından yüksekliği.
        /// </summary>
        public static float Build(RectTransform content, int levelCount, int unlocked, Action<int> onPlay)
        {
            int worlds = Mathf.CeilToInt(levelCount / (float)PerWorld);
            float height = BottomPad + worlds * WorldHeight + TopPad;
            content.sizeDelta = new Vector2(content.sizeDelta.x, height);

            // Katmanlar: yol en altta, sonra kapılar, en üstte bloklar
            var pathLayer = UIFactory.Rect("Path", content);
            UIFactory.Stretch(pathLayer);
            var gateLayer = UIFactory.Rect("Gates", content);
            UIFactory.Stretch(gateLayer);
            var nodeLayer = UIFactory.Rect("Nodes", content);
            UIFactory.Stretch(nodeLayer);

            var nodes = new List<NodeInfo>(levelCount);
            for (int w = 0; w < worlds; w++)
            {
                float baseY = BottomPad + w * WorldHeight;
                BuildGate(gateLayer, w, baseY + GateH * 0.5f, levelCount, unlocked);

                float y = baseY + GateH + GateToRow + Node * 0.5f;
                int first = w * PerWorld;
                int k = 0;
                for (int r = 0; r < RowCounts.Length; r++, y += RowStep)
                {
                    int c = RowCounts[r];
                    bool leftToRight = r % 2 == 0;
                    for (int j = 0; j < c; j++, k++)
                    {
                        int col = leftToRight ? j : c - 1 - j;
                        float x = (col - (c - 1) * 0.5f) * SpacingX;
                        if (first + k < levelCount)
                            nodes.Add(new NodeInfo { index = first + k, pos = new Vector2(x, y), boss = false });
                    }
                }
                float apexY = y + ApexExtra;
                if (first + k < levelCount)
                    nodes.Add(new NodeInfo { index = first + k, pos = new Vector2(0f, apexY), boss = true });
            }

            // Yol
            for (int i = 0; i + 1 < nodes.Count; i++)
            {
                bool lit = nodes[i + 1].index <= unlocked;
                BuildPath(pathLayer, nodes[i], nodes[i + 1], lit);
            }

            // Bloklar
            float focusY = nodes.Count > 0 ? nodes[0].pos.y : 0f;
            foreach (var n in nodes)
            {
                bool current = BuildNode(nodeLayer, n, unlocked, onPlay);
                if (current || (n.index == Mathf.Min(unlocked, levelCount - 1))) focusY = n.pos.y;
            }

            // Tepede kapanış yazısı
            if (nodes.Count > 0)
            {
                var soon = UIFactory.Text("ComingSoon", nodeLayer, "MORE WORLDS\nCOMING SOON", 38, new Color(1f, 1f, 1f, 0.35f));
                soon.lineSpacing = 1.1f;
                At(soon.rectTransform, new Vector2(0f, nodes[nodes.Count - 1].pos.y + BossNode * 0.5f + 150f), new Vector2(700, 120));
            }
            return focusY;
        }

        // ================================================================ Parçalar

        static void BuildGate(RectTransform parent, int world, float y, int levelCount, int unlocked)
        {
            int first = world * PerWorld;
            int last = Mathf.Min(levelCount, first + PerWorld);
            bool open = first <= unlocked;
            int stars = 0;
            for (int i = first; i < last; i++) stars += SaveSystem.GetStars(i);

            var gate = UIFactory.Panel("World" + (world + 1), parent, new Color(0f, 0f, 0f, open ? 0.30f : 0.22f));
            At(gate.rectTransform, new Vector2(0f, y), new Vector2(660f, 112f));

            // Dünyanın rengi: blok ikonu (kilitliyse soluk)
            var icon = UIFactory.BlockIcon("Icon", gate.transform, world % Mathf.Max(1, GameSettings.Instance.blockColors.Length), 70f);
            UIFactory.Place(icon.rectTransform, new Vector2(0f, 0.5f), new Vector2(26f, 0f), new Vector2(70f, 70f));
            if (!open) icon.color = UIFactory.Locked;

            var title = UIFactory.Text("Title", gate.transform, Loc.F("WORLD {0}", world + 1), 48,
                open ? Color.white : new Color(1f, 1f, 1f, 0.45f), TextAnchor.MiddleLeft);
            UIFactory.Place(title.rectTransform, new Vector2(0f, 0.5f), new Vector2(120f, 2f), new Vector2(320f, 80f));
            UIFactory.AddShadow(title, 4f, 0.4f);

            // Dünyanın tüm bölümleri geçildiyse başlığın yanında onay işareti
            bool done = open;
            for (int i = first; i < last && done; i++) if (SaveSystem.GetStars(i) == 0) done = false;
            if (done)
            {
                var ck = UIFactory.Image("Done", gate.transform, "icon_check", UIFactory.Green);
                UIFactory.Place(ck.rectTransform, new Vector2(0f, 0.5f), new Vector2(120f + title.preferredWidth + 14f, 2f), new Vector2(46f, 46f));
            }

            if (open)
            {
                var cnt = UIFactory.Text("Stars", gate.transform, stars + "/" + ((last - first) * 3), 40, Color.white, TextAnchor.MiddleRight);
                UIFactory.Place(cnt.rectTransform, new Vector2(1f, 0.5f), new Vector2(-30f, 0f), new Vector2(160f, 70f));
                var st = UIFactory.Image("StarIcon", gate.transform, "star", UIFactory.Gold);
                // Yıldız ikonu sayının hemen soluna otursun
                UIFactory.Place(st.rectTransform, new Vector2(1f, 0.5f), new Vector2(-30f - cnt.preferredWidth - 10f, 2f), new Vector2(50f, 50f));
            }
            else
            {
                var lk = UIFactory.Image("Lock", gate.transform, "icon_lock", new Color(1f, 1f, 1f, 0.5f));
                UIFactory.Place(lk.rectTransform, new Vector2(1f, 0.5f), new Vector2(-32f, 0f), new Vector2(56f, 56f));
            }
        }

        static void BuildPath(RectTransform parent, NodeInfo a, NodeInfo b, bool lit)
        {
            Vector2 d = b.pos - a.pos;
            float len = d.magnitude;
            if (len < 1f) return;
            Vector2 dir = d / len;
            float ra = (a.boss ? BossNode : Node) * 0.5f + 16f;
            float rb = (b.boss ? BossNode : Node) * 0.5f + 16f;
            float usable = len - ra - rb;
            if (usable <= 0f) return;
            int n = Mathf.Max(1, Mathf.FloorToInt(usable / DotStep));
            float step = usable / n;
            var col = lit ? new Color(1f, 0.86f, 0.45f, 0.9f) : new Color(1f, 1f, 1f, 0.16f);
            for (int i = 0; i <= n; i++)
            {
                var p = a.pos + dir * (ra + step * i);
                if (UnderBadge(p, a) || UnderBadge(p, b)) continue; // yıldız rozetinin üstünden geçmesin
                var dot = UIFactory.Image("Dot", parent, "circle", col);
                At(dot.rectTransform, p, Vector2.one * DotSize);
            }
        }

        /// <summary>Nokta, bloğun altındaki yıldız rozetinin alanına düşüyor mu (biraz payla).</summary>
        static bool UnderBadge(Vector2 p, NodeInfo n)
        {
            float half = (n.boss ? BossNode : Node) * 0.5f;
            return Mathf.Abs(p.x - n.pos.x) < 92f && p.y < n.pos.y - half + 8f && p.y > n.pos.y - half - 66f;
        }

        /// <summary>Bir bölüm bloğu kurar. Dönüş: sıradaki (oynanacak) bölüm mü.</summary>
        static bool BuildNode(RectTransform parent, NodeInfo n, int unlocked, Action<int> onPlay)
        {
            int i = n.index;
            bool open = i <= unlocked;
            int stars = SaveSystem.GetStars(i);
            bool current = open && stars == 0 && i == unlocked;
            int world = i / PerWorld;
            float size = n.boss ? BossNode : Node;

            // Tüm parçaları taşıyan tutucu (süzülme animasyonu hepsini birlikte oynatsın)
            var holder = UIFactory.Rect("Level" + (i + 1), parent);
            At(holder, n.pos, Vector2.one * size);

            Color color;
            if (!open) color = UIFactory.Locked;
            else if (current) color = UIFactory.Orange;
            else color = GameSettings.Instance.GetColor(world % Mathf.Max(1, GameSettings.Instance.blockColors.Length));

            // Sıradaki bölüm: arkada nabız gibi atan ışık halkası
            if (current)
            {
                var glow = UIFactory.Image("Glow", holder, null, new Color(1f, 0.75f, 0.35f, 0.5f), true);
                glow.sprite = SpriteLibrary.UIGlass(false);
                glow.pixelsPerUnitMultiplier = 1f;
                UIFactory.Stretch(glow.rectTransform, -10, -10, -10, -10);
                glow.gameObject.AddComponent<LevelMapPulse>();
            }

            int idx = i;
            var btn = UIFactory.Button("Block", holder, (i + 1).ToString(), color, Vector2.one * size, n.boss ? 86 : 70, () =>
            {
                if (idx <= SaveSystem.UnlockedLevel && onPlay != null) onPlay(idx);
            });
            UIFactory.Stretch((RectTransform)btn.transform);
            btn.interactable = open;
            if (!open)
            {
                var press = btn.GetComponent<PressScale>();
                if (press != null) press.enabled = false; // kilitli blok basınca küçülmesin
                UIFactory.ApplyGlassSkin(btn.image, size);
                var label = btn.GetComponentInChildren<UnityEngine.UI.Text>();
                if (label != null)
                {
                    label.color = new Color(1f, 1f, 1f, 0.38f);
                    var sh = label.GetComponent<UnityEngine.UI.Shadow>();
                    if (sh != null) sh.enabled = false;
                }
            }

            // Boss etiketi: bloğun üst kenarına oturan küçük şerit
            if (n.boss)
            {
                var tag = UIFactory.Image("BossTag", holder, null, open ? UIFactory.Red : new Color(0.45f, 0.40f, 0.55f), true);
                tag.sprite = SpriteLibrary.UIGlass(false);
                tag.pixelsPerUnitMultiplier = 1.6f;
                UIFactory.Place(tag.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, 26f), new Vector2(128f, 46f));
                var tt = UIFactory.Text("Text", tag.transform, "BOSS", 28, open ? Color.white : new Color(1f, 1f, 1f, 0.6f));
                UIFactory.Stretch(tt.rectTransform);
            }

            // Yıldız rozeti: bloğun altında, küçük cam hap içinde, ortadaki yıldız hafif yukarıda
            if (open && !current)
            {
                var badge = UIFactory.Panel("Stars", holder, new Color(0f, 0f, 0f, 0.38f));
                UIFactory.Place(badge.rectTransform, new Vector2(0.5f, 0f), new Vector2(0f, -54f), new Vector2(144f, 50f));
                for (int s = 0; s < 3; s++)
                {
                    bool got = s < stars;
                    var st = UIFactory.Image("Star" + s, badge.transform, "star", got ? UIFactory.Gold : new Color(1f, 1f, 1f, 0.16f));
                    UIFactory.Place(st.rectTransform, new Vector2(0.5f, 0.5f), new Vector2((s - 1) * 42f, s == 1 ? 4f : 0f),
                        Vector2.one * (s == 1 ? 42f : 36f));
                }
            }

            if (current)
            {
                var bob = holder.gameObject.AddComponent<UIBob>(); // Awake anlık konumu taban alır
                bob.amplitude = 9f;
                bob.speed = 2.4f;
            }
            return current;
        }

        /// <summary>İçerikte alt-orta çapaya göre, merkezden konumlandırır.</summary>
        static void At(RectTransform rt, Vector2 center, Vector2 size)
        {
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = size;
            rt.anchoredPosition = center;
        }
    }

    /// <summary>Sıradaki bölümün arkasında dışa doğru genişleyip sönen ışık halkası.</summary>
    public class LevelMapPulse : MonoBehaviour
    {
        public float period = 1.4f;
        UnityEngine.UI.Image _img;
        Color _base;

        void Awake()
        {
            _img = GetComponent<UnityEngine.UI.Image>();
            _base = _img != null ? _img.color : Color.white;
            UICanvasIsolation.Isolate(gameObject); // 100 bölümlük harita her karede yeniden batch'lenmesin
        }

        void Update()
        {
            if (_img == null) return;
            float t = Mathf.Repeat(Time.unscaledTime / period, 1f);
            float s = 1f + 0.22f * t;
            transform.localScale = new Vector3(s, s, 1f);
            var c = _base;
            c.a = _base.a * (1f - t) * (1f - t);
            _img.color = c;
        }
    }
}
