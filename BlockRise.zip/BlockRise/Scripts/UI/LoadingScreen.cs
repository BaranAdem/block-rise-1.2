using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Açılış yükleme ekranı. Oyunun canlı arka planı (gradyan + yıldız tozu) üstünde logo, oyunun blok renklerinde
    /// ilerledikçe yanan beş blok ve ince bir ilerleme çubuğu gösterir. GameRoot ağır hazırlıkları (arayüz, blok
    /// karoları, sesler, shader'lar, bölüm haritası) bu ekran açıkken yapar; böylece menüye girildiğinde hiçbir şey
    /// ilk kez hazırlanmaz ve oyun takılmaz. Bitince yumuşakça kaybolur. Kendi Canvas'ı vardır, en üstte çizilir ve
    /// altındaki arayüze dokunulmasını engeller.
    /// </summary>
    public class LoadingScreen : MonoBehaviour
    {
        const float RefW = 1080f, RefH = 1920f;
        const int Blocks = 5;

        CanvasGroup _group;
        RectTransform _fill;
        CanvasGroup[] _blocks; // blok + üstündeki parlama birlikte solsun
        float _shown, _target;

        public static LoadingScreen Create()
        {
            var go = new GameObject("LoadingScreen", typeof(RectTransform));
            go.layer = 5;
            var canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 1000;
            var scaler = go.AddComponent<UnityEngine.UI.CanvasScaler>();
            scaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(RefW, RefH);
            scaler.screenMatchMode = UnityEngine.UI.CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = (float)Screen.width / Mathf.Max(1, Screen.height) > 0.62f ? 1f : 0f;
            go.AddComponent<UnityEngine.UI.GraphicRaycaster>();
            var ls = go.AddComponent<LoadingScreen>();
            ls.Build((RectTransform)go.transform);
            return ls;
        }

        void Build(RectTransform root)
        {
            _group = gameObject.AddComponent<CanvasGroup>();

            // Tam ekran, görünmez ama dokunuşları tutan katman (yükleme sürerken altındaki menüye basılamasın)
            var blocker = UIFactory.Image("Blocker", root, null, new Color(0f, 0f, 0f, 0.18f), false, true);
            UIFactory.Stretch(blocker.rectTransform);

            var title = UIFactory.Text("Title", root, "BLOCK RISE", 120, Color.white);
            UIFactory.Place(title.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 170f), new Vector2(1000f, 170f));
            UIFactory.AddShadow(title, 8f, 0.45f);

            // Blok renklerinde beş blok: ilerleme her %20'de bir tanesini yakar
            var colors = GameSettings.Instance.blockColors;
            int nColors = colors != null && colors.Length > 0 ? colors.Length : 1;
            _blocks = new CanvasGroup[Blocks];
            const float size = 96f, gap = 18f;
            float x0 = -(Blocks - 1) * (size + gap) * 0.5f;
            for (int i = 0; i < Blocks; i++)
            {
                var b = UIFactory.BlockIcon("Block" + i, root, i % nColors, size);
                var rt = b.rectTransform;
                rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
                rt.anchoredPosition = new Vector2(x0 + i * (size + gap), -10f);
                _blocks[i] = b.gameObject.AddComponent<CanvasGroup>();
                SetBlock(i, 0f);
            }

            // İnce ilerleme çubuğu
            var track = UIFactory.Image("Track", root, null, new Color(1f, 1f, 1f, 0.14f));
            UIFactory.Place(track.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, -130f), new Vector2(560f, 10f));
            var fill = UIFactory.Image("Fill", track.transform, null, new Color(1f, 1f, 1f, 0.85f));
            _fill = fill.rectTransform;
            _fill.anchorMin = new Vector2(0f, 0f);
            _fill.anchorMax = new Vector2(0f, 1f);
            _fill.pivot = new Vector2(0f, 0.5f);
            _fill.offsetMin = _fill.offsetMax = Vector2.zero;
        }

        /// <summary>0..1. Görüntü hedefe yumuşakça yaklaşır.</summary>
        public void SetProgress(float p) => _target = Mathf.Max(_target, Mathf.Clamp01(p));

        void SetBlock(int i, float k)
        {
            var g = _blocks[i];
            g.alpha = Mathf.Lerp(0.18f, 1f, k);
            float s = Mathf.Lerp(0.82f, 1f, k);
            g.transform.localScale = new Vector3(s, s, 1f);
        }

        void Update()
        {
            _shown = Mathf.MoveTowards(Mathf.Lerp(_shown, _target, 1f - Mathf.Exp(-10f * Time.unscaledDeltaTime)), _target, 0.002f);
            if (_fill != null)
            {
                _fill.anchorMax = new Vector2(_shown, 1f);
                _fill.offsetMax = Vector2.zero;
            }
            for (int i = 0; i < Blocks; i++)
                SetBlock(i, Mathf.Clamp01(_shown * Blocks - i));
        }

        /// <summary>Çubuğu doldurur, kısa bir süre bekler ve ekranı söndürerek yok eder.</summary>
        public System.Collections.IEnumerator FinishAndHide(float fade = 0.35f)
        {
            _target = 1f;
            float wait = 0f;
            while (_shown < 0.995f && wait < 0.6f) { wait += Time.unscaledDeltaTime; yield return null; }
            _group.blocksRaycasts = false;
            for (float t = 0f; t < fade; t += Time.unscaledDeltaTime)
            {
                _group.alpha = 1f - t / fade;
                yield return null;
            }
            Destroy(gameObject);
        }
    }
}
