using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BlockRise
{
    /// <summary>
    /// Adventure ekranı (Block Blast tarzı): her 20 bölüm bir piksel resmi açar.
    ///
    ///  • Üstte "ADVENTURE 7" ve önceki/sonraki resim okları (gelecekteki resimler kilitli).
    ///  • Ortada resim: açılmış bloklar renkli (oyundaki blok görünümü), açılmamışlar soluk siluet.
    ///    Bloklar ALTTAN YUKARI açılır; bölüm kazanıp dönünce yeni bloklar notalar eşliğinde tek tek belirir.
    ///  • Resim tamamlanınca adı ortaya çıkar, kutlama ve "NEXT ADVENTURE".
    ///  • Altta resmin 20 bölümü (yıldızlar, kilit, sıradaki bölüm vurgulu): tamamlanan bölümler tekrar oynanabilir.
    ///  • En altta büyük oynama düğmesi: sıradaki bölüm (zor / boss bölümlerinde rozet).
    /// </summary>
    public class AdventureView : MonoBehaviour
    {
        const float NavY = -205f, NavH = 120f;
        const float FrameTop = 330f, FrameBottom = 520f;
        const float ChipW = 94f, ChipH = 104f, ChipGap = 8f;
        const float PlayW = 680f, PlayH = 170f, PlayBottom = 64f;

        System.Action<int> _onPlay;
        RectTransform _root;

        Text _title, _subtitle;
        Button _prev, _next;
        RectTransform _frame, _grid;
        RectTransform _strip;
        readonly List<LevelChip> _chips = new List<LevelChip>();
        Button _play;
        RectTransform _badge;
        Text _badgeText;
        RectTransform _congrats;
        Text _congratsTitle, _congratsBody;
        Button _nextAdventure;

        int _shown = -1;          // gösterilen resim
        int _revealedShown;       // ekranda renkli olan blok sayısı
        Vector2 _lastFrameSize;
        Coroutine _anim;
        readonly List<Image> _cells = new List<Image>();   // RevealOrder sırasıyla

        class LevelChip
        {
            public Button button;
            public Image bg;
            public Text number;
            public Image[] stars;
            public Image lockIcon;
        }

        // ================================================================ Kurulum

        public void Build(RectTransform screen, System.Action<int> onPlay)
        {
            _root = screen;
            _onPlay = onPlay;

            // Gezinme: ◀  ADVENTURE 7 / ilerleme  ▶
            var nav = UIFactory.Rect("Nav", screen);
            UIFactory.TopStrip(nav, NavY + NavH * 0.5f, NavH, 30);
            _prev = Arrow(nav, "Prev", false, () => ShowPicture(_shown - 1, false));
            _next = Arrow(nav, "Next", true, () => ShowPicture(_shown + 1, false));
            _title = UIFactory.Text("Title", nav, "ADVENTURE 1", 56, Color.white);
            UIFactory.Place(_title.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 20f), new Vector2(700f, 70f));
            UIFactory.FitText(_title, 36);
            UIFactory.AddShadow(_title, 5f, 0.45f);
            _subtitle = UIFactory.Text("Sub", nav, "", 36, UIFactory.TextSecondary);
            UIFactory.Place(_subtitle.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, -34f), new Vector2(700f, 48f));
            UIFactory.FitText(_subtitle, 24);

            // Resim çerçevesi: üst gezinme ile alttaki bölüm şeridi arasındaki tüm alan
            var frameBg = UIFactory.Panel("Frame", screen, new Color(0f, 0f, 0f, 0.20f));
            _frame = frameBg.rectTransform;
            UIFactory.Stretch(_frame, 30, 30, FrameTop, FrameBottom);
            _grid = UIFactory.Rect("Picture", _frame);
            UIFactory.Place(_grid, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);

            // Bölüm şeridi: 2 sıra x 10
            _strip = UIFactory.Rect("Levels", screen);
            float stripW = 10 * ChipW + 9 * ChipGap, stripH = 2 * ChipH + ChipGap;
            UIFactory.Place(_strip, new Vector2(0.5f, 0f), new Vector2(0f, PlayBottom + PlayH + 40f), new Vector2(stripW, stripH));
            for (int i = 0; i < AdventureDatabase.LevelsPerPicture && i < 20; i++) _chips.Add(BuildChip(i));

            // Oyna düğmesi + zorluk rozeti
            _play = UIFactory.Button("Play", screen, "LEVEL 1", UIFactory.Orange, new Vector2(PlayW, PlayH), 64, PlayCurrent);
            UIFactory.Place((RectTransform)_play.transform, new Vector2(0.5f, 0f), new Vector2(0f, PlayBottom), new Vector2(PlayW, PlayH));
            var badge = UIFactory.Pill("Badge", _play.transform, UIFactory.Red, 54f);
            _badge = badge.rectTransform;
            UIFactory.Place(_badge, new Vector2(0.5f, 1f), new Vector2(0f, 30f), new Vector2(190f, 54f));
            _badge.pivot = new Vector2(0.5f, 0.5f);
            _badgeText = UIFactory.Text("Text", _badge, "BOSS", 34, Color.white);
            UIFactory.Stretch(_badgeText.rectTransform);
            UIFactory.FitText(_badgeText, 22);

            // Tamamlanan resim: tebrik + sonraki resim
            _congrats = UIFactory.Rect("Congrats", screen);
            UIFactory.Place(_congrats, new Vector2(0.5f, 0f), new Vector2(0f, PlayBottom), new Vector2(1000f, PlayH + 120f));
            _congratsTitle = UIFactory.Text("Title", _congrats, "Congratulations!", 64, UIFactory.Gold);
            UIFactory.Place(_congratsTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, 0f), new Vector2(1000f, 80f));
            UIFactory.FitText(_congratsTitle, 40);
            UIFactory.AddShadow(_congratsTitle, 5f, 0.45f);
            _congratsBody = UIFactory.Text("Body", _congrats, "You have completed this Adventure.", 34, UIFactory.TextSecondary);
            UIFactory.Place(_congratsBody.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -78f), new Vector2(1000f, 48f));
            UIFactory.FitText(_congratsBody, 24);
            _nextAdventure = UIFactory.Button("NextAdventure", _congrats, "NEXT ADVENTURE", UIFactory.Green, new Vector2(PlayW, 150f), 52,
                () => ShowPicture(_shown + 1, false));
            UIFactory.Place((RectTransform)_nextAdventure.transform, new Vector2(0.5f, 0f), Vector2.zero, new Vector2(PlayW, 150f));
            _congrats.gameObject.SetActive(false);
        }

        Button Arrow(RectTransform parent, string name, bool right, System.Action onClick)
        {
            var b = UIFactory.Chip(name, parent, new Vector2(120f, 110f), onClick);
            UIFactory.Place((RectTransform)b.transform, new Vector2(right ? 1f : 0f, 0.5f), Vector2.zero, new Vector2(120f, 110f));
            var img = UIFactory.Image("Arrow", b.transform, null, Color.white);
            img.sprite = IconLibrary.ChevronLeft();
            img.preserveAspect = true;
            img.raycastTarget = false;
            UIFactory.Place(img.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(right ? 4f : -4f, 0f), new Vector2(56f, 56f));
            if (right) img.rectTransform.localScale = new Vector3(-1f, 1f, 1f);
            return b;
        }

        LevelChip BuildChip(int i)
        {
            int col = i % 10, row = i / 10;
            var c = new LevelChip();
            c.button = UIFactory.Chip("L" + (i + 1), _strip, new Vector2(ChipW, ChipH), () => OnChip(i));
            var rt = (RectTransform)c.button.transform;
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(col * (ChipW + ChipGap), -row * (ChipH + ChipGap));
            c.bg = c.button.GetComponent<Image>();
            c.number = UIFactory.Text("Num", rt, "1", 34, Color.white);
            UIFactory.Place(c.number.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -10f), new Vector2(ChipW - 6f, 50f));
            UIFactory.FitText(c.number, 20);
            c.stars = new Image[3];
            for (int s = 0; s < 3; s++)
            {
                var st = UIFactory.Image("Star" + s, rt, "star", UIFactory.Gold);
                UIFactory.Place(st.rectTransform, new Vector2(0.5f, 0f), new Vector2((s - 1) * 26f, 12f + (s == 1 ? 6f : 0f)), new Vector2(26f, 26f));
                c.stars[s] = st;
            }
            c.lockIcon = UIFactory.Image("Lock", rt, "icon_lock", new Color(1f, 1f, 1f, 0.55f));
            UIFactory.Place(c.lockIcon.rectTransform, new Vector2(0.5f, 0f), new Vector2(0f, 14f), new Vector2(34f, 34f));
            return c;
        }

        // ================================================================ Gösterim

        /// <summary>
        /// Ekran açılırken: bekleyen (görülmemiş) bir açılma varsa o resim, yoksa oyuncunun şu anki resmi gösterilir.
        /// animate = false: anında (yükleme ekranında ön kurulum için).
        /// </summary>
        public void Show(bool animate)
        {
            int cur = AdventureDatabase.CurrentPicture;
            int pending = AdventureDatabase.PendingReveal(cur);
            ShowPicture(pending >= 0 ? pending : cur, animate);
        }

        void ShowPicture(int p, bool animate)
        {
            int cur = AdventureDatabase.CurrentPicture;
            p = Mathf.Clamp(p, 0, Mathf.Max(0, Mathf.Min(cur, AdventureDatabase.Count - 1)));
            if (_anim != null) { StopCoroutine(_anim); _anim = null; }

            int done = AdventureDatabase.CompletedLevels(p);
            int seen = Mathf.Min(AdventureDatabase.Seen(p), done);
            int target = AdventureDatabase.RevealedCells(p, done);
            int from = animate ? AdventureDatabase.RevealedCells(p, seen) : target;

            if (p != _shown) BuildPicture(p);
            _shown = p;
            SetRevealed(from);
            RefreshTexts(p, done, done > seen && animate ? seen : done);
            RefreshChips(p);
            _prev.interactable = p > 0;
            _next.interactable = p < cur;
            SetArrowAlpha(_prev, p > 0);
            SetArrowAlpha(_next, p < cur);

            if (from < target || (animate && done > seen))
                _anim = StartCoroutine(RevealRoutine(p, from, target, done, seen));
            else
                AdventureDatabase.SetSeen(p, done);
        }

        static void SetArrowAlpha(Button b, bool on)
        {
            var g = b.GetComponent<CanvasGroup>();
            if (g == null) g = b.gameObject.AddComponent<CanvasGroup>();
            g.alpha = on ? 1f : 0.3f;
        }

        void RefreshTexts(int p, int done, int doneForTexts)
        {
            int count = AdventureDatabase.LevelCount(p);
            bool complete = doneForTexts >= count && count > 0;
            _title.text = Loc.F("ADVENTURE {0}", p + 1);
            _subtitle.text = complete ? Loc.T(AdventureDatabase.Picture(p).name) : doneForTexts + " / " + count;
            _subtitle.color = complete ? UIFactory.Gold : UIFactory.TextSecondary;

            bool isLast = p >= AdventureDatabase.Count - 1;
            _congrats.gameObject.SetActive(complete);
            _play.gameObject.SetActive(!complete);
            if (complete)
            {
                _congratsTitle.text = Loc.T("Congratulations!");
                _congratsBody.text = isLast ? Loc.T("MORE ADVENTURES COMING SOON") : Loc.T("You have completed this Adventure.");
                _nextAdventure.gameObject.SetActive(!isLast && p < AdventureDatabase.CurrentPicture);
            }
            else
            {
                int next = Mathf.Clamp(SaveSystem.UnlockedLevel, 0, LevelDatabase.Count - 1);
                UIFactory.SetLabel(_play, Loc.F("LEVEL {0}", next + 1));
                int hard = LevelDatabase.Get(next).hard;
                _badge.gameObject.SetActive(hard > 0);
                if (hard > 0)
                {
                    _badgeText.text = Loc.T(hard >= 2 ? "BOSS" : "HARD");
                    _badge.GetComponent<Image>().color = hard >= 2 ? UIFactory.Red : UIFactory.Purple;
                }
            }
        }

        void RefreshChips(int p)
        {
            int first = AdventureDatabase.FirstLevel(p), count = AdventureDatabase.LevelCount(p);
            int unlocked = SaveSystem.UnlockedLevel;
            for (int i = 0; i < _chips.Count; i++)
            {
                var c = _chips[i];
                int lv = first + i;
                bool exists = i < count;
                c.button.gameObject.SetActive(exists);
                if (!exists) continue;
                int stars = SaveSystem.GetStars(lv);
                bool locked = lv > unlocked;
                bool current = lv == unlocked && stars == 0;
                int hard = LevelDatabase.Get(lv).hard;
                c.number.text = (lv + 1).ToString();
                c.number.color = locked ? new Color(1f, 1f, 1f, 0.4f) : hard >= 2 ? new Color(1f, 0.55f, 0.55f) : hard == 1 ? new Color(0.85f, 0.7f, 1f) : Color.white;
                for (int s = 0; s < 3; s++)
                {
                    c.stars[s].gameObject.SetActive(!locked && !current);
                    c.stars[s].color = s < stars ? UIFactory.Gold : new Color(0f, 0f, 0f, 0.35f);
                }
                c.lockIcon.gameObject.SetActive(locked);
                c.bg.color = current ? new Color(1f, 0.6f, 0.2f, 0.85f) : locked ? new Color(0f, 0f, 0f, 0.18f) : new Color(0f, 0f, 0f, 0.32f);
                c.button.interactable = !locked;
            }
        }

        void OnChip(int i)
        {
            int lv = AdventureDatabase.FirstLevel(_shown) + i;
            if (lv > SaveSystem.UnlockedLevel || lv >= LevelDatabase.Count) { Haptics.Error(); return; }
            _onPlay?.Invoke(lv);
        }

        void PlayCurrent()
        {
            int next = Mathf.Clamp(SaveSystem.UnlockedLevel, 0, LevelDatabase.Count - 1);
            _onPlay?.Invoke(next);
        }

        // ================================================================ Resim

        void BuildPicture(int p)
        {
            for (int i = _grid.childCount - 1; i >= 0; i--) Destroy(_grid.GetChild(i).gameObject);
            _cells.Clear();
            var rows = AdventureDatabase.Picture(p).rows;
            int h = rows.Length, w = h > 0 ? rows[0].Length : 0;
            var order = AdventureDatabase.RevealOrder(p);
            var body = SpriteLibrary.UnifiedTile(0, false);
            var shine = SpriteLibrary.UnifiedTile(0, true);
            float bodyScale = SpriteLibrary.TileBodyWorldSize;
            foreach (var cell in order)
            {
                // Her hücre birim kare (1x1) olarak kurulur; Layout ızgarayı çerçeveye sığdırır (ölçek)
                var img = UIFactory.Image("C" + cell.x + "_" + cell.y, _grid, null, Color.white);
                img.sprite = body;
                img.raycastTarget = false;
                var rt = img.rectTransform;
                rt.anchorMin = rt.anchorMax = new Vector2(0f, 1f);
                rt.pivot = new Vector2(0.5f, 0.5f);
                rt.sizeDelta = Vector2.one * bodyScale;
                rt.anchoredPosition = new Vector2(cell.x + 0.5f, -(cell.y + 0.5f));
                var sh = UIFactory.Image("Shine", rt, null, Color.white);
                sh.sprite = shine;
                sh.raycastTarget = false;
                UIFactory.Place(sh.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.one);
                _cells.Add(img);
            }
            _grid.sizeDelta = new Vector2(w, h);
            _lastFrameSize = Vector2.zero; // LateUpdate yeniden ölçeklesin
            Layout();
        }

        void LateUpdate()
        {
            if (_frame != null && _frame.rect.size != _lastFrameSize) Layout();
        }

        /// <summary>Izgarayı çerçeveye sığdırır (hücre en fazla 90 birim).</summary>
        void Layout()
        {
            var size = _frame.rect.size;
            if (size.x <= 1f || size.y <= 1f) return;
            _lastFrameSize = size;
            var g = _grid.sizeDelta;
            if (g.x <= 0f || g.y <= 0f) return;
            float cell = Mathf.Min((size.x - 60f) / g.x, (size.y - 60f) / g.y, 90f);
            _grid.localScale = new Vector3(cell, cell, 1f);
            _grid.anchoredPosition = Vector2.zero;
        }

        /// <summary>İlk n blok (açılma sırasıyla) renkli, kalanı soluk siluet.</summary>
        void SetRevealed(int n)
        {
            _revealedShown = n;
            var order = AdventureDatabase.RevealOrder(_shown);
            var rows = AdventureDatabase.Picture(_shown).rows;
            for (int i = 0; i < _cells.Count; i++) Paint(i, i < n, order, rows);
        }

        void Paint(int i, bool on, Vector2Int[] order, string[] rows)
        {
            var img = _cells[i];
            var cell = order[i];
            img.transform.localScale = Vector3.one;
            if (on)
            {
                img.color = AdventureDatabase.ColorOf(rows[cell.y][cell.x]);
                img.transform.GetChild(0).gameObject.SetActive(true);
            }
            else
            {
                img.color = new Color(1f, 1f, 1f, 0.09f);
                img.transform.GetChild(0).gameObject.SetActive(false);
            }
        }

        /// <summary>
        /// Yeni açılan bloklar alttan yukarı, tek tek "pop" ile belirir; her blokta pentatonik dizide yükselen bir nota.
        /// Resim tamamlanırsa adı ortaya çıkar, kutlama sesi ve konfeti.
        /// </summary>
        IEnumerator RevealRoutine(int p, int from, int to, int done, int seen)
        {
            yield return new WaitForSecondsRealtime(0.35f); // ekran yerleşsin, oyuncu resmi görsün
            var order = AdventureDatabase.RevealOrder(p);
            var rows = AdventureDatabase.Picture(p).rows;
            var sm = SoundManager.Instance;
            var s = GameSettings.Instance;
            int n = Mathf.Max(1, to - from);
            float step = Mathf.Clamp(1.3f / n, 0.025f, 0.09f);
            for (int i = from; i < to && i < _cells.Count; i++)
            {
                Paint(i, true, order, rows);
                StartCoroutine(Pop(_cells[i].transform));
                if (sm != null && ((i - from) % 2 == 0 || n < 12)) sm.PlayScaleNote(s.sfxDrag, Mathf.Min(7, (i - from) * 7 / n), s.dragVolume, 0f);
                if ((i - from) % 3 == 0) Haptics.Selection();
                yield return new WaitForSecondsRealtime(step);
            }
            _revealedShown = to;
            AdventureDatabase.SetSeen(p, done);

            bool complete = done >= AdventureDatabase.LevelCount(p);
            if (complete && seen < done)
            {
                yield return new WaitForSecondsRealtime(0.25f);
                if (sm != null) sm.PlayFrom(s.sfxPerfect, 1f, 0.9f);
                Haptics.Success();
                StartCoroutine(Confetti());
                StartCoroutine(Pop(_grid, 1.06f));
            }
            RefreshTexts(p, done, done);
            if (complete) StartCoroutine(Pop(_congrats, 1.08f));
            _anim = null;
        }

        static IEnumerator Pop(Transform t, float peak = 1.25f)
        {
            if (t == null) yield break;
            Vector3 baseScale = t == null ? Vector3.one : t.localScale;
            float e = 0f, dur = 0.22f;
            while (e < dur && t != null)
            {
                e += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(e / dur);
                float sc = k < 0.5f ? Mathf.Lerp(0.3f, peak, k / 0.5f) : Mathf.Lerp(peak, 1f, (k - 0.5f) / 0.5f);
                t.localScale = baseScale * sc;
                yield return null;
            }
            if (t != null) t.localScale = baseScale;
        }

        /// <summary>Resim tamamlanınca resmin üstünden saçılan renkli UI konfetisi.</summary>
        IEnumerator Confetti()
        {
            var s = GameSettings.Instance;
            var layer = UIFactory.Rect("Confetti", _root);
            UIFactory.Stretch(layer);
            const int n = 46;
            var parts = new RectTransform[n];
            var vel = new Vector2[n];
            var spin = new float[n];
            Vector2 origin = (Vector2)_root.InverseTransformPoint(_frame.position);
            for (int i = 0; i < n; i++)
            {
                var img = UIFactory.Image("P", layer, "square", s.GetColor(i % 5));
                img.raycastTarget = false;
                var rt = img.rectTransform;
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                rt.sizeDelta = new Vector2(Random.Range(16f, 26f), Random.Range(10f, 18f));
                rt.anchoredPosition = origin + new Vector2(Random.Range(-60f, 60f), Random.Range(-40f, 40f));
                float a = Random.Range(0f, Mathf.PI * 2f);
                float sp = Random.Range(500f, 1300f);
                vel[i] = new Vector2(Mathf.Cos(a), Mathf.Abs(Mathf.Sin(a)) * 1.2f + 0.3f) * sp;
                spin[i] = Random.Range(-540f, 540f);
                parts[i] = rt;
            }
            float t = 0f, life = 1.8f;
            while (t < life)
            {
                float dt = Time.unscaledDeltaTime;
                t += dt;
                for (int i = 0; i < n; i++)
                {
                    vel[i].y -= 2200f * dt;
                    vel[i] *= 1f - 0.8f * dt;
                    parts[i].anchoredPosition += vel[i] * dt;
                    parts[i].localRotation = Quaternion.Euler(0f, 0f, spin[i] * t);
                    var img = parts[i].GetComponent<Image>();
                    var c = img.color; c.a = Mathf.Clamp01((life - t) / 0.5f); img.color = c;
                }
                yield return null;
            }
            Destroy(layer.gameObject);
        }

        void OnDisable()
        {
            // Ekran kapanırken animasyon yarıda kalırsa bloklar doğru durumda kalsın (bir sonraki açılışta yeniden çizilir)
            if (_anim != null) { StopCoroutine(_anim); _anim = null; }
        }
    }
}
