using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace BlockRise
{
    /// <summary>
    /// Tüm ekranlar kodla kurulur: Ana menü, Level seçimi, Oyun HUD'ı, Duraklatma, Sonuç, Toast.
    /// Metinleri değiştirmek için bu dosyadaki string'leri düzenle.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        const float RefW = 1080f, RefH = 1920f;
        const float TopBarHeight = 170f;
        const float GoalsHeight = 140f;

        GameController _ctrl;
        BoardView _board;
        GameSettings _s;

        Canvas _canvas;
        UnityEngine.UI.CanvasScaler _scaler;
        RectTransform _safe;
        UnityEngine.UI.Image _bg;

        RectTransform _menu, _levels, _hud, _pause, _result, _toast;
        RectTransform _bannerPlaceholder;
        UnityEngine.UI.Text _menuStreak, _menuMedals;
        RectTransform _menuSnd, _menuHap, _menuNoAds, _menuEnergyChip;
        UnityEngine.UI.Button _menuLang;
        RectTransform _langPopup;
        readonly List<UnityEngine.UI.Button> _langButtons = new List<UnityEngine.UI.Button>();
        UnityEngine.UI.Text _menuEnergy, _menuEnergyTimer;
        float _energyRefreshT;
        RectTransform _topBar, _tut;
        UnityEngine.UI.Text _tutStep, _tutTitle, _tutBody;
        UnityEngine.UI.Button _tutAction;
        System.Action _tutActionCallback;
        UnityEngine.UI.Text _menuBest, _menuStars, _levelsStars;
        RectTransform _levelsContent;
        UnityEngine.UI.ScrollRect _levelsScroll;
        Coroutine _levelsScrollAnim;

        // HUD
        UnityEngine.UI.Text _scoreLabel, _scoreValue, _centerLabel, _centerValue;
        UnityEngine.UI.Image _crown;
        UnityEngine.UI.Text _punchText; // skor artınca zıplayan yazı (endless: orta kutu, level: sol kutu)
        RectTransform _goalsBar;
        readonly List<GoalItem> _goalItems = new List<GoalItem>();
        int _lastScore;
        float _scorePunch;

        // Result
        UnityEngine.UI.Text _resTitle, _resScore, _resSub;
        readonly List<UnityEngine.UI.Image> _resStars = new List<UnityEngine.UI.Image>();
        RectTransform _resStarRow;
        UnityEngine.UI.Button _resPrimary, _resRevive, _resRetry, _resHome;

        // Revive geri sayımı: buton tombul bir yükleme çubuğu gibi boşalır, kalp gibi atar
        const float ReviveSeconds = 5f;
        const float ReviveW = 600f, ReviveH = 130f;
        static readonly Color ReviveTrack = new Color(0f, 0f, 0f, 0.28f);        // boşalan kısım
        static readonly Color ReviveLate = new Color(1f, 0.62f, 0.25f);          // son saniyelerde dolgunun rengi
        Coroutine _reviveCountdown;
        RectTransform _reviveHolder;      // kalp atışı bu taşıyıcıya uygulanır (PressScale ile çakışmasın)
        UnityEngine.UI.Image _reviveFill;
        UnityEngine.UI.Image _reviveFillShine;
        UnityEngine.UI.Text _toastText;
        Coroutine _toastRoutine;

        Rect _lastSafe;
        int _lastW, _lastH;

        class GoalItem
        {
            public GoalData goal;
            public UnityEngine.UI.Text count;
            public UnityEngine.UI.Image check;
        }

        // ================================================================ Reserve (kamera için)

        float CanvasScale
        {
            get
            {
                float match = _scaler != null ? _scaler.matchWidthOrHeight : 0f;
                float lw = Mathf.Log(Screen.width / RefW, 2);
                float lh = Mathf.Log(Screen.height / RefH, 2);
                return Mathf.Pow(2, Mathf.Lerp(lw, lh, match));
            }
        }

        const float TutorialHeight = 370f;
        float HudHeight => _ctrl != null && _ctrl.Mode == GameMode.Tutorial
            ? TutorialHeight + 20f
            : TopBarHeight + 20f + (_ctrl != null && _ctrl.Mode == GameMode.Level ? GoalsHeight + 10f : 0f);

        public float TopReservePixels => (Screen.height - Screen.safeArea.yMax) + HudHeight * CanvasScale;
        public float BottomReservePixels => Screen.safeArea.yMin + (_s.bottomReserve + (BannerActive ? _s.bannerReserveHeight : 0f)) * CanvasScale;

        /// <summary>Oyun ekranında alt banner reklam alanı ayrılsın mı (tutorial hariç).</summary>
        bool BannerActive => _s.bannerAds && !SaveSystem.AdsRemoved && _ctrl != null && _ctrl.Mode != GameMode.Tutorial;

        // ================================================================ Build

        public void Init(GameController ctrl, BoardView board)
        {
            _ctrl = ctrl;
            Achievements.Unlocked -= OnMedalUnlocked;
            Achievements.Unlocked += OnMedalUnlocked;
            _board = board;
            _s = GameSettings.Instance;

            if (FindObjectOfType<EventSystem>() == null)
            {
                var es = new GameObject("EventSystem");
                es.AddComponent<EventSystem>();
                es.AddComponent<StandaloneInputModule>();
            }

            var cgo = new GameObject("UI", typeof(RectTransform));
            cgo.layer = 5;
            cgo.transform.SetParent(transform, false);
            _canvas = cgo.AddComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _canvas.sortingOrder = 10;
            _scaler = cgo.AddComponent<UnityEngine.UI.CanvasScaler>();
            _scaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
            _scaler.referenceResolution = new Vector2(RefW, RefH);
            _scaler.screenMatchMode = UnityEngine.UI.CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            UpdateMatch();
            cgo.AddComponent<UnityEngine.UI.GraphicRaycaster>();

            _bg = UIFactory.Image("Background", cgo.transform, null, Color.clear); // görsel yok; gerçek arka plan BackgroundGradient
            _bg.gameObject.SetActive(false);
            _bg.preserveAspect = false;
            UIFactory.Stretch(_bg.rectTransform);

            _safe = UIFactory.Rect("SafeArea", cgo.transform);
            ApplySafeArea();

            BuildMenu();
            BuildLevels();
            BuildHUD();
            BuildPause();
            BuildResult();
            BuildTutorial();
            BuildToast();
        }

        void UpdateMatch()
        {
            // Telefon (dar ekran): genişliğe göre; tablet (geniş ekran): yüksekliğe göre ölçekle
            float aspect = (float)Screen.width / Mathf.Max(1, Screen.height);
            _scaler.matchWidthOrHeight = aspect > 0.62f ? 1f : 0f;
        }

        void ApplySafeArea()
        {
            var sa = Screen.safeArea;
            _lastSafe = sa;
            _lastW = Screen.width;
            _lastH = Screen.height;
            var min = new Vector2(sa.xMin / Screen.width, sa.yMin / Screen.height);
            var max = new Vector2(sa.xMax / Screen.width, sa.yMax / Screen.height);
            _safe.anchorMin = min;
            _safe.anchorMax = max;
            _safe.offsetMin = Vector2.zero;
            _safe.offsetMax = Vector2.zero;
        }

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape)) HandleBack(); // Android geri tuşu

            if (Screen.width != _lastW || Screen.height != _lastH || Screen.safeArea != _lastSafe)
            {
                UpdateMatch();
                ApplySafeArea();
                if (_hud.gameObject.activeSelf) _board.FitCamera(TopReservePixels, BottomReservePixels);
            }

            _energyRefreshT -= Time.unscaledDeltaTime;
            if (_energyRefreshT <= 0f)
            {
                _energyRefreshT = 0.25f;
                bool popup = _energyPopup != null && _energyPopup.gameObject.activeSelf;
                if (_levels.gameObject.activeSelf || popup) RefreshEnergyUI(timerOnly: true);
            }

            if (_scorePunch > 0)
            {
                _scorePunch = Mathf.Max(0, _scorePunch - Time.unscaledDeltaTime * 4f);
                float s = 1f + _scorePunch * 0.25f;
                if (_punchText != null) _punchText.transform.localScale = new Vector3(s, s, 1);
            }
        }

        RectTransform Screen_(string name)
        {
            var rt = UIFactory.Rect(name, _safe);
            UIFactory.Stretch(rt);
            rt.gameObject.SetActive(false);
            return rt;
        }

        // ---------------------------------------------------------------- Main menu

        void BuildMenu()
        {
            _menu = Screen_("MainMenu");

            // Sol üst: günlük seri (alev + gün sayısı) → dokununca seri penceresi
            var streakBtn = UIFactory.Image("Streak", _menu, "square", new Color(0f, 0f, 0f, 0.28f), false, true);
            streakBtn.sprite = SpriteLibrary.UIGlass(false);
            streakBtn.type = UnityEngine.UI.Image.Type.Sliced;
            streakBtn.preserveAspect = false;
            streakBtn.pixelsPerUnitMultiplier = 0.8f;
            UIFactory.Place(streakBtn.rectTransform, new Vector2(0f, 1f), new Vector2(30f, -40f), new Vector2(210f, 110f));
            // Madalya chip'iyle aynı parlak cam kenar (çerçeve parlaması)
            var streakRim = UIFactory.Image("Rim", streakBtn.transform, null, Color.white, true);
            streakRim.sprite = SpriteLibrary.UIGlass(true);
            streakRim.pixelsPerUnitMultiplier = 0.8f;
            UIFactory.Stretch(streakRim.rectTransform);
            streakRim.raycastTarget = false;
            var sb_ = streakBtn.gameObject.AddComponent<UnityEngine.UI.Button>();
            sb_.targetGraphic = streakBtn;
            sb_.onClick.AddListener(() => ShowStreakPopup());
            streakBtn.gameObject.AddComponent<PressScale>();
            var flame = UIFactory.Image("Flame", streakBtn.transform, null, Color.white);
            flame.sprite = IconLibrary.Flame();
            flame.preserveAspect = true;
            UIFactory.Place(flame.rectTransform, new Vector2(0f, 0.5f), new Vector2(14f, 0f), new Vector2(84f, 84f));
            _menuStreak = UIFactory.Text("Days", streakBtn.transform, "0", 58, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(_menuStreak.rectTransform, new Vector2(0f, 0.5f), new Vector2(104f, 2f), new Vector2(100f, 90f));
            UIFactory.AddShadow(_menuStreak, 4f, 0.4f);
            UISparkle.AddTo(streakBtn.transform);

            // Sağ üst: madalyalar
            // Sağ üst: madalyalar — soldaki seri göstergesiyle aynı cam chip (simge + sayı)
            var medalBtn = UIFactory.Chip("Medals", _menu, new Vector2(250, 110), ShowMedals);
            UIFactory.Place((RectTransform)medalBtn.transform, new Vector2(1f, 1f), new Vector2(-30f, -40f), new Vector2(250, 110));
            var mimg = UIFactory.Image("Icon", medalBtn.transform, null, Achievements.TierColors[2]);
            mimg.sprite = IconLibrary.Medal();
            mimg.preserveAspect = true;
            mimg.raycastTarget = false;
            UIFactory.Place(mimg.rectTransform, new Vector2(0f, 0.5f), new Vector2(14f, 0f), new Vector2(84f, 84f));
            _menuMedals = UIFactory.Text("Count", medalBtn.transform, "0", 50, Color.white, TextAnchor.MiddleLeft);
            // Sayı chip'in sağ kenarına kadar uzanır; "12/33" gibi uzun değerlerde taşmak yerine küçülür
            UIFactory.Place(_menuMedals.rectTransform, new Vector2(0f, 0.5f), new Vector2(104f, 2f), new Vector2(128f, 70f));
            UIFactory.FitText(_menuMedals, 30);
            UIFactory.AddShadow(_menuMedals, 4f, 0.4f);
            UISparkle.AddTo(medalBtn.transform);

            // Dekoratif blok sırası
            var deco = UIFactory.Rect("Deco", _menu);
            UIFactory.Place(deco, new Vector2(0.5f, 1f), new Vector2(0, -230), new Vector2(700, 130));
            var hl = deco.gameObject.AddComponent<UnityEngine.UI.HorizontalLayoutGroup>();
            hl.spacing = 18;
            hl.childAlignment = TextAnchor.MiddleCenter;
            hl.childControlWidth = false;
            hl.childControlHeight = false;
            hl.childForceExpandWidth = false;
            hl.childForceExpandHeight = false;
            int[] order = { 0, 3, 1, 2, 4 };
            for (int i = 0; i < order.Length; i++)
            {
                // Taşıyıcıyı yerleşim grubu dizer, içindeki blok hafifçe süzülür
                var holder = UIFactory.Rect("B" + i, deco);
                holder.sizeDelta = new Vector2(115, 115);
                var b = UIFactory.BlockIcon("Block", holder, order[i], 115 * SpriteLibrary.TileBodyWorldSize);
                UIFactory.Place(b.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, b.rectTransform.sizeDelta);
                var bob = b.gameObject.AddComponent<UIBob>();
                bob.phase = i * 0.7f;
            }

            // Gizli test paneli: blok sırasına art arda 5 dokunuş → cihazdaki oyun istatistikleri
            if (_s.enableStatsPanel)
            {
                var hit = deco.gameObject.AddComponent<UnityEngine.UI.Image>();
                hit.color = new Color(1f, 1f, 1f, 0f);
                hit.raycastTarget = true;
                deco.gameObject.AddComponent<SecretTap>().onTrigger = ShowStats;
            }

            // Harf renkleri oyundaki blok renklerinden gelir (kırmızı, sarı, yeşil, mavi, mor)
            string word = "COLOR";
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < word.Length; i++)
                sb.Append("<color=#").Append(ColorUtility.ToHtmlStringRGB(_s.GetColor(order[i]))).Append('>').Append(word[i]).Append("</color>");
            sb.Append("\nPOP");
            var title = UIFactory.Text("Title", _menu, sb.ToString(), 190, Color.white);
            title.lineSpacing = 0.85f;
            UIFactory.Place(title.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -400), new Vector2(1000, 460));
            UIFactory.AddShadow(title, 10f, 0.5f);

            var sub = UIFactory.Text("Subtitle", _menu, "BLOCK PUZZLE", 80, UIFactory.TextDim);
            UIFactory.Place(sub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -900), new Vector2(1000, 60));

            var endless = UIFactory.Button("EndlessButton", _menu, "CLASSIC", UIFactory.Green, new Vector2(680, 180), 72,
                () => { if (_ctrl.EndlessNeedsEnergy) WithEnergy(_ctrl.StartEndless); else _ctrl.StartEndless(); });
            UIFactory.Place(endless.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0, -150), new Vector2(680, 180));
            _menuBest = UIFactory.Text("Best", _menu, "BEST 0", 36, UIFactory.Gold);
            UIFactory.Place(_menuBest.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0, -275), new Vector2(680, 50));

            var levels = UIFactory.Button("LevelsButton", _menu, "ADVENTURE", UIFactory.Blue, new Vector2(680, 180), 72, ShowLevelSelect);
            UIFactory.Place(levels.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0, -420), new Vector2(680, 180));

            var starRow = UIFactory.Rect("Stars", _menu);
            UIFactory.Place(starRow, new Vector2(0.5f, 0.5f), new Vector2(0, -545), new Vector2(400, 56));
            var st = UIFactory.Image("StarIcon", starRow, "star", UIFactory.Gold);
            UIFactory.Place(st.rectTransform, new Vector2(0f, 0.5f), new Vector2(90, 0), new Vector2(48, 48));
            _menuStars = UIFactory.Text("StarText", starRow, "0 / 0", 36, UIFactory.TextDim, TextAnchor.MiddleLeft);
            UIFactory.Place(_menuStars.rectTransform, new Vector2(0f, 0.5f), new Vector2(150, 0), new Vector2(250, 56));


            // HOW TO PLAY'in iki yanında: ses ve titreşim aç/kapa
            _menuSnd = SoundToggle(_menu, new Vector2(120, 100));
            UIFactory.Place(_menuSnd, new Vector2(0.5f, 0.5f), new Vector2(-90, -690), new Vector2(140, 140));
            _menuHap = HapticsToggle(_menu, new Vector2(120, 100));
            UIFactory.Place(_menuHap, new Vector2(0.5f, 0.5f), new Vector2(90, -690), new Vector2(140, 140));

            // Sağ alt köşe: reklam kaldırma görseli (Resources/BlockRiseSprites/icon_noads.png; satın alınınca kaybolur)
            var noAdsImg = UIFactory.Image("NoAds", _menu, "icon_noads", Color.white, false, true);
            noAdsImg.preserveAspect = true;
            _menuNoAds = noAdsImg.rectTransform;
            UIFactory.Place(_menuNoAds, new Vector2(1f, 0f), new Vector2(-30f, 40f), new Vector2(150, 150));
            var noAds = noAdsImg.gameObject.AddComponent<UnityEngine.UI.Button>();
            noAds.targetGraphic = noAdsImg;
            noAds.onClick.AddListener(() =>
            {
                var sm = SoundManager.Instance;
                if (sm != null) sm.PlayFrom(_s.sfxButton, 1f, 0.8f);
                Haptics.Light();
                ShowRemoveAds();
            });
            noAdsImg.gameObject.AddComponent<PressScale>();

            // Sol alt köşe: dil seçimi (reklam kaldırma düğmesinin simetriği)
            _menuLang = UIFactory.Button("Language", _menu, Loc.ShortCodes[(int)Loc.Current], new Color(1f, 1f, 1f, 0.16f), new Vector2(170, 110), 44, ShowLanguagePicker);
            UIFactory.ApplyGlassSkin(_menuLang.GetComponent<UnityEngine.UI.Image>(), 110f);
            UIFactory.Place(_menuLang.GetComponent<RectTransform>(), new Vector2(0f, 0f), new Vector2(30f, 60f), new Vector2(170, 110));
        }

        // ---------------------------------------------------------------- Dil seçimi

        void BuildLanguagePicker()
        {
            const float bw = 360f, bh = 116f, gapY = 18f, top = 170f;
            int rows = (Loc.Count + 1) / 2;
            float ph = top + rows * (bh + gapY) + 40f;
            _langPopup = Overlay("LanguagePopup", out var panel, new Vector2(840, ph), true);
            var t = UIFactory.Text("Title", panel, "LANGUAGE", 72, Color.white);
            UIFactory.Place(t.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -50), new Vector2(760, 100));
            UIFactory.AddShadow(t, 6f, 0.45f);

            _langButtons.Clear();
            for (int i = 0; i < Loc.Count; i++)
            {
                int idx = i;
                var b = UIFactory.Button("Lang" + i, panel, Loc.NativeNames[i], new Color(1f, 1f, 1f, 0.16f), new Vector2(bw, bh), 40, () => PickLanguage((Language)idx));
                UIFactory.ApplyGlassSkin(b.GetComponent<UnityEngine.UI.Image>(), bh);
                int col = i % 2, row = i / 2;
                UIFactory.Place(b.GetComponent<RectTransform>(), new Vector2(0.5f, 1f),
                    new Vector2(col == 0 ? -(bw / 2f + 12f) : (bw / 2f + 12f), -top - row * (bh + gapY)), new Vector2(bw, bh));
                _langButtons.Add(b);
            }
        }

        void ShowLanguagePicker()
        {
            if (_langPopup == null) BuildLanguagePicker();
            // Seçili dil: daha belirgin cam + altın yazı
            for (int i = 0; i < _langButtons.Count; i++)
            {
                bool sel = i == (int)Loc.Current;
                _langButtons[i].GetComponent<UnityEngine.UI.Image>().color = new Color(1f, 1f, 1f, sel ? 0.42f : 0.16f);
                var label = _langButtons[i].GetComponentInChildren<UnityEngine.UI.Text>();
                if (label != null) label.color = sel ? UIFactory.Gold : UIFactory.TextLight;
            }
            _langPopup.gameObject.SetActive(true);
            _langPopup.SetAsLastSibling();
            StartCoroutine(PopIn(_langPopup.Find("Panel"), 0.2f));
        }

        void PickLanguage(Language lang)
        {
            Loc.Set(lang);
            UIFactory.SetLabel(_menuLang, Loc.ShortCodes[(int)Loc.Current]);
            _langPopup.gameObject.SetActive(false);
            ShowMainMenu(); // menüdeki değişken yazılar (rekor, yıldızlar...) yeni dilde yeniden yazılsın
        }

        public void ShowMainMenu()
        {
            HideAll();
            _bg.gameObject.SetActive(false); // oyunun canlı arka planı ve yıldız tozu görünsün
            _menu.gameObject.SetActive(true);
            RefreshToggles();
            RefreshNoAds();
            RefreshEnergyUI();
            _menuBest.text = Loc.F("BEST  {0}", SaveSystem.BestEndless);
            _menuStreak.text = DailyStreak.Current.ToString();
            _menuMedals.text = Achievements.TotalTiers() + "/" + (Achievements.All.Length * 3);
            _menuStars.text = SaveSystem.TotalStars(LevelDatabase.Count) + " / " + (LevelDatabase.Count * 3);
            StartCoroutine(PopIn(_menu, 0.25f));
            // Günün ilk açılışında seri penceresi (tutorial'dan sonra, menüye ilk dönüşte)
            if (SaveSystem.TutorialSeen && DailyStreak.Current > 0 && DailyStreak.ConsumeShowToday()) ShowStreakPopup(true);
        }

        // ---------------------------------------------------------------- Level select

        void BuildLevels()
        {
            _levels = Screen_("LevelSelect");
            var header = BuildScreenHeader(_levels, "LEVELS");

            // Orta: enerji (şimşek + sayı + dolum süresi) → dokununca enerji penceresi. Başlığın yerini alır.
            header.Find("Title").gameObject.SetActive(false);
            var energyBtn = UIFactory.Chip("Energy", header, new Vector2(240, 120), () => ShowEnergy(null));
            UIFactory.Place((RectTransform)energyBtn.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(240, 120));
            var eicon = EnergyIcon(energyBtn.transform, 84f);
            UIFactory.Place(eicon, new Vector2(0f, 0.5f), new Vector2(14f, 0f), new Vector2(84f, 84f));
            _menuEnergy = UIFactory.Text("Count", energyBtn.transform, "5", 50, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(_menuEnergy.rectTransform, new Vector2(0f, 0.5f), new Vector2(108f, 18f), new Vector2(122f, 60f));
            UIFactory.FitText(_menuEnergy, 30);
            UIFactory.AddShadow(_menuEnergy, 4f, 0.4f);
            _menuEnergyTimer = UIFactory.Text("Timer", energyBtn.transform, "FULL", 26, UIFactory.TextDim, TextAnchor.MiddleLeft);
            UIFactory.Place(_menuEnergyTimer.rectTransform, new Vector2(0f, 0.5f), new Vector2(108f, -28f), new Vector2(122f, 36f));
            UIFactory.FitText(_menuEnergyTimer, 18);
            _menuEnergyChip = (RectTransform)energyBtn.transform;

            var starBox = UIFactory.Rect("Stars", header);
            UIFactory.Place(starBox, new Vector2(1, 0.5f), Vector2.zero, new Vector2(230, 80));
            var st = UIFactory.Image("StarIcon", starBox, "star", UIFactory.Gold);
            UIFactory.Place(st.rectTransform, new Vector2(0, 0.5f), Vector2.zero, new Vector2(56, 56));
            _levelsStars = UIFactory.Text("Text", starBox, "0", 40, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(_levelsStars.rectTransform, new Vector2(0, 0.5f), new Vector2(66, 0), new Vector2(170, 80));

            // ScrollView: ScrollRect -> Viewport(Image+Mask) -> Content(Grid+ContentSizeFitter)
            var scroll = UIFactory.Rect("ScrollView", _levels);
            UIFactory.Stretch(scroll, 20, 20, 190, 40);
            var sr = scroll.gameObject.AddComponent<UnityEngine.UI.ScrollRect>();
            sr.horizontal = false;
            sr.vertical = true;
            sr.movementType = UnityEngine.UI.ScrollRect.MovementType.Elastic;
            sr.scrollSensitivity = 30f;

            // Görünmez ama dokunmayı yakalayan viewport (boş alandan da kaydırılabilsin).
            // RectMask2D: ekran dışındaki blokları çizmez → uzun haritada da akıcı.
            var viewportImg = UIFactory.Image("Viewport", scroll, "square", new Color(1f, 1f, 1f, 0f), false, true);
            viewportImg.preserveAspect = false;
            UIFactory.Stretch(viewportImg.rectTransform);
            viewportImg.gameObject.AddComponent<UnityEngine.UI.RectMask2D>();

            // Harita içeriği: yüksekliği LevelMap.Build belirler (aşağıdan yukarı tırmanan piramitler)
            _levelsContent = UIFactory.Rect("Content", viewportImg.transform);
            _levelsContent.anchorMin = new Vector2(0, 1);
            _levelsContent.anchorMax = new Vector2(1, 1);
            _levelsContent.pivot = new Vector2(0.5f, 1);
            _levelsContent.anchoredPosition = Vector2.zero;
            _levelsContent.sizeDelta = new Vector2(0, 0);

            sr.viewport = viewportImg.rectTransform;
            sr.content = _levelsContent;
            sr.decelerationRate = 0.12f;
            _levelsScroll = sr;
        }

        public void ShowLevelSelect()
        {
            HideAll();
            _bg.gameObject.SetActive(false); // oyunun canlı arka planı ve yıldız tozu görünsün
            _levels.gameObject.SetActive(true);
            RefreshEnergyUI();
            PopulateLevels();
            StartCoroutine(PopIn(_levels, 0.2f));
        }

        string _levelsBuiltKey;
        float _levelsFocusY;

        void PopulateLevels()
        {
            // İlerleme değişmediyse haritayı yeniden kurma (250 bölümde binlerce nesne): sadece kaydır
            int totalStars = SaveSystem.TotalStars(LevelDatabase.Count);
            string key = SaveSystem.UnlockedLevel + ":" + totalStars + ":" + LevelDatabase.Count + ":" + (int)Loc.Current; // dil değişince harita yeniden kurulsun
            if (key == _levelsBuiltKey && _levelsContent.childCount > 0)
            {
                if (_levelsScrollAnim != null) StopCoroutine(_levelsScrollAnim);
                _levelsScrollAnim = StartCoroutine(ScrollLevelsTo(_levelsFocusY));
                return;
            }
            _levelsBuiltKey = key;

            // Tekrar açılışta çoğalmasın diye temizle
            for (int i = _levelsContent.childCount - 1; i >= 0; i--)
            {
                var ch = _levelsContent.GetChild(i);
                ch.SetParent(null, false);
                Destroy(ch.gameObject);
            }

            _levelsStars.text = SaveSystem.TotalStars(LevelDatabase.Count) + "/" + (LevelDatabase.Count * 3);
            float focusY = LevelMap.Build(_levelsContent, LevelDatabase.Count, SaveSystem.UnlockedLevel, index => WithEnergy(() => _ctrl.StartLevel(index)));
            _levelsFocusY = focusY;

            if (_levelsScrollAnim != null) StopCoroutine(_levelsScrollAnim);
            _levelsScrollAnim = StartCoroutine(ScrollLevelsTo(focusY));
        }

        /// <summary>Haritayı sıradaki bölüme kaydırır: biraz aşağıdan başlayıp yumuşakça yukarı tırmanır.</summary>
        IEnumerator ScrollLevelsTo(float focusY)
        {
            _levelsScroll.StopMovement();
            yield return null; // viewport boyutu yerleşsin
            Canvas.ForceUpdateCanvases();
            float contentH = _levelsContent.rect.height;
            float viewH = _levelsScroll.viewport.rect.height;
            float range = Mathf.Max(1f, contentH - viewH);
            // Odak ekranın alttan ~%40'ında dursun (üstte sıradaki dünyadan bir parça görünsün)
            float target = Mathf.Clamp01((focusY - viewH * 0.4f) / range);
            float start = Mathf.Clamp01(target - 500f / range);
            _levelsScroll.verticalNormalizedPosition = start;

            float t = 0f, dur = 0.7f;
            while (t < dur)
            {
                if (Input.GetMouseButton(0)) yield break; // oyuncu kaydırmaya başladıysa bırak
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / dur);
                k = 1f - Mathf.Pow(1f - k, 3f);
                _levelsScroll.verticalNormalizedPosition = Mathf.Lerp(start, target, k);
                yield return null;
            }
            _levelsScroll.verticalNormalizedPosition = target;
        }

        // ---------------------------------------------------------------- HUD

        void BuildHUD()
        {
            _hud = Screen_("HUD");

            var top = UIFactory.Rect("TopBar", _hud);
            UIFactory.TopStrip(top, -10, TopBarHeight, 24);
            _topBar = top;

            // Sol kutu: skor
            var scoreBox = UIFactory.Panel("ScoreBox", top, UIFactory.PanelDark);
            UIFactory.Place(scoreBox.rectTransform, new Vector2(0, 0.5f), Vector2.zero, new Vector2(340, 150));
            _scoreLabel = UIFactory.Text("Label", scoreBox.transform, "SCORE", 30, UIFactory.TextDim);
            UIFactory.Place(_scoreLabel.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -14), new Vector2(320, 40));
            _scoreValue = UIFactory.Text("Value", scoreBox.transform, "0", 62, Color.white);
            UIFactory.Place(_scoreValue.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 16), new Vector2(320, 80));
            // Endless: "BEST" yazısı yerine taç (rekor skorun solunda)
            _crown = UIFactory.Image("Crown", scoreBox.transform, null, Color.white);
            _crown.sprite = IconLibrary.Crown();
            _crown.preserveAspect = true;
            UIFactory.Place(_crown.rectTransform, new Vector2(0f, 0.5f), new Vector2(22f, 2f), new Vector2(84f, 84f));

            // Orta kutu: hamle (level) / en iyi (endless)
            var center = UIFactory.Panel("CenterBox", top, UIFactory.PanelDark);
            UIFactory.Place(center.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(10, 0), new Vector2(300, 150));
            _centerLabel = UIFactory.Text("Label", center.transform, "MOVES", 30, UIFactory.TextDim);
            UIFactory.Place(_centerLabel.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -14), new Vector2(290, 40));
            _centerValue = UIFactory.Text("Value", center.transform, "0", 62, Color.white);
            UIFactory.Place(_centerValue.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 16), new Vector2(290, 80));

            // Sağ: duraklat
            var pause = UIFactory.IconButton("PauseButton", top, "icon_pause", UIFactory.Purple, new Vector2(130, 130), () => _ctrl.Pause());
            UIFactory.Place(pause.GetComponent<RectTransform>(), new Vector2(1, 0.5f), Vector2.zero, new Vector2(130, 130));

            // Editörde banner reklamın yerini gösteren yer tutucu (cihazda görünmez)
            var bp = UIFactory.Image("BannerPlaceholder", _hud, "square", new Color(0f, 0f, 0f, 0.35f), false, false);
            bp.preserveAspect = false;
            var bprt = bp.rectTransform;
            bprt.anchorMin = new Vector2(0f, 0f); bprt.anchorMax = new Vector2(1f, 0f); bprt.pivot = new Vector2(0.5f, 0f);
            bprt.anchoredPosition = Vector2.zero;
            bprt.sizeDelta = new Vector2(0f, _s.bannerReserveHeight);
            var bpt = UIFactory.Text("Label", bp.transform, "BANNER AD", 34, new Color(1f, 1f, 1f, 0.5f));
            UIFactory.Stretch(bpt.rectTransform);
            _bannerPlaceholder = bprt;
            _bannerPlaceholder.gameObject.SetActive(false);

            // Hedef şeridi
            var goals = UIFactory.Panel("GoalsBar", _hud, UIFactory.PanelDark);
            _goalsBar = goals.rectTransform;
            UIFactory.TopStrip(_goalsBar, -(TopBarHeight + 20), GoalsHeight, 24);
            var hl = goals.gameObject.AddComponent<UnityEngine.UI.HorizontalLayoutGroup>();
            hl.spacing = 22;
            hl.childAlignment = TextAnchor.MiddleCenter;
            hl.childControlWidth = false;
            hl.childControlHeight = false;
            hl.childForceExpandWidth = false;
            hl.childForceExpandHeight = false;
        }

        public void ShowHUD(GameController ctrl)
        {
            HideAll();
            _bg.gameObject.SetActive(false);
            _hud.gameObject.SetActive(true);
            // Alt banner reklam: tahta için alan zaten ayrıldı (BottomReservePixels); SDK bağlıysa banner görünür
            AdHooks.SetBannerVisible(BannerActive);
            if (_bannerPlaceholder != null) _bannerPlaceholder.gameObject.SetActive(BannerActive && Application.isEditor && _s.showBannerPlaceholder);
            _lastScore = 0;

            bool level = ctrl.Mode == GameMode.Level;
            _goalsBar.gameObject.SetActive(level);
            _topBar.gameObject.SetActive(ctrl.Mode != GameMode.Tutorial);
            _centerLabel.text = level ? Loc.F("LEVEL {0} • MOVES", ctrl.LevelIndex + 1) : Loc.T("SCORE");
            _centerLabel.fontSize = level ? 26 : 30;

            // Sol kutu — level: "SCORE" + skor | endless: taç + rekor (altın, yazısız)
            _scoreLabel.gameObject.SetActive(level);
            _crown.gameObject.SetActive(!level);
            if (level)
            {
                _scoreValue.alignment = TextAnchor.MiddleCenter;
                _scoreValue.color = Color.white;
                UIFactory.Place(_scoreValue.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 16), new Vector2(320, 80));
            }
            else
            {
                _scoreValue.alignment = TextAnchor.MiddleLeft;
                _scoreValue.color = UIFactory.Gold;
                UIFactory.Place(_scoreValue.rectTransform, new Vector2(0f, 0.5f), new Vector2(116f, 2f), new Vector2(214f, 90f));
            }
            _scoreValue.transform.localScale = Vector3.one;
            _centerValue.transform.localScale = Vector3.one;
            _centerValue.color = Color.white;
            _punchText = level ? _scoreValue : _centerValue;

            for (int i = _goalsBar.childCount - 1; i >= 0; i--)
            {
                var ch = _goalsBar.GetChild(i);
                ch.SetParent(null, false);
                Destroy(ch.gameObject);
            }
            _goalItems.Clear();
            if (level && ctrl.Level.goals != null)
            {
                foreach (var g in ctrl.Level.goals)
                    _goalItems.Add(BuildGoalItem(g));
            }
        }

        GoalItem BuildGoalItem(GoalData g)
        {
            var item = new GoalItem { goal = g };
            var root = UIFactory.Rect("Goal_" + g.type, _goalsBar);
            root.sizeDelta = new Vector2(210, 110);

            string sprite;
            Color tint = Color.white;
            switch (g.type)
            {
                case "color": sprite = "block_" + Mathf.Clamp(g.color, 0, 4); break;
                case "bomb": sprite = "icon_bomb"; break;
                case "lightning": sprite = "icon_lightning"; break;
                case "score": sprite = "star"; tint = UIFactory.Gold; break;
                default: sprite = "cell"; tint = new Color(1, 1, 1, 0.85f); break;
            }
            UnityEngine.UI.Image icon;
            if (g.type == "color")
            {
                icon = UIFactory.BlockIcon("Icon", root, Mathf.Clamp(g.color, 0, 4), 84);
                UIFactory.Place(icon.rectTransform, new Vector2(0, 0.5f), new Vector2(4, 0), new Vector2(84, 84));
            }
            else
            {
                icon = UIFactory.Image("Icon", root, sprite, tint);
                UIFactory.Place(icon.rectTransform, new Vector2(0, 0.5f), new Vector2(4, 0), new Vector2(84, 84));
            }

            item.count = UIFactory.Text("Count", root, "0", g.type == "score" ? 44 : 54, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(item.count.rectTransform, new Vector2(0, 0.5f), new Vector2(98, 0), new Vector2(116, 90));
            UIFactory.AddShadow(item.count, 3f, 0.4f);

            item.check = UIFactory.Image("Check", root, "icon_check", UIFactory.Green);
            UIFactory.Place(item.check.rectTransform, new Vector2(0, 0.5f), new Vector2(110, 0), new Vector2(70, 70));
            item.check.gameObject.SetActive(false);
            return item;
        }

        public void UpdateHUD(GameController ctrl)
        {
            if (ctrl.Score != _lastScore)
            {
                _scorePunch = 1f;
                _lastScore = ctrl.Score;
            }
            if (ctrl.Mode == GameMode.Level)
            {
                _scoreValue.text = ctrl.Score.ToString();
                _centerValue.text = ctrl.MovesLeft.ToString();
                _centerValue.color = ctrl.MovesLeft <= 3 ? UIFactory.Red : Color.white;
                foreach (var gi in _goalItems)
                {
                    int rem = ctrl.GoalRemaining(gi.goal);
                    bool done = rem <= 0;
                    gi.count.gameObject.SetActive(!done);
                    gi.check.gameObject.SetActive(done);
                    gi.count.text = rem.ToString();
                }
            }
            else
            {
                // Sol: rekor (oyun içinde geçilirse canlı olarak güncellenir), orta: güncel skor
                _scoreValue.text = Mathf.Max(SaveSystem.BestEndless, ctrl.Score).ToString();
                _centerValue.text = ctrl.Score.ToString();
                // Rekor geçildiği an güncel skor da altına döner
                _centerValue.color = ctrl.Score > SaveSystem.BestEndless && SaveSystem.BestEndless > 0 ? UIFactory.Gold : Color.white;
            }
        }

        // ---------------------------------------------------------------- Pause

        RectTransform Overlay(string name, out RectTransform panel, Vector2 size, bool dismissOnBackdrop = false)
        {
            var root = UIFactory.Rect(name, _canvas.transform);
            UIFactory.Stretch(root);
            var dim = UIFactory.Image("Dim", root, "square", new Color(0.03f, 0.01f, 0.08f, 0.72f), false, true);
            dim.preserveAspect = false;
            UIFactory.Stretch(dim.rectTransform);
            if (dismissOnBackdrop)
            {
                // Bilgi pencereleri: panelin dışına dokunmak kapatır (eylem gerektiren pencerelerde kapalı)
                var close = dim.gameObject.AddComponent<UnityEngine.UI.Button>();
                close.transition = UnityEngine.UI.Selectable.Transition.None;
                close.onClick.AddListener(() => root.gameObject.SetActive(false));
            }
            var p = UIFactory.Panel("Panel", root, UIFactory.PanelSolid, true);
            UIFactory.Place(p.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, size);
            panel = p.rectTransform;
            root.gameObject.SetActive(false);
            return root;
        }

        // ---------------------------------------------------------------- Günlük seri

        RectTransform _streakPopup;
        UnityEngine.UI.Text _streakDays, _streakMsg, _streakGoal, _streakGoalValue, _streakBest;
        UnityEngine.UI.Image _streakGoalFill;
        RectTransform _streakFlame;
        StreakDay[] _streakWeek;
        Coroutine _streakAnim;

        /// <summary>Seri penceresinin tek vurgu rengi (alevle aynı aile): tamamlanan günler, hedef çubuğu, etiket.</summary>
        static readonly Color StreakAccent = new Color(1f, 0.55f, 0.15f);
        static readonly int[] StreakMilestones = { 3, 7, 14, 30, 60, 100, 180, 365 };
        static readonly string[] WeekLetters = { "M", "T", "W", "T", "F", "S", "S" };

        class StreakDay
        {
            public UnityEngine.UI.Text letter;
            public UnityEngine.UI.Image circle, ring, check, flame;
        }

        /// <summary>
        /// Günlük seri penceresi: ışık halesi içinde süzülen alev, büyük gün sayısı, bu haftanın günleri
        /// (tamamlanan günler işaretli, bugün halkalı), bir sonraki hedefe ilerleme ve en iyi seri.
        /// </summary>
        void BuildStreakPopup()
        {
            const float pw = 860f, ph = 1180f;
            _streakPopup = Overlay("StreakPopup", out var panel, new Vector2(pw, ph), true);

            // Alev ve arkasındaki nefes alan ışık halesi
            var glow = UIFactory.Image("Glow", panel, null, new Color(1f, 0.47f, 0.12f, 0.55f));
            glow.sprite = SpriteLibrary.SoftGlow();
            glow.raycastTarget = false;
            UIFactory.Place(glow.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, 60f), new Vector2(560f, 560f));
            glow.gameObject.AddComponent<UIBreathe>();
            var flame = UIFactory.Image("Flame", panel, null, Color.white);
            flame.sprite = IconLibrary.Flame();
            flame.preserveAspect = true;
            flame.raycastTarget = false;
            UIFactory.Place(flame.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -50f), new Vector2(280f, 280f));
            _streakFlame = flame.rectTransform;

            _streakDays = UIFactory.Text("Days", panel, "1", 170, Color.white);
            UIFactory.Place(_streakDays.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -310f), new Vector2(700f, 180f));
            UIFactory.AddShadow(_streakDays, 7f, 0.4f);
            var lbl = UIFactory.Text("Label", panel, "DAY STREAK", 46, StreakAccent);
            UIFactory.Place(lbl.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -470f), new Vector2(700f, 60f));
            _streakMsg = UIFactory.Text("Message", panel, "", 32, UIFactory.TextSecondary);
            UIFactory.Place(_streakMsg.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -532f), new Vector2(780f, 48f));

            // Bu hafta (Pazartesi → Pazar)
            var week = UIFactory.Panel("Week", panel, new Color(0f, 0f, 0f, 0.30f));
            UIFactory.Place(week.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -610f), new Vector2(pw - 80f, 190f));
            _streakWeek = new StreakDay[7];
            float colW = (pw - 80f) / 7f;
            for (int d = 0; d < 7; d++)
            {
                var cell = UIFactory.Rect("Day" + d, week.transform);
                UIFactory.Place(cell, new Vector2(0f, 1f), new Vector2(colW * d, 0f), new Vector2(colW, 190f));
                var sd = new StreakDay();
                sd.letter = UIFactory.Text("Letter", cell, WeekLetters[d], 28, UIFactory.TextSecondary);
                int day = d;
                Loc.Bind(sd.letter, () => Loc.WeekLetters()[day]);
                UIFactory.Place(sd.letter.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -20f), new Vector2(colW, 40f));
                sd.ring = UIFactory.Image("Ring", cell, "ring", StreakAccent);
                UIFactory.Place(sd.ring.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -68f), new Vector2(92f, 92f));
                sd.circle = UIFactory.Image("Circle", cell, "circle", Color.white);
                UIFactory.Place(sd.circle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -74f), new Vector2(80f, 80f));
                sd.check = UIFactory.Image("Check", sd.circle.transform, "icon_check", Color.white);
                UIFactory.Place(sd.check.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(40f, 40f));
                sd.flame = UIFactory.Image("Flame", sd.circle.transform, null, Color.white);
                sd.flame.sprite = IconLibrary.Flame();
                sd.flame.preserveAspect = true;
                UIFactory.Place(sd.flame.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0f, 2f), new Vector2(54f, 54f));
                _streakWeek[d] = sd;
            }

            // Sıradaki hedef
            _streakGoal = UIFactory.Text("Goal", panel, "", 30, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(_streakGoal.rectTransform, new Vector2(0f, 1f), new Vector2(50f, -838f), new Vector2(560f, 44f));
            _streakGoalValue = UIFactory.Text("GoalValue", panel, "", 30, UIFactory.TextSecondary, TextAnchor.MiddleRight);
            UIFactory.Place(_streakGoalValue.rectTransform, new Vector2(1f, 1f), new Vector2(-50f, -838f), new Vector2(240f, 44f));
            var track = UIFactory.Pill("GoalTrack", panel, new Color(0f, 0f, 0f, 0.38f), 22f);
            UIFactory.Place(track.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -895f), new Vector2(pw - 100f, 22f));
            _streakGoalFill = UIFactory.Pill("Fill", track.transform, StreakAccent, 22f);
            var frt = _streakGoalFill.rectTransform;
            frt.anchorMin = Vector2.zero; frt.anchorMax = new Vector2(0f, 1f);
            frt.offsetMin = Vector2.zero; frt.offsetMax = Vector2.zero;

            _streakBest = UIFactory.Text("Best", panel, "", 28, UIFactory.TextSecondary);
            UIFactory.Place(_streakBest.rectTransform, new Vector2(0.5f, 1f), new Vector2(0f, -946f), new Vector2(760f, 44f));

            var ok = UIFactory.Button("OK", panel, "CONTINUE", UIFactory.Green, new Vector2(520, 130), 52, () => _streakPopup.gameObject.SetActive(false));
            UIFactory.Place(ok.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0f, 50f), new Vector2(520, 130));
        }

        /// <param name="celebrate">Yeni günün ilk açılışı: sayı dünden bugüne sayar, bugünün dairesi belirir.</param>
        void ShowStreakPopup(bool celebrate = false)
        {
            if (_streakPopup == null) BuildStreakPopup();
            int n = Mathf.Max(1, DailyStreak.Current);

            _streakMsg.text = Loc.T(!celebrate ? "Play every day to grow your streak."
                            : n == 1 ? "Your streak starts today. See you tomorrow!"
                            : "You're on fire! Keep it going tomorrow.");

            // Sıradaki kilometre taşı
            int next = 0;
            foreach (int m in StreakMilestones) if (m > n) { next = m; break; }
            if (next > 0)
            {
                _streakGoal.text = Loc.F("NEXT GOAL: {0} DAYS", next);
                _streakGoalValue.text = n + " / " + next;
                _streakGoalFill.rectTransform.anchorMax = new Vector2(Mathf.Clamp01(n / (float)next), 1f);
            }
            else
            {
                _streakGoal.text = Loc.T("LEGENDARY STREAK");
                _streakGoalValue.text = Loc.F("{0} DAYS", n);
                _streakGoalFill.rectTransform.anchorMax = Vector2.one;
            }
            int best = Mathf.Max(DailyStreak.Best, n);
            _streakBest.text = Loc.F(best == 1 ? "BEST STREAK  ·  {0} DAY" : "BEST STREAK  ·  {0} DAYS", best);

            SetStreakWeek(n, celebrate);
            _streakDays.text = (celebrate && n > 1 ? n - 1 : n).ToString();

            _streakPopup.gameObject.SetActive(true);
            _streakPopup.SetAsLastSibling();
            StartCoroutine(PopIn((RectTransform)_streakPopup.Find("Panel"), 0.3f));
            if (_streakAnim != null) StopCoroutine(_streakAnim);
            _streakAnim = StartCoroutine(StreakIntro(n, celebrate));
        }

        /// <summary>Bu haftanın günleri: serinin kapsadığı günler turuncu + onay, bugün halkalı + alev, kalanlar sönük.</summary>
        void SetStreakWeek(int n, bool hideToday)
        {
            var today = System.DateTime.Now.Date;
            int dow = ((int)today.DayOfWeek + 6) % 7; // Pazartesi = 0
            var monday = today.AddDays(-dow);
            var start = today.AddDays(-(n - 1));
            for (int d = 0; d < 7; d++)
            {
                var date = monday.AddDays(d);
                var sd = _streakWeek[d];
                bool isToday = date == today, covered = date >= start && date < today;
                sd.letter.color = isToday ? Color.white : UIFactory.TextSecondary;
                sd.ring.gameObject.SetActive(isToday);
                sd.check.gameObject.SetActive(covered);
                sd.flame.gameObject.SetActive(isToday);
                sd.circle.color = covered ? StreakAccent
                                : isToday ? new Color(1f, 0.55f, 0.15f, 0.20f) // koyu, sıcak tonlu cam: alev öne çıksın
                                : new Color(1f, 1f, 1f, 0.08f);
                sd.circle.transform.localScale = isToday && hideToday ? Vector3.zero : Vector3.one;
            }
        }

        IEnumerator StreakIntro(int n, bool celebrate)
        {
            if (!celebrate) { Haptics.Light(); yield break; }
            yield return new WaitForSecondsRealtime(0.35f);

            // Sayı dünden bugüne: kısa büyüme + titreşim
            _streakDays.text = n.ToString();
            Haptics.Medium();
            float t = 0f;
            while (t < 0.35f)
            {
                t += Time.unscaledDeltaTime;
                float k = Mathf.Sin(Mathf.Clamp01(t / 0.35f) * Mathf.PI);
                float sc = 1f + 0.22f * k;
                _streakDays.transform.localScale = new Vector3(sc, sc, 1f);
                _streakFlame.localScale = new Vector3(1f + 0.12f * k, 1f + 0.12f * k, 1f);
                yield return null;
            }
            _streakDays.transform.localScale = Vector3.one;
            _streakFlame.localScale = Vector3.one;

            // Bugünün dairesi yaylanarak belirir
            int dow = ((int)System.DateTime.Now.DayOfWeek + 6) % 7;
            var c = _streakWeek[dow].circle.transform;
            t = 0f;
            while (t < 0.4f)
            {
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / 0.4f);
                // 0 → 1.18 (taşma) → 1: yaylanarak oturma
                float sc = k < 0.6f ? Mathf.Lerp(0f, 1.18f, k / 0.6f) : Mathf.Lerp(1.18f, 1f, (k - 0.6f) / 0.4f);
                c.localScale = new Vector3(sc, sc, 1f);
                yield return null;
            }
            c.localScale = Vector3.one;
            Haptics.Light();
        }

        // ---------------------------------------------------------------- Reklam kaldırma

        RectTransform _removeAds;
        UnityEngine.UI.Button _removeAdsBuy;

        void RefreshNoAds()
        {
            bool removed = SaveSystem.AdsRemoved;
            _menuNoAds.gameObject.SetActive(!removed);
        }

        void ShowRemoveAds()
        {
            if (_removeAds == null)
            {
                _removeAds = Overlay("RemoveAds", out var panel, new Vector2(840, 900), true);
                var t = UIFactory.Text("Title", panel, "REMOVE ADS", 72, Color.white);
                UIFactory.Place(t.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -70), new Vector2(760, 100));
                UIFactory.FitText(t, 48);
                UIFactory.AddShadow(t, 6f, 0.45f);

                var body = UIFactory.Text("Body", panel, "", 36, Color.white);
                Loc.Bind(body, () => Loc.T("No more banners or ads between games.\nOne-time purchase, yours forever.")
                    + "\n\n<color=#FFD95A>" + Loc.F("+{0} ENERGY bonus included!", _s.removeAdsEnergyBonus) + "</color>"
                    + "\n\n<color=#FFFFFFA8>" + Loc.T("Revive ads stay available — they're always your choice.") + "</color>");
                UIFactory.Place(body.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -190), new Vector2(740, 300));
                body.lineSpacing = 1.1f;
                UIFactory.FitText(body, 26);

                _removeAdsBuy = UIFactory.Button("Buy", panel, "BUY", UIFactory.Green, new Vector2(600, 150), 58, BuyRemoveAds);
                UIFactory.Place(_removeAdsBuy.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 230), new Vector2(600, 150));

                // App Store kuralı: önceki satın almayı geri yükleme yolu görünür olmalı
                var restore = UIFactory.Text("Restore", panel, "Restore purchase", 32, UIFactory.TextSecondary);
                restore.raycastTarget = true;
                UIFactory.Place(restore.rectTransform, new Vector2(0.5f, 0f), new Vector2(0, 150), new Vector2(500, 60));
                var rb = restore.gameObject.AddComponent<UnityEngine.UI.Button>();
                rb.transition = UnityEngine.UI.Selectable.Transition.None;
                rb.onClick.AddListener(RestorePurchase);

                var close = UIFactory.Button("Close", panel, "NOT NOW", new Color(1f, 1f, 1f, 0.16f), new Vector2(360, 100), 36,
                    () => _removeAds.gameObject.SetActive(false));
                UIFactory.ApplyGlassSkin(close.GetComponent<UnityEngine.UI.Image>(), 100f);
                UIFactory.Place(close.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 40), new Vector2(360, 100));
            }
            UIFactory.SetLabel(_removeAdsBuy, Loc.F("BUY  {0}", StoreHooks.PriceLabel));
            _removeAdsBuy.interactable = true;
            _removeAds.gameObject.SetActive(true);
            _removeAds.SetAsLastSibling();
            StartCoroutine(PopIn((RectTransform)_removeAds.Find("Panel"), 0.25f));
        }

        void BuyRemoveAds()
        {
            _removeAdsBuy.interactable = false; // çift dokunuşla iki satın alma başlamasın
            StoreHooks.PurchaseRemoveAds("menu", OnAdsRemoved, msg =>
            {
                _removeAdsBuy.interactable = true;
                if (!string.IsNullOrEmpty(msg)) Toast(msg, 1.6f);
            });
        }

        void RestorePurchase()
        {
            StoreHooks.Restore(found =>
            {
                if (found) OnAdsRemoved();
                else Toast("NO PURCHASE FOUND", 1.6f);
            });
        }

        void OnAdsRemoved()
        {
            SaveSystem.AdsRemoved = true;
            bool bonus = Energy.GrantRemoveAdsBonus(); // Restore tekrar bonus vermez
            AdHooks.SetBannerVisible(false);
            if (_removeAds != null) _removeAds.gameObject.SetActive(false);
            if (_menu.gameObject.activeSelf) RefreshNoAds();
            RefreshEnergyUI();
            Haptics.Success();
            Toast(bonus ? Loc.F("ADS REMOVED + {0} ENERGY!", _s.removeAdsEnergyBonus) : "ADS REMOVED. THANK YOU!", 2f);
            ContinuePendingIfPossible();
        }

        // ---------------------------------------------------------------- Enerji

        RectTransform _energyPopup;
        UnityEngine.UI.Text _energyTitle, _energyCount, _energyNext;
        UnityEngine.UI.Button _energyAdBtn, _energyBuyBtn;
        System.Action _energyPending; // enerji bulununca kaldığı yerden başlatılacak oyun

        void ClickSound()
        {
            var sm = SoundManager.Instance;
            if (sm != null) sm.PlayFrom(_s.sfxButton, 1f, 0.8f);
            Haptics.Light();
        }

        /// <summary>Enerji varsa oyunu başlatır; yoksa enerji penceresini açar (enerji bulunca oyun kendiliğinden başlar).</summary>
        /// <summary>needs false ise (ör. enerji harcamayan Classic) doğrudan başlatır.</summary>
        void WithEnergyIf(bool needs, System.Action start)
        {
            if (needs) WithEnergy(start); else start?.Invoke();
        }

        void WithEnergy(System.Action start)
        {
            if (Energy.CanPlay) { start?.Invoke(); return; }
            Analytics.EnergyEmpty(Energy.TimeToNext.TotalMinutes); // oyuncu enerjisizlikle karşılaştı: churn riski
            Haptics.Error();
            ShowEnergy(start);
        }

        void ShowEnergy(System.Action pending)
        {
            _energyPending = pending;
            if (_energyPopup == null) BuildEnergyPopup();
            RefreshEnergyUI();
            _energyPopup.gameObject.SetActive(true);
            _energyPopup.SetAsLastSibling();
            StartCoroutine(PopIn((RectTransform)_energyPopup.Find("Panel"), 0.25f));
        }

        void CloseEnergy()
        {
            _energyPending = null;
            if (_energyPopup != null) _energyPopup.gameObject.SetActive(false);
        }

        // Pencere ölçüleri: öğeler üstten aşağı dizilir, yükseklik görünen butonlara göre ayarlanır
        const float EnergyPanelW = 760f, EnergyBtnW = 640f, EnergyBtnH = 140f, EnergyGap = 22f, EnergyPad = 44f;
        RectTransform _energyPanel, _energyClose;

        /// <summary>
        /// Enerji simgesi + arkasında sarı↔turuncu nefes alan ışıma. Simgenin kendisi sabit durur.
        /// Sprite: IconLibrary.Energy() (GameSettings > Energy Icon ya da icon_energy.png; yoksa çizilen şimşek).
        /// </summary>
        RectTransform EnergyIcon(Transform parent, float size)
        {
            var holder = UIFactory.Rect("EnergyIcon", parent);
            holder.sizeDelta = new Vector2(size, size);

            var glow = UIFactory.Image("Glow", holder, null, new Color(1f, 0.8f, 0.25f, 0.6f));
            glow.sprite = SpriteLibrary.SoftGlow();
            glow.raycastTarget = false;
            UIFactory.Place(glow.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(size * 1.9f, size * 1.9f));
            glow.gameObject.AddComponent<UIGlowPulse>();

            var img = UIFactory.Image("Icon", holder, null, Color.white);
            img.sprite = IconLibrary.Energy();
            img.preserveAspect = true;
            img.raycastTarget = false;
            UIFactory.Stretch(img.rectTransform);
            return holder;
        }

        void BuildEnergyPopup()
        {
            _energyPopup = Overlay("EnergyPopup", out var panel, new Vector2(EnergyPanelW, 800), true);
            _energyPanel = panel;
            // Arka plana dokununca kapanınca bekleyen oyun da iptal olsun
            _energyPopup.Find("Dim").GetComponent<UnityEngine.UI.Button>().onClick.AddListener(() => _energyPending = null);

            _energyTitle = UIFactory.Text("Title", panel, "ENERGY", 68, Color.white);
            UIFactory.Place(_energyTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -EnergyPad), new Vector2(680, 90));
            UIFactory.FitText(_energyTitle, 44);
            UIFactory.AddShadow(_energyTitle, 6f, 0.45f);

            // Simge + sayı yan yana, tek satır
            var row = UIFactory.Rect("Row", panel);
            UIFactory.Place(row, new Vector2(0.5f, 1f), new Vector2(0, -150), new Vector2(420, 130));
            var icon = EnergyIcon(row, 130f);
            UIFactory.Place(icon, new Vector2(0f, 0.5f), new Vector2(20, 0), new Vector2(130, 130));
            _energyCount = UIFactory.Text("Count", row, "0 / 5", 80, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(_energyCount.rectTransform, new Vector2(0f, 0.5f), new Vector2(170, 0), new Vector2(250, 110));
            UIFactory.FitText(_energyCount, 48);
            UIFactory.AddShadow(_energyCount, 5f, 0.4f);

            _energyNext = UIFactory.Text("Next", panel, "", 36, UIFactory.TextDim);
            UIFactory.Place(_energyNext.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -292), new Vector2(680, 50));

            _energyAdBtn = UIFactory.Button("WatchAd", panel, "WATCH AD", UIFactory.Green, new Vector2(EnergyBtnW, EnergyBtnH), 50, WatchAdForEnergy);
            _energyBuyBtn = UIFactory.Button("Buy", panel, "NO ADS", UIFactory.Orange, new Vector2(EnergyBtnW, EnergyBtnH), 44, BuyFromEnergy);
            var close = UIFactory.Button("Close", panel, "NOT NOW", new Color(1f, 1f, 1f, 0.16f), new Vector2(340, 100), 36, CloseEnergy);
            UIFactory.ApplyGlassSkin(close.GetComponent<UnityEngine.UI.Image>(), 100f);
            _energyClose = close.GetComponent<RectTransform>();
        }

        /// <summary>Butonları üstten sırayla dizer ve pencere yüksekliğini içeriğe göre ayarlar.</summary>
        void LayoutEnergyPopup()
        {
            float y = 292f + 50f + 34f; // "+1 energy in" satırının altı + boşluk
            foreach (var b in new[] { _energyAdBtn, _energyBuyBtn })
            {
                if (!b.gameObject.activeSelf) continue;
                UIFactory.Place(b.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0, -y), new Vector2(EnergyBtnW, EnergyBtnH));
                y += EnergyBtnH + EnergyGap;
            }
            y += 8f;
            UIFactory.Place(_energyClose, new Vector2(0.5f, 1f), new Vector2(0, -y), new Vector2(340, 100));
            y += 100f + EnergyPad;
            _energyPanel.sizeDelta = new Vector2(EnergyPanelW, y);
        }

        int _uiEnergy = -1;
        bool _uiEnergyAds, _uiEnergyEnabled;
        string _uiEnergyNext;

        /// <param name="timerOnly">
        /// Periyodik çağrı (saniyede 4 kez). PERFORMANS: değer değişmediyse hiçbir şeye dokunmaz; yalnızca sayaç
        /// değiştiyse sadece sayaç yazılarını günceller. Pencere yerleşimi, buton etiketleri ve metin sığdırma yalnızca
        /// enerji miktarı / satın alma durumu değişince yeniden yapılır (önceden saniyede 4 kez yapılıyordu).
        /// </param>
        void RefreshEnergyUI(bool timerOnly = false)
        {
            int e = Energy.Current;
            bool full = e >= Energy.Max;
            string next = full ? Loc.T("FULL") : Energy.TimeToNextLabel;
            bool ads = SaveSystem.AdsRemoved;
            bool enabled = Energy.Enabled;

            if (timerOnly && e == _uiEnergy && ads == _uiEnergyAds && enabled == _uiEnergyEnabled)
            {
                if (next == _uiEnergyNext) return;
                _uiEnergyNext = next;
                if (_menuEnergyTimer != null) _menuEnergyTimer.text = next;
                if (_energyNext != null) _energyNext.text = full ? Loc.T("Energy is full") : Loc.F("+1 energy in {0}", next);
                return;
            }
            _uiEnergy = e;
            _uiEnergyAds = ads;
            _uiEnergyEnabled = enabled;
            _uiEnergyNext = next;

            if (_menuEnergy != null)
            {
                _menuEnergyChip.gameObject.SetActive(Energy.Enabled);
                _menuEnergy.text = e.ToString();
                _menuEnergyTimer.text = next;
            }

            if (_energyPopup == null) return;
            _energyTitle.text = Loc.T(e <= 0 ? "OUT OF ENERGY" : "ENERGY");
            _energyCount.text = e + " / " + Energy.Max;
            _energyNext.text = full ? Loc.T("Energy is full") : Loc.F("+1 energy in {0}", next);
            _energyAdBtn.gameObject.SetActive(!full);
            UIFactory.SetLabel(_energyAdBtn, Loc.F("WATCH AD  +{0}", _s.energyFromAd));
            _energyBuyBtn.gameObject.SetActive(!SaveSystem.AdsRemoved);
            var buyLabel = UIFactory.SetLabel(_energyBuyBtn, Loc.F("NO ADS + {0} ENERGY  {1}", _s.removeAdsEnergyBonus, StoreHooks.PriceLabel));
            UIFactory.FitText(buyLabel, 28);
            LayoutEnergyPopup();
        }

        void WatchAdForEnergy()
        {
            ClickSound();
            _energyAdBtn.interactable = false; // çift dokunuşla iki reklam açılmasın
            AdHooks.Rewarded("energy", () =>
            {
                _energyAdBtn.interactable = true;
                Energy.Add(_s.energyFromAd);
                Haptics.Success();
                Toast(Loc.F("+{0} ENERGY", _s.energyFromAd), 1.4f);
                RefreshEnergyUI();
                ContinuePendingIfPossible();
            }, () =>
            {
                _energyAdBtn.interactable = true;
                Toast("AD NOT AVAILABLE", 1.6f);
            });
        }

        void BuyFromEnergy()
        {
            ClickSound();
            _energyBuyBtn.interactable = false;
            StoreHooks.PurchaseRemoveAds("energy_popup", () =>
            {
                _energyBuyBtn.interactable = true;
                OnAdsRemoved();
            }, msg =>
            {
                _energyBuyBtn.interactable = true;
                if (!string.IsNullOrEmpty(msg)) Toast(msg, 1.6f);
            });
        }

        /// <summary>Enerji kazanıldıysa pencereyi kapatıp bekleyen oyunu başlatır.</summary>
        void ContinuePendingIfPossible()
        {
            if (_energyPending == null || !Energy.CanPlay) return;
            var start = _energyPending;
            CloseEnergy();
            start();
        }

        // ---------------------------------------------------------------- Değerlendirme isteği

        RectTransform _rate, _ratePageAsk, _ratePageFeedback;
        System.Action _rateNext;

        /// <summary>"Oyunu beğendin mi?" → Evet: mağaza değerlendirmesi. Hayır: geri bildirim (mağazaya yönlendirmeden).</summary>
        void ShowRatePrompt(System.Action next)
        {
            _rateNext = next;
            if (_rate == null)
            {
                _rate = Overlay("Rate", out var panel, new Vector2(840, 760), false);

                _ratePageAsk = UIFactory.Rect("Ask", panel);
                UIFactory.Stretch(_ratePageAsk);
                var heart = UIFactory.Image("Star", _ratePageAsk, "star", UIFactory.Gold);
                UIFactory.Place(heart.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -60), new Vector2(150, 150));
                heart.gameObject.AddComponent<UIBob>().amplitude = 6f;
                var q = UIFactory.Text("Question", _ratePageAsk, "ENJOYING BLOCK RISE?", 60, Color.white);
                UIFactory.Place(q.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -240), new Vector2(760, 90));
                UIFactory.FitText(q, 40);
                UIFactory.AddShadow(q, 5f, 0.45f);
                var sub = UIFactory.Text("Sub", _ratePageAsk, "Your opinion helps us make the game better.", 32, UIFactory.TextSecondary);
                UIFactory.Place(sub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -335), new Vector2(760, 50));
                UIFactory.FitText(sub, 24);
                var yes = UIFactory.Button("Yes", _ratePageAsk, "YES, I LOVE IT!", UIFactory.Green, new Vector2(620, 140), 50, () =>
                {
                    Rating.RequestReview();
                    CloseRate();
                });
                UIFactory.Place(yes.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 170), new Vector2(620, 140));
                var no = UIFactory.Button("No", _ratePageAsk, "NOT REALLY", new Color(1f, 1f, 1f, 0.16f), new Vector2(420, 100), 36, () =>
                {
                    if (string.IsNullOrEmpty(_s.feedbackEmail)) { Toast("THANKS FOR YOUR FEEDBACK!", 1.6f); CloseRate(); return; }
                    _ratePageAsk.gameObject.SetActive(false);
                    _ratePageFeedback.gameObject.SetActive(true);
                });
                UIFactory.ApplyGlassSkin(no.GetComponent<UnityEngine.UI.Image>(), 100f);
                UIFactory.Place(no.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 45), new Vector2(420, 100));

                _ratePageFeedback = UIFactory.Rect("Feedback", panel);
                UIFactory.Stretch(_ratePageFeedback);
                var ft = UIFactory.Text("Title", _ratePageFeedback, "SORRY TO HEAR THAT", 58, Color.white);
                UIFactory.Place(ft.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -90), new Vector2(760, 90));
                UIFactory.FitText(ft, 40);
                UIFactory.AddShadow(ft, 5f, 0.45f);
                var fb = UIFactory.Text("Body", _ratePageFeedback, "Tell us what we can improve.\nWe read every message.", 36, UIFactory.TextSecondary);
                UIFactory.Place(fb.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -210), new Vector2(760, 120));
                fb.lineSpacing = 1.1f;
                UIFactory.FitText(fb, 26);
                var send = UIFactory.Button("Send", _ratePageFeedback, "SEND FEEDBACK", UIFactory.Blue, new Vector2(620, 140), 50, () =>
                {
                    Rating.SendFeedback();
                    CloseRate();
                });
                UIFactory.Place(send.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 170), new Vector2(620, 140));
                var later = UIFactory.Button("Close", _ratePageFeedback, "NO THANKS", new Color(1f, 1f, 1f, 0.16f), new Vector2(420, 100), 36, CloseRate);
                UIFactory.ApplyGlassSkin(later.GetComponent<UnityEngine.UI.Image>(), 100f);
                UIFactory.Place(later.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 45), new Vector2(420, 100));
            }
            _ratePageAsk.gameObject.SetActive(true);
            _ratePageFeedback.gameObject.SetActive(false);
            _rate.gameObject.SetActive(true);
            _rate.SetAsLastSibling();
            StartCoroutine(PopIn((RectTransform)_rate.Find("Panel"), 0.3f));
        }

        void CloseRate()
        {
            _rate.gameObject.SetActive(false);
            var next = _rateNext;
            _rateNext = null;
            next?.Invoke();
        }

        // ---------------------------------------------------------------- Madalyalar

        RectTransform _medals, _medalsContent;
        UnityEngine.UI.Text _medalsCount;

        void BuildMedals()
        {
            _medals = Screen_("Medals");
            var header = BuildScreenHeader(_medals, "MEDALS");
            _medalsCount = UIFactory.Text("Count", header, "", 40, UIFactory.Gold, TextAnchor.MiddleRight);
            UIFactory.Place(_medalsCount.rectTransform, new Vector2(1, 0.5f), Vector2.zero, new Vector2(220, 80));

            var scroll = UIFactory.Rect("ScrollView", _medals);
            UIFactory.Stretch(scroll, 30, 30, 190, 40);
            var sr = scroll.gameObject.AddComponent<UnityEngine.UI.ScrollRect>();
            sr.horizontal = false;
            var vp = UIFactory.Image("Viewport", scroll, "square", new Color(1f, 1f, 1f, 0f), false, true);
            vp.preserveAspect = false;
            UIFactory.Stretch(vp.rectTransform);
            vp.gameObject.AddComponent<UnityEngine.UI.RectMask2D>();
            _medalsContent = UIFactory.Rect("Content", vp.transform);
            _medalsContent.anchorMin = new Vector2(0, 1); _medalsContent.anchorMax = new Vector2(1, 1); _medalsContent.pivot = new Vector2(0.5f, 1);
            _medalsContent.anchoredPosition = Vector2.zero;
            sr.viewport = vp.rectTransform;
            sr.content = _medalsContent;
        }

        void ShowMedals()
        {
            if (_medals == null) BuildMedals();
            HideAll();
            _medals.gameObject.SetActive(true);
            for (int i = _medalsContent.childCount - 1; i >= 0; i--)
            {
                var ch = _medalsContent.GetChild(i);
                ch.SetParent(null, false);
                Destroy(ch.gameObject);
            }

            const float gap = 22f;
            float y = 0f;

            // ---- Özet: kademe başına kazanılan madalya + genel ilerleme
            int[] perTier = new int[3];
            foreach (var d in Achievements.All)
                for (int k = 0; k < Achievements.Tier(d.id); k++) perTier[k]++;
            int total = Achievements.TotalTiers(), max = Achievements.All.Length * 3;

            var summary = UIFactory.Panel("Summary", _medalsContent, new Color(0f, 0f, 0f, 0.34f));
            var srt = summary.rectTransform;
            srt.anchorMin = new Vector2(0f, 1f); srt.anchorMax = new Vector2(1f, 1f); srt.pivot = new Vector2(0.5f, 1f);
            srt.anchoredPosition = Vector2.zero;
            srt.sizeDelta = new Vector2(0f, 250f);
            for (int k = 0; k < 3; k++)
            {
                var col = UIFactory.Rect("Tier" + k, summary.transform);
                UIFactory.Place(col, new Vector2((k + 0.5f) / 3f, 1f), new Vector2(0f, -24f), new Vector2(280f, 130f));
                var m = UIFactory.Image("Medal", col, null, perTier[k] > 0 ? Achievements.TierColors[k] : Achievements.LockedColor);
                m.sprite = IconLibrary.Medal();
                m.preserveAspect = true;
                UIFactory.Place(m.rectTransform, new Vector2(0f, 0.5f), new Vector2(40f, 0f), new Vector2(100f, 100f));
                var n = UIFactory.Text("Count", col, perTier[k].ToString(), 64, Color.white, TextAnchor.MiddleLeft);
                UIFactory.Place(n.rectTransform, new Vector2(0f, 0.5f), new Vector2(150f, 10f), new Vector2(130f, 80f));
                UIFactory.AddShadow(n, 4f, 0.4f);
                var lbl = UIFactory.Text("Label", col, Loc.T(Achievements.TierNames[k]), 24, UIFactory.TextSecondary, TextAnchor.MiddleLeft);
                UIFactory.Place(lbl.rectTransform, new Vector2(0f, 0.5f), new Vector2(150f, -38f), new Vector2(130f, 32f));
            }
            AddProgressBar(summary.transform, total, max, Achievements.TierColors[2], 40f, 34f, 22f, total + " / " + max);
            y += 250f + gap * 1.5f;

            // ---- Madalya kartları
            const float cardH = 210f;
            foreach (var d in Achievements.All)
            {
                int tier = Achievements.Tier(d.id);
                long val = Achievements.Value(d.id);
                bool maxed = tier >= 3;
                var card = UIFactory.Panel(d.id, _medalsContent, maxed ? new Color(0.30f, 0.22f, 0.04f, 0.42f) : new Color(0f, 0f, 0f, 0.28f));
                var rt = card.rectTransform;
                rt.anchorMin = new Vector2(0f, 1f); rt.anchorMax = new Vector2(1f, 1f); rt.pivot = new Vector2(0.5f, 1f);
                rt.anchoredPosition = new Vector2(0f, -y);
                rt.sizeDelta = new Vector2(0f, cardH);
                y += cardH + gap;

                // En yüksek kazanılan kademenin madalyası; hiç yoksa sönük
                var icon = UIFactory.Image("Medal", card.transform, null, tier > 0 ? Achievements.TierColors[tier - 1] : new Color(1f, 1f, 1f, 0.14f));
                icon.sprite = IconLibrary.Medal();
                icon.preserveAspect = true;
                UIFactory.Place(icon.rectTransform, new Vector2(0f, 0.5f), new Vector2(28f, 0f), new Vector2(140f, 140f));

                var t = UIFactory.Text("Title", card.transform, Loc.Upper(Loc.T(d.title)), 44, maxed ? UIFactory.Gold : Color.white, TextAnchor.MiddleLeft);
                UIFactory.Place(t.rectTransform, new Vector2(0f, 1f), new Vector2(196f, -26f), new Vector2(520f, 58f));
                UIFactory.AddShadow(t, 4f, 0.35f);

                int next = Mathf.Min(tier, 2);
                string desc = maxed ? Loc.T("All three medals earned") : Loc.F(d.format, d.tiers[next].ToString("N0"));
                var ds = UIFactory.Text("Desc", card.transform, desc, 31, UIFactory.TextSecondary, TextAnchor.MiddleLeft);
                UIFactory.Place(ds.rectTransform, new Vector2(0f, 1f), new Vector2(196f, -84f), new Vector2(740f, 44f));

                // Sağ üst: üç kademe noktası (bronz, gümüş, altın)
                for (int k = 0; k < 3; k++)
                {
                    var pip = UIFactory.Image("Tier" + k, card.transform, null, k < tier ? Achievements.TierColors[k] : new Color(1f, 1f, 1f, 0.12f));
                    pip.sprite = IconLibrary.Medal();
                    pip.preserveAspect = true;
                    UIFactory.Place(pip.rectTransform, new Vector2(1f, 1f), new Vector2(-26f - (2 - k) * 52f, -24f), new Vector2(46f, 46f));
                }

                // Alt: sıradaki kademeye ilerleme (yuvarlak uçlu çubuk + "120 / 500")
                if (maxed)
                {
                    var done = UIFactory.Text("Done", card.transform, "COMPLETE", 30, UIFactory.Gold, TextAnchor.MiddleLeft);
                    UIFactory.Place(done.rectTransform, new Vector2(0f, 0f), new Vector2(196f, 26f), new Vector2(400f, 44f));
                }
                else
                {
                    long goal = d.tiers[next];
                    long shown = System.Math.Min(val, goal);
                    AddProgressBar(card.transform, shown, goal, Achievements.TierColors[next], 196f, 34f, 22f,
                        shown.ToString("N0") + " / " + goal.ToString("N0"));
                }
            }
            _medalsContent.sizeDelta = new Vector2(0f, y + 40f);
            _medalsCount.text = Achievements.TotalTiers() + "/" + (Achievements.All.Length * 3);
            StartCoroutine(PopIn(_medals, 0.2f));
        }

        /// <summary>Kartın altına yuvarlak uçlu ilerleme çubuğu ve sağında "x / y" metni ekler.</summary>
        void AddProgressBar(Transform parent, long value, long goal, Color color, float left, float bottom, float height, string label)
        {
            const float labelW = 220f, right = 30f;
            var track = UIFactory.Pill("Track", parent, new Color(0f, 0f, 0f, 0.38f), height);
            var trt = track.rectTransform;
            trt.anchorMin = new Vector2(0f, 0f); trt.anchorMax = new Vector2(1f, 0f); trt.pivot = new Vector2(0f, 0f);
            trt.offsetMin = new Vector2(left, bottom);
            trt.offsetMax = new Vector2(-(labelW + right + 16f), bottom + height);

            float frac = goal > 0 ? Mathf.Clamp01(value / (float)goal) : 1f;
            if (frac > 0f)
            {
                var fill = UIFactory.Pill("Fill", track.transform, color, height);
                var frt = fill.rectTransform;
                frt.anchorMin = Vector2.zero; frt.anchorMax = new Vector2(frac, 1f);
                frt.offsetMin = Vector2.zero; frt.offsetMax = Vector2.zero;
                // Çok kısa dolgu hap şeklini bozmasın: en az çubuk yüksekliği kadar genişlik
                if (frac < 0.06f) { frt.anchorMax = new Vector2(0f, 1f); frt.offsetMax = new Vector2(height, 0f); }
            }

            var txt = UIFactory.Text("Value", parent, label, 28, UIFactory.TextSecondary, TextAnchor.MiddleRight);
            var xrt = txt.rectTransform;
            xrt.anchorMin = new Vector2(1f, 0f); xrt.anchorMax = new Vector2(1f, 0f); xrt.pivot = new Vector2(1f, 0f);
            xrt.sizeDelta = new Vector2(labelW, height + 20f);
            xrt.anchoredPosition = new Vector2(-right, bottom - 10f);
        }

        // ---------------------------------------------------------------- Madalya bildirimi

        readonly Queue<KeyValuePair<Achievements.Def, int>> _medalQueue = new Queue<KeyValuePair<Achievements.Def, int>>();
        Coroutine _medalRoutine;
        RectTransform _medalToast;
        UnityEngine.UI.Image _medalToastIcon;
        UnityEngine.UI.Text _medalToastTitle, _medalToastSub;

        void OnMedalUnlocked(Achievements.Def d, int tier)
        {
            _medalQueue.Enqueue(new KeyValuePair<Achievements.Def, int>(d, tier));
            if (_medalRoutine == null) _medalRoutine = StartCoroutine(MedalToastRoutine());
        }

        void BuildMedalToast()
        {
            // Tüm pencerelerin üstünde görünsün diye doğrudan canvas'a (çentik payı gösterirken eklenir)
            var bg = UIFactory.Panel("MedalToast", _canvas.transform, new Color(0.08f, 0.09f, 0.18f, 0.94f));
            _medalToast = bg.rectTransform;
            _medalToast.anchorMin = _medalToast.anchorMax = new Vector2(0.5f, 1f);
            _medalToast.pivot = new Vector2(0.5f, 1f);
            _medalToast.sizeDelta = new Vector2(900f, 170f);
            var cg = bg.gameObject.AddComponent<CanvasGroup>();
            cg.blocksRaycasts = false;
            _medalToastIcon = UIFactory.Image("Medal", bg.transform, null, Color.white);
            _medalToastIcon.sprite = IconLibrary.Medal();
            _medalToastIcon.preserveAspect = true;
            UIFactory.Place(_medalToastIcon.rectTransform, new Vector2(0f, 0.5f), new Vector2(24f, 0f), new Vector2(130f, 130f));
            _medalToastTitle = UIFactory.Text("Title", bg.transform, "MEDAL UNLOCKED", 34, UIFactory.Gold, TextAnchor.MiddleLeft);
            UIFactory.Place(_medalToastTitle.rectTransform, new Vector2(0f, 1f), new Vector2(176f, -24f), new Vector2(700f, 50f));
            _medalToastSub = UIFactory.Text("Sub", bg.transform, "", 46, Color.white, TextAnchor.MiddleLeft);
            UIFactory.Place(_medalToastSub.rectTransform, new Vector2(0f, 1f), new Vector2(176f, -78f), new Vector2(700f, 66f));
            UIFactory.AddShadow(_medalToastSub, 4f, 0.35f);
            bg.gameObject.SetActive(false);
        }

        IEnumerator MedalToastRoutine()
        {
            if (_medalToast == null) BuildMedalToast();
            while (_medalQueue.Count > 0)
            {
                var item = _medalQueue.Dequeue();
                _medalToastIcon.color = Achievements.TierColors[item.Value];
                _medalToastTitle.text = Loc.F("{0} MEDAL UNLOCKED", Loc.T(Achievements.TierNames[item.Value]));
                _medalToastSub.text = Loc.Upper(Loc.T(item.Key.title));
                _medalToast.gameObject.SetActive(true);
                _medalToast.SetAsLastSibling();
                var cg = _medalToast.GetComponent<CanvasGroup>();
                Haptics.Success();
                var sm = SoundManager.Instance;
                if (sm != null) sm.PlayFrom(_s.sfxMedal, 1f, 0.9f);

                const float dur = 2.6f;
                float notch = (Screen.height - Screen.safeArea.yMax) / Mathf.Max(0.01f, CanvasScale);
                float t = 0f;
                while (t < dur)
                {
                    t += Time.unscaledDeltaTime;
                    float inK = Mathf.Clamp01(t / 0.3f), outK = Mathf.Clamp01((dur - t) / 0.3f);
                    float k = Mathf.Min(inK, outK);
                    float ease = 1f - (1f - k) * (1f - k);
                    _medalToast.anchoredPosition = new Vector2(0f, Mathf.Lerp(200f, -30f - notch, ease));
                    cg.alpha = k;
                    _medalToastIcon.transform.localScale = Vector3.one * (1f + 0.12f * Mathf.Sin(t * 6f) * (1f - t / dur));
                    yield return null;
                }
                _medalToast.gameObject.SetActive(false);
                yield return new WaitForSecondsRealtime(0.15f);
            }
            _medalRoutine = null;
        }

        // ---------------------------------------------------------------- Test istatistikleri

        RectTransform _stats;
        UnityEngine.UI.Text _statsText;
        UnityEngine.UI.ScrollRect _statsScroll;

        void BuildStats()
        {
            _stats = Overlay("Stats", out var panel, new Vector2(1000, 1650), true);
            var t = UIFactory.Text("Title", panel, "TEST STATS", 64, Color.white);
            UIFactory.Place(t.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -40), new Vector2(900, 90));

            var scroll = UIFactory.Rect("Scroll", panel);
            UIFactory.Stretch(scroll, 40, 40, 150, 210);
            _statsScroll = scroll.gameObject.AddComponent<UnityEngine.UI.ScrollRect>();
            _statsScroll.horizontal = false;
            _statsScroll.movementType = UnityEngine.UI.ScrollRect.MovementType.Clamped;
            var vp = UIFactory.Image("Viewport", scroll, "square", new Color(0f, 0f, 0f, 0.25f), false, true);
            vp.preserveAspect = false;
            UIFactory.Stretch(vp.rectTransform);
            vp.gameObject.AddComponent<UnityEngine.UI.RectMask2D>();

            _statsText = UIFactory.Text("Report", vp.transform, "", 28, Color.white, TextAnchor.UpperLeft);
            var rt = _statsText.rectTransform;
            rt.anchorMin = new Vector2(0, 1); rt.anchorMax = new Vector2(1, 1); rt.pivot = new Vector2(0.5f, 1);
            rt.offsetMin = new Vector2(20, 0); rt.offsetMax = new Vector2(-20, -16);
            _statsText.horizontalOverflow = HorizontalWrapMode.Wrap;
            _statsText.verticalOverflow = VerticalWrapMode.Overflow;
            _statsText.lineSpacing = 1.15f;
            var fit = _statsText.gameObject.AddComponent<UnityEngine.UI.ContentSizeFitter>();
            fit.verticalFit = UnityEngine.UI.ContentSizeFitter.FitMode.PreferredSize;
            _statsScroll.viewport = vp.rectTransform;
            _statsScroll.content = rt;

            var copy = UIFactory.Button("Copy", panel, "COPY", UIFactory.Green, new Vector2(280, 120), 44, () =>
            {
                GUIUtility.systemCopyBuffer = LocalStats.Report();
                Toast("COPIED", 1f);
            });
            UIFactory.Place(copy.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(-300, 50), new Vector2(280, 120));
            var reset = UIFactory.Button("Reset", panel, "RESET", UIFactory.Red, new Vector2(280, 120), 44, () =>
            {
                LocalStats.Reset();
                RefreshStats();
            });
            UIFactory.Place(reset.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(0, 50), new Vector2(280, 120));
            var close = UIFactory.Button("Close", panel, "CLOSE", UIFactory.Purple, new Vector2(280, 120), 44, () => _stats.gameObject.SetActive(false));
            UIFactory.Place(close.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(300, 50), new Vector2(280, 120));
        }

        void ShowStats()
        {
            if (_stats == null) BuildStats();
            _stats.gameObject.SetActive(true);
            _stats.SetAsLastSibling();
            RefreshStats();
        }

        void RefreshStats()
        {
            _statsText.text = LocalStats.Report();
            _statsScroll.verticalNormalizedPosition = 1f;
        }

        void BuildPause()
        {
            _pause = Overlay("Pause", out var panel, new Vector2(760, 1000));
            var t = UIFactory.Text("Title", panel, "PAUSED", 80, Color.white);
            UIFactory.Place(t.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -60), new Vector2(700, 110));
            UIFactory.AddShadow(t, 6f, 0.4f);

            var resume = UIFactory.Button("Resume", panel, "RESUME", UIFactory.Green, new Vector2(560, 150), 56, () => _ctrl.Resume());
            UIFactory.Place(resume.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0, -220), new Vector2(560, 150));
            var restart = UIFactory.Button("Restart", panel, "RESTART", UIFactory.Blue, new Vector2(560, 150), 56, () => ConfirmLeave(true));
            UIFactory.Place(restart.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0, -400), new Vector2(560, 150));
            var home = UIFactory.Button("Home", panel, "HOME", UIFactory.Red, new Vector2(560, 150), 56, () => ConfirmLeave(false));
            UIFactory.Place(home.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0, -580), new Vector2(560, 150));

            // Alt sıra: ses ve titreşim aç/kapa
            var snd = SoundToggle(panel, new Vector2(170, 140));
            UIFactory.Place(snd, new Vector2(0.5f, 1f), new Vector2(-105, -780), new Vector2(170, 140));
            var hap = HapticsToggle(panel, new Vector2(170, 140));
            UIFactory.Place(hap, new Vector2(0.5f, 1f), new Vector2(105, -780), new Vector2(170, 140));
        }

        // ---------------------------------------------------------------- Ses / titreşim düğmeleri
        // Ana menüde ve duraklat menüsünde aynı ayarı gösteren düğmeler; biri değişince hepsi güncellenir.

        readonly List<UnityEngine.UI.Button> _soundToggles = new List<UnityEngine.UI.Button>();
        readonly List<UnityEngine.UI.Button> _hapticsToggles = new List<UnityEngine.UI.Button>();

        RectTransform SoundToggle(Transform parent, Vector2 size)
        {
            var b = UIFactory.IconButton("SoundToggle", parent, null, UIFactory.Purple, size, () =>
            {
                bool on = !SaveSystem.SoundOn;
                if (SoundManager.Instance != null) SoundManager.Instance.SetSoundOn(on);
                else SaveSystem.SoundOn = on;
                RefreshToggles();
            });
            _soundToggles.Add(b);
            RefreshToggles();
            return (RectTransform)b.transform;
        }

        RectTransform HapticsToggle(Transform parent, Vector2 size)
        {
            var b = UIFactory.IconButton("HapticsToggle", parent, null, UIFactory.Purple, size, () =>
            {
                Haptics.Enabled = !Haptics.Enabled;
                if (Haptics.Enabled) Haptics.Medium(); // açılınca hissettir
                RefreshToggles();
            });
            _hapticsToggles.Add(b);
            RefreshToggles();
            return (RectTransform)b.transform;
        }

        /// <summary>Tüm ses/titreşim düğmelerinin simgesini ve rengini kayıtlı ayara göre günceller (kapalı = gri).</summary>
        void RefreshToggles()
        {
            bool snd = SaveSystem.SoundOn, hap = Haptics.Enabled;
            foreach (var b in _soundToggles) SetToggleLook(b, IconLibrary.Speaker(snd), snd);
            foreach (var b in _hapticsToggles) SetToggleLook(b, IconLibrary.Vibration(hap), hap);
        }

        static void SetToggleLook(UnityEngine.UI.Button b, Sprite icon, bool on)
        {
            if (b == null) return;
            b.image.color = on ? UIFactory.Purple : UIFactory.Locked;
            var ic = b.transform.Find("Icon");
            if (ic == null) return;
            var img = ic.GetComponent<UnityEngine.UI.Image>();
            img.sprite = icon;
            img.preserveAspect = true;
            var sh = img.GetComponent<UnityEngine.UI.Shadow>();
            var c = b.image.color;
            if (sh != null) sh.effectColor = new Color(c.r * 0.35f, c.g * 0.35f, c.b * 0.35f, 0.9f);
        }

        public void ShowPause()
        {
            _pause.gameObject.SetActive(true);
            _pause.SetAsLastSibling();
            RefreshToggles();
            StartCoroutine(PopIn(_pause.Find("Panel"), 0.2f));
        }

        public void HidePause() => _pause.gameObject.SetActive(false);

        // ---------------------------------------------------------------- Emin misin? (Pause → Restart / Home)

        RectTransform _confirm;
        UnityEngine.UI.Text _confirmTitle, _confirmBody;
        UnityEngine.UI.Button _confirmYes;
        System.Action _confirmAction;

        void BuildConfirm()
        {
            _confirm = Overlay("Confirm", out var panel, new Vector2(760, 600));
            _confirmTitle = UIFactory.Text("Title", panel, "ARE YOU SURE?", 64, Color.white);
            UIFactory.Place(_confirmTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -50), new Vector2(700, 90));
            UIFactory.FitText(_confirmTitle, 40);
            UIFactory.AddShadow(_confirmTitle, 6f, 0.45f);

            _confirmBody = UIFactory.Text("Body", panel, "", 38, UIFactory.TextDim);
            UIFactory.Place(_confirmBody.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -160), new Vector2(660, 150));
            UIFactory.FitText(_confirmBody, 26);

            _confirmYes = UIFactory.Button("Yes", panel, "RESTART", UIFactory.Red, new Vector2(300, 130), 46, () =>
            {
                var a = _confirmAction;
                CloseConfirm();
                a?.Invoke();
            });
            UIFactory.Place(_confirmYes.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(165, 60), new Vector2(300, 130));

            var no = UIFactory.Button("No", panel, "CANCEL", new Color(1f, 1f, 1f, 0.16f), new Vector2(300, 130), 46, CloseConfirm);
            UIFactory.ApplyGlassSkin(no.GetComponent<UnityEngine.UI.Image>(), 130f);
            UIFactory.Place(no.GetComponent<RectTransform>(), new Vector2(0.5f, 0f), new Vector2(-165, 60), new Vector2(300, 130));
        }

        /// <summary>Duraklatma menüsünden çıkmadan önce onay ister. restart = true: yeniden başlat, false: ana menü.</summary>
        void ConfirmLeave(bool restart)
        {
            if (_confirm == null) BuildConfirm();
            bool level = _ctrl.Mode == GameMode.Level;

            if (restart)
            {
                _confirmTitle.text = Loc.T("RESTART?");
                string body = Loc.T(level ? "Your progress in this level will be lost." : "Your current game will be lost.");
                if (_ctrl.RestartNeedsEnergy && Energy.Enabled) body += "\n" + Loc.T("Restarting uses 1 energy.");
                _confirmBody.text = body;
                UIFactory.SetLabel(_confirmYes, "RESTART");
                _confirmAction = () => WithEnergyIf(_ctrl.RestartNeedsEnergy, () => { HidePause(); _ctrl.Restart(); });
            }
            else
            {
                _confirmTitle.text = Loc.T("GO HOME?");
                _confirmBody.text = Loc.T(level
                    ? "Your progress in this level will be lost."
                    : "Your game is saved. You can continue it later.");
                UIFactory.SetLabel(_confirmYes, "HOME");
                _confirmAction = () => { HidePause(); _ctrl.GoHome(); };
            }

            _confirm.gameObject.SetActive(true);
            _confirm.SetAsLastSibling();
            StartCoroutine(PopIn(_confirm.Find("Panel"), 0.2f));
        }

        void CloseConfirm()
        {
            _confirmAction = null;
            if (_confirm != null) _confirm.gameObject.SetActive(false);
        }

        // ---------------------------------------------------------------- Result

        const float ResStarsGap = 180f;   // yıldız satırının kapladığı dikey alan
        float _resButtonsTop = -560f;     // düğmelerin başladığı y (yıldız yoksa yukarı kayar)

        void BuildResult()
        {
            _result = Overlay("Result", out var panel, new Vector2(840, 1080));

            _resTitle = UIFactory.Text("Title", panel, "GAME OVER", 76, Color.white);
            UIFactory.Place(_resTitle.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -50), new Vector2(800, 110));
            UIFactory.AddShadow(_resTitle, 6f, 0.4f);

            _resStarRow = UIFactory.Rect("Stars", panel);
            UIFactory.Place(_resStarRow, new Vector2(0.5f, 1f), new Vector2(0, -170), new Vector2(560, 170));
            for (int i = 0; i < 3; i++)
            {
                var st = UIFactory.Image("Star" + i, _resStarRow, "star", UIFactory.Gold);
                float size = i == 1 ? 170 : 140;
                UIFactory.Place(st.rectTransform, new Vector2(0.5f, 1f), new Vector2((i - 1) * 175, i == 1 ? 0 : -24), new Vector2(size, size));
                st.rectTransform.pivot = new Vector2(0.5f, 0.5f);
                st.rectTransform.anchoredPosition = new Vector2((i - 1) * 175, i == 1 ? -85 : -105);
                _resStars.Add(st);
            }

            _resScore = UIFactory.Text("Score", panel, "0", 96, Color.white);
            UIFactory.Place(_resScore.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -360), new Vector2(800, 120));
            UIFactory.AddShadow(_resScore, 6f, 0.4f);
            _resSub = UIFactory.Text("Sub", panel, "", 36, UIFactory.TextDim);
            UIFactory.Place(_resSub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -480), new Vector2(820, 60));
            UIFactory.FitText(_resSub, 24);

            _reviveHolder = UIFactory.Rect("ReviveHolder", panel);
            _resRevive = UIFactory.Button("Revive", _reviveHolder, "REVIVE", ReviveTrack, new Vector2(ReviveW, ReviveH), 50, () =>
            {
                StopReviveCountdown(); // reklam yüklenirken süre dolmasın
                _resRevive.interactable = false;
                AdHooks.Rewarded("revive", () => { AdPolicy.RewardedWatched(); _ctrl.Revive(); }, () =>
                {
                    // Reklam yoksa/yüklenemediyse: oyuncuyu bekletme, kayıp ekranının seçeneklerini göster
                    Toast("NO AD AVAILABLE", 1.4f);
                    ShowLossButtons();
                });
            });
            UIFactory.Stretch(_resRevive.GetComponent<RectTransform>());
            UIFactory.ApplyGlassSkin(_resRevive.GetComponent<UnityEngine.UI.Image>(), ReviveH); // boşalan kısım: dolguyla aynı şekilde cam yuva

            // Dolgu: soldan sabitlenmiş, genişliği süreyle azalan yeşil gövde (yazının arkasında)
            _reviveFill = UIFactory.Image("Fill", _resRevive.transform, null, UIFactory.Green, true);
            UIFactory.ApplyBlockSkin(_reviveFill, ReviveH); // dolu kısım: oyundaki blok gibi
            var fr = _reviveFill.rectTransform;
            fr.anchorMin = new Vector2(0f, 0f);
            fr.anchorMax = new Vector2(0f, 1f);
            fr.pivot = new Vector2(0f, 0.5f);
            fr.anchoredPosition = Vector2.zero;
            fr.sizeDelta = new Vector2(ReviveW, 0f);
            fr.SetAsFirstSibling();
            _resPrimary = UIFactory.Button("Primary", panel, "NEXT", UIFactory.Orange, new Vector2(600, 140), 56, OnResultPrimary);
            _resRetry = UIFactory.Button("Retry", panel, "RETRY", UIFactory.Blue, new Vector2(600, 140), 56, () => WithEnergyIf(_ctrl.RestartNeedsEnergy, () => LeaveResult(_ctrl.Restart)));
            _resHome = UIFactory.Button("Home", panel, "HOME", UIFactory.Purple, new Vector2(600, 140), 56, () => LeaveResult(_ctrl.GoHome));
        }

        void OnResultPrimary()
        {
            // Son bölümden sonra NEXT haritaya döner: enerji gerekmez
            if (_ctrl.LevelIndex + 1 < LevelDatabase.Count) WithEnergy(() => LeaveResult(_ctrl.NextLevel));
            else LeaveResult(_ctrl.NextLevel);
        }

        bool _lastResultPositive;

        /// <summary>
        /// Sonuç ekranından çıkış: sırası gelmişse önce değerlendirme isteği ya da geçiş reklamı, sonra eylem.
        /// Bitmiş oyun burada sayılır (revive teklifi reddedilmiş / oyun gerçekten bitmiş olur).
        /// </summary>
        void LeaveResult(System.Action next)
        {
            HideResult();
            AdPolicy.AfterGame(_lastResultPositive, next, ShowRatePrompt);
        }

        public void ShowResult(GameController ctrl, bool win, int stars, bool newBest, bool canRevive, bool outOfMoves)
        {
            _lastResultPositive = win || newBest;
            _result.gameObject.SetActive(true);
            _result.SetAsLastSibling();
            bool level = ctrl.Mode == GameMode.Level;

            if (win) _resTitle.text = Loc.F("LEVEL {0} CLEAR!", ctrl.LevelIndex + 1);
            else if (level) _resTitle.text = Loc.T(outOfMoves ? "OUT OF MOVES" : "TOO HIGH!");
            else _resTitle.text = Loc.T("GAME OVER");
            _resTitle.color = win ? UIFactory.Gold : Color.white;

            bool showStars = level && win;
            _resStarRow.gameObject.SetActive(showStars);
            // Yıldızlar yoksa onların 180 px'lik yerini boş bırakma: alttaki her şeyi yukarı kaydır
            float shift = showStars ? 0f : ResStarsGap;
            UIFactory.Place(_resScore.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -360 + shift), new Vector2(800, 120));
            UIFactory.Place(_resSub.rectTransform, new Vector2(0.5f, 1f), new Vector2(0, -480 + shift), new Vector2(800, 60));
            _resButtonsTop = -560 + shift;
            for (int i = 0; i < 3; i++)
            {
                _resStars[i].color = i < stars ? UIFactory.Gold : new Color(0, 0, 0, 0.3f);
                _resStars[i].transform.localScale = Vector3.one;
            }
            if (level && win) StartCoroutine(StarsIn(stars));

            _resScore.text = ctrl.Score.ToString();
            _resScore.color = !level && newBest ? UIFactory.Gold : Color.white;
            // Kayıpta "kıl payı" metni: ne kadar yaklaştığını göster → tekrar deneme isteği
            bool close = false;
            string near = win || newBest ? "" : ctrl.NearMissText(out close);
            if (level) _resSub.text = win ? Loc.T("SCORE") : (near != "" ? near : Loc.F("LEVEL {0}", ctrl.LevelIndex + 1));
            else _resSub.text = newBest ? Loc.T("NEW BEST!") : (near != "" ? near : Loc.F("BEST  {0}", SaveSystem.BestEndless));
            _resSub.color = level ? (near != "" && close ? UIFactory.Gold : UIFactory.TextDim) : UIFactory.Gold;

            StopReviveCountdown();
            bool hasNext = level && win && ctrl.LevelIndex + 1 < LevelDatabase.Count;
            _resPrimary.gameObject.SetActive(hasNext);
            UIFactory.SetLabel(_resRetry, win ? "REPLAY" : "RETRY");
            var panel = (RectTransform)_result.Find("Panel");

            if (canRevive)
            {
                // Önce yalnızca REVIVE + 5 sn geri sayım; süre dolunca RETRY / HOME belirir
                UIFactory.SetLabel(_resRevive, outOfMoves
                    ? Loc.F("+{0} MOVES", _s.reviveExtraMoves)
                    : "REVIVE!");
                _resRevive.gameObject.SetActive(true);
                _reviveHolder.gameObject.SetActive(true);
                _reviveHolder.localScale = Vector3.one;
                _resRevive.interactable = true;
                SetReviveFill(1f, UIFactory.Green);
                _resRetry.gameObject.SetActive(false);
                _resHome.gameObject.SetActive(false);
                UIFactory.Place(_reviveHolder, new Vector2(0.5f, 1f), new Vector2(0, _resButtonsTop), new Vector2(ReviveW, ReviveH));
                panel.sizeDelta = new Vector2(840, -_resButtonsTop + 150 + 40);
                _reviveCountdown = StartCoroutine(ReviveCountdown(panel, hasNext));
            }
            else
            {
                _reviveHolder.gameObject.SetActive(false);
                _resRetry.gameObject.SetActive(true);
                _resHome.gameObject.SetActive(true);
                _resRetry.transform.localScale = Vector3.one;
                _resHome.transform.localScale = Vector3.one;
                var buttons = new List<UnityEngine.UI.Button>();
                if (hasNext) buttons.Add(_resPrimary);
                buttons.Add(_resRetry);
                buttons.Add(_resHome);
                LayoutResultButtons(panel, buttons);
            }

            StartCoroutine(PopIn(panel, 0.25f));
        }

        /// <summary>Revive kullanılamadığında RETRY / HOME düğmelerini gösterir.</summary>
        void ShowLossButtons()
        {
            StopReviveCountdown();
            var panel = (RectTransform)_result.Find("Panel");
            _reviveHolder.gameObject.SetActive(false);
            _resRetry.gameObject.SetActive(true);
            _resHome.gameObject.SetActive(true);
            _resRetry.transform.localScale = Vector3.one;
            _resHome.transform.localScale = Vector3.one;
            LayoutResultButtons(panel, new List<UnityEngine.UI.Button> { _resRetry, _resHome });
        }

        public void HideResult()
        {
            StopReviveCountdown();
            _result.gameObject.SetActive(false);
        }

        void LayoutResultButtons(RectTransform panel, List<UnityEngine.UI.Button> buttons)
        {
            float y = _resButtonsTop;
            foreach (var b in buttons)
            {
                UIFactory.Place(b.GetComponent<RectTransform>(), new Vector2(0.5f, 1f), new Vector2(0, y), new Vector2(600, 130));
                y -= 150;
            }
            panel.sizeDelta = new Vector2(840, -y + 40);
        }

        void StopReviveCountdown()
        {
            if (_reviveCountdown != null) { StopCoroutine(_reviveCountdown); _reviveCountdown = null; }
        }

        /// <summary>
        /// REVIVE düğmesi 5 sn'de soldan sağa değil, sağdan sola boşalan tombul bir çubuk gibi azalır
        /// ve kalp atışı gibi (tık-tık ... tık-tık) büyüyüp küçülür; süre azaldıkça kalp hızlanır.
        /// Süre dolunca düğme kaybolur, RETRY ve HOME belirir.
        /// </summary>
        IEnumerator ReviveCountdown(RectTransform panel, bool hasNext)
        {
            float t = 0f, beatPhase = 0f;
            while (t < ReviveSeconds)
            {
                float dt = Time.unscaledDeltaTime;
                t += dt;
                float left = Mathf.Max(0f, ReviveSeconds - t);
                float frac = left / ReviveSeconds;

                // Son 1.5 sn'de dolgu turuncuya döner
                var col = Color.Lerp(UIFactory.Green, ReviveLate, Mathf.Clamp01((1.5f - left) / 1.5f));
                SetReviveFill(frac, col);

                // Kalp atışı: periyot 0.95 sn → sona doğru 0.5 sn
                float period = Mathf.Lerp(0.5f, 0.95f, frac);
                beatPhase = Mathf.Repeat(beatPhase + dt / period, 1f);
                float lub = Mathf.Exp(-Mathf.Pow((beatPhase - 0.06f) / 0.055f, 2f));
                float dub = 0.65f * Mathf.Exp(-Mathf.Pow((beatPhase - 0.28f) / 0.055f, 2f));
                float s = 1f + 0.075f * (lub + dub);
                _reviveHolder.localScale = new Vector3(s, s, 1f);
                yield return null;
            }

            // Süre doldu: REVIVE küçülüp kaybolur
            _resRevive.interactable = false;
            float e = 0f;
            while (e < 0.2f)
            {
                e += Time.unscaledDeltaTime;
                float k = 1f - Mathf.Clamp01(e / 0.2f);
                _reviveHolder.localScale = new Vector3(k, k, 1f);
                yield return null;
            }
            _reviveHolder.gameObject.SetActive(false);

            // RETRY ve HOME belirir
            var buttons = new List<UnityEngine.UI.Button>();
            if (hasNext) buttons.Add(_resPrimary);
            buttons.Add(_resRetry);
            buttons.Add(_resHome);
            LayoutResultButtons(panel, buttons);
            _resRetry.gameObject.SetActive(true);
            _resHome.gameObject.SetActive(true);
            StartCoroutine(PopIn(_resRetry.transform, 0.2f));
            yield return new WaitForSecondsRealtime(0.08f);
            StartCoroutine(PopIn(_resHome.transform, 0.2f));
            _reviveCountdown = null;
        }

        /// <summary>Dolgu oranı (1 = dolu). Çok daraldığında yuvarlak köşeler bozulmasın diye genişlik yerine saydamlık azalır.</summary>
        void SetReviveFill(float frac, Color col)
        {
            const float minW = 120f; // blok kenarları (bevel) bozulmadan inebileceği en dar hâl
            float w = ReviveW * frac;
            _reviveFill.rectTransform.sizeDelta = new Vector2(Mathf.Max(minW, w), 0f);
            col.a = w >= minW ? 1f : Mathf.Clamp01(w / minW);
            _reviveFill.color = col;
            if (_reviveFillShine == null)
            {
                var t = _reviveFill.transform.Find("Shine");
                if (t != null) _reviveFillShine = t.GetComponent<UnityEngine.UI.Image>();
            }
            if (_reviveFillShine != null) _reviveFillShine.color = new Color(1f, 1f, 1f, col.a); // parlama da dolguyla birlikte solsun
        }

        IEnumerator StarsIn(int stars)
        {
            for (int i = 0; i < 3; i++) _resStars[i].transform.localScale = i < stars ? Vector3.zero : Vector3.one;
            yield return new WaitForSecondsRealtime(0.25f);
            for (int i = 0; i < stars; i++)
            {
                float t = 0;
                while (t < 0.25f)
                {
                    t += Time.unscaledDeltaTime;
                    float k = Mathf.Clamp01(t / 0.25f);
                    float s = k < 0.7f ? Mathf.Lerp(0, 1.25f, k / 0.7f) : Mathf.Lerp(1.25f, 1f, (k - 0.7f) / 0.3f);
                    _resStars[i].transform.localScale = new Vector3(s, s, 1);
                    yield return null;
                }
            }
        }

        // ---------------------------------------------------------------- Toast

        // ---------------------------------------------------------------- Tutorial

        void BuildTutorial()
        {
            var bg = UIFactory.Panel("Tutorial", _safe, new Color(0.10f, 0.09f, 0.17f, 0.9f));
            _tut = bg.rectTransform;
            UIFactory.TopStrip(_tut, -10, TutorialHeight, 24);

            _tutStep = UIFactory.Text("Step", _tut, "1 / 5", 30, new Color(1f, 1f, 1f, 0.6f), TextAnchor.MiddleLeft);
            UIFactory.Place(_tutStep.rectTransform, new Vector2(0f, 1f), new Vector2(36, -18), new Vector2(200, 50));

            var skip = UIFactory.Button("Skip", _tut, "SKIP", new Color(1f, 1f, 1f, 0.16f), new Vector2(170, 70), 30, () => _ctrl.SkipTutorial());
            UIFactory.ApplyGlassSkin(skip.GetComponent<UnityEngine.UI.Image>(), 70f);
            UIFactory.Place(skip.GetComponent<RectTransform>(), new Vector2(1f, 1f), new Vector2(-24, -16), new Vector2(170, 70));

            // Bantlar (üstten): 16-86 adım + SKIP, 96-172 başlık, 180-(alt 22) açıklama.
            // Başlık ve açıklama panel genişliğine esner ve kutularına sığacak kadar küçülür → üst üste binmez.
            _tutTitle = UIFactory.Text("Title", _tut, "", 60, UIFactory.Gold);
            var ttr = _tutTitle.rectTransform;
            ttr.anchorMin = new Vector2(0f, 1f); ttr.anchorMax = new Vector2(1f, 1f); ttr.pivot = new Vector2(0.5f, 1f);
            ttr.offsetMin = new Vector2(40f, -172f); ttr.offsetMax = new Vector2(-40f, -96f);
            UIFactory.FitText(_tutTitle, 40);
            UIFactory.AddShadow(_tutTitle, 4f, 0.4f);

            _tutBody = UIFactory.Text("Body", _tut, "", 38, Color.white);
            _tutBody.lineSpacing = 1.1f;
            var tbr = _tutBody.rectTransform;
            tbr.anchorMin = Vector2.zero; tbr.anchorMax = Vector2.one;
            tbr.offsetMin = new Vector2(40f, 22f); tbr.offsetMax = new Vector2(-40f, -180f);
            UIFactory.FitText(_tutBody, 26);

            // Bilgi adımlarının düğmesi: ekranın ortasında, tahtanın üstünde
            _tutAction = UIFactory.Button("TutorialAction", _safe, "LET'S PLAY!", UIFactory.Green, new Vector2(560, 160), 60, () =>
            {
                _tutAction.gameObject.SetActive(false);
                _tutActionCallback?.Invoke();
            });
            UIFactory.Place(_tutAction.GetComponent<RectTransform>(), new Vector2(0.5f, 0.5f), new Vector2(0, -60), new Vector2(560, 160));
            _tutAction.gameObject.SetActive(false);

            _tut.gameObject.SetActive(false);
        }

        public void ShowTutorial(int step, int total, string title, string body)
        {
            _tut.gameObject.SetActive(true);
            _tut.SetAsLastSibling();
            _tutAction.gameObject.SetActive(false);
            _tutStep.text = step + " / " + total;
            _tutTitle.text = Loc.T(title);
            _tutBody.text = Loc.T(body);
            StartCoroutine(PopIn(_tut, 0.2f));
        }

        public void ShowTutorialAction(string label, System.Action onClick)
        {
            _tutActionCallback = onClick;
            UIFactory.SetLabel(_tutAction, label);
            _tutAction.gameObject.SetActive(true);
            _tutAction.transform.SetAsLastSibling();
            StartCoroutine(PopIn(_tutAction.transform, 0.25f));
        }

        public void HideTutorial()
        {
            if (_tut != null) _tut.gameObject.SetActive(false);
            if (_tutAction != null) _tutAction.gameObject.SetActive(false);
            _tutActionCallback = null;
        }

        void BuildToast()
        {
            var bg = UIFactory.Panel("Toast", _safe, new Color(0.08f, 0.07f, 0.14f, 0.88f));
            _toast = bg.rectTransform;
            UIFactory.Place(_toast, new Vector2(0.5f, 0.5f), new Vector2(0, 120), new Vector2(900, 240));
            _toastText = UIFactory.Text("Text", _toast, "", 46, Color.white);
            _toastText.horizontalOverflow = HorizontalWrapMode.Wrap;
            UIFactory.Stretch(_toastText.rectTransform, 30, 30, 20, 20);
            _toast.gameObject.AddComponent<CanvasGroup>();
            _toast.gameObject.SetActive(false);
            if (_medals != null) _medals.gameObject.SetActive(false);
            if (_streakPopup != null) _streakPopup.gameObject.SetActive(false);
            AdHooks.SetBannerVisible(false);
        }

        public void Toast(string msg, float duration)
        {
            msg = Loc.T(msg); // anahtar ise seçili dile çevrilir (biçimli metinler çağıran yerde Loc.F ile gelir)
            if (_toastRoutine != null) StopCoroutine(_toastRoutine);
            _toastRoutine = StartCoroutine(ToastRoutine(msg, duration));
        }

        IEnumerator ToastRoutine(string msg, float duration)
        {
            _toast.gameObject.SetActive(true);
            _toast.SetAsLastSibling();
            _toastText.text = msg;
            int lines = msg.Split('\n').Length;
            _toast.sizeDelta = new Vector2(900, 70 + lines * 62);
            var cg = _toast.GetComponent<CanvasGroup>();
            cg.blocksRaycasts = false;
            float t = 0;
            while (t < duration)
            {
                t += Time.unscaledDeltaTime;
                float a = t < 0.15f ? t / 0.15f : t > duration - 0.3f ? (duration - t) / 0.3f : 1f;
                cg.alpha = Mathf.Clamp01(a);
                float s = t < 0.15f ? Mathf.Lerp(0.85f, 1f, t / 0.15f) : 1f;
                _toast.localScale = new Vector3(s, s, 1);
                yield return null;
            }
            _toast.gameObject.SetActive(false);
            _toastRoutine = null;
        }

        // ---------------------------------------------------------------- Helpers

        void HideAll()
        {
            _menu.gameObject.SetActive(false);
            _levels.gameObject.SetActive(false);
            _hud.gameObject.SetActive(false);
            _pause.gameObject.SetActive(false);
            _result.gameObject.SetActive(false);
            if (_tut != null) _tut.gameObject.SetActive(false);
            if (_tutAction != null) _tutAction.gameObject.SetActive(false);
            if (_medals != null) _medals.gameObject.SetActive(false);
            if (_streakPopup != null) _streakPopup.gameObject.SetActive(false);
            if (_stats != null) _stats.gameObject.SetActive(false);
            if (_removeAds != null) _removeAds.gameObject.SetActive(false);
            if (_langPopup != null) _langPopup.gameObject.SetActive(false);
            if (_energyPopup != null) { _energyPopup.gameObject.SetActive(false); _energyPending = null; }
            if (_confirm != null) CloseConfirm();
            if (_toastRoutine != null) { StopCoroutine(_toastRoutine); _toastRoutine = null; }
            _toast.gameObject.SetActive(false);
        }

        // ---------------------------------------------------------------- Geri tuşu (Android) / Escape

        /// <summary>
        /// En üstteki katmanı kapatır: açılır pencere → alt ekran → menü. Oyun sırasında oyunu duraklatır,
        /// duraklatma menüsündeyken devam ettirir. Sonuç ekranında ve ana menüde bir şey yapmaz.
        /// </summary>
        void HandleBack()
        {
            if (_stats != null && _stats.gameObject.activeSelf) { _stats.gameObject.SetActive(false); return; }
            if (_langPopup != null && _langPopup.gameObject.activeSelf) { _langPopup.gameObject.SetActive(false); return; }
            if (_rate != null && _rate.gameObject.activeSelf) { CloseRate(); return; }
            if (_removeAds != null && _removeAds.gameObject.activeSelf) { _removeAds.gameObject.SetActive(false); return; }
            if (_energyPopup != null && _energyPopup.gameObject.activeSelf) { CloseEnergy(); return; }
            if (_confirm != null && _confirm.gameObject.activeSelf) { CloseConfirm(); return; }
            if (_streakPopup != null && _streakPopup.gameObject.activeSelf) { _streakPopup.gameObject.SetActive(false); return; }
            if (_medals != null && _medals.gameObject.activeSelf) { ShowMainMenu(); return; }
            if (_levels.gameObject.activeSelf) { ShowMainMenu(); return; }
            if (_pause.gameObject.activeSelf) { _ctrl.Resume(); return; }
            if (_hud.gameObject.activeSelf && !_result.gameObject.activeSelf
                && _ctrl.State == GameState.Playing && _ctrl.Mode != GameMode.Tutorial) _ctrl.Pause();
        }

        /// <summary>Alt ekran başlığı: solda cam chip geri butonu (çizilmiş ok), ortada başlık.</summary>
        RectTransform BuildScreenHeader(RectTransform screen, string title)
        {
            var header = UIFactory.Rect("Header", screen);
            UIFactory.TopStrip(header, -20, 150, 30);
            var back = UIFactory.Chip("Back", header, new Vector2(130, 120), ShowMainMenu);
            UIFactory.Place((RectTransform)back.transform, new Vector2(0, 0.5f), Vector2.zero, new Vector2(130, 120));
            var arrow = UIFactory.Image("Arrow", back.transform, null, Color.white);
            arrow.sprite = IconLibrary.ChevronLeft();
            arrow.preserveAspect = true;
            arrow.raycastTarget = false;
            UIFactory.Place(arrow.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(-4f, 0f), new Vector2(62f, 62f));
            var t = UIFactory.Text("Title", header, title, 72, Color.white);
            UIFactory.Stretch(t.rectTransform);
            UIFactory.AddShadow(t, 6f, 0.45f);
            return header;
        }

        IEnumerator PopIn(Transform t, float dur)
        {
            if (t == null) yield break;
            float e = 0;
            while (e < dur)
            {
                e += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(e / dur);
                float s = Mathf.Lerp(0.85f, 1f, 1f - (1f - k) * (1f - k));
                t.localScale = new Vector3(s, s, 1);
                yield return null;
            }
            t.localScale = Vector3.one;
        }
    }

    /// <summary>Menüdeki dekor bloklar için hafif yukarı-aşağı süzülme.</summary>
    /// <summary>Yavaşça büyüyüp küçülen ve parlaklığı dalgalanan ışık (seri penceresindeki hale).</summary>
    public class UIBreathe : MonoBehaviour
    {
        public float period = 2.6f, scaleAmount = 0.06f, alphaAmount = 0.25f;
        UnityEngine.UI.Image _img;
        float _baseA;

        void Awake()
        {
            _img = GetComponent<UnityEngine.UI.Image>();
            _baseA = _img != null ? _img.color.a : 1f;
            UICanvasIsolation.Isolate(gameObject);
        }

        void Update()
        {
            float k = 0.5f + 0.5f * Mathf.Sin(Time.unscaledTime * 6.2832f / Mathf.Max(0.1f, period));
            float s = 1f + scaleAmount * (k - 0.5f) * 2f;
            transform.localScale = new Vector3(s, s, 1f);
            if (_img != null)
            {
                var c = _img.color;
                c.a = _baseA * (1f - alphaAmount + alphaAmount * k);
                _img.color = c;
            }
        }
    }

    /// <summary>Kısa sürede art arda N dokunuşta tetiklenen gizli düğme (test paneli için).</summary>
    public class SecretTap : MonoBehaviour, IPointerClickHandler
    {
        public int taps = 5;
        public float window = 2f;
        public System.Action onTrigger;
        int _count;
        float _first;

        public void OnPointerClick(PointerEventData e)
        {
            if (_count == 0 || Time.unscaledTime - _first > window) { _count = 0; _first = Time.unscaledTime; }
            if (++_count >= taps)
            {
                _count = 0;
                Haptics.Medium();
                onTrigger?.Invoke();
            }
        }
    }

    /// <summary>Işıma: rengi sarı ile turuncu arasında gidip gelir, hafifçe büyüyüp küçülerek nefes alır.</summary>
    /// <summary>
    /// Çerçeve parıltısı: birkaç saniyede bir chip'in üst kenarının bir köşesinde küçük bir yıldız
    /// belirip dönerek söner. Konum her seferinde kenar boyunca biraz değişir.
    /// </summary>
    public class UISparkle : MonoBehaviour
    {
        public float size = 46f;
        public float minDelay = 2.2f, maxDelay = 4.2f, duration = 0.75f;
        RectTransform _rt, _host;
        UnityEngine.UI.Image _img;
        float _wait, _t = -1f;

        void Awake()
        {
            _rt = (RectTransform)transform;
            _host = (RectTransform)transform.parent;
            _img = GetComponent<UnityEngine.UI.Image>();
            _img.color = new Color(1f, 1f, 1f, 0f);
            _wait = Random.Range(0.4f, maxDelay); // butonlar aynı anda parlamasın
            UICanvasIsolation.Isolate(gameObject);
        }

        void OnEnable() { if (_img != null) _img.color = new Color(1f, 1f, 1f, 0f); _t = -1f; }

        void Update()
        {
            float dt = Time.unscaledDeltaTime;
            if (_t < 0f)
            {
                _wait -= dt;
                if (_wait > 0f) return;
                // Kenar üzerinde yeni yer: çoğunlukla sağ üst köşe civarı, bazen sol üst
                var r = _host.rect;
                bool right = Random.value < 0.7f;
                float x = right ? r.xMax - r.height * Random.Range(0.18f, 0.45f) : r.xMin + r.height * Random.Range(0.25f, 0.5f);
                float y = r.yMax - Random.Range(2f, 8f);
                _rt.localPosition = new Vector3(x, y, 0f);
                _t = 0f;
            }

            _t += dt;
            float k = Mathf.Clamp01(_t / duration);
            float s = Mathf.Sin(k * Mathf.PI);                 // 0 → 1 → 0
            _rt.localScale = Vector3.one * Mathf.Lerp(0.2f, 1f, s);
            _rt.localRotation = Quaternion.Euler(0f, 0f, Mathf.Lerp(-25f, 25f, k));
            _img.color = new Color(1f, 0.97f, 0.85f, s);
            if (k >= 1f)
            {
                _t = -1f;
                _img.color = new Color(1f, 1f, 1f, 0f);
                _wait = Random.Range(minDelay, maxDelay);
            }
        }

        /// <summary>Chip'e parıltı ekler (raycast almaz, butonun üstünde çizilir).</summary>
        public static void AddTo(Transform chip, float size = 46f)
        {
            var img = UIFactory.Image("Sparkle", chip, null, new Color(1f, 1f, 1f, 0f));
            img.sprite = IconLibrary.Sparkle();
            img.raycastTarget = false;
            var rt = img.rectTransform;
            rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = new Vector2(size, size);
            img.transform.SetAsLastSibling();
            img.gameObject.AddComponent<UISparkle>().size = size;
        }
    }

    public class UIGlowPulse : MonoBehaviour
    {
        public Color colorA = new Color(1f, 0.92f, 0.3f);   // sarı
        public Color colorB = new Color(1f, 0.5f, 0.08f);   // turuncu
        public float speed = 2.2f;
        public float minAlpha = 0.4f, maxAlpha = 0.85f;
        public float minScale = 0.9f, maxScale = 1.1f;
        UnityEngine.UI.Image _img;

        void Awake()
        {
            _img = GetComponent<UnityEngine.UI.Image>();
            UICanvasIsolation.Isolate(gameObject);
        }

        void Update()
        {
            float t = Time.unscaledTime;
            float k = 0.5f + 0.5f * Mathf.Sin(t * speed);           // parlaklık / boyut
            float c = 0.5f + 0.5f * Mathf.Sin(t * speed * 0.6f + 1f); // renk (biraz daha yavaş)
            var col = Color.Lerp(colorA, colorB, c);
            col.a = Mathf.Lerp(minAlpha, maxAlpha, k);
            _img.color = col;
            float s = Mathf.Lerp(minScale, maxScale, k);
            transform.localScale = new Vector3(s, s, 1f);
        }
    }

    public class UIBob : MonoBehaviour
    {
        public float amplitude = 7f, speed = 1.7f, phase;
        RectTransform _rt;
        Vector2 _base;

        void Awake()
        {
            _rt = (RectTransform)transform;
            _base = _rt.anchoredPosition;
            UICanvasIsolation.Isolate(gameObject);
        }

        void Update()
        {
            _rt.anchoredPosition = _base + new Vector2(0f, Mathf.Sin(Time.unscaledTime * speed + phase) * amplitude);
        }
    }
}