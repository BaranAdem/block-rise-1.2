using UnityEngine;
using UnityEngine.EventSystems;

namespace BlockRise
{
    /// <summary>Kodla uGUI oluşturmak için yardımcılar. Tüm görseller kendi sprite'larımızdan gelir.</summary>
    public static class UIFactory
    {
        public static readonly Color TextLight = new Color(1f, 1f, 1f, 1f);
        public static readonly Color TextDim = new Color(1f, 1f, 1f, 1f);
        // Paneller: board gibi koyu cam
        /// <summary>Açıklama, alt yazı, ilerleme metni: başlıklardan bir kademe geride (hiyerarşi).</summary>
        public static readonly Color TextSecondary = new Color(1f, 1f, 1f, 0.66f);
        public static readonly Color PanelDark = new Color(0f, 0f, 0f, 0.28f);
        public static readonly Color PanelSolid = new Color(0.13f, 0.12f, 0.22f, 0.97f);
        // Buton renkleri oyundaki blok renkleriyle aynı (GameSettings.blockColors)
        public static readonly Color Green = new Color(0.30f, 0.85f, 0.39f);
        public static readonly Color Blue = new Color(0.24f, 0.55f, 1.00f);
        public static readonly Color Orange = new Color(1.00f, 0.60f, 0.20f);
        public static readonly Color Red = new Color(1.00f, 0.30f, 0.37f);
        public static readonly Color Purple = new Color(0.65f, 0.42f, 1.00f);
        public static readonly Color Gold = new Color(1.00f, 0.79f, 0.24f);
        /// <summary>Kilitli / pasif buton.</summary>
        public static readonly Color Locked = new Color(0.36f, 0.34f, 0.46f);

        public static RectTransform Rect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5; // UI
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            return rt;
        }

        public static RectTransform Stretch(RectTransform rt, float left = 0, float right = 0, float top = 0, float bottom = 0)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = new Vector2(left, bottom);
            rt.offsetMax = new Vector2(-right, -top);
            return rt;
        }

        /// <summary>Anchor ve pivot aynı noktada; boyut ve pozisyon verilir.</summary>
        public static RectTransform Place(RectTransform rt, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            rt.anchorMin = anchor;
            rt.anchorMax = anchor;
            rt.pivot = anchor;
            rt.sizeDelta = size;
            rt.anchoredPosition = pos;
            return rt;
        }

        /// <summary>Üst kenara yapışık, yatayda esneyen şerit.</summary>
        public static RectTransform TopStrip(RectTransform rt, float y, float height, float sidePad = 0)
        {
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(0.5f, 1);
            rt.sizeDelta = new Vector2(-sidePad * 2, height);
            rt.anchoredPosition = new Vector2(0, y);
            return rt;
        }

        public static UnityEngine.UI.Image Image(string name, Transform parent, string sprite, Color color, bool sliced = false, bool raycast = false)
        {
            var rt = Rect(name, parent);
            var img = rt.gameObject.AddComponent<UnityEngine.UI.Image>();
            img.sprite = string.IsNullOrEmpty(sprite) ? null : SpriteLibrary.Get(sprite);
            img.color = color;
            img.type = sliced ? UnityEngine.UI.Image.Type.Sliced : UnityEngine.UI.Image.Type.Simple;
            img.preserveAspect = !sliced && img.sprite != null;
            img.raycastTarget = raycast;
            // Köşe yuvarlaklığı: küçük değer = daha yuvarlak/büyük köşe
            if (sliced) img.pixelsPerUnitMultiplier = 0.8f;
            return img;
        }

        public static UnityEngine.UI.Text Text(string name, Transform parent, string text, int size, Color color, TextAnchor anchor = TextAnchor.MiddleCenter)
        {
            var rt = Rect(name, parent);
            var t = rt.gameObject.AddComponent<UnityEngine.UI.Text>();
            t.font = SpriteLibrary.Font;
            t.fontSize = size;
            // Yerelleştirme: metin çeviri tablosunda varsa seçili dilde yazılır ve dil değişince kendiliğinden yenilenir
            if (Loc.Has(text)) Loc.Bind(t, () => Loc.T(text));
            else t.text = text;
            t.color = color;
            t.alignment = anchor;
            t.raycastTarget = false;
            t.supportRichText = true;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            rt.gameObject.AddComponent<TextShrink>(); // başka dillerde uzun gelen tek satırlık yazı kutusundan taşmasın
            return t;
        }

        /// <summary>
        /// Metni kutusuna sığdırır: taşacaksa yazı boyutu minSize'a kadar küçülür, kutunun dışına asla taşmaz.
        /// Kutunun yüksekliği en az bir satır (fontSize × ~1.2) olmalı.
        /// </summary>
        public static void FitText(UnityEngine.UI.Text t, int minSize)
        {
            t.horizontalOverflow = HorizontalWrapMode.Wrap;
            t.verticalOverflow = VerticalWrapMode.Truncate;
            t.resizeTextForBestFit = true;
            t.resizeTextMaxSize = t.fontSize;
            t.resizeTextMinSize = Mathf.Min(minSize, t.fontSize);
        }

        public static void AddShadow(Component c, float dist = 4f, float alpha = 0.35f)
        {
            var sh = c.gameObject.AddComponent<UnityEngine.UI.Shadow>();
            sh.effectColor = new Color(0.05f, 0.02f, 0.12f, alpha);
            sh.effectDistance = new Vector2(0, -dist);
        }

        /// <summary>
        /// Oyundaki bloklar gibi görünen buton: aynı bevel, ışık ve parlama; altında hafif gölge.
        /// Kök nesne gövde Image'ıdır (renk = butonun rengi); "Shine" çocuğu beyaz parlamadır.
        /// </summary>
        public static UnityEngine.UI.Button Button(string name, Transform parent, string label, Color color, Vector2 size, int fontSize, System.Action onClick)
        {
            var img = Image(name, parent, null, color, true, true);
            img.rectTransform.sizeDelta = size;
            float scale = ApplyBlockSkin(img, size.y);

            var btn = img.gameObject.AddComponent<UnityEngine.UI.Button>();
            btn.targetGraphic = img;
            var colors = btn.colors;
            colors.highlightedColor = Color.white;
            colors.pressedColor = new Color(0.9f, 0.9f, 0.9f);
            colors.disabledColor = new Color(0.75f, 0.75f, 0.75f, 0.75f);
            btn.colors = colors;
            btn.onClick.AddListener(() =>
            {
                var sm = SoundManager.Instance;
                if (sm != null) sm.PlayFrom(GameSettings.Instance.sfxButton, 1f, 0.8f);
                Haptics.Light();
                PulseStardust(img.rectTransform, img.color);
            });
            if (onClick != null) btn.onClick.AddListener(() => onClick());
            img.gameObject.AddComponent<PressScale>();

            if (!string.IsNullOrEmpty(label))
            {
                var t = Text("Label", img.transform, label, fontSize, TextLight);
                // Gölge payı kadar yukarı: yazı bloğun görünen ortasında dursun
                Stretch(t.rectTransform, 10, 10, 0, SpriteLibrary.UIBlockShadowPad * scale);
                // Yazı gölgesi butonun kendi renginin koyusu (şeker gibi derinlik)
                var sh = t.gameObject.AddComponent<UnityEngine.UI.Shadow>();
                sh.effectColor = new Color(color.r * 0.35f, color.g * 0.35f, color.b * 0.35f, 0.9f);
                sh.effectDistance = new Vector2(0, -Mathf.Max(3f, fontSize * 0.06f));
            }
            return btn;
        }

        /// <summary>
        /// Bir Image'ı blok görünümüne çevirir (9-dilimli gövde + parlama çocuğu).
        /// Bevel kalınlığı, tahtadaki blokla aynı görünecek şekilde yüksekliğe göre ayarlanır.
        /// Dönüş: doku pikseli → canvas birimi ölçeği.
        /// </summary>
        public static float ApplyBlockSkin(UnityEngine.UI.Image img, float height)
        {
            // 1 doku pikseli ≈ 1.3 canvas birimi (tahtadaki bir hücreyle aynı bevel); küçük butonlarda sığacak kadar küçült
            const int bordersV = SpriteLibrary.UIBlockBorder * 2 + SpriteLibrary.UIBlockShadowPad;
            float scale = Mathf.Min(1.3f, height * 0.98f / bordersV);
            img.sprite = SpriteLibrary.UIBlock(false);
            img.type = UnityEngine.UI.Image.Type.Sliced;
            img.pixelsPerUnitMultiplier = 1f / scale;
            img.preserveAspect = false;

            var old = img.transform.Find("Shine");
            if (old != null) Object.Destroy(old.gameObject);
            var shine = Image("Shine", img.transform, null, Color.white, true);
            shine.sprite = SpriteLibrary.UIBlock(true);
            shine.pixelsPerUnitMultiplier = 1f / scale;
            Stretch(shine.rectTransform);
            shine.transform.SetAsFirstSibling(); // yazı ve ikonların altında
            return scale;
        }

        /// <summary>Butonu blok yerine cam görünümüne çevirir (ikincil düğmeler ve boş çubuk yuvası için).</summary>
        public static void ApplyGlassSkin(UnityEngine.UI.Image img, float height = 0f)
        {
            // Blok butonla aynı ölçek → köşe, kenar ve gölge payı birebir aynı oturur
            if (height <= 0f) height = img.rectTransform.rect.height > 0f ? img.rectTransform.rect.height : img.rectTransform.sizeDelta.y;
            const int bordersV = SpriteLibrary.UIBlockBorder * 2 + SpriteLibrary.UIBlockShadowPad;
            float scale = height > 0f ? Mathf.Min(1.3f, height * 0.98f / bordersV) : 1f;

            img.sprite = SpriteLibrary.UIGlassButton(false);
            img.type = UnityEngine.UI.Image.Type.Sliced;
            img.pixelsPerUnitMultiplier = 1f / scale;
            var shine = img.transform.Find("Shine");
            if (shine != null) Object.Destroy(shine.gameObject);
            var rim = Image("Rim", img.transform, null, Color.white, true);
            rim.sprite = SpriteLibrary.UIGlassButton(true);
            rim.pixelsPerUnitMultiplier = 1f / scale;
            Stretch(rim.rectTransform);
            rim.transform.SetAsFirstSibling();
            // Yazı yerinde kalır: blok butondaki gibi gölge payı kadar yukarıda, görünen gövdenin ortasında
        }

        /// <summary>Board gibi koyu cam panel: yarı saydam gövde + sol üstte ince ışık kenarı.</summary>
        public static UnityEngine.UI.Image Panel(string name, Transform parent, Color color, bool raycast = false)
        {
            var img = Image(name, parent, null, color, true, raycast);
            img.sprite = SpriteLibrary.UIGlass(false);
            img.pixelsPerUnitMultiplier = 1f;
            var rim = Image("Rim", img.transform, null, Color.white, true);
            rim.sprite = SpriteLibrary.UIGlass(true);
            rim.pixelsPerUnitMultiplier = 1f;
            Stretch(rim.rectTransform);
            rim.transform.SetAsFirstSibling();
            return img;
        }

        /// <summary>
        /// Koyu cam "chip" buton: üst bar rozetleri, geri butonu gibi ikincil eylemler için.
        /// Renkli blok butonlar ana eylemlere (oyna, devam et) ayrılır; ikincil eylemler hep bu görünümde.
        /// </summary>
        public static UnityEngine.UI.Button Chip(string name, Transform parent, Vector2 size, System.Action onClick)
        {
            var img = Image(name, parent, null, new Color(0f, 0f, 0f, 0.28f), true, true);
            img.sprite = SpriteLibrary.UIGlass(false);
            img.type = UnityEngine.UI.Image.Type.Sliced;
            img.preserveAspect = false;
            img.pixelsPerUnitMultiplier = 0.8f;
            var rt = img.rectTransform;
            rt.sizeDelta = size;
            var rim = Image("Rim", img.transform, null, Color.white, true);
            rim.sprite = SpriteLibrary.UIGlass(true);
            rim.pixelsPerUnitMultiplier = 0.8f;
            Stretch(rim.rectTransform);
            rim.raycastTarget = false;
            var btn = img.gameObject.AddComponent<UnityEngine.UI.Button>();
            btn.targetGraphic = img;
            var colors = btn.colors;
            colors.highlightedColor = Color.white;
            colors.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            btn.colors = colors;
            btn.onClick.AddListener(() =>
            {
                var sm = SoundManager.Instance;
                if (sm != null) sm.PlayFrom(GameSettings.Instance.sfxButton, 1f, 0.8f);
                Haptics.Light();
                onClick?.Invoke();
            });
            img.gameObject.AddComponent<PressScale>();
            return btn;
        }

        /// <summary>Uçları tam yuvarlak çubuk (ilerleme çubuğu izi / dolgusu). height: çubuğun yüksekliği.</summary>
        public static UnityEngine.UI.Image Pill(string name, Transform parent, Color color, float height)
        {
            var img = Image(name, parent, null, color, true);
            img.sprite = SpriteLibrary.UIGlass(false);
            img.type = UnityEngine.UI.Image.Type.Sliced;
            img.preserveAspect = false;
            img.pixelsPerUnitMultiplier = SpriteLibrary.UIGlassBorder / Mathf.Max(1f, height * 0.5f);
            return img;
        }

        /// <summary>Oyundaki tek bir blok (renk indeksiyle), ikon ve dekor için.</summary>
        public static UnityEngine.UI.Image BlockIcon(string name, Transform parent, int colorIndex, float size)
        {
            var col = GameSettings.Instance.GetColor(colorIndex);
            var img = Image(name, parent, null, col);
            img.sprite = SpriteLibrary.UnifiedTile(0, false);
            img.preserveAspect = true;
            // Gövde sprite'ı kenar payı içerir (hücreden biraz büyük); boyutu ona göre ayarla
            img.rectTransform.sizeDelta = Vector2.one * size;
            var sh = Image("Shine", img.transform, null, Color.white);
            sh.sprite = SpriteLibrary.UnifiedTile(0, true);
            sh.preserveAspect = true;
            float inner = size / SpriteLibrary.TileBodyWorldSize;
            Place(sh.rectTransform, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.one * inner);
            return img;
        }

        /// <summary>Butona basınca arka plandaki yıldız tozunda küçük, buton renginde bir dalga.</summary>
        static void PulseStardust(RectTransform rt, Color color)
        {
            var cam = Camera.main;
            if (cam == null || rt == null || color.a < 0.5f) return; // saydam/cam butonlarda dalga yok
            // Overlay canvas'ta transform.position ekran pikselidir
            Vector3 sp = rt.position;
            sp.z = Mathf.Abs(cam.transform.position.z);
            StardustField.Emit(cam.ScreenToWorldPoint(sp), color, 1, 3);
        }

        public static UnityEngine.UI.Button IconButton(string name, Transform parent, string icon, Color color, Vector2 size, System.Action onClick)
        {
            var btn = Button(name, parent, null, color, size, 0, onClick);
            var ic = Image("Icon", btn.transform, icon, Color.white);
            // Simge bloğun görünen ortasında: alttaki gölge payı kadar yukarıda
            float pad = SpriteLibrary.UIBlockShadowPad * Mathf.Min(1.3f, size.y * 0.98f / (SpriteLibrary.UIBlockBorder * 2 + SpriteLibrary.UIBlockShadowPad));
            float m = size.y * 0.25f;
            Stretch(ic.rectTransform, size.x * 0.25f, size.x * 0.25f, m, m + pad);
            var sh = ic.gameObject.AddComponent<UnityEngine.UI.Shadow>();
            sh.effectColor = new Color(color.r * 0.35f, color.g * 0.35f, color.b * 0.35f, 0.9f);
            sh.effectDistance = new Vector2(0, -3f);
            return btn;
        }

        public static UnityEngine.UI.Text SetLabel(UnityEngine.UI.Button b, string text)
        {
            var t = b.GetComponentInChildren<UnityEngine.UI.Text>();
            if (t != null) t.text = Loc.T(text);
            return t;
        }
    }

    /// <summary>
    /// PERFORMANS: sürekli hareket eden UI süsleri (nabız, süzülme, parıltı) kendi alt Canvas'ına alınır.
    /// Unity UI'da bir Canvas içindeki tek bir elemanın rengi/ölçeği/konumu değişince o Canvas'ın TAMAMI yeniden
    /// batch'lenir. Süs kendi Canvas'ındayken her karede yalnızca o küçük parça yeniden kurulur, ana UI dokunulmaz.
    /// Sıralama değişmez (overrideSorting kapalı: hiyerarşi sırası korunur). Altında tıklanabilir bir şey varsa
    /// tıklamalar çalışmaya devam etsin diye GraphicRaycaster da eklenir.
    /// </summary>
    public static class UICanvasIsolation
    {
        public static void Isolate(GameObject go)
        {
            if (go == null || go.GetComponent<Canvas>() != null) return;
            if (go.transform.parent == null || go.transform.parent.GetComponentInParent<Canvas>() == null) return;
            go.AddComponent<Canvas>();
            foreach (var g in go.GetComponentsInChildren<UnityEngine.UI.Graphic>(true))
            {
                if (!g.raycastTarget) continue;
                go.AddComponent<UnityEngine.UI.GraphicRaycaster>();
                break;
            }
        }
    }

    /// <summary>
    /// YERELLEŞTİRME: İngilizce dışındaki dillerde metin daha uzun olabilir (Almanca, Rusça...). Tek satırlık
    /// (taşmalı) bir yazı kutusunun genişliğini aşarsa yazı boyutu kutuya sığacak kadar küçülür (en fazla yarıya).
    /// Yalnızca metin ya da kutu değişince ölçer. İngilizcede hiçbir şeye dokunmaz (tasarım birebir korunur).
    /// </summary>
    [DisallowMultipleComponent]
    public class TextShrink : MonoBehaviour
    {
        UnityEngine.UI.Text _t;
        RectTransform _rt;
        string _lastText;
        float _lastW = -1f;
        int _baseSize, _applied = -1;

        void Awake()
        {
            _t = GetComponent<UnityEngine.UI.Text>();
            _rt = (RectTransform)transform;
        }

        void LateUpdate()
        {
            if (_t == null) return;
            // Boyutu başka bir kod değiştirdiyse yeni taban o
            if (_t.fontSize != _applied) { _baseSize = _t.fontSize; _applied = -1; }
            if (Loc.IsEnglish || _t.resizeTextForBestFit || _t.horizontalOverflow != HorizontalWrapMode.Overflow)
            {
                if (_applied >= 0) { _t.fontSize = _baseSize; _applied = -1; _lastText = null; }
                return;
            }
            float w = _rt.rect.width;
            if (ReferenceEquals(_t.text, _lastText) && Mathf.Approximately(w, _lastW)) return;
            _lastText = _t.text;
            _lastW = w;

            _t.fontSize = _baseSize;
            int size = _baseSize;
            if (w > 1f && !string.IsNullOrEmpty(_t.text) && _t.text.IndexOf('\n') < 0)
            {
                float pw = _t.preferredWidth;
                if (pw > w) size = Mathf.Max(Mathf.RoundToInt(_baseSize * 0.5f), Mathf.FloorToInt(_baseSize * w / pw));
            }
            _t.fontSize = size;
            _applied = size;
        }
    }

    /// <summary>Butona basınca küçülme efekti.</summary>
    public class PressScale : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        public float pressed = 0.93f;
        float _target = 1f;

        public void OnPointerDown(PointerEventData e) => _target = pressed;
        public void OnPointerUp(PointerEventData e) => _target = 1f;
        public void OnPointerExit(PointerEventData e) => _target = 1f;

        void OnDisable()
        {
            _target = 1f;
            transform.localScale = Vector3.one;
        }

        void Update()
        {
            // PERFORMANS: hedefe ulaşınca dur. Önceden her buton her karede scale yazıyordu; UI'da transform değişikliği
            // tüm Canvas'ın yeniden batch'lenmesine yol açar (ekranda 20 buton = her karede tam UI yeniden kurulumu).
            float cur = transform.localScale.x;
            if (Mathf.Abs(cur - _target) < 0.0005f)
            {
                if (cur != _target) transform.localScale = new Vector3(_target, _target, 1);
                return;
            }
            float s = Mathf.Lerp(cur, _target, 1f - Mathf.Exp(-25f * Time.unscaledDeltaTime));
            transform.localScale = new Vector3(s, s, 1);
        }
    }
}