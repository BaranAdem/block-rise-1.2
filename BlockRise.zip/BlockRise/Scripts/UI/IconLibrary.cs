using UnityEngine;

namespace BlockRise
{
    /// <summary>
    /// Kodla çizilen UI simgeleri (PNG gerekmez). Beyaz çizilir, Image.color ile boyanabilir.
    /// Alev simgesi PNG ile değiştirilebilir: GameSettings > Icons ya da Resources/BlockRiseSprites/icon_flame.png.
    /// </summary>
    public static class IconLibrary
    {
        const int Size = 256;
        static Sprite _speakerOn, _speakerOff, _crown, _vibeOn, _vibeOff, _medal;

        /// <summary>Hoparlör simgesi. on = ses dalgaları, off = çarpı işareti.</summary>
        public static Sprite Speaker(bool on)
        {
            if (on) return _speakerOn != null ? _speakerOn : (_speakerOn = BuildSpeaker(true));
            return _speakerOff != null ? _speakerOff : (_speakerOff = BuildSpeaker(false));
        }

        // Hoparlör gövdesi: kutu + koni (koordinatlar -1..1)
        static readonly Vector2[] Body =
        {
            new Vector2(-0.62f, -0.20f), new Vector2(-0.32f, -0.20f), new Vector2(0.00f, -0.50f),
            new Vector2(0.00f, 0.50f), new Vector2(-0.32f, 0.20f), new Vector2(-0.62f, 0.20f),
        };

        static Sprite BuildSpeaker(bool on)
        {
            var px = new Color[Size * Size];
            for (int j = 0; j < Size; j++)
                for (int i = 0; i < Size; i++)
                {
                    var p = new Vector2((i + 0.5f) / Size * 2f - 1f, (j + 0.5f) / Size * 2f - 1f);
                    float d = Polygon(p, Body) - 0.05f; // köşeleri hafif yuvarla

                    if (on)
                    {
                        d = Mathf.Min(d, Arc(p, new Vector2(0.02f, 0f), 0.30f, 0.72f, 0.065f));
                        d = Mathf.Min(d, Arc(p, new Vector2(0.02f, 0f), 0.56f, 0.72f, 0.065f));
                    }
                    else
                    {
                        var c = new Vector2(0.48f, 0f);
                        const float s = 0.19f;
                        d = Mathf.Min(d, Segment(p, c + new Vector2(-s, -s), c + new Vector2(s, s)) - 0.065f);
                        d = Mathf.Min(d, Segment(p, c + new Vector2(-s, s), c + new Vector2(s, -s)) - 0.065f);
                    }

                    float a = Mathf.Clamp01(0.5f - d * Size * 0.5f); // 1 piksellik yumuşak kenar
                    px[j * Size + i] = new Color(1f, 1f, 1f, a);
                }

            var tex = new Texture2D(Size, Size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply();
            var sp = Sprite.Create(tex, new Rect(0, 0, Size, Size), new Vector2(0.5f, 0.5f), 100f);
            sp.name = on ? "icon_speaker_on" : "icon_speaker_off";
            return sp;
        }

        /// <summary>
        /// Altın taç (en iyi skor simgesi). Kendi renkleriyle çizilir: Image.color beyaz bırakılmalı.
        /// Üstten alta açık→koyu altın geçiş, sol üstte parlama, uçlarda yuvarlak toplar, altta ayrı bir bant.
        /// </summary>
        public static Sprite Crown()
        {
            return _crown != null ? _crown : (_crown = BuildCrown());
        }

        static readonly Vector2[] CrownBody =
        {
            new Vector2(-0.70f, -0.40f), new Vector2(-0.84f, 0.30f), new Vector2(-0.40f, 0.00f),
            new Vector2(0.00f, 0.46f), new Vector2(0.40f, 0.00f), new Vector2(0.84f, 0.30f),
            new Vector2(0.70f, -0.40f),
        };

        static Sprite BuildCrown()
        {
            var light = new Color(1.00f, 0.90f, 0.38f);
            var dark = new Color(1.00f, 0.62f, 0.10f);
            var band = new Color(0.98f, 0.55f, 0.08f);
            var px = new Color[Size * Size];
            for (int j = 0; j < Size; j++)
                for (int i = 0; i < Size; i++)
                {
                    var p = new Vector2((i + 0.5f) / Size * 2f - 1f, (j + 0.5f) / Size * 2f - 1f);

                    // Gövde + uçlardaki toplar
                    float body = Polygon(p, CrownBody) - 0.035f;
                    body = Mathf.Min(body, (p - new Vector2(-0.86f, 0.40f)).magnitude - 0.13f);
                    body = Mathf.Min(body, (p - new Vector2(0.00f, 0.58f)).magnitude - 0.14f);
                    body = Mathf.Min(body, (p - new Vector2(0.86f, 0.40f)).magnitude - 0.13f);
                    // Alt bant (gövdeden ince bir boşlukla ayrı)
                    float qx = Mathf.Abs(p.x) - 0.66f, qy = Mathf.Abs(p.y + 0.56f) - 0.07f;
                    float bandD = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude + Mathf.Min(Mathf.Max(qx, qy), 0f) - 0.06f;

                    float aBody = Mathf.Clamp01(0.5f - body * Size * 0.5f);
                    float aBand = Mathf.Clamp01(0.5f - bandD * Size * 0.5f);
                    float a = Mathf.Max(aBody, aBand);
                    if (a <= 0f) { px[j * Size + i] = Color.clear; continue; }

                    Color c;
                    if (aBand > aBody) c = band;
                    else
                    {
                        float k = Mathf.Clamp01((p.y + 0.45f) / 1.15f); // alt 0 → üst 1
                        c = Color.Lerp(dark, light, k);
                        // Sol üstte yumuşak parlama
                        float g = Mathf.Exp(-((p.x + 0.35f) * (p.x + 0.35f) + (p.y - 0.12f) * (p.y - 0.12f)) / 0.06f);
                        c = Color.Lerp(c, Color.white, g * 0.35f);
                    }
                    c.a = a;
                    px[j * Size + i] = c;
                }

            var tex = new Texture2D(Size, Size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply();
            var sp = Sprite.Create(tex, new Rect(0, 0, Size, Size), new Vector2(0.5f, 0.5f), 100f);
            sp.name = "icon_crown";
            return sp;
        }

        /// <summary>Titreşim simgesi: telefon + iki yanında titreşim çizgileri (on) veya üstünde çapraz çizgi (off).</summary>
        public static Sprite Vibration(bool on)
        {
            if (on) return _vibeOn != null ? _vibeOn : (_vibeOn = BuildVibration(true));
            return _vibeOff != null ? _vibeOff : (_vibeOff = BuildVibration(false));
        }

        static Sprite BuildVibration(bool on)
        {
            const float w = 0.065f; // çizgi kalınlığı (hoparlör simgesiyle aynı)
            var px = new Color[Size * Size];
            for (int j = 0; j < Size; j++)
                for (int i = 0; i < Size; i++)
                {
                    var p = new Vector2((i + 0.5f) / Size * 2f - 1f, (j + 0.5f) / Size * 2f - 1f);

                    // Telefon: yuvarlak köşeli dikdörtgen çerçeve + alttaki küçük nokta
                    float qx = Mathf.Abs(p.x) - 0.20f, qy = Mathf.Abs(p.y) - 0.52f;
                    float box = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude + Mathf.Min(Mathf.Max(qx, qy), 0f) - 0.10f;
                    float d = Mathf.Abs(box) - w;
                    d = Mathf.Min(d, (p - new Vector2(0f, -0.44f)).magnitude - 0.055f);

                    if (on)
                    {
                        // İki yanda içten dışa kısalan titreşim çizgileri
                        for (int s = -1; s <= 1; s += 2)
                        {
                            d = Mathf.Min(d, Segment(p, new Vector2(s * 0.50f, -0.28f), new Vector2(s * 0.50f, 0.28f)) - w);
                            d = Mathf.Min(d, Segment(p, new Vector2(s * 0.72f, -0.15f), new Vector2(s * 0.72f, 0.15f)) - w);
                        }
                    }
                    else
                    {
                        // Çapraz çizgi; çevresinde ince boşluk bırakarak telefonu keser
                        float slash = Segment(p, new Vector2(-0.62f, -0.70f), new Vector2(0.62f, 0.70f));
                        d = Mathf.Max(d, -(slash - w * 2.6f));
                        d = Mathf.Min(d, slash - w);
                    }

                    float a = Mathf.Clamp01(0.5f - d * Size * 0.5f);
                    px[j * Size + i] = new Color(1f, 1f, 1f, a);
                }

            var tex = new Texture2D(Size, Size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply();
            var sp = Sprite.Create(tex, new Rect(0, 0, Size, Size), new Vector2(0.5f, 0.5f), 100f);
            sp.name = on ? "icon_vibration_on" : "icon_vibration_off";
            return sp;
        }

        /// <summary>
        /// Günlük seri alevi: GameSettings > Icons > Streak Flame Icon, yoksa Resources/BlockRiseSprites/icon_flame.png.
        /// Kendi renkleriyle gösterilir (Image.color beyaz bırakılmalı).
        /// </summary>
        public static Sprite Flame()
        {
            var custom = CustomFlame();
            return custom != null ? custom : SpriteLibrary.Get(FlameFileName);
        }

        static Sprite _flameFile;
        static bool _flameFileChecked;

        /// <summary>Kullanıcının koyduğu alev görseli (yoksa null).</summary>
        static Sprite CustomFlame()
        {
            var gs = GameSettings.Instance;
            if (gs.streakFlameIcon != null) return gs.streakFlameIcon;
            if (!_flameFileChecked)
            {
                _flameFileChecked = true;
                string path = SpriteLibrary.Folder + FlameFileName;
                _flameFile = Resources.Load<Sprite>(path);
                if (_flameFile == null)
                {
                    var tex = Resources.Load<Texture2D>(path);
                    if (tex != null)
                    {
                        _flameFile = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), tex.width);
                        _flameFile.name = FlameFileName;
                    }
                }
            }
            return _flameFile;
        }

        /// <summary>Resources/BlockRiseSprites içinde aranan alev PNG'sinin adı (uzantısız).</summary>
        public const string FlameFileName = "icon_flame";

        static Sprite _chevronLeft;

        /// <summary>Geri oku (sola bakan, yuvarlak uçlu). Beyaz; renk Image.color ile.</summary>
        public static Sprite ChevronLeft()
        {
            if (_chevronLeft != null) return _chevronLeft;
            return _chevronLeft = Build("icon_chevron_left", p =>
            {
                float d = Mathf.Min(SegmentDist(p, new Vector2(0.22f, 0.58f), new Vector2(-0.30f, 0f)),
                                    SegmentDist(p, new Vector2(-0.30f, 0f), new Vector2(0.22f, -0.58f))) - 0.12f;
                return new Color(1f, 1f, 1f, Mathf.Clamp01(0.5f - d * Size * 0.5f));
            });
        }

        /// <summary>
        /// Madalya: kurdeleli yuvarlak madalya, ortasında yıldız. Beyaz/gri tonlarda çizilir;
        /// Image.color ile bronz/gümüş/altın renklendirilir (kurdele ve kenar biraz koyu kalır).
        /// </summary>
        public static Sprite Medal()
        {
            if (_medal != null) return _medal;
            return _medal = Build("icon_medal", p =>
            {
                // Kurdele: iki eğik şerit
                float r1 = SegmentDist(p, new Vector2(-0.30f, 0.95f), new Vector2(-0.05f, 0.25f)) - 0.17f;
                float r2 = SegmentDist(p, new Vector2(0.30f, 0.95f), new Vector2(0.05f, 0.25f)) - 0.17f;
                float ribbon = Mathf.Max(Mathf.Min(r1, r2), p.y - 0.95f);
                // Madalya diski ve kenarı
                var c0 = new Vector2(0f, -0.25f);
                float disc = (p - c0).magnitude - 0.62f;
                float innerDisc = (p - c0).magnitude - 0.48f;
                float star = StarDist(p - c0, 0.30f, 0.13f);

                float aR = Mathf.Clamp01(0.5f - ribbon * Size * 0.5f);
                float aD = Mathf.Clamp01(0.5f - disc * Size * 0.5f);
                float aI = Mathf.Clamp01(0.5f - innerDisc * Size * 0.5f);
                float aS = Mathf.Clamp01(0.5f - star * Size * 0.5f);
                float a = Mathf.Max(aR * (1f - aD), aD);
                if (a <= 0f) return Color.clear;

                float v;
                if (aD > 0f)
                {
                    v = Mathf.Lerp(0.78f, 1f, aI);               // kenar halkası biraz koyu
                    float hl = Mathf.Clamp01(1f - ((p - c0) - new Vector2(-0.2f, 0.2f)).magnitude / 0.5f);
                    v = Mathf.Lerp(v, 1f, hl * 0.3f);
                    v = Mathf.Lerp(v, 0.72f, aS);                // yıldız kabartması
                }
                else v = 0.62f;                                  // kurdele
                return new Color(v, v, v, a);
            });
        }

        static Sprite _sparkle;

        /// <summary>Dört kollu parıltı yıldızı (merkezi yumuşak ışıklı). Beyaz; renk Image.color ile.</summary>
        public static Sprite Sparkle()
        {
            if (_sparkle != null) return _sparkle;
            return _sparkle = Build("icon_sparkle", p =>
            {
                float ax = Mathf.Abs(p.x), ay = Mathf.Abs(p.y);
                float star = Mathf.Pow(Mathf.Sqrt(ax) + Mathf.Sqrt(ay), 2f);   // içbükey 4 kollu yıldız
                float aStar = Mathf.Pow(Mathf.Clamp01(1f - star / 0.95f), 1.5f);
                float r2 = p.sqrMagnitude;
                float aGlow = Mathf.Exp(-r2 / (2f * 0.18f * 0.18f)) * 0.7f;
                float edge = Mathf.Clamp01((1f - Mathf.Sqrt(r2)) * 3f);
                return new Color(1f, 1f, 1f, Mathf.Clamp01(aStar + aGlow) * edge);
            });
        }

        static float SegmentDist(Vector2 p, Vector2 a, Vector2 b) => Segment(p, a, b);

        /// <summary>5 köşeli yıldıza yaklaşık işaretli uzaklık.</summary>
        static float StarDist(Vector2 p, float ro, float ri)
        {
            float ang = Mathf.Atan2(p.x, p.y);
            float seg = Mathf.PI / 5f;
            float a = Mathf.Repeat(ang, 2f * seg) - seg;     // en yakın kol eksenine açı
            float t = Mathf.Abs(a) / seg;                    // 0 = kol ucu, 1 = iç köşe
            float edge = Mathf.Lerp(ro, ri, t);
            return p.magnitude - edge;
        }

        static Sprite Build(string name, System.Func<Vector2, Color> shade)
        {
            var px = new Color[Size * Size];
            for (int j = 0; j < Size; j++)
                for (int i = 0; i < Size; i++)
                    px[j * Size + i] = shade(new Vector2((i + 0.5f) / Size * 2f - 1f, (j + 0.5f) / Size * 2f - 1f));
            var tex = new Texture2D(Size, Size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            tex.SetPixels(px);
            tex.Apply();
            var sp = Sprite.Create(tex, new Rect(0, 0, Size, Size), new Vector2(0.5f, 0.5f), 100f);
            sp.name = name;
            return sp;
        }

        /// <summary>Çizgi parçasına uzaklık.</summary>
        static float Segment(Vector2 p, Vector2 a, Vector2 b)
        {
            Vector2 pa = p - a, ba = b - a;
            float h = Mathf.Clamp01(Vector2.Dot(pa, ba) / Vector2.Dot(ba, ba));
            return (pa - ba * h).magnitude;
        }

        /// <summary>Çokgene işaretli uzaklık (içeride negatif).</summary>
        static float Polygon(Vector2 p, Vector2[] v)
        {
            float d = float.MaxValue;
            float sign = 1f;
            for (int i = 0, n = v.Length; i < n; i++)
            {
                Vector2 a = v[i], b = v[(i + 1) % n];
                d = Mathf.Min(d, Segment(p, a, b));
                bool c1 = p.y >= a.y, c2 = p.y < b.y, c3 = (b.x - a.x) * (p.y - a.y) > (b.y - a.y) * (p.x - a.x);
                if ((c1 && c2 && c3) || (!c1 && !c2 && !c3)) sign = -sign;
            }
            return sign * d;
        }

        /// <summary>Sağa bakan, uçları yuvarlak yay (ses dalgası).</summary>
        static float Arc(Vector2 p, Vector2 c, float r, float halfAngle, float width)
        {
            Vector2 d = p - c;
            float ang = Mathf.Atan2(d.y, d.x);
            if (Mathf.Abs(ang) <= halfAngle) return Mathf.Abs(d.magnitude - r) - width;
            var end = c + new Vector2(Mathf.Cos(halfAngle), Mathf.Sin(halfAngle) * (d.y >= 0f ? 1f : -1f)) * r;
            return (p - end).magnitude - width;
        }
    }
}
