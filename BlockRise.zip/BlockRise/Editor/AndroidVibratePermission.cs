#if UNITY_ANDROID
using System.IO;
using System.Xml;
using UnityEditor.Android;
using UnityEngine;

namespace BlockRise.EditorTools
{
    /// <summary>
    /// Android derlemesinde titreşim iznini (android.permission.VIBRATE) manifeste garanti olarak ekler.
    /// Unity bu izni yalnızca kodda Handheld.Vibrate kullanımı görürse otomatik ekliyor; kod küçültme
    /// (stripping) bu kullanımı silebildiği için izni burada doğrudan yazıyoruz.
    /// Gradle projesi her oluşturulduğunda kendiliğinden çalışır, elle bir şey yapmaya gerek yok.
    /// </summary>
    public class AndroidVibratePermission : IPostGenerateGradleAndroidProject
    {
        const string AndroidNs = "http://schemas.android.com/apk/res/android";
        const string Permission = "android.permission.VIBRATE";

        public int callbackOrder => 100;

        public void OnPostGenerateGradleAndroidProject(string path)
        {
            // path = unityLibrary modülü
            string manifest = Path.Combine(path, "src", "main", "AndroidManifest.xml");
            if (!File.Exists(manifest))
            {
                Debug.LogWarning("[BlockRise] AndroidManifest.xml bulunamadı: " + manifest);
                return;
            }

            var doc = new XmlDocument();
            doc.Load(manifest);
            var root = doc.DocumentElement;
            if (root == null) return;

            foreach (XmlNode n in root.SelectNodes("uses-permission"))
            {
                var attr = n.Attributes?["name", AndroidNs];
                if (attr != null && attr.Value == Permission) return; // zaten var
            }

            var el = doc.CreateElement("uses-permission");
            el.SetAttribute("name", AndroidNs, Permission);
            root.PrependChild(el);
            doc.Save(manifest);
            Debug.Log("[BlockRise] Android manifestine VIBRATE izni eklendi.");
        }
    }
}
#endif
