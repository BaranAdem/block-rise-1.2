using UnityEditor;
using UnityEngine;

namespace BlockRise
{
    /// <summary>[Help("...")] yazılan alanların üstünde okunabilir, sarmalanan açıklama kutusu çizer.</summary>
    [CustomPropertyDrawer(typeof(HelpAttribute))]
    public class HelpDrawer : DecoratorDrawer
    {
        static GUIStyle _style;

        static GUIStyle Style
        {
            get
            {
                if (_style != null) return _style;
                _style = new GUIStyle(EditorStyles.helpBox)
                {
                    fontSize = 11,
                    wordWrap = true,
                    richText = true,
                    padding = new RectOffset(8, 8, 6, 6)
                };
                return _style;
            }
        }

        string Text => ((HelpAttribute)attribute).text;

        public override float GetHeight()
        {
            float w = EditorGUIUtility.currentViewWidth - 40f;
            return Style.CalcHeight(new GUIContent(Text), w) + 6f;
        }

        public override void OnGUI(Rect position)
        {
            position.height -= 4f;
            position.y += 2f;
            EditorGUI.LabelField(position, Text, Style);
        }
    }
}
