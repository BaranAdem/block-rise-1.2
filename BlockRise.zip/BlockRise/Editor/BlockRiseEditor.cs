using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace BlockRise.EditorTools
{
    /// <summary>BlockRiseSprites klasörüne konan PNG'leri otomatik olarak temiz sprite ayarıyla içe aktarır.</summary>
    public class BlockRiseTextureImporter : AssetPostprocessor
    {
        void OnPreprocessTexture()
        {
            if (!assetPath.Replace('\\', '/').Contains("/Resources/BlockRiseSprites/")) return;
            var ti = (TextureImporter)assetImporter;
            ti.textureType = TextureImporterType.Sprite;
            ti.spriteImportMode = SpriteImportMode.Single;
            ti.mipmapEnabled = false;
            ti.alphaIsTransparency = true;
            ti.filterMode = FilterMode.Bilinear;
            ti.wrapMode = TextureWrapMode.Clamp;
            ti.textureCompression = TextureImporterCompression.Uncompressed;
            ti.maxTextureSize = 512;
        }
    }

    public static class BlockRiseMenu
    {
        const string ScenePath = "Assets/BlockRise/Scenes/BlockRise.unity";

        [MenuItem("Block Rise/1) Setup Scene + Mobile Settings", priority = 1)]
        public static void SetupScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 8;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = GameSettings.Instance.backgroundColor;
            camGo.transform.position = new Vector3(0, 0, -10);

            new GameObject("BlockRiseGame").AddComponent<GameRoot>();

            Directory.CreateDirectory(Path.GetDirectoryName(ScenePath));
            EditorSceneManager.SaveScene(scene, ScenePath);

            // Build Settings'e ilk sahne olarak ekle
            var list = new List<EditorBuildSettingsScene> { new EditorBuildSettingsScene(ScenePath, true) };
            foreach (var s in EditorBuildSettings.scenes)
                if (s.path != ScenePath) list.Add(s);
            EditorBuildSettings.scenes = list.ToArray();

            ApplyMobileSettings();
            ReimportSprites();

            EditorUtility.DisplayDialog("Block Rise",
                "Sahne hazır: " + ScenePath + "\n\nPlay'e bas. Game penceresinde dikey bir telefon çözünürlüğü seç (ör. 1080x1920).",
                "Tamam");
        }

        [MenuItem("Block Rise/Apply Mobile Player Settings", priority = 20)]
        public static void ApplyMobileSettings()
        {
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = true;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.productName = "Block Rise";
            PlayerSettings.statusBarHidden = true;
            PlayerSettings.Android.startInFullscreen = true;
            PlayerSettings.Android.renderOutsideSafeArea = true;
            Debug.Log("[BlockRise] Mobil ayarlar uygulandı (Portrait, fullscreen).");
        }

        [MenuItem("Block Rise/Reimport Sprites", priority = 21)]
        public static void ReimportSprites()
        {
            var guids = AssetDatabase.FindAssets("t:Texture2D", new[] { "Assets/BlockRise/Resources/BlockRiseSprites" });
            foreach (var g in guids)
                AssetDatabase.ImportAsset(AssetDatabase.GUIDToAssetPath(g), ImportAssetOptions.ForceUpdate);
            AssetDatabase.Refresh();
        }

        [MenuItem("Block Rise/Create Settings Asset", priority = 40)]
        public static void CreateSettings()
        {
            const string path = "Assets/BlockRise/Resources/BlockRiseSettings.asset";
            var existing = AssetDatabase.LoadAssetAtPath<GameSettings>(path);
            if (existing == null)
            {
                existing = ScriptableObject.CreateInstance<GameSettings>();
                AssetDatabase.CreateAsset(existing, path);
                AssetDatabase.SaveAssets();
            }
            Selection.activeObject = existing;
            EditorGUIUtility.PingObject(existing);
        }

        [MenuItem("Block Rise/Open Levels JSON", priority = 41)]
        public static void OpenLevels()
        {
            var ta = AssetDatabase.LoadAssetAtPath<TextAsset>("Assets/BlockRise/Resources/BlockRiseLevels.json");
            if (ta != null) AssetDatabase.OpenAsset(ta);
        }

        [MenuItem("Block Rise/Progress: Unlock All Levels", priority = 60)]
        public static void UnlockAll()
        {
            LevelDatabase.Load();
            SaveSystem.UnlockedLevel = Mathf.Max(0, LevelDatabase.Count - 1);
            Debug.Log("[BlockRise] Tüm leveller açıldı.");
        }

        [MenuItem("Block Rise/Progress: Reset All Player Data", priority = 61)]
        public static void ResetProgress()
        {
            if (Application.isPlaying)
            {
                EditorUtility.DisplayDialog("Block Rise", "Önce Play modunu durdur, sonra tekrar dene.", "Tamam");
                return;
            }
            if (EditorUtility.DisplayDialog("Block Rise",
                    "Tüm oyuncu verisi silinsin mi?\n\nEn iyi skor, yıldızlar, açık bölümler, madalyalar, seri, enerji, " +
                    "reklam kaldırma satın alımı, ayarlar, tutorial ve yarım kalan Classic oyunu.",
                    "Hepsini Sil", "Vazgeç"))
            {
                SaveSystem.ResetAll(keepPurchases: false); // geliştirici: tam temiz kurulum
                Debug.Log("[BlockRise] Tüm oyuncu verisi silindi.");
            }
        }
    }
}
